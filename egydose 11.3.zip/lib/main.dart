import 'dart:io';
import 'dart:math';
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:app_version_update/app_version_update.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:easy_dynamic_theme/easy_dynamic_theme.dart';
import 'package:egydosecalcfree/dose.dart';
import 'package:egydosecalcfree/payments.dart';
import 'package:egydosecalcfree/web.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:rate_my_app/rate_my_app.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';
import 'package:url_launcher/url_launcher.dart';
import 'calculators.dart';
import 'firebase_options.dart';
import 'help.dart';
import 'package:flutter/services.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';

var lightThemeData = ThemeData(
  brightness: Brightness.light,
  // useMaterial3: false,
  // primarySwatch: Colors.green,
  colorScheme: ColorScheme.fromSwatch(
    primarySwatch: Colors.green,
  ).copyWith(
    secondary: Colors.white,
  ),
  appBarTheme: AppBarTheme(
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor: Colors.green[700],
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.light,
    ),
    backgroundColor: Colors.green,
    foregroundColor: Colors.white,
  ),
  radioTheme: RadioThemeData(
    fillColor: WidgetStateProperty.resolveWith<Color>(
          (Set<WidgetState> states) {
        if (states.contains(WidgetState.selected)) {
          return Colors.green;
        }
        return Colors.blueGrey;
      },
    ),
  ),
  checkboxTheme: CheckboxThemeData(
    checkColor: WidgetStateProperty.all(Colors.white),
    fillColor: WidgetStateProperty.resolveWith<Color>(
          (Set<WidgetState> states) {
        if (states.contains(WidgetState.selected)) {
          return Colors.green;
        }
        return Colors.white;
      },
    ),
    side: const BorderSide(color: Colors.green, width: 2, style: BorderStyle.solid),
  ),
  dialogTheme: DialogTheme(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
    ),
    actionsPadding: const EdgeInsets.only(top: 0, bottom: 8),
    backgroundColor: Colors.grey[100],
    surfaceTintColor: Colors.grey[100],
  ),
  textButtonTheme: TextButtonThemeData( // Customize text button theme
    style: TextButton.styleFrom( // Define button style
        foregroundColor: Colors.green),
  ),
  hintColor: Colors.grey,
  textSelectionTheme: TextSelectionThemeData(
    cursorColor: Colors.green[700],
    selectionColor: Colors.green[100],
    selectionHandleColor: Colors.green,
  ),
);
var darkThemeData = ThemeData(
  brightness: Brightness.dark,
  // useMaterial3: false,
  // primarySwatch: Colors.green,
  // colorScheme: ColorScheme.fromSwatch(
  //   primarySwatch: Colors.orange,
  // ).copyWith(
  //   secondary: Colors.black,
  // ),
  appBarTheme: AppBarTheme(
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor: Colors.green[900],
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.light,
    ),
    backgroundColor: Colors.green[700],
    foregroundColor: Colors.white,
  ),
  radioTheme: RadioThemeData(
    // checkColor: MaterialStateProperty.all(Colors.white),
    fillColor: WidgetStateProperty.resolveWith<Color>(
          (Set<WidgetState> states) {
        if (states.contains(WidgetState.selected)) {
          return Colors.green;
        }
        return Colors.white;
      },
    ),
  ),
  checkboxTheme: CheckboxThemeData(
    checkColor: WidgetStateProperty.all(Colors.white),
    fillColor: WidgetStateProperty.resolveWith<Color>(
          (Set<WidgetState> states) {
        if (states.contains(WidgetState.selected)) {
          return Colors.green;
        }
        return Colors.white;
      },
    ),
    side: const BorderSide(color: Colors.green, width: 2, style: BorderStyle.solid),
  ),
  dialogTheme: DialogTheme(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
    ),
    actionsPadding: const EdgeInsets.only(top: 0, bottom: 8),
    backgroundColor: Colors.grey[800],
    surfaceTintColor: Colors.grey[800],
  ),
  textButtonTheme: TextButtonThemeData( // Customize text button theme
    style: TextButton.styleFrom( // Define button style
        foregroundColor: Colors.lightGreenAccent[700]),
  ),
  hintColor: Colors.grey,
  textSelectionTheme: TextSelectionThemeData(
    cursorColor: Colors.green[100],
    selectionColor: Colors.green[700],
    selectionHandleColor: Colors.green,
  ),
);


Future<void> main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  runApp(EasyDynamicThemeWidget(child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.noScaling),
      child: MaterialApp(
        title: 'Egydose',
        builder: BotToastInit(),
        theme: lightThemeData,
        darkTheme: darkThemeData,
        themeMode: EasyDynamicTheme.of(context).themeMode,
        home: const MyHomePage(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {
  String title = "Egydose";
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController searchEditText = TextEditingController();

  String selectedMode = "Regular Patient";
  String selectedAgeTextMenu = "age";
  String selectedAgeTextVar = "age";
  String selectedGestAge = ">36 weeks";
  String selectedGestAgeVar = ">36 weeks";
  int gestAgeNumber = 37;
  double pretermAge = 0;
  String selectedDialysis = "Not on Dialysis";
  String selectedFilter = "show all";
  String pughScore = 'Class A';
  bool favIconV = false;
  bool selectAgeV = true;
  bool gestAgeV = false;
  bool postNatalAgeV = false;
  bool crclV = false;
  double crcl = 0;
  bool dialysisV = false;
  bool hepaticV = false;
  bool gerV = false;
  double gerAge = 0;
  bool switchV = false;
  bool favAddTextV = false;
  bool favDrugListV = false;
  bool mainDrugListV = true;
  bool searchLinearV = true;
  bool notFoundV = false;
  String modeVar = 'normal';
  String weightHint = '0';
  String searchHint = 'search trade or generic name';
  // Color searchBackground = Colors.white;
  final TextEditingController weightText = TextEditingController();
  final TextEditingController crclText = TextEditingController();
  final TextEditingController windowsEmailController = TextEditingController();
  double myVar = 0;
  double selectedAge = 0;
  String favContentDescription = 'inactive';
  String favImage = 'assets/images/fav_not_active.png';
  bool watchVideoV = true;
  bool unlockDrawerV = true;
  int points = 0;
  String unityGameId = "";
  String unityRewardedID = "";
  String unityInterstitialID = "";
  String unityBannerID = "";
  bool unityRewardedReady = false;
  bool unityInterstitialReady = false;
  int showInterstitialEvery3Sec = 0;
  FocusNode weightFocus = FocusNode();
  FocusNode postNataFocus = FocusNode();
  FocusNode crclFocus = FocusNode();
  FocusNode gerFocus = FocusNode();
  FocusNode searchEditFocus = FocusNode();
  String selectedDrug = '';
  final ageItems = <String>['2 weeks', '1 month', '2 months', '3 months', '4 months', '5 months', '6 months', '7 months', '8 months', '9 months', '10 months', '11 months', '➤ 1 year', '1.5 years', '➤ 2 years', '2.5 years', '➤ 3 years', '3.5 years', '➤ 4 years', '4.5 years', '➤ 5 years', '5.5 years', '➤ 6 years', '➤ 7 years', '➤ 8 years', '➤ 9 years', '➤ 10 years', '➤ 11 years', '➤ 12 years', '➤ 13 years', '➤ 14 years', '➤ 15 years', '➤ 16 years', '➤ 17 years', '➤ Adult'];
  final gestItems = <String>['>36 weeks', '36 weeks', '35 weeks', '34 weeks', '33 weeks', '32 weeks', '31 weeks', '30 weeks', '29 weeks', '28 weeks', '<28 weeks'];
  List<Map<String, String>> mapList = [];
  List<Map<String, String>> favMapList = [];
  List<Map<String, String>> _filteredItems = [];
  List<Map<String, String>> _favFilteredItems = [];
  List<Map<String, String>> typeFilterItems = [];
  bool premium = false;
  String premiumTo = 'no';
  String premiumFreeCheck = "free";
  final Set<String> _productIds = {'egydose_product_id'};
  late List<ProductDetails> _products;
  String price = "16.99\$";
  User? user;
  bool userTap = false;
  bool claimPay = false;
  bool purchasePressed = false;
  bool saveAgeChecked = false;
  bool saveMenuChecked = false;
  bool saveWeightChecked = false;
  bool saveSearchChecked = false;
  final String saveAgeCheckbox = 'age checkboxStatus key';
  final String saveMenuCheckbox = 'menu checkboxStatus key';
  final String saveWeightCheckbox = 'weight checkboxStatus key';
  final String saveSearchCheckbox = 'search checkboxStatus key';
  final String saveAgeCheckboxValue = 'age checkboxStatus';
  final String saveMenuCheckboxValue = 'menu checkboxStatus';
  final String saveWeightCheckboxValue = 'weight checkboxStatus';
  final String saveSearchCheckboxValue = 'search checkboxStatus';
  Color ageBorder = Colors.grey;
  Color weightBorder = Colors.grey;
  Color crclBorder = Colors.grey;
  Color gerBorder = Colors.grey;
  String currentPlatform = "";
  String _authStatus = 'Unknown';
  String authorizationStatus = "Unknown";
  String uuid = "";
  String appName = "";
  String packageName = "";
  String currentVersion = "";
  int currentBuildNumber = 0;
  String latestVersionAndroid = "";
  String latestVersionWindows = "";
  String latestDateAndroid = "";
  String latestDateWindows = "";
  int latestBuildNumberAndroid = 0;
  int latestBuildNumberWindows = 0;
  bool ageMenuClicked = false;
  double leftSearchPadding = 16;
  int msgId = 0; String msgTitle = ""; String msgBody = ""; bool actionOn = false; String actionName = ""; String actionData = "";
  //tar
  String raz = ""; bool shdo = false; bool makbol = false;
  int maxVersionNum = 200; String freeORpaid = "premium free"; DateTime endDate = DateTime.now(); String targetPlatforms = "android ios macos windows linux web";
  bool updateDiagShown = false; bool notificationDiagShown = false;
  bool checkUpdateTap = false;

  late final AnimationController _controller = AnimationController(
    duration: const Duration(milliseconds: 750),
    vsync: this,
  );
  late final Animation<double> _animation = Tween<double>(begin: 1, end: 1.3).animate(_controller);
  bool _isAnimating = false;
  RateMyApp rateMyApp = RateMyApp(
    preferencesPrefix: 'rateMyApp_',
    minDays: 2,
    minLaunches: 5,
    remindDays: 7,
    remindLaunches: 10,
    appStoreIdentifier: '6452034344',
  );
  String lastSync = "now";
  int favListNum = 0;
  bool loadIntentionally = false;
  String windowsEmail = "";
  String enteredCode = "";
  bool windowsUserTap = false;
  bool codeDiag = false;
  bool drawerOpened = false;
  String cdML = "";
  String currentTheme = "";
  String switchTheme = "Switch Theme: light";
  String drugColors = "default";
  Color? modeColor = Colors.indigo[50];
  Color? unlockBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("750212") : Colors.red[100];}
  Color? calcInteractionBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("59231d") : Colors.red[50];}
  Color? howToContactBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("1e1d54") : Colors.blue[100];}
  Color? settingsBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("244028") : Colors.green[100];}
  Color? blackWhiteBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[700] : Colors.grey[200];}
  Color? denseBlackWhiteBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[900] : Colors.grey[50];}
  Color? blackWhiteText(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.white : Colors.black;}
  Color? modeColorTheme(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[800] : modeColor;}
  Color? inputColorTheme(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("16361c") : Colors.green[50];}
  Color? filterBannerColor(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.green[800] : Colors.green[400];}
  String abColor(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}
  String analgesicColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "F44336" : "F44336";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String resColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "07ad0f" : "2E7D32";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String gitColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "4754ff" : "3F51B5";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String cnsColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "04D5C1" : "04D5C1";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String cvsColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "F4780B" : "F4780B";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String hormoneColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "FA3BBA" : "FA3BBA";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String strdColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "df2bff" : "9C27B0";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String urinaryColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "607D8B" : "607D8B";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String vitColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "03A9F4" : "03A9F4";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String otherColor(BuildContext context) {final theme = Theme.of(context); if (drugColors == "default") {return theme.brightness == Brightness.dark ? "a34f31" : "795548";} else {return theme.brightness == Brightness.dark ? "FFFFFF" : "000000";}}
  String searchBackground(BuildContext context) {final theme = Theme.of(context); if (searchHint == 'search trade or generic name') {return theme.brightness == Brightness.dark ? "000000" : "FFFFFF";} else {return theme.brightness == Brightness.dark ? "54383C" : "FFEBEE";}}
  bool dismissSettingsDiag = true;
  bool filterBannerV = true;
  String selectedFilterText = "show all drugs";
  List<String> drugsNeedWeight = ["Insulin", "Iron sucrose", "Acyclovir 250", "Acyclovir 500", "Amikacin", "Gentamicin", "Metronidazole 500 mg / 100 ml", "Digoxin 0.5", "Enoxaparin", "Teicoplanin", "Dopamine", "Dobutamine", "Propofol", "Amphotericin B", "Midazolam 15", "Sodium Nitroprusside", "Ivermectin", "Ketamine", "Isotretinoin", "Cyclosporine", "Azathioprine", "Acetylcysteine 100 mg / ml", "Acetylcysteine 200 mg / ml", "Acetazolamide", "Ursodiol", "Methotrexate", "Erythropoietin", "L-Carnitine (levocarnitine) 1000 mg / 5 ml", "Deflazacort", "Cyclophosphamide", "Rituximab", "Mannitol", "Filgrastim", "Factor VIII", "Nalbuphine", "Calcitonin", "Ifosfamide", "Mesna", "Tirofiban", "Ribavirin", "Bevacizumab", "Chlorambucil", "Temozolomide", "Dexmedetomidine", "NaHCo3 4.2%", "NaHCo3 8.4%", "Tacrolimus", "milrinone"];
  bool comingFromInjections = false;
  double bannerHeight = 45;
  Color allDrugsFrame = Colors.red;
  Color tabFrame = Colors.transparent;
  Color drinkFrame = Colors.transparent;
  Color syringeFrame = Colors.transparent;
  Color suppositoryFrame = Colors.transparent;
  Color sachetsFrame = Colors.transparent;
  Color inhalersFrame = Colors.transparent;
  Color othersFrame = Colors.transparent;
  bool sortManually = false;

  @override
  void initState() {
    super.initState();
    detectPlatform();
    loadSavedPreferences();
    loadFavListLocally();
    checkIosMacosUpdate();
    loadPoints().then((savedPoints) {
      setState(() {
        points = savedPoints;
      });
    });

    inAppPurchaseStatus().whenComplete(() => initFirebase().whenComplete(() =>crashlytics().whenComplete(() => checkCurrentUser().whenComplete(() => firestore().whenComplete(() => getPackageInfo().whenComplete(() => checkUpdateOnStartupOnceADay().whenComplete(() => getNotificationData().whenComplete(() => checkAvailableNotifications().whenComplete(() => saveFavListCloud().whenComplete(() => loadBothAds()))))))))));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        getSavedColorBW().whenComplete(() => addMainListItems());
        _filteredItems = List.from(mapList);
        _favFilteredItems = List.from(favMapList);
      });
      Future.delayed(const Duration(seconds: 1), () {
        FlutterNativeSplash.remove();
      });
    });
    rateMyApp.init().then((_) {
      if (rateMyApp.shouldOpenDialog && Platform.isIOS) {
        rateAppDiag();
      }
    });
    // themeNotifyDiag();
  }


  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) {
          return;
        }
        if (drawerOpened) {
        Navigator.of(context).pop();
        }
        else {
          if (favContentDescription == 'active') {
            setState(() {
              favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
              favDrugListV = false; sortManually = false;
              mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
              favAddTextV = false;
              filterBannerV = true; bannerHeight = 45;
            });
          }
          else {
            if (searchEditText.text.isNotEmpty && !saveSearchChecked) {
              searchEditText.clear();
              SharedPreferences.getInstance().then((prefs) {
                prefs.setString(saveSearchCheckboxValue, '');
              });
              setState(() {
                showAllDrugsShortcut();
                filterItemsByName("");
                filterItemsByIndication("");
                if (_filteredItems.length < 6) {notFoundV = true;} else {notFoundV= false;}
              });
            }
            else {
              SystemNavigator.pop();
            }
          }
        }

      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        key: _scaffoldKey,
        floatingActionButton: Visibility(visible: sortManually,
          child: FloatingActionButton(
            foregroundColor: blackWhiteText(context),
            backgroundColor: Colors.green,
            tooltip: "finish",
            onPressed: () {
              setState(() {
                sortManually = false;
              });
            },
            child: const Icon(Icons.check_circle),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        appBar: AppBar(toolbarHeight: 40,
          leading: Builder(
            builder: (BuildContext context) {
              return IconButton(padding: const EdgeInsets.all(0),
                icon: const Icon(Icons.menu), iconSize: 40,
                onPressed: () {
                  Scaffold.of(context).openDrawer();
                },
              );
            },
          ),
          title: Row(
            children: <Widget>[
              Expanded(
                child: Center(
                  child: Container(height: 37, padding: const EdgeInsets.symmetric(vertical: 2),
                    decoration: BoxDecoration(
                      color: denseBlackWhiteBackground(context),
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(color: Colors.black54, width: 1,),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: DropdownButton2<String>(alignment: AlignmentDirectional.center,
                        value: selectedMode,
                        items: <String>["Regular Patient", "Preterm Infant", "Renal Patient", "Hepatic Patient", "Geriatric Patient"].map((String item) {
                          Image image = Image.asset('assets/images/regular_icon.png', height: 20, width: 20,);

                          switch (item) {
                            case "Regular Patient":
                              image = Image.asset('assets/images/regular_icon.png', height: 20, width: 20,);
                              break;
                            case "Preterm Infant":
                              image = Image.asset('assets/images/preterm_icon.png', height: 20, width: 20,);
                              break;
                            case "Renal Patient":
                              image = Image.asset('assets/images/renal_icon.png', height: 20, width: 20,);
                              break;
                            case "Hepatic Patient":
                              image = Image.asset('assets/images/hepatic_icon.png', height: 20, width: 20,);
                              break;
                            case "Geriatric Patient":
                              image = Image.asset('assets/images/geriatric_icon.png', height: 20, width: 20,);
                              break;
                          }

                          return DropdownMenuItem<String>(
                            alignment: Alignment.center,
                            value: item,
                            child: Container(height: 34, padding: const EdgeInsets.symmetric(horizontal: 6),
                              child: Row(
                                children: [
                                  image,
                                  const SizedBox(width: 6),
                                  Text(item, style: const TextStyle(fontSize: 18,)),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedMode = newValue!;
                            weightText.text = ''; selectedAgeTextMenu = 'age'; myVar = 0; selectedAge = 0;
                            if (newValue == 'Regular Patient') {
                              selectAgeV = true; gestAgeV = false; postNatalAgeV = false; crclV = false; dialysisV = false; hepaticV = false; gerV = false;
                              modeVar = "normal"; modeColor = Colors.indigo[50]; weightHint = '0';
                            }
                            else if (newValue == 'Preterm Infant') {
                              selectAgeV = false; gestAgeV = true; postNatalAgeV = true; crclV = false; dialysisV = false; hepaticV = false; gerV = false;
                              modeVar = "preterm"; modeColor = Colors.pink[50]; weightHint = 'enter weight'; weightFocus.requestFocus();
                            }
                            else if (newValue == 'Renal Patient') {
                              selectAgeV = true; gestAgeV = false; postNatalAgeV = false; crclV = true; dialysisV = true; hepaticV = false; gerV = false;
                              modeVar = "renal"; modeColor = Colors.yellow[50]; weightHint = '0';
                            }
                            else if (newValue == 'Hepatic Patient') {
                              selectAgeV = true; gestAgeV = false; postNatalAgeV = false; crclV = false; dialysisV = false; hepaticV = true; gerV = false;
                              modeVar = "hepatic"; modeColor = Colors.lightGreen[50]; weightHint = '0';
                            }
                            else if (newValue == 'Geriatric Patient') {
                              selectAgeV = false; gestAgeV = false; postNatalAgeV = false; crclV = false; dialysisV = false; hepaticV = false; gerV = true;
                              modeVar = "geriatric"; modeColor = Colors.white; weightHint = 'enter weight'; weightFocus.requestFocus();
                            }
                          });
                        },
                        underline: Container(),
                        menuItemStyleData: const MenuItemStyleData(height: 35, padding: EdgeInsets.symmetric(horizontal: 0)),
                        iconStyleData: const IconStyleData(iconSize: 0),
                        dropdownStyleData: DropdownStyleData(
                          padding: EdgeInsets.zero,
                          decoration: BoxDecoration(
                            color: denseBlackWhiteBackground(context),
                          ),),
                        // iconSize: 0,
                      ),
                    ),
                  ),
                ),
              ),

              Visibility(visible: favIconV, maintainSize: true, maintainAnimation: true, maintainState: true,
                child: GestureDetector(onTap: () {
                  if (favContentDescription == 'inactive') {
                    searchEditFocus.unfocus();
                    setState(() {
                      favContentDescription = 'active'; favImage = 'assets/images/fav_active.png'; FocusScope.of(context).unfocus(); //try using FocusManager.instance.primaryFocus?.unfocus();
                      favDrugListV = true;
                      mainDrugListV = false; notFoundV = false; searchLinearV = false;
                      if (_favFilteredItems.isEmpty) {
                        favAddTextV = true;
                      }
                      else {
                        favAddTextV = false;
                      }
                      filterBannerV = false; bannerHeight = 0;
                    });
                    for (int i = 0; i < _favFilteredItems.length; i++) {
                      Map<String, String> itemToEdit = _favFilteredItems[i];
                      for (Map<String, dynamic> map in mapList) {
                        if (map["trade"] == itemToEdit["trade"]) {
                          itemToEdit["color"] = map["color"];
                        }
                      }
                    }
                  }
                  else {
                    setState(() {
                      favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
                      favDrugListV = false; sortManually = false;
                      mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
                      favAddTextV = false;
                      filterBannerV = true; bannerHeight = 45;
                    });
                  }
                },
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5, right: 5),
                    child: Image.asset(favImage,
                      width: 40,
                      height: 35,
                      semanticLabel: favContentDescription,
                      fit: BoxFit.fitHeight,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        drawer: Drawer(
          child: Padding(padding: const EdgeInsets.all(8),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 50),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (user == null && Platform.isAndroid)
                        ElevatedButton(onPressed: () {
                          claimPay = false;  userTap = true;
                          BotToast.showText(text: "wait a moment");
                          loadIntentionally = false;
                          signInWithGoogle().whenComplete(() => firestore().whenComplete(() => loadFavListCloud()));
                        },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.indigo,
                            minimumSize: const Size(double.infinity, 40),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            alignment: Alignment.centerLeft,
                          ), child:
                          Row(
                            children: [
                              Image.asset('assets/images/sign_in.png',
                                width: 24, height: 24,
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'Sign in with Google',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),),
                      if (user != null && Platform.isAndroid)
                        Row(
                          children: [
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(8),
                                child: SelectableText('${user?.email}', style: const TextStyle(fontWeight: FontWeight.bold),),
                              ),
                            ),
                            ElevatedButton(
                                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 2),
                                  backgroundColor: Colors.red[600],
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                onPressed: () async {
                                  signOut();
                                }, child: const Text("Sign out",
                              style: TextStyle(color: Colors.white),)),
                          ],
                        ),

                    ],
                  ),
                  const SizedBox(height: 2),
                  const Image(image: AssetImage('assets/images/icon.jpg'), width: 175, height:  175,),
                  const SizedBox(height: 10),
                  Text("Egydose", style: TextStyle(
                    color: Colors.green[600], fontWeight: FontWeight.bold, fontSize: 22,),),
                  Text("V $currentVersion", style: TextStyle(color: Colors.green[600]),),
                  const SizedBox(height: 10),
                  Visibility(visible: unlockDrawerV,
                    child: GestureDetector(onTap: (){
                      Navigator.pop(context);
                      watchVideoV = false;
                      adPayDiag();
                    },
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: const [BoxShadow (color: Colors.black38, spreadRadius: 0, blurRadius: 2, offset: Offset(1, 1))],
                          color: unlockBackground(context),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        padding: const EdgeInsets.all(10),
                        child: Row (
                          children: <Widget> [
                            const Image(image: AssetImage('assets/images/unlock.png'), width: 30, height: 30,),
                            Text(" Unlock full version",
                              style: TextStyle(
                                  color: blackWhiteText(context),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18),),
                            const Spacer(),
                            if (Platform.isAndroid || Platform.isIOS)
                              GestureDetector( onTap: () {
                                Navigator.pop(context);
                                if (points > 29) {
                                  BotToast.showText(text: "maximum points reached");
                                }
                                else {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: const Text("Accumulate points"),
                                        content: const Text("Watch more than one video to accumulate up to 30 points to open all categories 30 times when offline\n\nيمكنك مشاهدة أكثر من اعلان فيديو لتجميع نقاط بحد أقصى 30 نقطة لتتمكن من فتح جميع الاقسام 30 مرة بدون انترنت"),
                                        actions: <Widget>[
                                          TextButton(
                                            child: const Text("Cancel"),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                          TextButton(
                                            child: const Text("Watch Now"),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                              showRewarded();
                                            },
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                }
                              },
                                child: AnimatedBuilder(
                                    animation: _animation,
                                    builder: (context, child) {
                                      return Transform.scale(
                                        scale: _animation.value,
                                        child: child,
                                      );
                                    },
                                    child: Container(
                                        padding: const EdgeInsets.only(top: 10, bottom: 10, left: 16, right: 16),
                                        decoration: BoxDecoration(
                                          image: getImage(),
                                        ),
                                        child: Text(points.toString(),
                                          style: const TextStyle(color: Colors.black,
                                            fontSize: 14,
                                          ),
                                        )
                                    )
                                ),
                              )
                          ],
                        ),
                      ),),
                  ),

                  const SizedBox(height: 5),
                  ElevatedButton(onPressed: () async {
                    Navigator.pop(context);
                    showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
                    final returnedCrcl = await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>  CalculatorPage(calc: "main", returnedCrcl: '', premium: premiumTo, unityBannerID: unityBannerID,)),
                    );
                    showInterstitial();
                    if (returnedCrcl != null) {
                      setState(() {
                        crclText.text = returnedCrcl; crcl = double.parse(returnedCrcl);
                      });
                    }
                  },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: calcInteractionBackground(context),
                      minimumSize: const Size(double.infinity, 45),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.centerLeft,
                    ), child: Row(
                      children: [
                        Image.asset(
                          'assets/images/calc_icon.png',
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Calculators',
                          style: TextStyle(
                            color: blackWhiteText(context),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),),
                  const SizedBox(height: 5),
                  ElevatedButton(onPressed: () async {
                    Navigator.pop(context);
                    if (currentPlatform == "android" || currentPlatform == "ios") {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) =>  const WebPage(url: "https://reference.medscape.com/drug-interactionchecker")),
                      );
                    }
                    else {
                      await launchUrl(Uri.parse("https://reference.medscape.com/drug-interactionchecker"), mode: LaunchMode.externalApplication);
                    }
                  },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: calcInteractionBackground(context),
                      minimumSize: const Size(double.infinity, 45),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.centerLeft,
                    ), child: Row(
                      children: [
                        Image.asset(
                          'assets/images/interaction.png',
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Drug Interactions',
                          style: TextStyle(
                            color: blackWhiteText(context),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),),
                  const SizedBox(height: 5),
                  ElevatedButton(onPressed: () {
                    Navigator.pop(context);
                    showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>  HelpPage(help: "help", premium: premiumTo, unityBannerID: unityBannerID,)),
                    );
                    showInterstitial();
                  },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: howToContactBackground(context),
                      minimumSize: const Size(double.infinity, 45),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.centerLeft,
                    ), child: Row(
                      children: [
                        Image.asset(
                          'assets/images/question.png',
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'How to use',
                          style: TextStyle(
                            color: blackWhiteText(context),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),),
                  const SizedBox(height: 5),
                  ElevatedButton(onPressed: () {
                    Navigator.pop(context);
                    showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>  HelpPage(help: "contact", premium: premiumTo, unityBannerID: unityBannerID,)),
                    );
                    showInterstitial();
                  },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: howToContactBackground(context),
                      minimumSize: const Size(double.infinity, 45),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.centerLeft,
                    ), child: Row(
                      children: [
                        Image.asset(
                          'assets/images/envelop.png',
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Contact us',
                          style: TextStyle(
                            color: blackWhiteText(context),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),),
                  const SizedBox(height: 5),
                  ElevatedButton(onPressed: () {
                    Navigator.pop(context);
                    ThemeMode? themeMode = EasyDynamicTheme.of(context).themeMode;
                    currentTheme = themeMode!.name;
                    switchTheme = "Switch Theme: $currentTheme";
                    getSavedColorBW();
                    showDialog(
                        // barrierDismissible: true,
                        context: context,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (context, setState) {
                                return Theme(data: Theme.of(context).copyWith(
                                    dialogBackgroundColor: Colors.grey[400]),
                                  child: PopScope(
                                    canPop: dismissSettingsDiag,
                                    child: AlertDialog(backgroundColor: Colors.grey[400],
                                      contentPadding: const EdgeInsets.all(0),
                                      content: Container(
                                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 0),
                                        child: SingleChildScrollView(
                                          child: IntrinsicWidth(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                const Center(
                                                  child: Text(
                                                    'Settings',
                                                    style: TextStyle(
                                                      decoration: TextDecoration.underline, decorationColor: Colors.black,
                                                      fontSize: 20,
                                                      fontWeight: FontWeight.bold,
                                                      color: Colors.black,
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(height: 8,),
                                                Container(margin: const EdgeInsets.all(4),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(50),
                                                    color: Colors.white,
                                                  ),
                                                  child: CheckboxListTile(dense: true,
                                                    value: saveAgeChecked,
                                                    onChanged: (value) {
                                                      setState(() {
                                                        saveAgeChecked = value!;
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setBool(saveAgeCheckbox, saveAgeChecked);});
                                                      });
                                                      if (saveAgeChecked) {
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setString(saveAgeCheckboxValue, selectedAgeTextMenu);
                                                        });
                                                      } else {
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setString(saveAgeCheckboxValue, 'age');
                                                        });
                                                      }
                                                    },
                                                    title: Transform.translate( offset: const Offset(-15, 0),
                                                      child: const Text('Save age input',
                                                        style: TextStyle(color: Colors.black,
                                                          fontSize: 16,
                                                          fontStyle: FontStyle.italic,
                                                        ),
                                                      ),
                                                    ),
                                                    controlAffinity: ListTileControlAffinity
                                                        .leading,
                                                  ),
                                                ),
                                                Container(margin: const EdgeInsets.all(4),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(50),
                                                    color: Colors.white,
                                                  ),
                                                  child: CheckboxListTile(dense: true,
                                                    value: saveMenuChecked,
                                                    onChanged: (value) {
                                                      setState(() {
                                                        saveMenuChecked = value!;
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setBool(saveMenuCheckbox, saveMenuChecked);});
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setBool(saveMenuCheckboxValue, saveMenuChecked);
                                                        });
                                                      });
                                                    },
                                                    title: Transform.translate( offset: const Offset(-15, 0),
                                                      child: const Text(
                                                        'Open age menu on startup',
                                                        style: TextStyle(color: Colors.black,
                                                          fontSize: 16,
                                                          fontStyle: FontStyle.italic,
                                                        ),
                                                      ),
                                                    ),
                                                    controlAffinity: ListTileControlAffinity
                                                        .leading,
                                                  ),
                                                ),
                                                Container(margin: const EdgeInsets.all(4),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(50),
                                                    color: Colors.white,
                                                  ),
                                                  child: CheckboxListTile(dense: true,
                                                    value: saveWeightChecked,
                                                    onChanged: (value) {
                                                      setState(() {
                                                        saveWeightChecked = value!;
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setBool(saveWeightCheckbox, saveWeightChecked);});
                                                        if (saveWeightChecked) {
                                                          SharedPreferences.getInstance().then((prefs) {
                                                            prefs.setString(saveWeightCheckboxValue, weightText.text);
                                                          });
                                                        } else {
                                                          SharedPreferences.getInstance().then((prefs) {
                                                            prefs.setString(saveWeightCheckboxValue, '');
                                                          });
                                                        }
                                                      });
                                                    },
                                                    title: Transform.translate( offset: const Offset(-15, 0),
                                                      child: const Text(
                                                        'Save weight input',
                                                        style: TextStyle(color: Colors.black,
                                                          fontSize: 16,
                                                          fontStyle: FontStyle.italic,
                                                        ),
                                                      ),
                                                    ),
                                                    controlAffinity: ListTileControlAffinity
                                                        .leading,
                                                  ),
                                                ),
                                                Container(margin: const EdgeInsets.all(4),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(50),
                                                    color: Colors.white,
                                                  ),
                                                  child: CheckboxListTile(dense: true,
                                                    value: saveSearchChecked,
                                                    onChanged: (value) {
                                                      setState(() {
                                                        saveSearchChecked = value!;
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setBool(saveSearchCheckbox, saveSearchChecked);});
                                                        if (saveSearchChecked) {
                                                          if (searchHint == 'search trade or generic name') {
                                                            SharedPreferences.getInstance().then((prefs) {
                                                              prefs.setString(saveSearchCheckboxValue, searchEditText.text);
                                                            });
                                                          }
                                                        } else {
                                                          SharedPreferences.getInstance().then((prefs) {
                                                            prefs.setString(saveSearchCheckboxValue, '');
                                                          });
                                                        }
                                                      });
                                                    },
                                                    title: Transform.translate( offset: const Offset(-15, 0),
                                                      child: const Text(
                                                        'Save search input',
                                                        style: TextStyle(color: Colors.black,
                                                          fontSize: 16,
                                                          fontStyle: FontStyle.italic,
                                                        ),
                                                      ),
                                                    ),
                                                    controlAffinity: ListTileControlAffinity
                                                        .leading,
                                                  ),
                                                ),
                                                if (Platform.isAndroid || Platform.isIOS || Platform.isWindows)
                                                  Container(margin: const EdgeInsets.all(4),
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(50),
                                                      color: Colors.white,
                                                    ),
                                                    child: ElevatedButton(onPressed: () async {
                                                      Navigator.pop(context);
                                                      if (Platform.isAndroid) {
                                                        try {
                                                          if (latestBuildNumberAndroid > currentBuildNumber) {
                                                            showUpdateDiagAndroid();
                                                          } else {
                                                            generalDiag("No update available", "You are using the latest version");
                                                          }
                                                        } catch (e) {
                                                          BotToast.showText(text: 'error checking update. try again later');
                                                        }
                                                      }
                                                      else {
                                                        if (Platform.isWindows) {
                                                          try {
                                                            if (latestBuildNumberWindows > currentBuildNumber) {
                                                              showUpdateDiagWindows();
                                                            } else {
                                                              generalDiag("No update available", "You are using the latest version");
                                                            }
                                                          } catch (e) {
                                                            BotToast.showText(text: 'error checking update. try again later');
                                                          }
                                                        }
                                                        else {
                                                          checkUpdateTap = true;
                                                          checkIosMacosUpdate();
                                                        }
                                                      }
                                                    },
                                                      style: ElevatedButton.styleFrom(
                                                        elevation: 0,
                                                        backgroundColor: Colors.white,
                                                        minimumSize: const Size(double.infinity, 45),
                                                        shape: RoundedRectangleBorder(
                                                          borderRadius: BorderRadius.circular(50),
                                                        ),
                                                        alignment: Alignment.centerLeft,
                                                      ), child:  Row(
                                                        children: [
                                                          Image.asset("assets/images/update.png", width: 24, height: 24,),
                                                          const Padding(
                                                            padding: EdgeInsets.only(left: 8),
                                                            child: Text(
                                                              'Check for updates',
                                                              style: TextStyle(color: Colors.black,
                                                                fontSize: 16,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),),
                                                  ),
                                                if (Platform.isIOS)
                                                  Visibility(visible: unlockDrawerV,
                                                    child: Container(margin: const EdgeInsets.all(4),
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(50),
                                                        color: Colors.white,
                                                      ),
                                                      child: ElevatedButton(onPressed: () async {
                                                        Navigator.pop(context);
                                                        final TrackingStatus status = await AppTrackingTransparency.requestTrackingAuthorization();
                                                        setState(() {
                                                          _authStatus = '$status';
                                                          if (_authStatus == "TrackingStatus.notDetermined") {authorizationStatus = "not determined";} else if (_authStatus == "TrackingStatus.authorized") {authorizationStatus = "authorized";} else if (_authStatus == "TrackingStatus.denied") {authorizationStatus = "denied";} else if (_authStatus == "TrackingStatus.notSupported") {authorizationStatus = "not supported";} else if (_authStatus == "TrackingStatus.restricted") {authorizationStatus = "restricted";}
                                                        });
                                                        generalDiag("ads settings", "Authorization Status: $authorizationStatus\n\nYou can change your choice anytime in the app settings");
                                                      },
                                                        style: ElevatedButton.styleFrom(
                                                          elevation: 0,
                                                          backgroundColor: Colors.white,
                                                          minimumSize: const Size(double.infinity, 45),
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.circular(50),
                                                          ),
                                                          alignment: Alignment.centerLeft,
                                                        ), child: Row(
                                                          children: [
                                                            Image.asset("assets/images/ads.png", width: 24, height: 24,),
                                                            const Padding(
                                                              padding: EdgeInsets.only(left: 8),
                                                              child: Text(
                                                                'Ads Settings',
                                                                style: TextStyle(color: Colors.black,
                                                                  fontSize: 16,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),),
                                                    ),
                                                  ),
                                                Container(margin: const EdgeInsets.all(4),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(50),
                                                    color: Colors.white,
                                                  ),
                                                  child: ElevatedButton(onPressed: () async {
                                                    if (dismissSettingsDiag) {
                                                      setState((){
                                                        dismissSettingsDiag = false;
                                                      });
                                                      EasyDynamicTheme.of(context).changeTheme();
                                                      ThemeMode? themeMode = EasyDynamicTheme.of(context).themeMode;
                                                      currentTheme = themeMode!.name;
                                                      switchTheme = "Switch Theme: $currentTheme";

                                                      Future.delayed(const Duration(seconds: 1), () {
                                                        searchEditText.clear();
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setString(saveSearchCheckboxValue, '');
                                                        });
                                                        setState(() {
                                                          mapList.clear();
                                                          addMainListItems();
                                                          _filteredItems = List.from(mapList);
                                                          showAllDrugsShortcut();
                                                          filterItemsByName("");
                                                          filterItemsByIndication("");
                                                          if (_filteredItems.length < 6) {notFoundV = true;} else {notFoundV= false;}
                                                          if (favContentDescription == 'active') {
                                                            setState(() {
                                                              favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
                                                              favDrugListV = false; sortManually = false;
                                                              mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
                                                              favAddTextV = false;
                                                              filterBannerV = true; bannerHeight = 45;
                                                            });
                                                          }
                                                          dismissSettingsDiag = true;
                                                        });
                                                      });
                                                    }

                                                  },
                                                    style: ElevatedButton.styleFrom(
                                                      elevation: 0,
                                                      backgroundColor: Colors.white,
                                                      minimumSize: const Size(double.infinity, 45),
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(50),
                                                      ),
                                                      alignment: Alignment.centerLeft,
                                                    ), child: Row(
                                                      children: [
                                                        Image.asset("assets/images/theme.png", width: 24, height: 24,),
                                                        Padding(
                                                          padding: const EdgeInsets.only(left: 8),
                                                          child: Text(switchTheme,
                                                            style: const TextStyle(color: Colors.black,
                                                              fontSize: 16,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),),
                                                ),
                                                Container(margin: const EdgeInsets.all(4),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(50),
                                                    color: Colors.white,
                                                  ),
                                                  child: ElevatedButton(onPressed: () async {
                                                    if (dismissSettingsDiag) {
                                                      setState((){
                                                        dismissSettingsDiag = false;
                                                      });
                                                      if (drugColors == "default") {
                                                        setState((){
                                                          drugColors = "same color";
                                                        });
                                                      }
                                                      else {
                                                        setState((){
                                                          drugColors = "default";
                                                        });
                                                      }
                                                      SharedPreferences.getInstance().then((prefs) {
                                                        prefs.setString("saveColorBW", drugColors);});

                                                      Future.delayed(const Duration(seconds: 1), () {
                                                        searchEditText.clear();
                                                        SharedPreferences.getInstance().then((prefs) {
                                                          prefs.setString(saveSearchCheckboxValue, '');
                                                        });
                                                        setState(() {
                                                          mapList.clear();
                                                          addMainListItems();
                                                          _filteredItems = List.from(mapList);
                                                          showAllDrugsShortcut();
                                                          filterItemsByName("");
                                                          filterItemsByIndication("");
                                                          if (_filteredItems.length < 6) {notFoundV = true;} else {notFoundV= false;}
                                                          if (favContentDescription == 'active') {
                                                            setState(() {
                                                              favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
                                                              favDrugListV = false; sortManually = false;
                                                              mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
                                                              favAddTextV = false;
                                                              filterBannerV = true; bannerHeight = 45;
                                                            });
                                                          }
                                                          dismissSettingsDiag = true;
                                                        });
                                                      });
                                                    }
                                                  },
                                                    style: ElevatedButton.styleFrom(
                                                      elevation: 0,
                                                      backgroundColor: Colors.white,
                                                      minimumSize: const Size(double.infinity, 45),
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(50),
                                                      ),
                                                      alignment: Alignment.centerLeft,
                                                    ), child: Row(
                                                      children: [
                                                        Image.asset("assets/images/colorBW.jpg", width: 24, height: 24,),
                                                        Padding(
                                                          padding: const EdgeInsets.only(left: 8),
                                                          child: Text("drug colors: $drugColors",
                                                            style: const TextStyle(color: Colors.black,
                                                              fontSize: 16,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),),
                                                ),
                                                if (Platform.isIOS)
                                                  Container(margin: const EdgeInsets.all(4),
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(50),
                                                      color: Colors.white,
                                                    ),
                                                    child: ElevatedButton(onPressed: () async {
                                                      Navigator.pop(context);
                                                      rateAppDiag();
                                                    },
                                                      style: ElevatedButton.styleFrom(
                                                        elevation: 0,
                                                        backgroundColor: Colors.white,
                                                        minimumSize: const Size(double.infinity, 45),
                                                        shape: RoundedRectangleBorder(
                                                          borderRadius: BorderRadius.circular(50),
                                                        ),
                                                        alignment: Alignment.centerLeft,
                                                      ), child: Row(
                                                        children: [
                                                          Image.asset("assets/images/fav_active.png", width: 24, height: 24,),
                                                          const Padding(
                                                            padding: EdgeInsets.only(left: 8),
                                                            child: Text(
                                                              'Rate the app',
                                                              style: TextStyle(color: Colors.black,
                                                                fontSize: 16,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),),
                                                  ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              });});
                  },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: settingsBackground(context),
                      minimumSize: const Size(double.infinity, 45),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.centerLeft,
                    ), child: Row(
                      children: [
                        Image.asset(
                          'assets/images/options.png',
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Settings',
                          style: TextStyle(
                            color: blackWhiteText(context),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),),
                ],
              ),
            ),
          ),
        ),
        onDrawerChanged: (isOpen) {
          if (isOpen) {
            drawerOpened = true;
          } else {
            drawerOpened = false;
          }
          searchEditFocus.unfocus();
          if (!premium && (Platform.isIOS || Platform.isAndroid)) {
            setState(() {
              getImage();
            });
           try {
             if (isOpen) {
               if (unityRewardedReady && points < 30) {
                 setState(() {
                   _isAnimating ? null :  setState(() {
                     _isAnimating = true;
                   });
                   _controller.repeat(reverse: true);
                 });
               }
               else {
                 setState(() {
                   _controller.stop();
                 });
               }
             }
             else {
               setState(() {
                 _controller.stop();
               });
             }
           }
           catch (e) {
             //error
           }
          }
        },
        body: Center(
          child: Container(decoration: BoxDecoration(color: Colors.grey[600]),
            child: Padding(padding: const EdgeInsets.all(0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Visibility(visible: selectAgeV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      padding: const EdgeInsets.only(left: 8, right: 50, bottom: 1, top: 1),
                      color: modeColorTheme(context),
                      child: Row(
                        children: [
                           const Expanded(flex: 1,
                            child: Text(
                              'Select age:', style: TextStyle(fontWeight: FontWeight.bold,),
                            ),
                          ),
                          Expanded(flex: 1,
                            child: GestureDetector(onTap: () {
                              ageMenuClicked = true;
                              showAgeDiag();
                            },
                              child: Container(height: 40,
                                decoration: BoxDecoration(
                                  color: inputColorTheme(context),
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: ageBorder, width: 1,),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  child: Center(
                                      child:
                                      Text(selectedAgeTextMenu, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: blackWhiteText(context),),)
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.only(bottom: 1),
                    color: modeColorTheme(context),
                    padding: const EdgeInsets.only(left: 8, right: 50, bottom: 1, top: 1),
                    child: Row(
                      children: [
                        const Expanded(
                          flex: 1,
                          child: Text(
                            'Weight in Kg: ',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(height: 40,
                            decoration: BoxDecoration(
                              color: inputColorTheme(context),
                              borderRadius: BorderRadius.circular(50),
                              border: Border.all(color: weightBorder, width: 1,),
                            ),
                            child: TextFormField(
                              focusNode: weightFocus,
                              controller: weightText,
                              decoration: InputDecoration(
                                hintText: weightHint,
                                hintStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                border: InputBorder.none,
                              ),
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                              ],
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              textInputAction: TextInputAction.next,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                              ),
                              onChanged: (value) {
                                setState(() {
                                  if (value == '' || value == '.') {myVar = selectedAge;} else {myVar = double.parse(value); setState(() {weightBorder = Colors.grey;});}
                                });
                                if (saveWeightChecked) {
                                  SharedPreferences.getInstance().then((prefs) {
                                    prefs.setString(saveWeightCheckboxValue, weightText.text);
                                  });
                                } else {
                                  SharedPreferences.getInstance().then((prefs) {
                                    prefs.setString(saveWeightCheckboxValue, '');
                                  });
                                }
                              },
                              onFieldSubmitted: (v) {
                                weightFocus.unfocus();
                                if (modeVar == "renal") {
                                  FocusScope.of(context).requestFocus(crclFocus);
                                }
                                else {
                                  if (modeVar == "preterm") {
                                    FocusScope.of(context).requestFocus(postNataFocus);
                                  }
                                  else {
                                    if (modeVar == "geriatric") {
                                      FocusScope.of(context).requestFocus(gerFocus);
                                    }
                                    else {
                                      FocusScope.of(context).requestFocus(searchEditFocus);
                                    }
                                  }
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  Visibility(visible: gestAgeV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      padding: const EdgeInsets.only(left: 8, right: 50, bottom: 1, top: 1),
                      color: modeColorTheme(context),
                      child: Row(
                        children: [
                          const Expanded(flex: 1,
                            child: Text(
                              'Gestational Age:', style: TextStyle(fontWeight: FontWeight.bold,),
                            ),
                          ),
                          Expanded(flex: 1,
                            child: Container(height: 40,
                              decoration: BoxDecoration(
                                color: inputColorTheme(context),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: Colors.grey, width: 1,),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                child: Center(
                                  child: DropdownButton2<String>( alignment: AlignmentDirectional.center,
                                    value: selectedGestAge,
                                    items: gestItems.map((String value) {
                                      return DropdownMenuItem<String>(
                                        alignment: Alignment.center,
                                        value: value,
                                        child: Text(value,  style: TextStyle(
                                          fontSize: 18,
                                          color: blackWhiteText(context),
                                        ),),
                                      );
                                    }).toList(),
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        selectedGestAge = newValue!;
                                        if (newValue == ">36 weeks") {selectedGestAgeVar = ">36 weeks"; gestAgeNumber = 37;}
                                        if (newValue == "36 weeks") {selectedGestAgeVar = "36 weeks"; gestAgeNumber = 36;}
                                        if (newValue == "35 weeks") {selectedGestAgeVar = "35 weeks"; gestAgeNumber = 35;}
                                        if (newValue == "34 weeks") {selectedGestAgeVar = "34 weeks"; gestAgeNumber = 34;}
                                        if (newValue == "33 weeks") {selectedGestAgeVar = "33 weeks"; gestAgeNumber = 33;}
                                        if (newValue == "32 weeks") {selectedGestAgeVar = "32 weeks"; gestAgeNumber = 32;}
                                        if (newValue == "31 weeks") {selectedGestAgeVar = "31 weeks"; gestAgeNumber = 31;}
                                        if (newValue == "30 weeks") {selectedGestAgeVar = "30 weeks"; gestAgeNumber = 30;}
                                        if (newValue == "29 weeks") {selectedGestAgeVar = "29 weeks"; gestAgeNumber = 29;}
                                        if (newValue == "28 weeks") {selectedGestAgeVar = "28 weeks"; gestAgeNumber = 28;}
                                        if (newValue == "<28 weeks") {selectedGestAgeVar = "<28 weeks"; gestAgeNumber = 27;}
                                      });
                                    },
                                    underline: Container(),
                                    menuItemStyleData: const MenuItemStyleData(height: 35,),
                                    iconStyleData: const IconStyleData(iconSize: 0),
                                    dropdownStyleData: DropdownStyleData(
                                      padding: EdgeInsets.zero,
                                      decoration: BoxDecoration(
                                        color: blackWhiteBackground(context),
                                      ),),
                                    // iconSize: 0,
                                    isExpanded: true,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Visibility(visible: postNatalAgeV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      color: modeColorTheme(context),
                      padding: const EdgeInsets.only(left: 8, right: 50, bottom: 1, top: 1),
                      child: Row(
                        children: [
                          const Expanded(
                            flex: 1,
                            child: Text(
                              'Age in days: ',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(height: 40,
                              decoration: BoxDecoration(
                                color: inputColorTheme(context),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: Colors.grey, width: 1,),
                              ),
                              child: TextFormField(
                                focusNode: postNataFocus,
                                decoration: const InputDecoration(
                                  hintText: 'Post-natal age',
                                  hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                  border: InputBorder.none,
                                ),
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                ],
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                textInputAction: TextInputAction.next,
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                                ),
                                onChanged: (value) {
                                  if (value == '') {
                                    pretermAge = 0;
                                  }
                                  else {
                                    pretermAge = double.parse(value);
                                  }
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Visibility(visible: crclV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      color: modeColorTheme(context),
                      padding: const EdgeInsets.only(left: 8, right: 4, bottom: 1, top: 1),
                      child: Row(
                        children: [
                          const Expanded(
                            flex: 1,
                            child: Text(
                              'Creatinine Clearance: ',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(height: 40,
                              decoration: BoxDecoration(
                                color: inputColorTheme(context),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: crclBorder, width: 1,),
                              ),
                              child: TextFormField(
                                  controller: crclText,
                                  focusNode: crclFocus,
                                  decoration: const InputDecoration(
                                    hintText: 'mL/min',
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                  textInputAction: TextInputAction.next,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                                  ),
                                  onChanged: (value) {
                                    if (value == '') {
                                      crcl = 0;
                                    }
                                    else {
                                      crcl = double.parse(value); setState(() {crclBorder = Colors.grey;});
                                    }
                                  },
                                  onFieldSubmitted: (v) {
                                    crclFocus.unfocus();
                                    FocusScope.of(context).requestFocus(searchEditFocus);
                                  }
                              ),
                            ),
                          ),
                          GestureDetector(onTap: () {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return Theme(
                                  data: Theme.of(context).copyWith(
                                      dialogBackgroundColor: Colors.grey[200]),
                                  child: AlertDialog( contentPadding: const EdgeInsets.all(8),
                                    content: Column(mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        GestureDetector(onTap: () async {
                                          Navigator.pop(context);
                                          showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
                                          final returnedCrcl = await Navigator.push(
                                            context,
                                            MaterialPageRoute(builder: (context) =>  CalculatorPage(calc: "adult renal", returnedCrcl: '', premium: premiumTo, unityBannerID: unityBannerID,)),
                                          );
                                          showInterstitial();
                                          if (returnedCrcl != null) {
                                            setState(() {
                                              crclText.text = returnedCrcl; crcl = double.parse(returnedCrcl);
                                            });
                                          }
                                        },
                                            child: Container(color: Colors.grey[200],
                                                alignment: Alignment.center,
                                                padding: const EdgeInsets.all(6),
                                                child: const Text("Calculate Creatinine Clearance for Adults", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black),))),
                                        const SizedBox(height: 16),
                                        GestureDetector(onTap: () async {
                                          Navigator.pop(context);
                                          showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
                                          final returnedCrcl = await Navigator.push(
                                            context,
                                            MaterialPageRoute(builder: (context) =>  CalculatorPage(calc: "children renal", returnedCrcl: '', premium: premiumTo, unityBannerID: unityBannerID,)),
                                          );
                                          showInterstitial();
                                          if (returnedCrcl != null) {
                                            setState(() {
                                              crclText.text = returnedCrcl; crcl = double.parse(returnedCrcl);
                                            });
                                          }
                                        },
                                            child: Container(color: Colors.grey[200],
                                                alignment: Alignment.center,
                                                padding: const EdgeInsets.all(6),
                                                child: const Text("Calculate Creatinine Clearance for Children", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black),))),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                            child: Container( margin: const EdgeInsets.symmetric(horizontal: 5),
                              child: Image.asset(
                                'assets/images/calc_icon.png',
                                width: 34,
                                height: 34,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Visibility(visible: dialysisV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      color: modeColorTheme(context),
                      padding: const EdgeInsets.only(top: 1, bottom: 1, right: 55, left: 55),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(flex: 1,
                            child: Container(height: 40,
                              decoration: BoxDecoration(
                                color: inputColorTheme(context),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: Colors.grey, width: 1,),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                child: Center(
                                  child: DropdownButton2<String>( alignment: AlignmentDirectional.center,
                                    value: selectedDialysis,
                                    items: <String>['Not on Dialysis', 'Hemodialysis', 'Peritoneal Dialysis', 'CRRT'].map((String value) {
                                      return DropdownMenuItem<String>(
                                        alignment: Alignment.center,
                                        value: value,
                                        child: Text(value,  style: TextStyle(
                                          fontSize: 18,
                                          color: blackWhiteText(context),
                                        ),),
                                      );
                                    }).toList(),
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        selectedDialysis = newValue!;
                                        if (newValue == 'Not on Dialysis') {
                                        }
                                        if (newValue == 'Hemodialysis') {
                                        }
                                        if (newValue == 'Peritoneal Dialysis') {
                                        }
                                        if (newValue == 'CRRT') {
                                        }
                                      });
                                    },
                                    underline: Container(),
                                    isExpanded: true,
                                    menuItemStyleData: const MenuItemStyleData(height: 35,),
                                    dropdownStyleData: DropdownStyleData(
                                      padding: EdgeInsets.zero,
                                      decoration: BoxDecoration(
                                        color: blackWhiteBackground(context),
                                      ),),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Visibility(visible: hepaticV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      color: modeColorTheme(context),
                      padding: const EdgeInsets.all(2),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(top: 8, left: 8, right: 8),
                            child: Text(
                              'Child Pugh Score:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Row(
                            children: [
                              Expanded(
                                flex: 2,
                                child: GestureDetector(onTap: () {
                                  setState(() {
                                    pughScore = 'Class A';
                                  });
                                },
                                  child: Row(
                                    children: [
                                      Radio(
                                        value: 'Class A',
                                        groupValue: pughScore,
                                        onChanged: (value) {
                                          setState(() {
                                            pughScore = value.toString();
                                          });
                                        },
                                      ),
                                      const Text('Class A'),
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: GestureDetector(onTap: () {
                                  setState(() {
                                    pughScore = 'Class B';
                                  });
                                },
                                  child: Row(
                                    children: [
                                      Radio(
                                        value: 'Class B',
                                        groupValue: pughScore,
                                        onChanged: (value) {
                                          setState(() {
                                            pughScore = value.toString();
                                          });
                                        },
                                      ),
                                      const Text('Class B'),
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: GestureDetector(onTap: () {
                                  setState(() {
                                    pughScore = 'Class C';
                                  });
                                },
                                  child: Row(
                                    children: [
                                      Radio(
                                        value: 'Class C',
                                        groupValue: pughScore,
                                        onChanged: (value) {
                                          setState(() {
                                            pughScore = value.toString();
                                          });
                                        },
                                      ),
                                      const Text('Class C'),
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(flex: 1,
                                child: GestureDetector(onTap: () async {
                                  showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
                                  final returnedCrcl = await Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) =>  CalculatorPage(calc: "hepatic", returnedCrcl: '', premium: premiumTo, unityBannerID: unityBannerID,)),
                                  );
                                  showInterstitial();
                                  if (returnedCrcl != null) {
                                    setState(() {
                                      crclText.text = returnedCrcl; crcl = double.parse(returnedCrcl);
                                    });
                                  }
                                },
                                  child: Container( margin: const EdgeInsets.symmetric(horizontal: 5),
                                    child: Image.asset(
                                      'assets/images/calc_icon.png',
                                      width: 34,
                                      height: 34,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),

                  Visibility(visible: gerV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 1),
                      color: modeColorTheme(context),
                      padding: const EdgeInsets.only(left: 8, right: 50, bottom: 1, top: 1),
                      child: Row(
                        children: [
                          const Expanded(
                            flex: 1,
                            child: Text(
                              'Age in years: ',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(height: 40,
                              decoration: BoxDecoration(
                                color: inputColorTheme(context),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: gerBorder, width: 1,),
                              ),
                              child: TextFormField(
                                focusNode: gerFocus,
                                decoration: const InputDecoration(
                                  hintText: '60 years or older',
                                  hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                  border: InputBorder.none,
                                ),
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                ],
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                textInputAction: TextInputAction.next,
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                                ),
                                onChanged: (value) {
                                  if (value == '') {
                                    gerAge = 0;
                                  }
                                  else {
                                    gerAge = double.parse(value); setState(() {gerBorder = Colors.grey;});
                                  }
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Visibility(visible: searchLinearV,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 2),
                      color: Colors.grey[400],
                      padding: const EdgeInsets.all(1),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Visibility(visible: switchV,
                            child: GestureDetector(onTap: () {
                              notFoundV = false;
                              setState(() {
                                searchEditText.clear();
                                showAllDrugsShortcut();
                                filterItemsByName("");
                                filterItemsByIndication("");
                                if (searchHint == 'search trade or generic name') {
                                  searchHint = 'search by indication';
                                  // searchBackground = Colors.red[50]!;
                                }
                                else {
                                  searchHint = 'search trade or generic name';
                                  // searchBackground = Colors.white;
                                }
                              });
                              searchEditFocus.requestFocus();
                            },
                              child: Image.asset(
                                'assets/images/switch_search.png',
                                width: 35,
                                height: 35,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child:
                            Container(height: 45,
                              decoration: BoxDecoration(
                                color: HexColor.fromHex(searchBackground(context)),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: Colors.black54, width: 1,),
                              ),
                              child: TextFormField(
                                controller: searchEditText,
                                focusNode: searchEditFocus,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                textAlign: TextAlign.center,
                                textAlignVertical: TextAlignVertical.center,
                                style: TextStyle(fontSize: 20, color: blackWhiteText(context)),
                                decoration: InputDecoration(isDense: true,
                                  hintText: searchHint,
                                  hintStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.normal, fontSize: 18),
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(top: 12, bottom: 12, left: leftSearchPadding, right: 16),
                                  suffixIcon: searchEditText.text.isEmpty
                                      ? null
                                      : IconButton(
                                    icon: Icon(Icons.clear, color: blackWhiteText(context),),
                                    iconSize: 30,
                                    onPressed: () {
                                      searchEditText.clear();
                                      SharedPreferences.getInstance().then((prefs) {
                                        prefs.setString(saveSearchCheckboxValue, '');
                                      });
                                      setState(() {
                                        showAllDrugsShortcut();
                                        filterItemsByName("");
                                        filterItemsByIndication("");
                                        if (_filteredItems.length < 6) {notFoundV = true;} else {notFoundV= false;}
                                      });
                                      //check if keyboard not shown or searchEdit not focused
                                      if (MediaQuery.of(context).viewInsets.bottom == 0 || !searchEditFocus.hasFocus) {
                                        searchEditFocus.unfocus();
                                        Future.delayed(const Duration(milliseconds: 400), () {
                                          searchEditFocus.requestFocus();
                                        });
                                      }
                                    },
                                  ),
                                ),
                                inputFormatters: [
                                  FilteringTextInputFormatter.deny(RegExp(r'[+*()]')),
                                  LengthLimitingTextInputFormatter(15),
                                ],
                                onChanged: (value) async {
                                  setState(() {
                                    final newText = searchEditText.text.replaceAll('  ', ' ');
                                    if (searchEditText.text != newText) {
                                      searchEditText.text = newText;
                                      searchEditText.selection = TextSelection.fromPosition(TextPosition(offset: newText.length));
                                    }
                                    // final newText = value.replaceAll(RegExp(r'\s{2,}'), ' ');
                                    // searchEditText.text = newText;
                                    if (searchHint == 'search trade or generic name') {
                                      showAllDrugsShortcut();
                                      filterItemsByName(value);
                                      if (saveSearchChecked) {
                                        SharedPreferences.getInstance().then((prefs) {
                                          prefs.setString(saveSearchCheckboxValue, searchEditText.text);
                                        });
                                      } else {
                                        SharedPreferences.getInstance().then((prefs) {
                                          prefs.setString(saveSearchCheckboxValue, '');
                                        });
                                      }
                                    }
                                    else {
                                      showAllDrugsShortcut();
                                      filterItemsByIndication(value);
                                    }
                                    if (_filteredItems.length < 6) {notFoundV = true;} else {notFoundV= false;}
                                    if (_filteredItems.isEmpty) {leftSearchPadding = 16;} else {leftSearchPadding = 12;}
                                  });
                                  //tar
                                  if (Platform.isIOS || Platform.isMacOS) {
                                    if (value == raz) {
                                      setState(() {
                                        shdo = true;
                                      });
                                      SharedPreferences prefs = await SharedPreferences.getInstance();
                                      await prefs.setBool('shdo', true);
                                    }
                                  }
                                },
                              ),
                            ),
                          ),
                          // SizedBox(width: 0,
                          //   child: TextFormField(
                          //     style: const TextStyle(color: Colors.transparent),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                  Visibility(visible: favDrugListV,
                    child: Container(margin: const EdgeInsets.only(bottom: 2, top: 1),
                      width: double.infinity,
                      height: null,
                      color: Colors.grey[300],
                      child: Center(
                        child: Row(mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(onTap: () async {
                              showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    contentPadding: const EdgeInsets.all(4),
                                    backgroundColor: blackWhiteBackground(context),
                                    content: Column(mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text("options", textAlign: TextAlign.center, style: TextStyle(decoration: TextDecoration.underline, fontSize: 18, fontWeight: FontWeight.bold, color: blackWhiteText(context)),),
                                        ),

                                        GestureDetector(onTap: () {
                                            setState(() {
                                              _favFilteredItems.sort((a, b) => a['trade']!.compareTo(b['trade']!));
                                              saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                                            });
                                            Navigator.of(context).pop();
                                        },
                                            child: Container(color: denseBlackWhiteBackground(context), padding: const EdgeInsets.symmetric(vertical: 8),
                                                margin: const EdgeInsets.only(bottom: 8), width: double.infinity,
                                                child: Text("sort by name", textAlign: TextAlign.center, style: TextStyle(color: blackWhiteText(context)),))),

                                        GestureDetector(onTap: () {
                                            setState(() {
                                              _favFilteredItems.sort((a, b) => a['color']!.compareTo(b['color']!));
                                              saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                                            });
                                            Navigator.of(context).pop();
                                        },
                                            child: Container(color: denseBlackWhiteBackground(context), padding: const EdgeInsets.symmetric(vertical: 8),
                                                margin: const EdgeInsets.only(bottom: 8), width: double.infinity,
                                                child: Text("sort by color", textAlign: TextAlign.center, style: TextStyle(color: blackWhiteText(context)),))),

                                        if (Platform.isIOS || Platform.isAndroid)
                                          GestureDetector(onTap: () {
                                            setState(() {
                                              sortManually = true;
                                            });
                                            Navigator.of(context).pop();
                                          },
                                              child: Container(color: denseBlackWhiteBackground(context), padding: const EdgeInsets.symmetric(vertical: 8),
                                                  margin: const EdgeInsets.only(bottom: 8), width: double.infinity,
                                                  child: Text("sort manually", textAlign: TextAlign.center, style: TextStyle(color: blackWhiteText(context)),))),

                                        GestureDetector(onTap: () {
                                          Navigator.of(context).pop();
                                          deleteFavDiag();
                                        },
                                            child: Container(color: denseBlackWhiteBackground(context), padding: const EdgeInsets.symmetric(vertical: 8),
                                                margin: const EdgeInsets.only(bottom: 8), width: double.infinity,
                                                child: const Text("delete favourite list", textAlign: TextAlign.center, style: TextStyle(color: Colors.red),))),

                                        GestureDetector(onTap: () {
                                          Navigator.of(context).pop();
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                title: const Text("save"),
                                                content: const Text("save current favorite list online?"),
                                                actions: <Widget>[
                                                  TextButton(
                                                    child: const Text("save"),
                                                    onPressed: () {
                                                      setState(() {
                                                        saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                                                      });
                                                      Navigator.of(context).pop();
                                                    },
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        },
                                            child: Container(color: denseBlackWhiteBackground(context), padding: const EdgeInsets.symmetric(vertical: 8),
                                                margin: const EdgeInsets.only(bottom: 8), width: double.infinity,
                                                child: Text("save list online", textAlign: TextAlign.center, style: TextStyle(color: Colors.greenAccent[700]),))),

                                        GestureDetector(onTap: () {
                                          Navigator.of(context).pop();
                                          if (user != null) {
                                            setState(() {
                                              loadIntentionally = true;
                                              loadFavListCloud();
                                            });
                                          }
                                          else {
                                            setState(() {
                                              BotToast.showText(text: "wait a moment");
                                              loadIntentionally = false;
                                              signInWithGoogle().whenComplete(() => firestore().whenComplete(() => loadFavListCloud()));
                                            });
                                          }
                                        },
                                            child: Container(color: denseBlackWhiteBackground(context), padding: const EdgeInsets.symmetric(vertical: 8),
                                                margin: const EdgeInsets.only(bottom: 0), width: double.infinity,
                                                child: Text("load online list", textAlign: TextAlign.center, style: TextStyle(color: Colors.blueAccent[700]),))),
                                      ],
                                    ),
                                  );
                                },
                              );
                            },
                                child: Icon(Icons.settings, color: Colors.green[800], size: 40)),
                            Expanded(
                              child: Text(
                                'Favourite Drugs List', textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.green[900],
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            GestureDetector(onTap: () async {
                              SharedPreferences prefs = await SharedPreferences.getInstance();
                              if (prefs.getString("lastSync") != null) {
                                lastSync = prefs.getString("lastSync")!;
                              }
                              else {
                                lastSync = "none";
                              }
                              showFavHelpDiag();
                            },
                                child: Icon(Icons.help, color: Colors.green[800], size: 40,)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(color: denseBlackWhiteBackground(context),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.center, mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Visibility(visible: mainDrugListV,
                            child: Flexible(
                                child: ListView.builder(shrinkWrap: true,
                                  itemCount: _filteredItems.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    final item = _filteredItems[index];
                                    return Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        onTap: () {
                                          selectedDrug = item['trade']!;
                                          getDose();
                                        },
                                        onLongPress: () {
                                          if (premium) {
                                            if (_favFilteredItems.any((itemN) => item['trade'] == itemN['trade'])) {
                                              showDialog(
                                                context: context,
                                                builder: (BuildContext context) {
                                                  return const AlertDialog(
                                                    content: Text('already added to favourite list'),
                                                  );
                                                },
                                              );
                                            }
                                            else {
                                              showDialog(
                                                context: context,
                                                builder: (BuildContext context) {
                                                  return AlertDialog(
                                                    title: Text(item['trade']!),
                                                    content: const Text('Add this drug to favourites?'),
                                                    actions: [
                                                      TextButton(
                                                        onPressed: () {
                                                          setState(() {
                                                            _favFilteredItems.add(_filteredItems[index]);
                                                            saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                                                          });
                                                          BotToast.showText(text: "added successfully");
                                                          Navigator.of(context).pop();
                                                        },
                                                        child: const Text('Yes, add'),
                                                      ),
                                                      TextButton(
                                                        onPressed: () {

                                                          Navigator.of(context).pop();
                                                        },
                                                        child: const Text('No'),
                                                      ),
                                                    ],
                                                  );
                                                },
                                              );
                                            }
                                          }
                                        },
                                        child: Container(
                                          decoration: const BoxDecoration(
                                            border: Border(
                                              bottom: BorderSide(
                                                color: Colors.grey,
                                                width: 0.5,
                                              ),
                                            ),
                                          ),
                                          child: ListTile(dense: true,
                                            title: Text(
                                              item['trade']!,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 20,
                                                color: HexColor.fromHex(item['color']!),
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            subtitle: Text(
                                              item['generic']!,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13,
                                                color: HexColor.fromHex(item['color']!),
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                )
                            ),
                          ),
                          Visibility(visible: favDrugListV,
                            child: Flexible(
                                child: ReorderableListView.builder(shrinkWrap: true,
                                  onReorder: (int oldIndex, int newIndex) {
                                    setState(() {
                                      if (newIndex > oldIndex) {
                                        newIndex -= 1;
                                      }
                                      final item = _favFilteredItems.removeAt(oldIndex);
                                      _favFilteredItems.insert(newIndex, item);
                                      saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                                    });
                                  },
                                  itemCount: _favFilteredItems.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    final item = _favFilteredItems[index];
                                    return Material(
                                      key: Key('$index'),
                                      color: Colors.transparent,
                                      child: InkWell(
                                        onTap: () {
                                          selectedDrug = item['trade']!;
                                          getDose();
                                        },
                                        onLongPress: sortManually ? null : () {
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                title: Text(item['trade']!),
                                                content: const Text('Remove this drug from favourites?'),
                                                actions: [
                                                  TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        _favFilteredItems.removeAt(index);
                                                        saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                                                        if (_favFilteredItems.isEmpty) {
                                                          favAddTextV = true;
                                                        }
                                                      });
                                                      Navigator.of(context).pop();
                                                    },
                                                    child: const Text('Yes, remove'),
                                                  ),
                                                  TextButton(
                                                    onPressed: () {

                                                      Navigator.of(context).pop();
                                                    },
                                                    child: const Text('No'),
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        },
                                        child: Container(
                                          decoration: const BoxDecoration(
                                            border: Border(
                                              bottom: BorderSide(
                                                color: Colors.grey,
                                                width: 0.5,
                                              ),
                                            ),
                                          ),
                                          child: ListTile(
                                            title: Text(
                                              item['trade']!,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 20,
                                                color: HexColor.fromHex(item['color']!),
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            subtitle: Text(
                                              item['generic']!,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                                color: HexColor.fromHex(item['color']!),
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                )
                            ),
                          ),
                          Visibility(visible: favDrugListV,
                            child: Container(color: Colors.grey[300], width: double.maxFinite,
                              child: Column(
                                children: [
                                  if (user == null && (Platform.isAndroid || Platform.isIOS))
                                    ElevatedButton(
                                        onPressed: () {
                                          BotToast.showText(text: "wait a moment");
                                          loadIntentionally = false;
                                          signInWithGoogle().whenComplete(() => firestore().whenComplete(() => loadFavListCloud()));
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.green[600],
                                          foregroundColor: Colors.white,
                                        ),
                                        child: const Text("sync favourite list")),
                                  if (user != null && Platform.isIOS)
                                    Row(mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 16),
                                          child: Text('${user?.email}', style: const TextStyle(fontWeight: FontWeight.bold),),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 16),
                                          child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 2),
                                                backgroundColor: Colors.red,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(20),
                                                ),
                                              ),
                                              onPressed: () async {
                                                signOut();
                                              }, child: const Text("Sign out",
                                            style: TextStyle(color: Colors.white),)),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                          ),
                          Visibility(visible: favAddTextV,
                            child: const Padding(
                              padding: EdgeInsets.all(16),
                              child: Text(
                                'Favourite list is empty. Press and hold any drug from the main list to add to the favourite list.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                          Visibility(visible: notFoundV,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 16),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // const Padding(
                                  //   padding: EdgeInsets.all(8),
                                  //   child: Text("Make sure the search word spelled correctly", style: TextStyle(fontSize: 12, color: Colors.grey),),
                                  // ),
                                  Visibility(visible: false,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        const Text(
                                          'Can\'t find the drug you want?',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontStyle: FontStyle.italic,
                                          ),
                                        ),
                                        SizedBox(height: 35,
                                          child: TextButton(
                                            onPressed: () {
                                              searchEditFocus.unfocus(); weightFocus.unfocus(); crclFocus.unfocus(); gerFocus.unfocus(); postNataFocus.unfocus();
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(builder: (context) =>  HelpPage(help: "contact", premium: premiumTo, unityBannerID: unityBannerID)),
                                              );
                                              showInterstitial();
                                            },
                                            child: Text(
                                              'Contact us to add it',
                                              style: TextStyle(
                                                color: Colors.blue[700],
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Text(
                                        'Searching for Topical preparation?',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                      SizedBox(height: 35,
                                        child: TextButton(
                                          onPressed: () async {
                                            searchEditFocus.unfocus(); weightFocus.unfocus(); crclFocus.unfocus(); gerFocus.unfocus(); postNataFocus.unfocus();
                                            if (currentPlatform == "ios" || currentPlatform == "macos") {
                                              await launchUrl(Uri.parse("https://apps.apple.com/us/app/topical-treatment-guide/id6451004185"), mode: LaunchMode.externalApplication);
                                            }
                                            else {
                                              if (currentPlatform == "windows") {
                                                await launchUrl(Uri.parse("https://egydose.com/topical-treatment-guide-windows/"), mode: LaunchMode.externalApplication);
                                              }
                                              else {
                                                await launchUrl(Uri.parse("https://egydose.com/topical-treatment-guide/"), mode: LaunchMode.externalApplication);
                                              }
                                            }
                                          },
                                          child: Text(
                                            'Download TTG app',
                                            style: TextStyle(
                                              color: Colors.blue[700],
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: BottomAppBar(
          padding: EdgeInsets.zero,
          height: bannerHeight,
          elevation: 0,
          child: Visibility(visible: filterBannerV,
            child: Container(alignment: Alignment.center,
              color: filterBannerColor(context),
              height: 40,
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
              child: SingleChildScrollView(scrollDirection: Axis.horizontal,
                child: Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text("filter: ",  style: TextStyle(fontSize: 16,),),
                    GestureDetector(onTap: () {
                      showAllDrugsShortcut();
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: allDrugsFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/all.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.red;
                        drinkFrame = Colors.transparent;
                        syringeFrame = Colors.transparent;
                        suppositoryFrame = Colors.transparent;
                        sachetsFrame = Colors.transparent;
                        inhalersFrame = Colors.transparent;
                        othersFrame = Colors.transparent;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("capsules", "tablets", "odf", "gummies", "capsules", "capsules", "capsules", "capsules");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: tabFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/cap.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.transparent;
                        drinkFrame = Colors.red;
                        syringeFrame = Colors.transparent;
                        suppositoryFrame = Colors.transparent;
                        sachetsFrame = Colors.transparent;
                        inhalersFrame = Colors.transparent;
                        othersFrame = Colors.transparent;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("syrup", "suspension", "drops", "susp", "drink", "drops", "drops", "drops");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: drinkFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/drink.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.transparent;
                        drinkFrame = Colors.transparent;
                        syringeFrame = Colors.red;
                        suppositoryFrame = Colors.transparent;
                        sachetsFrame = Colors.transparent;
                        inhalersFrame = Colors.transparent;
                        othersFrame = Colors.transparent;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("vial", " ampoule", "prefilled pen", "prefilled syringe", "iv solution", "syringes", "cartridges", "flexpen");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: syringeFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/syringe.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.transparent;
                        drinkFrame = Colors.transparent;
                        syringeFrame = Colors.transparent;
                        suppositoryFrame = Colors.red;
                        sachetsFrame = Colors.transparent;
                        inhalersFrame = Colors.transparent;
                        othersFrame = Colors.transparent;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("suppositories", "suppository", "supp", "pessaries", "suppositories", "suppositories", "suppositories", "suppositories");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: suppositoryFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/suppository.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.transparent;
                        drinkFrame = Colors.transparent;
                        syringeFrame = Colors.transparent;
                        suppositoryFrame = Colors.transparent;
                        sachetsFrame = Colors.red;
                        inhalersFrame = Colors.transparent;
                        othersFrame = Colors.transparent;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("sachets", "sachets", "sachets", "sachets", "sachets", "sachets", "sachets", "sachets");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: sachetsFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/sachets.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.transparent;
                        drinkFrame = Colors.transparent;
                        syringeFrame = Colors.transparent;
                        suppositoryFrame = Colors.transparent;
                        sachetsFrame = Colors.transparent;
                        inhalersFrame = Colors.red;
                        othersFrame = Colors.transparent;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("turbuhaler", "nebulizer solution", "inhalation solution", "inhaler", "diskus", "evohaler", "transdermal patch", "enema");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: inhalersFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/inhaler.jpg', width: 38, height: 38,)))),
                    GestureDetector(onTap: () {
                      setState(() {
                        allDrugsFrame = Colors.transparent;
                        tabFrame = Colors.transparent;
                        drinkFrame = Colors.transparent;
                        syringeFrame = Colors.transparent;
                        suppositoryFrame = Colors.transparent;
                        sachetsFrame = Colors.transparent;
                        inhalersFrame = Colors.transparent;
                        othersFrame = Colors.red;
                      });
                      if (searchHint == 'search trade or generic name') {
                        filterItemsByName("");
                        filterItemsByName(searchEditText.text);
                      }
                      else {
                        filterItemsByIndication("");
                        filterItemsByIndication(searchEditText.text);
                      }
                      filterItemsByType("enema", "enema", "enema", "enema", "enema", "enema", "transdermal patch", "enema");
                    },
                        child: Container(padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: othersFrame,
                              borderRadius: BorderRadius.circular(19), // Half of the width and height to make it circular
                            ),
                            child: ClipRRect(borderRadius: BorderRadius.circular(19),
                                child: Image.asset('assets/images/others.jpg', width: 38, height: 38,)))),
                    // const SizedBox(width: 10,),
                    IconButton(padding: const EdgeInsets.all(0),
                      icon: const Icon(Icons.help_outlined, color: Colors.black), iconSize: 22,
                      onPressed: () {
                        filterDiag();
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        // bottomNavigationBar: BottomAppBar(
        //   padding: EdgeInsets.zero,
        //   height: bannerHeight,
        //   elevation: 0,
        //   child: Visibility(visible: filterBannerV,
        //     child: Container(
        //       color: filterBannerColor(context),
        //       height: 40,
        //       padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
        //       child: Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center,
        //         children: [
        //           const Text("filter drugs : ",  style: TextStyle(fontSize: 16,),),
        //           Expanded(flex: 1,
        //             child:
        //             ElevatedButton(
        //                 onPressed :() {
        //                   filterDiag();
        //                 },
        //                 style: ElevatedButton.styleFrom(
        //                   backgroundColor: inputColorTheme(context),
        //                   foregroundColor: blackWhiteText(context),
        //                 ),
        //                 child: Text(selectedFilterText)),
        //           ),
        //         ],
        //       ),
        //     ),
        //   ),
        // ),
      ),
    );
  }

  DecorationImage getImage() {
    if (unityRewardedReady) {
      return const DecorationImage(
        image: AssetImage("assets/images/rewarded_icon_active.png"),
        fit: BoxFit.fill,
      );
    } else {
      return const DecorationImage(
        image: AssetImage("assets/images/rewarded_icon_inactive.png"),
        fit: BoxFit.fill,
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    searchEditFocus.dispose();
    weightFocus.dispose();
    super.dispose();
  }

  // void filterItemsByName(String query) {
  //   setState(() {
  //     _filteredItems = mapList.where((item) {
  //       final search = item['search']!.toLowerCase();
  //       final lowerCaseQuery = query.toLowerCase();
  //       return search.contains(lowerCaseQuery);
  //     }).toList();
  //   });
  // }

  void filterItemsByName(String query) {
    setState(() {
      final List<String> words = query.toLowerCase().split(' ');
      final pattern = words.join('.*'); // Create a regular expression pattern
      _filteredItems = mapList.where((item) {
        final search = item['search']!.toLowerCase();
        return RegExp(pattern).hasMatch(search);
      }).toList();
    });
  }

  // void filterItemsByIndication(String query) {
  //   setState(() {
  //     _filteredItems = mapList.where((item) {
  //       final indications = item['indications']!.toLowerCase();
  //       final lowerCaseQuery = query.toLowerCase();
  //       return indications.contains(lowerCaseQuery);
  //     }).toList();
  //   });
  // }

  void filterItemsByIndication(String query) {
    setState(() {
      final List<String> words = query.toLowerCase().split(' ');
      final pattern = words.join('.*'); // Create a regular expression pattern
      _filteredItems = mapList.where((item) {
        final indications = item['indications']!.toLowerCase();
        return RegExp(pattern).hasMatch(indications);
      }).toList();
    });
  }

  void filterItemsByType(String query1, String query2, String query3, String query4, String query5, String query6, String query7, String query8) {
    setState(() {
      _filteredItems = _filteredItems.where((item) {
        final search = item['search']!.toLowerCase();
        final lowerCaseQuery1 = query1.toLowerCase();
        final lowerCaseQuery2 = query2.toLowerCase();
        final lowerCaseQuery3 = query3.toLowerCase();
        final lowerCaseQuery4 = query4.toLowerCase();
        final lowerCaseQuery5 = query5.toLowerCase();
        final lowerCaseQuery6 = query6.toLowerCase();
        final lowerCaseQuery7 = query7.toLowerCase();
        final lowerCaseQuery8 = query8.toLowerCase();
        return search.contains(lowerCaseQuery1) || search.contains(lowerCaseQuery2) || search.contains(lowerCaseQuery3) || search.contains(lowerCaseQuery4) || search.contains(lowerCaseQuery5) || search.contains(lowerCaseQuery6) || search.contains(lowerCaseQuery7) || search.contains(lowerCaseQuery8);
      }).toList();
    });
  }

  void addItem(String trade, String generic, String search, String color, String indications) {
    Map<String, String> map = {
      "trade": trade,
      "generic": generic,
      "search": search,
      "color": color,
      "indications": indications,
    };
    mapList.add(map);
  }

  // void favAddItem(String trade, String generic, String search, String color, String indications) {
  //   Map<String, String> favMap = {
  //     "trade": trade,
  //     "generic": generic,
  //     "search": search,
  //     "color": color,
  //     "indications": indications,
  //   };
  //   favMapList.add(favMap);
  // }

  void addMainListItems () {
    addItem ("A-viton cap", "Vit A 50000 IU", "a-viton vitamin a 50000iu aviton abivit-a abivita capsules", vitColor(context), "vitamin a deficiency supplementation xerophthalmia");
    addItem ("Abilaxine 10 supp", "Bisacodyl 10 mg", "abilaxine bisacodyl bisadyl adult 10mg suppositories", gitColor(context), "Constipation stimulant laxative");
    addItem ("Abimol supp", "Paracetamol 300 mg", "abimol paracetamol acetaminophen pyremol cetal 300mg suppositories", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Abimol syrup", "Paracetamol 150 mg /5 ml", "Abimol Paracetamol acetaminophen 150mg syrup suspension", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Abstral sublingual tab", "Fentanyl 100/200/400 mcg", "abstral fentanyl 100 200 400mcg sublingual tablets", cnsColor(context), "breakthrough cancer pain Anilinopiperidine opioids analgesics");
    addItem ("Acapril 5 tab", "Enalapril 5 mg", "acapril enalapril presslight renitec ezapril pres 5mg 10mg 20mg tablets", cvsColor(context), "Hypertension Congestive Heart Failure Left Ventricular Dysfunction ace Angiotensin-converting enzyme inhibitors");
    addItem ("Acetapax sach", "N-Acetylcysteine 300 mg +Thyme 100 mg +Vit C 80 mg", "Acetapax acetylcysteine thyme vitamin c ascorbic acid acetothyme sachets", resColor(context), "productive cough mucolytics antioxidant");
    addItem ("Acetylcistein 200 sach", "Acetylcysteine 200 mg", "acetylcistein acetylcysteine acc acenewrax mucolator windy 200mg sachets", resColor(context), "productive cough mucolytics");
    addItem ("Acetylcistein 600 sach", "Acetylcysteine 600 mg", "acetylcistein acetylcysteine acc long acenewrax acetylcystdar fluimucil mucobrave rotacysteine 600mg sachets", resColor(context), "productive cough mucolytics");
    addItem ("Achtenon tab", "Biperiden 2 mg", "Achtenon Biperiden Akenpark Akineton 2mg tablets", cnsColor(context), "Drug-induced Extrapyramidal Symptoms Parkinson's Disease Anticholinergic");
    addItem ("Aciloc 75 tab", "Ranitidine 75 mg", "aciloc ranitidine acilight Epiran 75mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric Ulcer Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Acitretin 10 cap", "Acitretin 10 mg", "acitretin acitretin neotigason psorin unitrin 10mg capsules", otherColor(context), "psoriasis");
    addItem ("Acitretin 25 cap", "Acitretin 25 mg", "acitretin acitretin neotigason psorin unitrin 25mg capsules", otherColor(context), "psoriasis");
    addItem ("Acti-folic tab", "L-methylfolate 1 mg", "acti-folic actifolic optimized L-methylfolate Levomefolic acid 1000mcg 1mg tablets", vitColor(context), "folic acid deficiency depression Megaloblastic Anemia");
    addItem ("Actifed syrup", "Pseudoephedrine 30 mg +Triprolidine 1.25 mg /5 ml", "Actifed Pseudoephedrine Triprolidine histarhine syrup", resColor(context), "Common Cold influenza Nasal Congestion decongestants");
    addItem ("Actifed expectorant syrup", "Pseudoephedrine 30 mg +Triprolidine 1.25 mg +Guaifenesin 100 mg /5 ml", "Actifed expectorant Pseudoephedrine Triprolidine Guaifenesin syrup", resColor(context), "Common Cold influenza Nasal Congestion Cough decongestants");
    addItem ("Actifed tab", "Pseudoephedrine 60 mg +Triprolidine 2.5 mg", "Actifed Pseudoephedrine Triprolidine tablets", resColor(context), "Common Cold influenza Nasal Congestion decongestants");
    addItem ("Actilyse vial", "Alteplase 50 mg", "actilyse alteplase activase 50mg vial", cvsColor(context), "acute myocardial infarction pulmonary embolism ischemic stroke thrombolytic");
    addItem ("Actonel 5 tab", "Risedronate 5 mg", "actonel risedronate actoday risefutal riseonate 5mg tablets", otherColor(context), "Postmenopausal Glucocorticoid-Induced Osteoporosis Paget Disease bisphosphonates");
    addItem ("Actonel 35 tab", "Risedronate 35 mg", "actonel risedronate actoweek risaldene 35mg tablets", otherColor(context), "Postmenopausal Osteoporosis in Men Paget Disease bisphosphonates");
    addItem ("Actos 15 tab", "Pioglitazone 15 mg", "actos pioglitazone actozone diabetin diabetonorm ensudyne glitazen glustazon glustin hi-glitazone higlitazone piojet 15mg 30mg 45mg tablets", hormoneColor(context), "type2 diabetes mellitus Thiazolidinediones");
    addItem ("Actrapid HM vial", "Insulin Regular Human 100 units/ml", "Actrapid hm insulin regular neutral human h bio insulinagypt r insuman rapid 100units/ml vial", hormoneColor(context), "type1 type2 diabetes mellitus severe hyperglycemia dka diabetic ketoacidosis hyperkalemia short-acting insulins");
    addItem ("Adancor 10 tab", "Nicorandil 10 mg", "adancor Nicorandil angilow angiprotect dilikorell 10mg 20mg tablets", cvsColor(context), "angina pectoris vasodilators");
    addItem ("Adol Sinus tab", "Paracetamol 325 mg +Pseudoephedrine 30 mg", "adol sinus paracetamol acetaminophen Pseudoephedrine tablets", resColor(context), "Common Cold Nasal congestion decongestants");
    addItem ("Adrenaline amp", "Adrenaline 1 mg / 1 ml (1/1000)", "Adrenaline adrenamax epinephrine 1mg/ml ampoule", cvsColor(context), "Anaphylaxis Asystole Pulseless Arrest croup alpha/beta adrenergic agonist");
    addItem ("Adrenocortine amp", "Tetracosactide 1 mg /ml", "Adrenocortine tetracosactide synacthen depot acth corticotrophin 1mg/ml ampoule", hormoneColor(context), "ulcerative colitis and Crohn's disease juvenile rheumatoid arthritis osteoarthrosis");
    addItem ("Adwipril 4 tab", "Perindopril 4 mg", "adwipril perindopril coversyl normafasten protectopril 4mg 5mg 8mg 10mg tablets", cvsColor(context), "hypertension cad stable coronary artery disease heart failure ace Angiotensin-converting enzyme inhibitors");
    addItem ("Aggrastat vial", "Tirofiban 12.5 mg /50 ml", "Aggrastat Tirofiban clograstat eupifiban rotagrreste sunnycardio sunny cardio thrombostat 12.5mg/50ml vial", cvsColor(context), "Non-ST Elevation Acute Coronary Syndrome NSTE-ACS antiplatelet");
    addItem ("Agiolax sach", "Ispaghula Husk +Plantago Seed +Senna", "agiolax sachets Ispaghula Husk Plantago Seed Senna", gitColor(context), "constipation laxative");
    addItem ("Agnucaston tab", "Dry extract of the fruit of the chaste tree 20 mg", "agnucaston Dry extract of the fruit of the chaste tree agni casti fructus vitex actus-cactus extract monk's pepper femicure 20mg tablets capsules", otherColor(context), "menstrual disorders mastodynia mastalgia premenstrual syndrome");
    addItem ("Aironyl syrup", "Terbutaline 1.5 mg /5 ml", "aironyl terbutaline bricanyl terbutanyl 1.5mg/5ml syrup", resColor(context), "Bronchospasm bronchial asthma short-acting beta2 agonists");
    addItem ("Aironyl tab", "Terbutaline 2.5 mg", "aironyl terbutaline bricanyl terbutanyl 2.5mg tablets", resColor(context), "Bronchospasm bronchial asthma short-acting beta2 agonists");
    addItem ("Alambuphine amp", "Nalbuphine 20 mg /2 ml", "Alambuphine Nalbuphine nalukemi 20mg/2ml ampoule", cnsColor(context), "pain opioids analgesics anesthesia supplement");
    addItem ("Aldactazide 25/25 tab", "Spironolactone 25 mg +Hydrochlorothiazide 25 mg", "aldactazide spironolactone hydrochlorothiazide spirozide 25/25mg tablets", cvsColor(context), "Hypertension Congestive Heart Failure edema ascites hypokalemia thiazides Potassium Sparing Diuretics");
    addItem ("Aldactone 25 tab", "Spironolactone 25 mg", "aldactone spironolactone epilactone potasave potaspirone spectone 25mg 50mg 100mg tablets", cvsColor(context), "edematous conditions essential hypertension congestive heart failure hypokalemia hirsutism acne vulgaris potassium sparing diuretics");
    addItem ("Aldomet 250 tab", "Methyldopa 250 mg", "aldomet methyldopa adamat alfadopa epidopa kadomet 250mg tablets", cvsColor(context), "Hypertension central acting alpha2 agonists");
    addItem ("Alemox 750 tab", "Amoxicillin 750 mg", "alemox amoxicillin 750 mg tablets", abColor(context), "UTI urinary tract Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Alemox 1 gm tab", "Amoxicillin 1 gm", "alemox amoxicillin ospamox unimox 1000mg 1gm tablets", abColor(context), "UTI urinary tract Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections anthrax Helicobacter Pylori Infective Endocarditis Prophylaxis Penicillins");
    addItem ("Alergoliber syrup", "Rupatadine 5 mg /5 ml", "alergoliber rupatadine rupatadine 5mg/5ml syrup", resColor(context), "Allergic rhinitis allergy urticaria 2nd generation antihistamine");
    addItem ("Alergoliber tab", "Rupatadine 10 mg", "alergoliber rupatadine darupax elirupalin healthtadine hisatrup rupatoclear 10mg tablets", resColor(context), "Allergic rhinitis allergy urticaria 2nd generation antihistamine");
    addItem ("Alertam 60 tab", "Fexofenadine 60 mg", "alertam fexofenadine allerex allerfen fastofen fexostadine 60mg tablets", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Alertam 120 tab", "Fexofenadine 120 mg", "alertam fexofenadine-cid allergyna fastel fastofen fexodine fexon histafree orgofexdine rapido sanzalera telfast 120mg tablets", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Alertam 180 tab", "Fexofenadine 180 mg", "alertam fexofenadine allerfen fastel fastofen fexodine fexolerg fexon linofenadine orgofexdine rapido sanzalera telfast 180mg tablets", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Alertam susp", "Fexofenadine 30 mg /5 ml", "alertam Fexofenadine fexon fexodine fastel telfast 30mg/5ml suspension", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Alexoquine tab", "Chloroquine Phosphate 250 mg", "alexoquine chloroquine phosphate malarquine 250mg tablets", abColor(context), "antiMalaria Extraintestinal Amebiasis Porphyria Cutanea Tarda aminoquinolines");
    addItem ("Alfaclindamycin amp", "Clindamycin 600 mg /4 ml", "Alfaclindamycin dalacin c 600mg/4ml ampoule", abColor(context), "Serious Infections caused by anaerobic bacteria Orofacial Infections Amnionitis Surgical Prophylaxis Neonatal Prophylaxis of Group B Streptococcus Endocarditis Prophylaxis Pneumocystis Carinii lincosamides");
    addItem ("All-Vent syrup", "Terbutaline +Bromhexine +Guaifenesin +Menthol", "allvent all-vent terbutaline sulphate 1.25 bromhexine 4 guaifenesin 50 menthol 2.5mg terhexine fourvent brozedex bro-zedex syrup", resColor(context), "bronchospasm associated with Productive Cough mucolytics expectorant");
    addItem ("Allerban tab", "Ketotifen 2 mg", "allerban Ketotifen 2mg tablets", resColor(context), "Chronic Urticaria Rhinitis Conjunctivitis Prophylaxis of Bronchial asthma mast cell stabilizers");
    addItem ("Allergex tab", "Chlorphenoxamine 20 mg", "Allergex Chlorphenoxamine 20mg tablets", resColor(context), "Allergic rhinitis allergy urticaria antihistamine");
    addItem ("Allergyl syrup", "Chlorpheniramine 2 mg /5 ml", "Allergyl Chlorpheniramine anallerge pirafene 2mg/5ml syrup", resColor(context), "Allergic rhinitis allergy urticaria 1st first generation antihistamines");
    addItem ("Allergyl tab", "Chlorpheniramine 4 mg", "Allergyl Chlorpheniramine anallerge pirafene chlorantine-m 4mg tablets", resColor(context), "Allergic rhinitis allergy urticaria 1st first generation antihistamines");
    addItem ("Alphavim 300 cap", "Alpha Lipoic Acid 300 mg +Vit B6 +Vit B12 +Folic Acid +Ginko Biloba +Bacopa ext.", "alphavim alpha lipoic thioctic acid 300mg capsules vitamins b6 pyridoxine b12 cobalamin b9 folic acid ginko ginkgo biloba bacopa extract", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Alphavim 600 cap", "Alpha Lipoic Acid 600 mg +Vit B6 +Vit B12 +Folic Acid +Ginko Biloba +Bacopa ext.", "alphavim alpha lipoic thioctic acid 600mg capsules vitamins b6 pyridoxine b12 cobalamin b9 folic acid ginko ginkgo biloba bacopa extract", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Alphintern tab", "Chymotrypsin +Trypsin", "alphintern chymotrypsin trypsin ambezimg ambezim-g newbezim tablets", otherColor(context), "Inflammations Oedema");
    addItem ("Alveolin syrup", "Grindelia +Primula +Pimpinella +Thyme +Flora Rose +Eucalyptus", "alveolin Grindelia Primula Pimpinella Thyme Flora Rose Eucalyptus syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Alveolin-P syrup", "Grindelia +Primula +Pimpinella +Thyme +Flora Rose +Anise", "alveolin-p Grindelia Primula Pimpinella Thyme Flora Rose anise syrup", resColor(context), "productive Cough");
    addItem ("Alzental susp", "Albendazole 100 mg /5 ml", "Alzental Albendazole antizole bendax 100mg/5ml suspension", abColor(context), "Entrobius Pinworm oxyuris Ancylostoma Ascariasis Hookworm Trichostrongylus Taenia solium Echinococcus Capillariasis Trichuriasis whipworm Cutaneous Visceral Larva Migrans Fluke Gnathostomiasis Microsporidiosis");
    addItem ("Alzental tab", "Albendazole 200 mg", "Alzental Albendazole antizole bendax vermizole 200mg tablets", abColor(context), "Entrobius Pinworm oxyuris Ancylostoma Ascariasis Hookworm Trichostrongylus Taenia solium Echinococcus Capillariasis Trichuriasis whipworm Cutaneous Visceral Larva Migrans Fluke Gnathostomiasis Microsporidiosis");
    addItem ("Alzmenda drops", "Memantine 10 mg /ml", "alzmenda memantine hydrochloride memexa 10mg/ml drops", cnsColor(context), "Alzheimer-Type Vascular Dementia nmda antagonists");
    addItem ("Alzmenda 5 tab", "Memantine 5 mg", "alzmenda memantine condomania delmenda alzixa dementexa ebixa memantcare memexa pentabixa ravemantine 5mg 10mg 20mg tablets", cnsColor(context), "Alzheimer-Type Vascular Dementia nmda antagonists");
    addItem ("Ambisome vial", "Amphotericin B Liposomal 50 mg", "ambisome amphotericin b liposomal 50mg vial", abColor(context), "Systemic antiFungal infections Candida Auris Cryptococcal Meningitis Visceral Leishmaniasis");
    addItem ("Ambroxol 30 tab", "Ambroxol 30 mg", "ambroxol mucosolvan mucoline 30mg tablets", resColor(context), "Productive Cough mucolytics");
    addItem ("Ambroxol 75 cap", "Ambroxol 75 mg", "Ambroxol bronchopro retard muco mucobroxol mucosin sr 75mg capsules", resColor(context), "Productive Cough mucolytics");
    addItem ("Ambroxol drops", "Ambroxol 7.5 mg /1 ml", "ambroxol mucosin bronchopro 7.5mg drops", resColor(context), "Productive Cough mucolytics");
    addItem ("Ambroxol syrup", "Ambroxol 15 mg /5 ml", "Ambroxol mucofar mucopect pulmosolvan bronchopro sedoproxol mucosolvan 15mg/5ml syrup", resColor(context), "Productive Cough mucolytics");
    addItem ("Amebazole tab", "Secnidazole 1 gm", "amebazole secnidazole cipazole opinidazole 1000mg 1gm tablets", abColor(context), "Trichomoniasis Bacterial Vaginosis nitroimidazoles");
    addItem ("Amigraine tab", "Caffeine +Dipyrone +Ergotamine", "amigraine caffeine dipyrone metamizole analgin ergotamine tablets", cnsColor(context), "migraine");
    addItem ("Amigrawest tab", "Zolmitriptan 2.5 mg", "amigrawest zolmitriptan antimigrozan no-migrain nomigrain z solpadol zomig zolmsolan 2.5mg tablets", cnsColor(context), "migraine treatment Serotonin 5-HT-Receptor Agonists");
    addItem ("Amikacin 100 vial", "Amikacin 100 mg /2 ml", "Amikacin amikin amikabiotic emijectacin vetomikacin 100mg/2ml vial", abColor(context), "Gram -ve negative bacterial UTI urinary tract infections Hospital Acquired Pneumonia aminoglycosides");
    addItem ("Amikacin 250 vial", "Amikacin 250 mg /2 ml", "Amikacin amikin amikaskiv 250mg/2ml vial", abColor(context), "Gram -ve negative bacterial UTI urinary tract infections Hospital Acquired Pneumonia aminoglycosides");
    addItem ("Amikacin 500 vial", "Amikacin 500 mg /2 ml", "Amikacin amikin advomikacin amikabiotic amikaskiv amikaskiv emijectacin remikabiotic vetomikacin 500mg/2ml vial", abColor(context), "Gram -ve negative bacterial UTI urinary tract infections Hospital Acquired Pneumonia aminoglycosides");
    addItem ("Aminoleban solution", "Amino Acids", "Aminoleban amino acids L-Threonine 2.25 L-Serine 2.50 L-Proline 4 L-Cysteine HCl.H2O 0.20 L-Cysteine equivalent 0.15 Aminoacetic acid 4.50 L-Alanine 3.75 L-Valine 4.20 L-Methionine 0.50 L-Isoleucine 4.50 L-Leucine 5.50 L-Phenylalanine 0.50 L-Tryptophan 0.35 L-Histidine HCl.H2O 1.60 L-Histidine equivalent 1.20 Lysine HCl 3.80 L-Lysine equivalent 3.05 L-Arginine HCl 3.65 L-Arginine equivalent 3 aminosteril n hepa gm iv infusion solution", otherColor(context), "hepatic encephalopathy");
    addItem ("Amipride 50 tab", "Amisulpride 50 mg", "amipride amisulpride solian 50mg 100mg 200mg 400mg tablets", cnsColor(context), "schizophrenia Antipsychotics");
    addItem ("Amiprostone 8 cap", "Lubiprostone 8 mcg", "Amiprostone Lubiprostone lubicont lubistone luprostam 8mcg capsules", gitColor(context), "Irritable Bowel Syndrome With Constipation laxative");
    addItem ("Amiprostone 24 cap", "Lubiprostone 24 mcg", "Amiprostone Lubiprostone lubicont lubistone lunaprist 24mcg capsules", gitColor(context), "Chronic Idiopathic Constipation Opioid-Induced Constipation laxative");
    addItem ("Amitriptine 50 tab", "Amitriptyline 50 mg", "amitriptine Amitriptyline 50 mg tablets", cnsColor(context), "depression Postherpetic Neuralgia Migraine Prophylaxis Eating Disorder Analgesia for Chronic Pain tricyclic antidepressants");
    addItem ("Amocerebral Plus tab", "Cinnarizine 20 mg +Dimenhydrinate 40 mg", "Amocerebral Plus Cinnarizine 20mg Dimenhydrinate 40mg tablets", cnsColor(context), "vertigo");
    addItem ("Amosar 50 tab", "Losartan 50 mg", "amosar losartan kanzar lostapressin lozapress cozaar losapott losar losarmepha sanitran remtozar 50mg 100mg tablets", cvsColor(context), "hypertension with left ventricular hypertrophy diabetic nephropathy ARBs Angiotensin receptor blockers");
    addItem ("Amoxil 125 susp", "Amoxicillin 125 mg /5 ml", "Amoxil Amoxicillin biomox emox e-mox amoxycillin amoxicid hicillin hiconcil moxipen 125mg/5ml suspension", abColor(context), "UTI urinary tract Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Amoxil 250 susp", "Amoxicillin 250 mg /5 ml", "amoxil forte Amoxicillin amoxicid amoxycillin biomox emox e-mox hiconcil moxipen 250mg/5ml suspension", abColor(context), "UTI urinary tract Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Ampicillin 125 susp", "Ampicillin 125 mg /5 ml", "Ampicillin epicocillin 125mg/5ml suspension", abColor(context), "Respiratory GIT Genitourinary uti urinary tract infections Penicillins");
    addItem ("Ampicillin 250 susp", "Ampicillin 250 mg /5 ml", "Ampicillin forte epicocillin 250mg/5ml suspension", abColor(context), "Respiratory GIT Genitourinary uti urinary tract infections Penicillins");
    addItem ("Ampicillin 250 cap", "Ampicillin 250 mg", "Ampicillin cid epicocillin 250mg capsules", abColor(context), "Respiratory GIT Genitourinary uti urinary tract infections Penicillins");
    addItem ("Ampicillin 500 cap", "Ampicillin 500 mg", "Ampicillin forte cid epicocillin 500mg capsules", abColor(context), "Respiratory GIT Genitourinary uti urinary tract infections Penicillins");
    addItem ("Ampicillin 250 vial", "Ampicillin 250 mg", "ampicillin epicocillin epicocillin 250mg vial", abColor(context), "gastrointestinal GIT genitourinary UTI urinary Respiratory tract Soft tissue Bacterial meningitis Septicemia Pneumonia endocarditis gonorrhea listeria infections Penicillins");
    addItem ("Ampicillin 500 vial", "Ampicillin 500 mg", "ampicillin epicocillin epicocillin 500mg vial", abColor(context), "gastrointestinal GIT genitourinary UTI urinary Respiratory tract Soft tissue Bacterial meningitis Septicemia Pneumonia endocarditis gonorrhea listeria infections Penicillins");
    addItem ("Ampicillin 1 gm vial", "Ampicillin 1 gm", "ampicillin epicocillin 1000mg 1gm vial", abColor(context), "gastrointestinal GIT genitourinary UTI urinary Respiratory tract Soft tissue Bacterial meningitis Septicemia Pneumonia endocarditis gonorrhea listeria infections Penicillins");
    addItem ("Ampiflux cap", "Ampicillin 250 mg +Flucloxacillin 250 mg", "Ampiflux ampiflux 500mg Ampicillin 250mg Flucloxacillin 250mg capsules", abColor(context), "Respiratory GIT Genitourinary uti urinary tract infections Penicillins");
    addItem ("Ampiflux susp", "Ampicillin 125 mg +Flucloxacillin 125 mg /5 ml", "Ampiflux suspension Ampicillin 125mg Flucloxacillin 125mg", abColor(context), "Respiratory GIT Genitourinary uti urinary tract infections Penicillins");
    addItem ("Amri-K amp", "Vitamin K1 10 mg /ml", "amri-k amrik vitamin k1 phytonadione konakion mm adcokion epikavit haemakion hithrombin phytomenadione phytovit 10mg/ml ampoule", vitColor(context), "Hemorrhagic Disease of the Newborn Hypoprothrombinemia Secondary to Liver Disease or Malabsorption Vit K Deficiency hemostatics");
    addItem ("Amrizole 250 tab", "Metronidazole 250 mg", "amrizole Metronidazole flagyl flagicure metrozole trichocid trichogyl 250mg tablets", abColor(context), "Amebiasis Giardiasis Trichomoniasis Anaerobic Bacterial Vaginosis Colorectal Surgical Prophylaxis Gardenerella infections nitroimidazoles");
    addItem ("Amrizole 500 tab", "Metronidazole 500 mg", "amrizole Metronidazole flagyl flagicure forte dumozol gedazole trichogyl zolguard 500mg tablets", abColor(context), "Amebiasis Giardiasis Trichomoniasis Anaerobic Bacterial Vaginosis Colorectal Surgical Prophylaxis Gardenerella infections nitroimidazoles");
    addItem ("Amrizole susp", "Metronidazole 125 mg /5 ml", "amrizole Metronidazole entophar dumozol flagyl metrozole 125mg/5ml suspension", abColor(context), "Amebiasis GiardiasisTrichomoniasis Clostridium Difficile Colitis Anaerobic infections Bacterial Vaginosis nitroimidazoles");
    addItem ("Anafronil 25 tab", "Clomipramine 25 mg", "Anafronil Clomipramine anapramine supranil 25mg 50mg 75mg tablets", cnsColor(context), "Obsessive-Compulsive Disorder premature ejaculation tricyclic antidepressants");
    addItem ("Andogonium syrup", "Pelargonium Sidoides 13.3 mg /5 ml", "Andogonium pelargonium reniforme sidoides 13.3mg/5ml syrup", resColor(context), "Immunity Enhancer Relieve URTI upper respiratory tract Symptoms");
    addItem ("Andovimpamide syrup", "Lacosamide 50 mg/ 5 ml", "andovimpamide lacosamide lacolepsy 50mg/5ml syrup", cnsColor(context), "Partial Onset Primary Generalized Tonic-Clonic Seizures convulsions epilepsy anticonvulsants");
    addItem ("Andovimpamide 50 tab", "Lacosamide 50 mg", "andovimpamide lacosamide lacosamagic lacosamet lacosanad lacovimp lacosavil 50mg 100mg 150mg 200mg tablets", cnsColor(context), "Partial Onset Primary Generalized Tonic-Clonic Seizures convulsions epilepsy anticonvulsants");
    addItem ("Andovimpamide vial", "Lacosamide 10 mg/ ml", "andovimpamide lacosamide 10mg/ml vial", cnsColor(context), "Partial Onset Primary Generalized Tonic-Clonic Seizures convulsions epilepsy anticonvulsants");
    addItem ("Androcur tab", "Cyproterone 50 mg", "androcur cyproterone acetate 50mg tablets", hormoneColor(context), "prostate cancer Control of libido in severe hypersexuality Antiandrogen");
    addItem ("Anexate amp", "Flumazenil 0.5 mg /5 ml", "anexate flumazenil inresa anexnil benzovieri 0.5mg/5ml ampoule", cnsColor(context), "Reversal of Benzodiazepine Sedation Reversal of Conscious Sedation and General Anesthesia Overdose antidote");
    addItem ("Angiofox 25 PR cap", "Isosorbide Mononitrate 25 mg", "angiofox isosorbide-5-mononitrate effox cardioguard m ismn stada mr angiofox imdur monomak depot sr 25mg 50mg 100mg prolonged release capsules", cvsColor(context), "angina pectoris prophylaxis");
    addItem ("Angiosartan 10 tab", "Olmesartan 10 mg", "angiosartan olmesartan olmeborg olmesab erastapex lezberg normesar vecovartec 10mg 20mg 40mg tablets", cvsColor(context), "Hypertension ARBs Angiotensin receptor blockers");
    addItem ("Angiosartan Plus tab", "Olmesartan +Hydrochlorothiazide", "angiosartan plus olmesartan hydrochlorothiazide erastapex lezberg normesar olmesab olmespironova vecovartec plus tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics");
    addItem ("Anschlarin syrup", "Ferric Fumarate 140 mg (Elemental Iron 45 mg) /5 ml", "Anschlarin ferrous fumarate iron syrup", vitColor(context), "iron deficiency anemia supplementation");
    addItem ("Antiflu cap", "Ibuprofen +Pseudoephedrine +Chlorpheniramine +Caffeine", "antiflu capsules Ibuprofen Pseudoephedrine Chlorpheniramine Caffeine", resColor(context), "Allergic rhinitis common cold influenza sinusitis Nasal congestion decongestants");
    addItem ("Antinal cap", "Nifuroxazide 200 mg", "antinal nifuroxazide diafuryl dia-furyl diax drotavex furfuril intestrelief intest-relief nifunal nitrofurinal 200mg capsules", abColor(context), "Bacterial Gastroenteritis Antidiarrheal");
    addItem ("Antinal susp", "Nifuroxazide 220 mg /5 ml", "Antinal Nifuroxazide diax furfuril intestrelief nifunal intest-relief diafuryl dia-furyl flatrolam 220mg/5ml suspension", abColor(context), "Bacterial Gastroenteritis Antidiarrheal");
    addItem ("Antiver susp", "Mebendazole 100 mg /5 ml", "Antiver Mebendazole antihelmin pentalmin permax vermin 100 mg /5 ml suspension", abColor(context), "Entrobius Pinworm oxyuris Ascaris roundworm whipworm trichuriasis Ancylostoma hookworm Visceral Larva Migrans Toxocariasis Mansonella Perstans Filariasis Giardia Duodenalis Giardiasis");
    addItem ("Antiver tab", "Mebendazole 100 mg", "Antiver Mebendazole mebamox pentalmin vermin 100mg tablets", abColor(context), "Entrobius Pinworm oxyuris Ascaris roundworm whipworm trichuriasis hookworm Ancylostoma Visceral Larva Migrans Toxocariasis Mansonella Perstans Filariasis Giardia Duodenalis Giardiasis");
    addItem ("Antodine 10 tab", "Famotidine 10 mg", "antodine famotidine peptofam 10mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric duodenal Peptic Ulcer heartburn Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Antodine 20 tab", "Famotidine 20 mg", "antodine 20 tablets famotidine 20 mg epcifam tab famotak 20 tab famotin 20 tab gastrodomina 20 tab peptec 20 tab servipep 20 tab", gitColor(context), "GERD gastroesophageal reflux disease Gastric duodenal Peptic Ulcer heartburn Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Antodine 40 tab", "Famotidine 40 mg", "antodine famotidine famotak famotin gastrodomina peptec servipep ulcetech 40mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric duodenal Peptic Ulcer heartburn Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Antodine amp", "Famotidine 20 mg /2 ml", "antodine famotidine gastrotidine 20mg/2ml ampoule", gitColor(context), "GERD gastroesophageal reflux disease Gastric duodenal Peptic Ulcer heartburn Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Antodine susp", "Famotidine 40 mg /5 ml", "antodine famotidine Gastrofam 40mg/5ml suspension", gitColor(context), "GERD gastroesophageal reflux disease Gastric duodenal Peptic Ulcer heartburn Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Antox tab", "Selenium +Vit A +Vit C +Vit E", "antox selenium vitamin a beta carotene vitamin c ascorbic acid vitamin e tocopherol lintovic selenium vit selenium-ace selenostar tablets", vitColor(context), "antioxidant");
    addItem ("Apetryl 0.5 tab", "Clonazepam 0.5 mg", "apetryl clonazepam amotril klozepam rivotril ronatril sigotryl clopam 0.5mg 2mg tablets", cnsColor(context), "seizure disorders panic disorder essential tremor rem sleep behavior disorder burning mouth syndrome tardive dyskinesia Benzodiazepines");
    addItem ("Apexidone syrup", "Risperidone 1 mg /ml", "apexidone risperidone neroschiz psychodal risdal rispadex risperdal schizoperdal 1mg/ml syrup", cnsColor(context), "schizophrenia bipolar mania autism bipolar disorder tourette syndrome posttraumatic stress disorder psychosis agitation related to alzheimer dementia antipsychotics");
    addItem ("Apexidone 0.5 tab", "Risperidone 0.5 mg", "apexidone risperidone itorisperidone psychodal riscure risdal risidrone rispadex risperdal schizodal sigmadone zesperone 0.5mg 1mg 2mg 3mg 4mg tablets", cnsColor(context), "schizophrenia bipolar mania autism bipolar disorder tourette syndrome posttraumatic stress disorder psychosis agitation related to alzheimer dementia antipsychotics");
    addItem ("Apidone syrup", "Dexamethasone +Chlorpheniramine", "apidone Dexamethasone Chlorpheniramine dexaphen phenadone vendexine syrup", strdColor(context), "Allergy Inflammation Corticosteroids 1st first generation antihistamines");
    addItem ("Apidra cartridges/prefilled pen", "Insulin Glulisine 100 units/ml", "Apidra Insulin Glulisine 100units/ml cartridges prefilled pen", hormoneColor(context), "type1 type2 diabetes mellitus rapid-acting insulins");
    addItem ("Apifortyl cap", "Multivitamins +Minerals", "apifortyl capsules Multivitamins a thiamine b1 riboflavin b2 pyridoxine b6 cobalamin b12 d3 C ascorbic acid tocopherol E Folic Acid b9 niacin Nicotinic Acid b3 Nicotinic Acid nicotinamide niacin B5 Calcium pantothenate Biotin b7 copper CU cobalt manganese Mn Royal Jelly Biopterin 10 hydroxydecanoic acid", vitColor(context), "multivitamins minerals supplementation");
    addItem ("Apo-Mefloquine tab", "Mefloquine 250 mg", "apo-mefloquine apomefloquine 250mg tablets", abColor(context), "Acute Antimalarial Infections Prevention");
    addItem ("Appe-raise syrup", "Menthol +Thymol +Pinene +Camphene +Anise", "appe-raise Menthol Thymol Pinene Camphene Anise apperaise syrup", gitColor(context), "loss of appetite appetizer Maldigestion malabsorption");
    addItem ("Apple-Lite tab", "Apple Fiber +Apple Pectin", "apple-lite apple fiber pure apple gel pectin tablets", vitColor(context), "Dietary Supplement during Weight Control Programs");
    addItem ("Apresoline amp", "Hydralazine 20 mg", "apresoline hydralazine 20mg ampoule", cvsColor(context), "Severe Essential Hypertension Hypertensive Crisis Heart Failure Vasodilators");
    addItem ("Apresoline 25 tab", "Hydralazine 25 mg", "apresoline 25 tablets hydralazine 25 mg ardiolazin 25 tab", cvsColor(context), "Severe Essential Hypertension Heart Failure Vasodilators");
    addItem ("Apresoline 50 tab", "Hydralazine 50 mg", "apresoline hydralazine ardiolazin 50mg tablets", cvsColor(context), "Severe Essential Hypertension Heart Failure Vasodilators");
    addItem ("Aqua Plus syrup", "Chamomile +Dill Oil +Sodium Bicarbonate +Caraway Oil +Fennel Oil", "aqua plus aqua cure syrup Chamomile Dill Oil Sodium Bicarbonate Caraway Oil Fennel Oil", gitColor(context), "flatulence gas retention colic");
    addItem ("Arcalion tab", "Sulbutiamine 200 mg", "arcalion sulbutiamine activate cercobion eurobutamine yonatone 200mg tablets", cnsColor(context), "fatigue asthenia psychosomatic disorders");
    addItem ("Arcoxia 60 tab", "Etoricoxib 60 mg", "arcoxia etoricoxib anselacox recoxibright coxinorin coxritor eticoxia etoricoxib-hexal futacoxib rumaximap winzoxib 60mg tablets", analgesicColor(context), "osteoarthritis rheumatoid acute gouty arthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Arcoxia 90 tab", "Etoricoxib 90 mg", "arcoxia etoricoxib anselacox recoxibright averocoxib coxinorin coxritor eticoxia etoricoxib-hexal futacoxib realcoxstar rumaximap winzoxib 90mg tablets", analgesicColor(context), "osteoarthritis rheumatoid acute gouty arthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Aricept 5 tab", "Donepezil 5 mg", "aricept donepezil alkapezil alzaglob alzepizil alzimer donazil donhimer lidemtzil nerhapezil norepezil zymadone 5mg 10mg tablets", cnsColor(context), "dementia of the Alzheimer type");
    addItem ("Aripiprazole 5 tab", "Aripiprazole 5 mg", "aripiprazole abilify apilipex aripiprazole adwiprazole arepexane aripiprex centalify schizofy schizostop abilia aripipracare prazolosab 5mg 10mg 15mg 20mg 30mg tablets", cnsColor(context), "Schizophrenia bipolar mania major depressive disorder antidepressants antipsychotics");
    addItem ("Aripiprex syrup", "Aripiprazole 1mg /ml", "aripiprex aripiprazole schizoswab 1mg/ml syrup", cnsColor(context), "Schizophrenia bipolar mania autism tourette disorder major depressive disorder antidepressants antipsychotics");
    addItem ("Arixtra prefilled syringe", "Fondaparinux", "arixtra prefilled syringes fondaparinux", cvsColor(context), "deep vein thrombosis dvt pulmonary embolism Factor Xa Inhibitor anticoagulants");
    addItem ("Armowake 50 tab", "Armodafinil 50 mg", "armowake armodafinil armovigil wakefinate 50mg tablets", cnsColor(context), "obstructive sleep apnea narcolepsy wakefulness excessive sleepiness shift work sleep disorder CNS Stimulant");
    addItem ("Armowake 150 tab", "Armodafinil 150 mg", "armowake armodafinil armovigil wakefinate armodacure 150mg tablets", cnsColor(context), "obstructive sleep apnea narcolepsy wakefulness excessive sleepiness shift work sleep disorder CNS Stimulant");
    addItem ("Artec tab", "Chondroitin +Glucosamine", "artec chondroitin glucosamine chondrogen chondvell ossaforten sharkilage sportive capsules tablets", analgesicColor(context), "Osteoarthritis");
    addItem ("Arthineur cap", "Diclofenac Na +Vit B1 +Vit B6 +Vit B12", "arthineur diclofenac na sodium vitamin b1 thiamine vitamin b6 pyridoxine vitamin b12 cyanocobalamin diclonerve painreliefer neurofenac capsules", analgesicColor(context), "Neuritis neuralgia arthrosis Chronic polyarthritis spondylitis ankylosans inflammations pain analgesic acute gout rheumatism");
    addItem ("Arthrofast 150 SR tab", "Diclofenac Na 150 mg", "Arthrofast diclofenac sodium na diclac diclopro 150mg sr tablets", analgesicColor(context), "rheumatoid osteoarthritis Ankylosing Spondylitis Pain analgesics Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Aspocid 75 tab", "Acetylsalicylic Acid 75 mg", "aspocid acetylsalicylic acid aspirin pediatric paediatric ezacard rivo aggrex 75mg tablets", analgesicColor(context), "fever pain analgesics antipyretics Juvenile Rheumatoid Arthritis Inflammations Kawasaki Disease Acute Coronary Syndrome Primary ASCVD Prevention Ischemic Stroke TIAs Antiplatelet transient ischemic attacks Colorectal Cancer Prophylaxis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Aspocid 300 tab", "Acetylsalicylic Acid 300 mg", "aspocid acetylsalicylic acid aspain rivo aggrex asponasr ecoprin rivomicro aspocid buffer 250 300 320 325mg tablets", analgesicColor(context), "fever pain analgesics antipyretics Juvenile Rheumatoid Arthritis Inflammations Kawasaki Disease Acute Coronary Syndrome Primary ASCVD Prevention Ischemic Stroke TIAs transient ischemic attacks Colorectal Cancer Prophylaxis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Aspirin Protect tab", "Acetylsalicylic Acid 100 mg", "aspirin protect acetylsalicylic acid rivo asprotect cardiprin aspocard 100 150mg tablets", analgesicColor(context), "fever pain analgesics antipyretics Juvenile Rheumatoid Arthritis Inflammations Kawasaki Disease Acute Coronary Syndrome Primary ASCVD Prevention Ischemic Stroke TIAs Antiplatelet transient ischemic attacks Colorectal Cancer Prophylaxis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Aspirin 500 tab", "Acetylsalicylic Acid 500 mg", "aspirin acetylsalicylic acid 500mg tablets", analgesicColor(context), "fever pain analgesics antipyretics Juvenile Rheumatoid Arthritis Inflammations Kawasaki Disease Acute Coronary Syndrome Primary ASCVD Prevention Ischemic Stroke TIAs transient ischemic attacks Colorectal Cancer Prophylaxis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Asthmarelief 2.5 nebulizer solution", "Salbutamol 0.1% (2.5 mg /2.5 ml)", "Asthmarelief Salbutamol albuterol 2.5mg/2.5ml 0.1% nebulizer solution", resColor(context), "acute severe bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Asthmarelief 5 nebulizer solution", "Salbutamol 0.2% (5 mg /2.5 ml)", "Asthmarelief Salbutamol albuterol 5mg/2.5ml 0.2% nebulizer solution", resColor(context), "acute severe bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Atacand 4 tab", "Candesartan 4 mg", "atacand candesartan candalkan candesar albustix blopress candeblock globacand holdisar candepressin 4mg 8mg 16mg 32mg tablets", cvsColor(context), "Hypertension Congestive Heart Failure ARBs Angiotensin receptor blockers");
    addItem ("Atacand Plus tab", "Candesartan +Hydrochlorothiazide", "atacand plus Candesartan hydrochlorothiazide albustix d blopress plus candalkan plus candeblock d candesar comp geocand plus sarcozide tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics");
    addItem ("Atconafil 100 tab", "Avanafil 100 mg", "Atconafil Avanafil avanjoy easyrect erectawest erovanafile 100mg 200mg tablets", urinaryColor(context), "erectile dysfunction Phosphodiesterase-5 Enzyme Inhibitor");
    addItem ("Atenoretic cap", "Atenolol 50 mg +Hydrochlorothiazide 25 mg +Amiloride 25 mg", "Atenoretic Atenolol Hydrochlorothiazide Amiloride hipress-d capsules", cvsColor(context), "hypertension Beta-1 selective blockers thiazides Potassium Sparing Diuretics class II 2 antiarrhythmic agents");
    addItem ("Atimos inhalation solution", "Formoterol Fumarate 12 mcg", "Atimos Formoterol Fumarate bronchostim 12mcg inhalation solution", resColor(context), "bronchial asthma maintenance copd chronic obstructive pulmonary disease long-acting Beta2 Agonists");
    addItem ("Ativan tab", "Lorazepam 1 mg", "ativan lorazepam 1mg tablets", cnsColor(context), "Anxiety Disorders Chronic Insomnia Anxiolytic Sedation Agitation Chemotherapy-Induced Nausea/Vomiting Benzodiazepines");
    addItem ("Atomorelax syrup", "Atomoxetine 20 mg /5 ml", "atomorelax atomoxetine atomoxapex 20mg/5ml syrup", cnsColor(context), "adhd attention-deficit/hyperactivity disorder selective norepinephrine reuptake inhibitors SNRIs");
    addItem ("Atomox apex 10 cap", "Atomoxetine 10 mg", "atomoxapex atomoxetine atomafutix genettera Kemoxetin strattera 10mg 18mg 25mg 40mg 60mg capsules", cnsColor(context), "adhd attention-deficit/hyperactivity disorder selective norepinephrine reuptake inhibitors SNRIs");
    addItem ("Ator 10 tab", "Atorvastatin 10 mg", "ator atorvastatin antichol atorstat borgastatin fatestatin lipicole lipiless lipinorm lipitor lipomax lipona lipovast prevenvast satogler adrobega cholestglob lirimar orgovastin rostatine sigmalip torastatin torvast vonteroid 10mg 20mg 40mg 80mg tablets", cvsColor(context), "familial hypercholesterolemia hyperlipidemia hypertriglyceridemia cardiovascular disease prevention HMG-CoA Reductase Inhibitor Statins");
    addItem ("Atoreza tab", "Atorvastatin +Ezetimibe", "atoreza atorvastatin ezetimibe atozet atrozemb ezastatin pencard tablets", cvsColor(context), "familial hypercholesterolemia hyperlipidemia hypertriglyceridemia HMG-CoA Reductase Inhibitor Statins Antilipemic Agents");
    addItem ("Atropine amp", "Atropine Sulphate 1 mg /ml", "atropine sulphate sulfate 0.1% 1mg/ml ampoule", cvsColor(context), "Anesthesia Premedication Sinus Bradycardia Bronchospasm Organophosphate Poisoning Mushroom Poisoning Cardiopulmonary Resuscitation Antidote to Cholinesterase Inhibitors");
    addItem ("Atrovent 0.25 nebulizer solution", "Ipratropium Bromide 250 mcg /2 ml", "atrovent ipratropium bromide mylan asmatropim 0.250mg mcg/2ml nebulizer solution", resColor(context), "acute severe bronchospasm bronchial asthma exacerbation copd chronic obstructive pulmonary disease bronchitis emphysema bronchodilators");
    addItem ("Atrovent 0.5 nebulizer solution", "Ipratropium Bromide 500 mcg /2 ml", "atrovent ipratropium bromide mylan asmatropim 0.500mg mcg/2ml nebulizer solution", resColor(context), "acute severe bronchospasm bronchial asthma exacerbation copd chronic obstructive pulmonary disease bronchitis emphysema bronchodilators");
    addItem ("Augmentin 62.5 drops", "Amoxicillin 50 mg +Clavulanate 12.5 mg /5 ml", "Augmentin 62.5mg drops Amoxicillin 50mg Clavulanate clavulanic acid 12.5mg/5ml", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 156.25 susp", "Amoxicillin 125 mg +Clavulanate 31.25 mg /5 ml", "Augmentin Amoxicillin 125mg Clavulanate clavulanic acid 31.25mg curam emoxclav e-moxclav larynclave megaclavox magnabiotic gardinova clavucin 156.25mg/5ml suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin duo 228.5 susp", "Amoxicillin 200 mg +Clavulanate 28.5 mg /5 ml", "Augmentin duo Amoxicillin 200mg Clavulanate clavulanic acid 28.5 amoclawin augmacillin augram clavimox curam deltaclav magnabiotic230 megamox amoxilanic emoxclav klavox e-moxclav hibiotic n 228.5mg/5ml suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 312.5 susp", "Amoxicillin 250 mg +Clavulanate 62.5 mg /5 ml", "Augmentin Amoxicillin 250mg Clavulanate clavulanic acid 62.5mg clavimox curam hibiotic emoxclav e-moxclav dexiclave gardinova larynclave magnabiotic 312.5mg/5ml suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 457 susp", "Amoxicillin 400 mg +Clavulanate 57 mg /5 ml", "Augmentin Amoxicillin 400mg Clavulanate clavulanic acid 57mg amoclawin augmacillin augram clavimox curam deltaclav hibiotic larynclave megamox magnabiotic460 new-clav newclav amoxilanic dexiclave emoxclav e-moxclav gardinova klavox 457mg/5ml suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin ES 600 susp", "Amoxicillin 600 mg +Clavulanate 42.9 mg /5 ml", "Augmentin ES Amoxicillin 600mg Clavulanate clavulanic acid 42.9mg augram clavimox curam deltaclav emoxclav e-moxclav hibiotic new-clav newclav augmentin averobios megamox es 600 642.9mg suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 375 tab", "Amoxicillin 250 mg +Clavulanate 125 mg", "augmentin Amoxicillin 250mg Clavulanate clavulanic acid 125mg clavocillin clavosigma clavucin dexiclave emoxclav e-moxclav hibiotic magnabiotic 375mg tablets", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 625 tab", "Amoxicillin 500 mg +Clavulanate 125 mg", "augmentin Amoxicillin 500mg Clavulanate clavulanic acid 125mg aujed clavucin dexiclave emoxclav e-moxclav hibiotic magnabiotic clavimox curam deltaclav maclavex megamox ultramox 625mg tablets", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 1 gm tab", "Amoxicillin 875 mg +Clavulanate 125 mg", "augmentin Amoxicillin 875mg Clavulanate clavulanic acid 125mg amoclawin clavosigma julmentin augram clavocillin dexiclave emoxclav e-moxclav hibiotic magnabiotic clavimox curam fondaclav klavox maclavex megamox ultramox clasynmo newclav new-clav 1gm tablets", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess Penicillins");
    addItem ("Augmentin 600 vial", "Amoxicillin 500 mg +Clavulanate 100 mg", "Augmentin Amoxicillin 500mg Clavulanate clavulanic acid 100mg clavucin magnabiotic 600mg vial", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess");
    addItem ("Augmentin 1.2 gm vial", "Amoxicillin 1 gm +Clavulanate 200 mg", "Augmentin Amoxicillin 1000mg Clavulanate clavulanic acid 200mg clavucin magnabiotic curam megaclavox 1.2gm vial", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Bite wounds Erysipelas Pyelonephritis Skin abscess");
    addItem ("Avastin vial", "Bevacizumab 25 mg /ml", "Avastin Bevacizumab mvasi 25mg/ml vial", otherColor(context), "Metastatic Colorectal Cancer Non-Small Cell Lung Cancer Renal Cell Carcinoma Cervical Cancer Ovarian cancer Fallopian Tube cancer Peritoneal Cancer Glioblastoma Exudative ARMD exudative age-related macular degeneration Hepatocellular Carcinoma Antineoplastic Agents Monoclonal Antibody");
    addItem ("Averozolid susp", "Linezolid 100 mg /5 ml", "Averozolid Linezolid bactizolid debacozolin jadozolid linezox oxazolid sazimoline strainoliz zyvox zyvoxenam 100mg/5ml suspension", abColor(context), "Skin Pneumonia MRSA Methicillin-Resistant MSSA Methicillin-Susceptible Staphylococcus Aureus Vancomycin-resistant Enterococcal Infections Oxazolidinones");
    addItem ("Averozolid tab", "Linezolid 600 mg", "Averozolid Linezolid oxazolid debacozolin elixozolid jadozolid linez linezox oxazolid respenzo therazolide vilzolid voxazoldin 600mg tablets", abColor(context), "Skin Pneumonia MRSA Methicillin-Resistant MSSA Methicillin-Susceptible Staphylococcus Aureus Vancomycin-resistant Enterococcal Infections Oxazolidinones");
    addItem ("Averozolid vial", "Linezolid 2 mg /ml", "Averozolid linezolid linezomentin voxazoldin zyvox zyvoxinam 2mg/ml vial", abColor(context), "Skin Pneumonia MRSA Methicillin-Resistant MSSA Methicillin-Susceptible Staphylococcus Aureus Vancomycin-resistant Enterococcal Infections Oxazolidinones");
    addItem ("Avil amp", "Pheniramine 45.5 mg /2 ml", "avil pheniramine 45.5mg/2ml ampoule", resColor(context), "allergy allergic conditions hypersensitivity reactions urticaria eczema 1st first generation antihistamines");
    addItem ("Avipect syrup", "Ammonium Chloride +Pheniramine", "avipect syrup ammonium chloride pheniramine", resColor(context), "Productive Cough");
    addItem ("Avipiravir tab", "Favipiravir 200 mg", "avipiravir favipiravir anviziram epifluver pirafavi pirastopivir privanork 200mg tablets", abColor(context), "pandemic influenza virus infection");
    addItem ("Avodart cap", "Dutasteride 0.5 mg", "avodart dutasteride bengiride prostplasia sigdutaster 0.5mg capsules", urinaryColor(context), "benign prostatic hyperplasia bph 5 Alpha-Reductase Inhibitor");
    addItem ("Avonex syringes", "Interferon Beta-1a 30 mcg/ 0.5 ml", "avonex interferon beta-1a syringes", otherColor(context), "multiple sclerosis");
    addItem ("Azathioprine 50 tab", "Azathioprine 50 mg", "azathioprine azathioprine azarin imuran 50mg tablets", otherColor(context), "kidney transplantation lupus nephritis rheumatoid arthritis crohn disease ulcerative colitis chronic refractory thrombocytopenic purpura immunosuppressive agents");
    addItem ("Azomycin 250 cap", "Azithromycin 250 mg", "Azomycin azithromycin azalide azatribact azionce azi-once azithromin aziwok neozolid zithromax 250mg capsules tablets", abColor(context), "Pharyngitis tonsillitis Acute otitis media Community-acquired Pneumonia Cat Scratch Disease Acute Bacterial Exacerbation of COPD Sinusitis Uncomplicated Skin infections Pertussis Chancroid Urethritis Cervicitis Endocarditis Prophylaxis Macrolides");

    addItem ("B-com amp", "Vit B complex", "b-com bcom vitamin b1 thiamine vitamin b2 riboflavin vitamin b3 Nicotinic Acid nicotinamide niacin vitamin b5 d-panthenol vitamin b6 pyridoxine becozyme power b complex ampoule", vitColor(context), "vitamin b deficiency supplementation");
    addItem ("Babeton syrup", "Thyme +Fennel +Bee Propolis +Rose Hips", "babeton syrup thyme fennel bee propolis rose hips", resColor(context), "Cough");
    addItem ("Baby rest drops", "Simethicone 40 mg /0.6 ml", "Baby rest drops Simethicone 40mg/0.6ml", gitColor(context), "Flatulence colic gas retention");
    addItem ("Balsam syrup", "Guava +Tilia +Fennel +Honey +Thyme", "Balsam Guava Tilia Fennel Honey Thyme fruity flavour syrup", resColor(context), "cough");
    addItem ("Bebe-vit drops", "Multivitamins", "bebe-vit drops bebevit Multivitamins a b1 thiamine b2 riboflavin b6 pyridoxine Nicotinic Acid nicotinamide niacin b3 c ascorbic acid d3 e tocopherol", vitColor(context), "multiVitamins Supplementation");
    addItem ("Beclosone inhaler", "Beclomethasone 50 mcg /dose", "beclosone beclomethasone viarex 50mcg/dose inhaler", resColor(context), "bronchial asthma maintenance Corticosteroid");
    addItem ("Beclosone forte inhaler", "Beclomethasone 100 mcg /dose", "beclosone forte beclomethasone 100mcg/dose inhaler", resColor(context), "bronchial asthma maintenance Corticosteroids");
    addItem ("Bedremine 50 ER tab", "Desvenlafaxine 50 mg", "bedremine desvenlafaxine desvenlafaxine prismaven pristimood sr pristiq venlatrope 50mg er tablets", cnsColor(context), "major depressive disorder antidepressants selective serotonin and norepinephrine reuptake inhibitors SSNRIs");
    addItem ("Betacor tab", "Sotalol 80 mg", "betacor sotalol betasotal sotaloc 80mg 160mg tablets", cvsColor(context), "Life-threatening ventricular arrhythmias Atrial fibrillation flutter nonselective beta-blocker class III 3 antiarrhythmic agents");
    addItem ("Betafos amp", "Betamethasone 14 mg /2 ml", "betafos betamethasone diprofos demancortil dexaglobe diprocortin durafos 14mg/2ml ampoule", strdColor(context), "Inflammation Multiple Sclerosis Inflammatory Conditions Tenosynovitis Peritendinitis Bursitis rheumatoid osteoarthritis Corticosteroids Corticosteroids");
    addItem ("Betallerge tab", "Betamethasone +Dexchlorpheniramine maleate", "betallerge tablets betamethasone 0.25mg dexchlorpheniramine maleate 2mg", resColor(context), "Allergic rhinitis allergy inflammations bronchial asthma Corticosteroids 1st first generation antihistamines");
    addItem ("Betaserc 8 tab", "Betahistine 8 mg", "betaserc betahistine betasine histaseric histine histotec microserc steadyfutal verserc balanserc mepahist vertiserc advoserc betabalance 8mg 16mg 24mg tablets", cnsColor(context), "meniere's syndrome vestibular vertigo Histamine H1 Agonist");
    addItem ("Betaxolol 10 tab", "Betaxolol 10 mg", "betaxolol betaxolol 10mg 20mg tablets", cvsColor(context), "hypertension Beta-1 selective blockers");
    addItem ("Betmiga 25 tab", "Mirabegron 25 mg", "betmiga mirabegron mirablad bladogra uribladon flowadjust flow adjust 25mg 50mg tablets", urinaryColor(context), "neurogenic Detrusor Ovaractivity overactive bladder Beta3 adrenoceptor Agonist");
    addItem ("Betolvex amp", "Cyanocobalamin (Vit B12) 1 mg /ml", "betolvex cyanocobalamin vitamin b12 beto12 beto-12 cidolvex rubivamin 1000 mcg mg/ml ampoule", vitColor(context), "Pernicious anemia Vitamin B12 deficiency supplementation");
    addItem ("Bi-Alcofan tab", "Ketoprofen 150 mg", "bi-alcofan ketoprofen bialcofan bi-ketogesic biketogesic bi-profenid biprofenid flamoguard xr ketorest sr mepacofen l.a. 150mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Biltricide tab", "Praziquantel 600 mg", "biltricide praziquantel epiquantel distocide bilharzine 600mg tablets", abColor(context), "Schistosomiasis bilharziasis Clonorchiasis Opisthorchiasis Cysticercosis Tapeworms");
    addItem ("Bioglita Plus 15/500 tab", "Pioglitazone 15 mg +Metformin 500 mg", "Bioglita Plus pioglitazone 15mg metformin 500mg averofage diabetonorm plus glustacomb pioglumet piomet suganorm diabetin plus 15/500 tablets", hormoneColor(context), "type2 diabetes mellitus Thiazolidinediones Biguanides");
    addItem ("Bional cap", "Silymarin +Lecithin +Astragalus +Zinc Ascorbate +Selenium +Vit C", "bional capsules Silymarin milk thistle Lecithin Astragalus Zinc Ascorbate Selenium vitamin c ascorbic acid", gitColor(context), "Liver Tonic support supplementation");
    addItem ("Biostrong cap", "Ginseng +Royal Jelly +Wheat Germ Oil", "biostrong ginseng royal jelly wheat germ oil life line g.r.o lifeline queen 2500 royal care capsules", vitColor(context), "fatigue asthenia loss of concentration premature aging erectile dysfunction weakness exhaustion tiredness improving physical and mental efficiency");
    addItem ("Biotin Forte cap", "Biotin (Vitamin B7) 5 mg", "biotin forte vitamin b7 azgobion probiontal coenzyme r vit h vitammin h 5mg capsules tablets", vitColor(context), "vitamin b7 biotin deficiency supplementation brittle fingernails diabetes alopecia hair loss");
    addItem ("Biovit-12 Depot amp", "Hydroxocobalamin 1 mg +Folic Acid 1 mg +Vit B6 20 mg /2 ml", "biovit-12 depot Hydroxocobalamin vitamin b12 folic acid vitamin b9 vitamin b6 pyridoxine biovit 12 ampoule", vitColor(context), "megaloblastic Pernicious anemia Vitamin B12 deficiency supplementation peripheral neuropathy neuritis");
    addItem ("Biovita gummies", "Vitamins +Minerals", "biovita gummies Multivitamins a pyridoxine b6 cobalamin b12 d ascorbic acid C tocopherol E Folic Acid b9 b3 Nicotinic Acid nicotinamide niacin b7 biotin B5 pantothenic acid iodine zinc choline inositol b8", vitColor(context), "minerals vitamins deficiency supplementation");
    addItem ("Bisadyl 5 tab", "Bisacodyl 5 mg", "bisadyl bisacodyl abilaxine constacodyl dulcolax 5mg tablets", gitColor(context), "constipation stimulant laxative");
    addItem ("Bisadyl 5 supp", "Bisacodyl 5 mg", "bisadyl bisacodyl abilaxine 5mg infantile children suppositories", gitColor(context), "constipation stimulant laxative");
    addItem ("Bismuth Oxide tab", "Bismuth Oxide 120 mg", "Bismuth Oxide 120mg tablets", gitColor(context), "Gastric Ulcer duodenal ulcer Peptic Ulcer heartburn acute gastritis chronic gastritis functional dyspepsia irritable bowel syndrome ibs");
    addItem ("Bisolvon amp", "Bromhexine 4 mg /2 ml", "Bisolvon Bromhexine 4mg/2ml ampoule", resColor(context), "Productive Cough mucolytics");
    addItem ("Bisolvon drops", "Bromhexine 2 mg /1 ml", "Bisolvon Bromhexine solvin 2mg/ml drops", resColor(context), "Productive Cough mucolytics");
    addItem ("Bisolvon syrup", "Bromhexine 4 mg /5 ml", "Bisolvon Bromhexine muclear solvin n solvolytic 4mg/5ml syrup", resColor(context), "Productive Cough mucolytics");
    addItem ("Bisolvon tab", "Bromhexine 8 mg", "Bisolvon Bromhexine solvin 8mg tablets", resColor(context), "Productive Cough mucolytics");
    addItem ("Bistol Plus tab", "Bisoprolol +Hydrochlorothiazide", "bistol plus bisoprolol hydrochlorothiazide lodoz aptoful bisocard plus bisolock-d bisolock d cardiocid cardivo-care cardivo care cardivocare concor plus contropace-h contropace h soprol plus tablets", cvsColor(context), "hypertension Beta-1 selective blockers thiazides Diuretics class II 2 antiarrhythmic agents");
    addItem ("Bonapex 70 tab", "Alendronate 70 mg", "bonapex alendronate alendronic acid alendex alendomax Alendene bonalene osteonate fosamax once weekly ostomax osteomepha 70mg tablets", otherColor(context), "osteoporosis bisphosphonates");
    addItem ("Bonidon cap", "Indomethacin 75 mg", "bonidon indomethacin 75mg capsules", analgesicColor(context), "Inflammatory Disorders Rheumatoid Disorders/ Bursitis Tendinitis Acute Gouty Arthritis Nephrogenic DI nephrogenic diabetes insipidus Pain analgesics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Bran cap", "Bran 400 mg", "bran 400mg capsules", gitColor(context), "control weight constipation");
    addItem ("Bravamax tab", "Modafinil 200 mg", "bravamax modafinil modasomil modifree 200mg tablets", cnsColor(context), "obstructive sleep apnea narcolepsy wakefulness excessive sleepiness shift work sleep disorder cns stimulant");
    addItem ("Brestto tab", "Herbs +Vitamins", "brestto tablets Fenugreek Caraway Anise Chamomile Dill Fennel Beta Carotene Multivitamins a b1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin b5 d-panthenol b6 pyridoxine b7 biotin b8 inositol b9 folic acid b12 Cyanocobalamin complex c ascorbic acid d tocopherol e", vitColor(context), "Improve the function of lactating glands Improve the gastrointestinal function");
    addItem ("Brilique tab", "Ticagrelor 60 mg & 90 mg", "brilique ticagrelor lintaram thrombolinta thromborest ticaloguard westgrelor 60 90mg tablets", cvsColor(context), "Acute Coronary Syndrome or History of myocardial infarction MI Coronary Artery Disease Acute Ischemic Stroke transient ischemic attacks TIA Antiplatelets");
    addItem ("Bristaflam tab", "Aceclofenac 100 mg", "bristaflam aceclofenac aceclocopa aceliofinaz amoflam fenac lambroflam 100mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis Ankylosing Spondylitis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Bronchicum syrup", "Thyme +Primula", "bronchicum primula root thyme fluid extract nexibronch broncandes syrup", resColor(context), "Cough");
    addItem ("Broncho-vaxom adult cap", "Bacterial lysates 7 mg", "Broncho-vaxom bronchovaxom Lyophilized Bacterial Lysates of H. Influenzae, Diplococcus Pneumoniae, Klebsiella Pneumonia and Ozaenae, Staph. Aureus, Strept. Pyogenes and Viridans, Neisseria Catarrhalis 7mg adult capsules", resColor(context), "Prophylaxis of recurrent Acute chest infections");
    addItem ("Broncho-vaxom children cap", "Bacterial lysates 3.5 mg", "Broncho-vaxom bronchovaxom Lyophilized Bacterial Lysates of H. Influenzae, Diplococcus Pneumoniae, Klebsiella Pneumonia and Ozaenae, Staph. Aureus, Strept. Pyogenes and Viridans, Neisseria Catarrhalis 3.5mg children capsules", resColor(context), "Prophylaxis of recurrent Acute chest infections");
    addItem ("Broncho-vaxom children sach", "Bacterial lysates 3.5 mg", "Broncho-vaxom bronchovaxom Lyophilized Bacterial Lysates of H. Influenzae, Diplococcus Pneumoniae, Klebsiella Pneumonia and Ozaenae, Staph. Aureus, Strept. Pyogenes and Viridans, Neisseria Catarrhalis 3.5mg children sachets", resColor(context), "Prophylaxis of recurrent Acute chest infections");
    addItem ("Bronchotec syrup", "Dextromethorphan +Guaifenesin", "Bronchotec dextromethorphan Guaifenesin vicksolytic guaiadesca syrup", resColor(context), "cough");
    addItem ("Bronchophane syrup", "Guaifenesin +Ephedrine +Diphenhydramine +Dextromethorphan", "Bronchophane Guaifenesin Ephedrine Diphenhydramine Dextromethorphan tusskan syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Broleaves syrup", "Ivy leaf +Thyme +Liquorice", "broleaves Thyme Liquorice ivy leaf leaves valulit tutis mardex ziawet ivycan ivywell chesty tri thyme zed helixbrom mave tec ivy spir ventoherb vento herb zad syrup", resColor(context), "Productive Cough mucolytics expectorant");
    addItem ("Brufen 200 tab", "Ibuprofen 200 mg", "brufen ibuprofen dajuanofen ibufen mafo novaprofen nova profen nova-profen profinal profusol rapifen ultrafen 200mg tablets capsules", analgesicColor(context), "fever pain analgesics antipyretics Dysmenorrhea Inflammation Osteoarthritis Rheumatoid Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Brufen 400 tab", "Ibuprofen 400 mg", "brufen ibuprofen dajuanofen flabu flamotal ibufen mafo marcofen novaprofen nova-profen profinal profusol ultrafen 400mg tablets capsules", analgesicColor(context), "fever pain analgesics antipyretics Dysmenorrhea Inflammation Osteoarthritis Rheumatoid Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Brufen 600 tab", "Ibuprofen 600 mg", "brufen ibuprofen alphafen dajuanofen flabu flamotal maxiprofen profinal profusol ultrafen 600mg tablets capsules", analgesicColor(context), "fever pain analgesics antipyretics Dysmenorrhea Inflammation Osteoarthritis Rheumatoid Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Brufen Retard 800 tab", "Ibuprofen 800 mg", "brufen ibuprofen alphafen flamotal maxiprofen ibuhexal sinufen maxiprofen retard 800mg tablets", analgesicColor(context), "fever pain analgesics antipyretics Dysmenorrhea Inflammation Osteoarthritis Rheumatoid Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Brufen susp", "Ibuprofen 100 mg /5 ml", "Brufen Ibuprofen alphafen ibuflam cetafen-n megafen-n profinal alphafen brufemol-n ibucalmin ibufen mafo marcofen juspoled novaprofen nova-profen 100mg/5ml suspension syrup", analgesicColor(context), "fever pain analgesics antipyretics Closure of PDA patent ductus arteriosus Juvenile Idiopathic Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Brufen Cold tab", "Ibuprofen 400 mg +Pseudoephedrine 60 mg", "Brufen Cold tablets Ibuprofen Pseudoephedrine", resColor(context), "Common Cold Nasal congestion decongestants");
    addItem ("Buspar 10 tab", "Buspirone 10 mg", "buspar buspirone neurobus seropar anxbeat buspalex exupar 10mg 15mg tablets", cnsColor(context), "generalized anxiety disorders smoking cessation anxiolytics");
    addItem ("Byetta 5 prefilled pen", "Exenatide 5 mcg", "byetta Exenatide 5mcg 10mcg prefilled pen solution for injection", hormoneColor(context), "type2 diabetes mellitus Glucagon-Like Peptide-1 GLP-1 Receptor Agonist");

    addItem ("C-retard 500 cap", "Vit C 500 mg", "C-retard vitamin c ascorbic acid cretard ascokarm c apex c-apex c-safe c-viton cevarol cevatron green and lean limitless liposom c magic c redox reen-c ultra vitamin c 500mg capsules tablets", vitColor(context), "vitamin c deficiency supplementation scurvy urinary acidification");
    addItem ("C-vit drops", "Vit C 100 mg /1 ml", "C-vit ascorbic acid cvit cebion cevilene vitamin c 100mg/ml drops", vitColor(context), "vitamin c deficiency supplementation");
    addItem ("Cabella syrup", "Pentoxyverine 10.6 mg /5 ml", "Cabella Pentoxyverine 10.6mg/5ml syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Caffeinospire vial", "Caffeine 20 mg /ml", "caffeinospire caffeine citrate 20mg/ml vial", resColor(context), "Neonatal Apnea");
    addItem ("Cal-Heparine 5000 iu amp", "Heparin  5000 iu /ml", "Cal-Heparine calheparin leo 5000iu/ml ampoule", cvsColor(context), "catheter patency deep venous thrombosis pulmonary embolism anticoagulation venous thromboembolism acute coronary syndrome Anticoagulants");
    addItem ("Cal-Mag tab", "Calcium 140 mg +Magnesium 45 mg", "cal-mag calcium magnesium calmag tablets", vitColor(context), "calcium magnesium deficiency supplementation");
    addItem ("Cal-Preg tab", "Calcium Carbonate 1600 mg (640 mg elemental calcium)", "Cal-Preg Calcium carbonate calpreg calcimax oktal uskade 1600mg tablets", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Calcifolinon vial", "Calcium Folinate 50 mg /5 ml", "calcifolinon bendafolin leucovorin calcium folinate folinobiogen nyrin 50mg/5ml vial", otherColor(context), "high dose methotrexate overdose advanced colorectal carcinoma methanol poisoning");
    addItem ("Calcimate tab", "Calcium Carbonate 500 mg (200 mg elemental calcium)", "calcimate Calcium carbonate caribo calcimate 500mg tablets capsules", vitColor(context), "antacid calcium deficiency supplementation hypocalcemia");
    addItem ("Calcitron cap", "Multivitamins +Minerals", "calcitron capsules calcium mg magnesium potassium phosphorus zinc mn manganese boron silicon cu copper vitamin a vitamin c ascorbic acid vitamin d", vitColor(context), "multiVitamins minerals deficiency Supplementation");
    addItem ("Calcium Chloride 10% amp", "Calcium Chloride 1 gm /10 ml", "calcium chloride 10% 1000 mg gm/ 10ml ampoule", vitColor(context), "hypocalcemia arrhythmia Hypermagnesemia Calcium Channel Blocker Beta-blocker Overdose, Refractory to Glucagon & High Dose Vasopressor Hypocalcemic Tetany");
    addItem ("Calcium Gluconate 10% amp", "Calcium Gluconate 1 gm /10 ml", "calcium gluconate calcionate 10% 1000 mg gm/ 10ml vial ampoule", vitColor(context), "Severe hypocalcemia Hypocalcemic Tetany cardiac arrest calcium channel blocker overdose hyperkalemia hypermagnesemia");
    addItem ("Calcium Pharco tab", "Calcium Citrate 950 mg (200 mg elemental calcium)", "Calcium Pharco Calcium citrate 950mg tablets", vitColor(context), "calcium deficiency supplementation hypocalcemia primary osteoporosis prevention");
    addItem ("Calcivit D3 syrup", "Calcium 50 mg +Vit B12 100 mcg +Vit D3 1000 iu /5 ml", "calcivit d3 calcium cobalamin vitamin b12 vitamin d3 calci-cal calcical syrup", vitColor(context), "Calcium deficiency supplementation hypocalcemia");
    addItem ("Caldin C tab", "Calcium +Magnesium +Vit D3 +Vit C", "caldin c Calcium Magnesium vitamin c ascorbic acid vitamin d tablets", vitColor(context), "hypocalcemia Calcium Magnesium Vitamin C Vitamin D deficiency supplementation");
    addItem ("Calmepam 1.5 tab", "Bromazepam 1.5 mg", "Calmepam Bromazepam amribromazepam calmetanil lexopam lexotanil bropam 1.5mg 3mg tablets", cnsColor(context), "Anxiety Muscle Spasm Alcohol Withdrawal Benzodiazepines");
    addItem ("Capoten 25 tab", "Captopril 25 mg", "capoten captopril angiopress capotril farcopril hypopress lotensine 25mg 50mg tablets", cvsColor(context), "Acute Hypertension Congestive Heart Failure Left Ventricular Dysfunction After MI Diabetic Nephropathy ace Angiotensin-converting enzyme inhibitors");
    addItem ("Capozide 50/25 tab", "Captopril 50 mg +Hydrochlorothiazide 25 mg", "capozide captopril hydrochlorothiazide angiopress comp capojed-h capojed h captopril-h farcopril plus hypopress d 50/25mg tablets", cvsColor(context), "Hypertension ace Angiotensin-converting enzyme inhibitors thiazides Diuretics");
    addItem ("Carbapex 100 tab", "Carbamazepine 100 mg", "carbapex carbamazepine neurotop tonoclone 100mg 200mg 400mg tablets", cnsColor(context), "epilepsy convulsions seizures trigeminal neuralgia bipolar mania restless legs syndrome schizophrenia postherpatic neuralgia anticonvulsants");
    addItem ("Carbimazole 5 tab", "Carbimazole 5 mg", "carbimazole neomercazole thyrocarbin 5mg tablets", hormoneColor(context), "hyperthyroidism Antithyroid Agents");
    addItem ("Cardio-Mep 200 tab", "Amiodarone 200 mg", "cardio-mep cardiomep amiodarone alexcorda amiron cordarone farcodarone ronecard sedacoron ventromed 200mg tablets", cvsColor(context), "ventricular cardiac arrhythmias class III 3 antiarrhythmic agents");
    addItem ("Cardio-Mep amp", "Amiodarone 150 mg /3 ml", "cardio-mep cardiomep amiodarone amiron cardionorm farcodarone farcodarone concentrate ronecard sunnydarone cordarone 150mg/3ml ampoule", cvsColor(context), "acls pulseless ventricular fibrillation cardiac arrhythmias Stable Monomorphic or Polymorphic supraventricular tachycardia class III 3 antiarrhythmic agents");
    addItem ("Cardiomil 120 SR cap", "Verapamil 120 mg", "cardiomil verapamil glopamil veratens isoptin retard izoptomil 120mg 180mg 240mg sr capsules tablets", cvsColor(context), "hypertension angina pectoris class IV 4 antiarrhythmic agents Calcium Channel Blockers CCBs");
    addItem ("Cardioton tab", "Crataegus (Hawthorn) extract 300 mg", "cardioton Crataegus Hawthorn extract cratageus emacardin tablets", cvsColor(context), "Arrhythmias atherosclerosis Buerger's disease circulatory disorders CHF chronic hear failure hyperlipidemia hypertension hypotension");
    addItem ("Cardura 1 tab", "Doxazosin 1 mg", "cardura doxazosin dosin doxazin duracin elaxicopa doxacor doxastine 1mg 2mg 4mg tablets", urinaryColor(context), "hypertension benign prostatic hyperplasia bph alpha1 blocker");
    addItem ("Cardura XL 4 tab", "Doxazosin 4 mg", "cardura xl doxazosin dalizos epcura 4mg tablets", urinaryColor(context), "benign prostatic hyperplasia bph alpha1 blocker");
    addItem ("Caredalud SR tab", "Tizanidine 6 mg", "Caredalud tizanidine epcidin 6mg SR tablets", cnsColor(context), "muscle spasticity Alpha 2 -Adrenergic Agonist");
    addItem ("Carminex sach", "Caraway Oil +Cinnamon Oil +Fennel Oil", "carminex sachets caraway cinnamon fennel oil", gitColor(context), "flatulence gas retention Colic spasm");
    addItem ("Carminex syrup", "Caraway Oil +Cinnamon Oil +Fennel Oil", "carminex syrup caraway cinnamon fennel oil", gitColor(context), "flatulence gas retention Colic spasm");
    addItem ("Carvipress 6.25 tab", "Carvedilol 6.25 mg", "carvipress carvedilol cardilol carlol-v carvid dilatrend dilatrol karvex vidilol carvena carviloc 6.25mg 12.5mg 25mg tablets", cvsColor(context), "Hypertension Congestive Heart Failure Left Ventricular Dysfunction following MI angina pectoris nonselective beta-blocker class II 2 antiarrhythmic agents");
    addItem ("Casodex tab", "Bicalutamide 50 mg", "casodex bicalutamide becalocyrl biluron malignomide 50mg tablets", otherColor(context), "Prostate Cancer Antineoplastic Agents Antiandrogen");
    addItem ("Catafast sach", "Diclofenac K 50 mg", "catafast diclofenac potassium actifast adwiflam declopegal k declophen fast flash act flashact inestafenac rapidinix diclopro k 50mg sachets", analgesicColor(context), "pain analgesics Dysmenorrhea acute migraine Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Cataflam 25 tab", "Diclofenac K 25 mg", "cataflam diclofenac potassium adwiflam antiflam dolphin k mipaflam oflam potafen rapiflam vastaflam 25mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis Ankylosing Spondylitis Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Cataflam 50 tab", "Diclofenac K 50 mg", "cataflam diclofenac potassium actifast adwiflam antiflam diclasium dicloflam diclorapid dolphin k flamifast oflam potafen rapidus rapiflam unirapecure vastaflam zitoxonal flector 50mg tablets capsules", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis Ankylosing Spondylitis Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Cataflam amp", "Diclofenac 75 mg /3 ml", "cataflam diclofenac sodium potassium articavol declophen diclac dicloferaz dolphin epifenac olfen pharofen rheumafen rheumarene romalex voltaren zacaglone adwiflam dolphin k potafen voltinac-k 75mg/3ml ampoule", analgesicColor(context), "pain analgesics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Catafly syrup", "Diclofenac K 10 mg /5 ml", "Catafly diclofenac potassium 10mg/5ml syrup", analgesicColor(context), "Juvenile Idiopathic Arthritis rheumatoid osteoarthritis Dysmenorrhea Pain analgesics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Catapresan 0.15 tab", "Clonidine 150 mcg", "Catapresan clonidine 0.150mcg mg tablets", cvsColor(context), "hypertension alcohol withdrawal Smoking Cessation Restless Legs Syndrome Tourette's Syndrome Opioid Withdrawal Postherpetic Neuralgia Psychosis Pheochromocytoma Diagnosis Alpha2 Adrenergic Agonists");
    addItem ("Caventol syrup", "Honey +Thyme +Vit C +Fennel +Eucalyptus +Marshmallow +Ivy +Zinc +Propolis", "caventol syrup Honey Thyme oil white vitamin c ascorbic acid Fennel Eucalyptus oil Marshmallow Ivy Zinc gluconate Propolis extract", resColor(context), "Dry Cough antitussive");
    addItem ("Ceclor 125 susp", "Cefaclor 125 mg /5 ml", "Ceclor Cefaclor bacticlor misaclor 125mg/5ml suspension", abColor(context), "UTI urinary tract infections Nose sinusitis Throat pharyngitis tonsillitis Skin Infections LRTI lower respiratory tract infections urti upper respiratory tract infection 2nd second generation cephalosporins");
    addItem ("Ceclor 250 susp", "Cefaclor 250 mg /5 ml", "Ceclor Cefaclor misaclor bacticlor cefbiolor clorocef 250mg/5ml suspension", abColor(context), "UTI urinary tract infections Nose sinusitis Throat pharyngitis tonsillitis Skin Infections LRTI lower respiratory tract infections urti upper respiratory tract infection 2nd second generation cephalosporins");
    addItem ("Cefaxone 250 vial", "Ceftriaxone 250 mg", "Cefaxone Ceftriaxone cefotrix oframax 250mg vial", abColor(context), "Acute Bacterial Otitis Media Meningitis Ophthalmia Neonatorum Disseminated Gonococcal Scalp Abscesses Epiglottitis Skin Pyelonephritis Intra-abdominal Prosthetic Joint Surgical Prophylaxis Septic toxic Shock Skin and Soft Necrotizing Severe Acute Bacterial Rhinosinusitis Acute Epididymitis Gonococcal conjunctivitis Disseminated gonococcal infections endocarditis meningitis 3rd third generation cephalosporins");
    addItem ("Cefaxone 500 vial", "Ceftriaxone 500 mg", "Cefaxone Ceftriaxone cefotrix enoxirt epicephin mesporin nercefaxone rameceftrax rocephin triamerican trixamarc trixomash votriaxone wintriaxone xoraxon zoxidel 500mg vial", abColor(context), "Acute Bacterial Otitis Media Meningitis Ophthalmia Neonatorum Disseminated Gonococcal Scalp Abscesses Epiglottitis Skin Pyelonephritis Intra-abdominal Prosthetic Joint Surgical Prophylaxis Septic toxic Shock Skin and Soft Necrotizing Severe Acute Bacterial Rhinosinusitis Acute Epididymitis Gonococcal conjunctivitis Disseminated gonococcal infections endocarditis meningitis 3rd third generation cephalosporins");
    addItem ("Cefaxone 1 gm vial", "Ceftriaxone 1 gm", "Cefaxone Ceftriaxone cefotrix enoxirt epicephin kempoxone longacef mesporin nercefaxone oframax rameceftrax rocephin triamerican trixamarc xoraxon trixomash votriaxone wintriaxone zoxidel 1000mg 1gm vial", abColor(context), "Acute Bacterial Otitis Media Meningitis Ophthalmia Neonatorum Disseminated Gonococcal Scalp Abscesses Epiglottitis Skin Pyelonephritis Intra-abdominal Prosthetic Joint Surgical Prophylaxis Septic toxic Shock Skin and Soft Necrotizing Severe Acute Bacterial Rhinosinusitis Acute Epididymitis Gonococcal conjunctivitis Disseminated gonococcal infections endocarditis meningitis 3rd third generation cephalosporins");
    addItem ("Cefaxone 2 gm vial", "Ceftriaxone 2 gm", "Cefaxone ceftriaxone cefotrix epicephin zoxidel 2000mg gm vial", abColor(context), "Acute Bacterial Otitis Media Meningitis Ophthalmia Neonatorum Disseminated Gonococcal Scalp Abscesses Epiglottitis Skin Pyelonephritis Intra-abdominal Prosthetic Joint Surgical Prophylaxis Septic toxic Shock Skin and Soft Necrotizing Severe Acute Bacterial Rhinosinusitis Acute Epididymitis Gonococcal conjunctivitis Disseminated gonococcal infections endocarditis meningitis 3rd third generation cephalosporins");
    addItem ("Cefotax 250 vial", "Cefotaxime 250 mg", "Cefotaxime claforan xorin 250mg vial", abColor(context), "Meningitis Neonatal Sepsis Typhoid fever Pneumonia Epiglottitis Gonococcal Infections Surgical Prophylaxis 3rd third generation cephalosporins");
    addItem ("Cefotax 500 vial", "Cefotaxime 500 mg", "Cefotaxime cefause cefaxim cefomerican ceforan claforan foxime rametax hebitaxime itotaxime pulomotax taximodel sigmataxim xorin 500mg vial", abColor(context), "Meningitis Neonatal Sepsis Typhoid fever Pneumonia Epiglottitis Gonococcal Infections Surgical Prophylaxis 3rd third generation cephalosporins");
    addItem ("Cefotax 1 gm vial", "Cefotaxime 1 gm", "Cefotaxime cefause cefaxin cefomerican ceforan claforan foxime itotaxime rametax hebitaxime pentatrox pulomotax sigmataxim taximodel xorin vucefetax 1000mg 1gm vial", abColor(context), "Meningitis Neonatal Sepsis Typhoid fever Pneumonia Epiglottitis Gonococcal Infections Surgical Prophylaxis 3rd third generation cephalosporins");
    addItem ("Cefotax 2 gm vial", "Cefotaxime 2 gm", "cefotaxime ceforan rametax taximodel xorin 2000mg gm vial", abColor(context), "Meningitis Neonatal Sepsis Typhoid fever Pneumonia Epiglottitis Gonococcal Infections Surgical Prophylaxis 3rd third generation cephalosporins");
    addItem ("Cefozon 1 gm vial", "Cefoperazone 1 gm", "Cefozon cefoperazone cefazone peracef cefrazon cefrone cefobid cibaprazon 1000mg 1gm vial", abColor(context), "rti respiratory peritonitis intra-abdominal septicemia skin pid pelvic inflammatory disease endometritis uti urinary tract infections 3rd third generation cephalosporins");
    addItem ("Cefozon 2 gm vial", "Cefoperazone 2 gm", "Cefozon cefoperazone cefrone cefobid maxibiotic 2000mg gm vial", abColor(context), "rti respiratory peritonitis intra-abdominal septicemia skin pid pelvic inflammatory disease endometritis uti urinary tract infections 3rd third generation cephalosporins");
    addItem ("Cefumax 250 vial", "Cefuroxime 250 mg", "Cefumax cefuroxime pancef zimocefox zinacef 250mg vial", abColor(context), "UTI urinary tract gonorrhea bronchitis pneumonia impetigo Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin severe complicated infections 2nd second generation cephalosporins");
    addItem ("Cefumax 750 vial", "Cefuroxime 750 mg", "Cefumax cefuroxime pancef zinacef 750mg vial", abColor(context), "UTI urinary tract gonorrhea bronchitis pneumonia impetigo Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin severe complicated infections 2nd second generation cephalosporins");
    addItem ("Cefumax 1500 vial", "Cefuroxime 1500 mg", "Cefumax cefuroxime zinacef 1500mg 1.5gm vial", abColor(context), "UTI urinary tract gonorrhea bronchitis pneumonia impetigo Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin severe complicated infections 2nd second generation cephalosporins");
    addItem ("Cefzil 125 susp", "Cefprozil 125 mg /5 ml", "Cefzil Cefprozil zilospore 125mg/5ml suspension", abColor(context), "Sinusitis Pharyngitis tonsillitis Skin Respiratory tract infections urti lrti Acute Otitis media 2nd second generation cephalosporins");
    addItem ("Cefzil 250 susp", "Cefprozil 250 mg /5 ml", "Cefzil Cefprozil zilospore speczil 250mg/5ml suspension", abColor(context), "Sinusitis Pharyngitis tonsillitis Skin Respiratory tract infections urti lrti Acute Otitis media 2nd second generation cephalosporins");
    addItem ("Cefzil 250 tab", "Cefprozil 250 mg", "cefzil cefprozil 250mg tab", abColor(context), "Sinusitis Pharyngitis tonsillitis Skin Respiratory tract infections urti lrti Acute Otitis media 2nd second generation cephalosporins");
    addItem ("Cefzil 500 tab", "Cefprozil 500 mg", "cefzil cefprozil zilospore 500mg tablets", abColor(context), "Sinusitis Pharyngitis tonsillitis Skin Respiratory tract infections urti lrti Acute Otitis media 2nd second generation cephalosporins");
    addItem ("Cefzim 500 vial", "Ceftazidime 500 mg", "Cefzim Ceftazidime cefidime ceftidin cetazime fortazedim fortum kefadim maximodim sigmazidim xtrazidime 500mg vial", abColor(context), "Life-Threatening Pneumonia Meningitis Bone Intra-abdominal Cystic Fibrosis Gynecologic Neonatal Sepsis Skin uti urinary tract infections 3rd third generation cephalosporins");
    addItem ("Cefzim 1 gm vial", "Ceftazidime 1 gm", "Cefzim Ceftazidime ceftidin cetazime inzad fortazedim fortum kefadim kempozedim maximodim negacef sigmazidim vanzadime xtrazidime 1000mg 1gm vial", abColor(context), "Life-Threatening Pneumonia Meningitis Bone Intra-abdominal Cystic Fibrosis Gynecologic Neonatal Sepsis Skin uti urinary tract infections 3rd third generation cephalosporins");
    addItem ("Cefzim 2 gm vial", "Ceftazidime 2 gm", "Cefzim ceftazidime cetazime vanzadime xtrazidime 2000mg gm vial", abColor(context), "Life-Threatening Pneumonia Meningitis Bone Intra-abdominal Cystic Fibrosis Gynecologic Neonatal Sepsis Skin uti urinary tract infections 3rd third generation cephalosporins");
    addItem ("Celebrex 100 cap", "Celecoxib 100 mg", "celebrex celecoxib arythrex celeborg celoxib eurocox rheumamax 100mg capsules tablets", analgesicColor(context), "Juvenile Rheumatoid Arthritis Acute Pain analgesics Primary Dysmenorrhea Ankylosing Spondylitis Osteoarthritis Familial Adenomatous Polyposis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Celebrex 200 cap", "Celecoxib 200 mg", "celebrex celecoxib arythrex celeborg celoxib eurocox 200mg capsules tablets", analgesicColor(context), "Juvenile Rheumatoid Arthritis Acute Pain analgesics Primary Dysmenorrhea Ankylosing Spondylitis Osteoarthritis Familial Adenomatous Polyposis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Cellcept 250 cap", "Mycophenolate Mofetil 250 mg", "cellcept mycophenolate mofetil mmf ceptolate mofetyl 250mg capsules tablets", otherColor(context), "kidney heart liver transplant lupus nephritis Immunosuppressive Agents");
    addItem ("Cellcept 500 tab", "Mycophenolate Mofetil 500 mg", "cellcept mycophenolate mofetil mmf ceptolate mofetyl 500mg tablets", otherColor(context), "kidney heart liver transplant lupus nephritis Immunosuppressive Agents");
    addItem ("Centronerve tab", "Alpha Lipoic Acid +Benfotiamine +Vit B6 +Vit B12 +Vit D", "Centronerve alpha lipoic thioctic acid Vitamins B1 Benfotiamine B6 pyridoxine B12 cobalamin D3", vitColor(context), "polyneuritis polyneuropathy neuralgia Supports Nervous System and Bone health");
    addItem ("Centrum tab", "Vitamins +Minerals", "centrum tablets multivitamins a b1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin b5 pantothenic acid b6 pyridoxine b12 cobalamin b7 biotin b9 folic acid c ascorbic acid d e tocopherol k calcium iron potassium chloride kcl chromium copper potassium iodine magnesium mg manganese mn molybdenum nickel calcium phosphorus selenium silicon vanadium tin zinc oxide boron", vitColor(context), "vitamin minerals deficiency supplementation");
    addItem ("Ceporex 125 susp", "Cephalexin 125 mg /5 ml", "Ceporex Cephalexin cefalexin amthrost cephoxin ospexin 125mg/5ml suspension ", abColor(context), "Uncomplicated Cystitis UTI urinary Bone Skin Respiratory Tract Infections Pharyngitis tonsillitis Acute Otitis Media 1st first generation cephalosporins");
    addItem ("Ceporex 250 susp", "Cephalexin 250 mg /5 ml", "Ceporex Cephalexin cefalexin amthrost cephoxin keflex mediceflexin neocef ospexin 250mg/5ml suspension", abColor(context), "Uncomplicated Cystitis UTI urinary Bone Skin Respiratory Tract Infections Pharyngitis tonsillitis Acute Otitis Media 1st first generation cephalosporins");
    addItem ("Ceporex 250 tab", "Cephalexin 250 mg", "Ceporex Cephalexin cefalexin amthrost cephalexcid keflex 250mg tablets", abColor(context), "Uncomplicated Cystitis UTI urinary Bone Skin Respiratory Tract Infections Pharyngitis tonsillitis Acute Otitis Media Cellulitis Mastitis 1st first generation cephalosporins");
    addItem ("Ceporex 500 tab", "Cephalexin 500 mg", "Ceporex Cephalexin cefalexin cefoldex cephalexcid cephoxin keflex mediceflexin neocef starcef 500mg tablets", abColor(context), "Uncomplicated Cystitis UTI urinary Bone Skin Respiratory Tract Infections Pharyngitis tonsillitis Acute Otitis Media Cellulitis Mastitis 1st first generation cephalosporins");
    addItem ("Ceporex 1 gm tab", "Cephalexin 1 gm", "ceporex Cephalexin cefalexin ceporex cefoldex cefoldex starcef starcef cephoxin gramocef keflex ospexin respicef 1000mg 1gm tablets", abColor(context), "Uncomplicated Cystitis UTI urinary Bone Skin Respiratory Tract Infections Pharyngitis tonsillitis Acute Otitis Media Cellulitis Mastitis 1st first generation cephalosporins");
    addItem ("Cerazette tab", "Desogestrel 75 mcg", "cerazette desogestrel ovunhipita 75 mcg tablets", hormoneColor(context), "contraceptive oral contraception");
    addItem ("Cerebrine cap", "Vinburnine 20 mg", "cerebrine vinburnine 20 mg capsules", cnsColor(context), "pathological cognitive deficiency acuity vision troubles caused by vascular circulation vasodilators");
    addItem ("Cerebrolysin amp", "Cerebrolysin 215.2 mg /ml", "Cerebrolysin 215.2mg/ml ampoule", cvsColor(context), "acute ischemic stroke dementia traumatic brain injury Craniocerebral Trauma Postapoplectic Complications");
    addItem ("Ceroxim 500 tab", "Cefuroxime 500 mg", "ceroxim cefuroxime zimocefox zenax zinacef 500mg tablets", abColor(context), "UTI urinary gonorrhea early lime disease impetigo sinusitis Throat pharyngitis tonsillitis bronchitis Skin LRTI lower urti upper respiratory tract infections pneumonia 2nd second generation cephalosporins");
    addItem ("Cervitam cap", "Piracetam 400 mg +Vincamine 20 mg", "cervitam capsules piracetam 400 vincamine 20 mg", cnsColor(context), "vertigo memory enhancement of concentration constituted cerebral infarction");
    addItem ("Cetafen Plus tab", "Ibuprofen 400 mg +Paracetamol 500 mg +Caffeine 65 mg", "Cetafen plus tablets ibuprofen paracetamol acetaminophen caffeine", analgesicColor(context), "antipyretics fever analgesics pain inflammations");
    addItem ("Cetal drops", "Paracetamol 100 mg /1 ml", "Cetal Paracetamol pyral acetaminophen febrimol paragesic unicetamol 100mg/ml drops", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Cetal Sinus tab", "Paracetamol 500 mg +Pseudoephedrine 30 mg", "cetal sinus tablets paracetamol acetaminophen Pseudoephedrine", resColor(context), "Common Cold Nasal congestion decongestants");
    addItem ("Cetal supp", "Paracetamol 120 mg", "Cetal suppositories Paracetamol 120 mg acetaminophen 120 mg", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Cetal susp", "Paracetamol 250 mg /5 ml", "Cetal suspension Paracetamol 250 mg susp temporal susp acetaminophen 250 mg paragesic paracetamol susp cetal 250 mg susp", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Cevamol eff tab", "Paracetamol 400 mg +Vit C 250 mg", "cevamol eff tablets paracetamol acetaminophen vitamin c ascorbic acid", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("CH Alpha sach", "Collagen 10 mg +Vit C 85 mg", "chalpha ch-alpha collagen hydrolysate gelatin vitamin c ascorbic acid aurier benogen cartino colgimor colgy collacogen collagix dulagen gelatexin jelace jeltamix jenax jointone jonmera karti to collagen lamazi leva regenax synova tigint u-pro u pro upro uni alpha sachets", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis");
    addItem ("CH Alpha Plus sach", "Collagen +Vit C +Rosehip extract", "chalpha ch-alpha chalpha plus collagen hydrolysate gelatin vitamin c ascorbic acid rosehip extract acti-colla-c acticollac sachets", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis");
    addItem ("Champix 0.5 tab", "Varenicline 0.5 mg", "champix varenicline 0.5mg 1mg tablets", otherColor(context), "smoking cessation");
    addItem ("Chitocal cap", "Chitosan +Vit C +Gymnema Sylvestre", "chitocal capsules Chitosan vhd vitamin c ascorbic acid Gymnema Sylvestre", vitColor(context), "to lose weight loss weight maintenance hypercholesterolemia gout");
    addItem ("Chloral syrup", "Chloral Hydrate 500 mg /5 ml", "chloral hydrate 500mg/5ml syrup", cnsColor(context), "insomnia sedative anxiety sedation of procedures hypnotics");
    addItem ("Choletimb tab", "Ezetimibe 10 mg", "choletimb ezetimibe cholstop ezetrol lipidnorm lowtimib zetamibe zetlip 10mg tablets", cvsColor(context), "primary hyperlipidemia Antilipemic Agents");
    addItem ("Choletrix-D3 drops", "Vit D3 400 iu /drop", "Choletrix-D3 cholecalciferol vitamin d3 nutritru d futi-d for kids genebaby immuno-mash immunomash kiddo d3 400iu/drop drops", vitColor(context), "vitamin d deficiency supplementation osteoporosis rickets");
    addItem ("Chromax cap", "Chromium Picolinate +Garcinia Cambogia Fruit extract", "Chromax capsules chromium Picolinate mepaco Garcinia Cambogia Fruit extract", vitColor(context), "weight loss weight control");
    addItem ("Chromitron cap", "Chromium +L.Cysteine +L.Glycine +L.Glutamic Acid +Vit B3 +Biotin +Citrus Bioflavonoids +Vit E +Vit A +Vit C", "chromitron capsules chromium l.cysteine l.glycine l.glutamic acid vitamin b3 Nicotinic Acid nicotinamide niacin vitamin b7 biotin citrus bioflavonoids tocopherol vitamin e vitamin a beta carotene vitamin c ascorbic acid", vitColor(context), "Insulin Resistance Metabolic Syndrome Obesity and Over Weight in Adults & Children Poly Cystic Ovarian Syndrome PCOS Insufficient dietary chromium");
    addItem ("Chromium cap", "Chromium Picolinate 200 mcg", "chromium chromium Picolinate act life nutra chrom 200mcg capsules tablets", vitColor(context), "Diabetes Mellitus type2 diabetes mellitus Beta Blocker-Related Low HDL Cholesterol Corticosteroid-Induced Hyperglycemia Hypoglycemia Dysthymic Disorder Prevention weight loss weight control");
    addItem ("Cidamex tab", "Acetazolamide 250 mg", "cidamex acetazolamide acetamex 250mg tablets", cvsColor(context), "epilepsy seizures convulsions acute altitude sickness glaucoma edema congestive heart failure drug-induced edema carbonic anhydrase inhibitor");
    addItem ("Cidodian Depot amp", "Estradiol Valerate 4 mg +Prasterone Enanthate 200 mg", "cidodian depot estradiol valerate prasterone enanthate dehydroepiandrosterone ampoule", hormoneColor(context), "vasomotor symptoms associated with the menopause vulvar atrophy and vaginal atrophy associated with the menopause hypoestrogenism due to hypogonadism, castration or primary ovarian failure");
    addItem ("Cidolut Depot amp", "Hydroxyprogesterone Caproate 250 mg /ml", "Cidolut Depot Hydroxyprogesterone Caproate 250mg/ml lentojeston ampoule", hormoneColor(context), "Preterm Labor");
    addItem ("Cidophage 500 tab", "Metformin 500 mg", "cidophage metformin alexodiab amophage glucophage diaphage diaphage mepaphage eaforment 500mg 1000mg 1gm tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides");
    addItem ("Cidoteston amp", "Testosterone Enantate 250 mg /ml", "Cidoteston testosterone Enantate 250mg/ml ampoule", hormoneColor(context), "Testosterone replacement therapy for male hypogonadism androgens");
    addItem ("Cilest tab", "Norgestimate 0.25 mg +Ethinyl Estradiol 35 mcg", "cilest Norgestimate 0.25mg Ethinylestradiol 35mcg estovlar estraceptive norgestadiol tablets", hormoneColor(context), "contraceptive oral contraception");
    addItem ("Cimetidine 200 tab", "Cimetidine 200 mg", "Cimetidine 200mg tablets", gitColor(context), "erosive GERD gastroesophageal reflux disease Gastric duodenal ulcer heartburn Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Histamine H2-receptor antagonists blockers");
    addItem ("Cimzia prefilled syringe", "Certolizumab Pegol 200 mg /ml", "cimzia certolizumab pegol 200mg/ml prefilled syringe", otherColor(context), "crohn disease rheumatoid arthritis psoriatic arthritis ankylosing spondylitis spondyloarthritis plaque psoriasis Tumor Necrosis Factor TNF Blockers");
    addItem ("Cipralex 10 tab", "Escitalopram 20 mg", "cipralex escitalopram atmecipia ciprapro citapronex escita estikana excelsa futapramin hermpro nodep psychopram verdapiotal citalomep escitaloborg escitapram 10mg 20mg tablets", cnsColor(context), "major depressive generalized anxiety antidepressants vasomotor symptoms associated with menopause obsessive-compulsive disorder Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Ciprocin 250 tab", "Ciprofloxacin 250 mg", "Ciprocin ciprofloxacin bactiflox ciprobay cipromax ciprofar elmodoxacin mifoxin rancif serviflox 250mg tablets", abColor(context), "uti urinary Intra-abdominal LRTI lower respiratory tract Skin Plague Acute Sinusitis Bone Chronic Bacterial Prostatitis Infectious Diarrhea Urethral Cervical Gonococcal Infections Anthrax fluoroquinolones");
    addItem ("Ciprocin 500 tab", "Ciprofloxacin 500 mg", "Ciprocin ciprofloxacin bactiflox cipro ciprobay cipromax ciprofar ciproquin elmodoxacin heroxacin mifoxin rancif serviflox quinolorox 500mg tablets", abColor(context), "uti urinary Intra-abdominal LRTI lower respiratory tract Skin Plague Acute Sinusitis Bone Chronic Bacterial Prostatitis Infectious Diarrhea Urethral Cervical Gonococcal Infections Anthrax fluoroquinolones");
    addItem ("Ciprocin 750 tab", "Ciprofloxacin 750 mg", "Ciprocin ciprofloxacin ciprobay ciprofar cipromax elmodoxacin karmaflox kiprokinza serviflox 750mg tablets", abColor(context), "uti urinary Intra-abdominal LRTI lower respiratory tract Skin Plague Acute Sinusitis Bone Chronic Bacterial Prostatitis Infectious Diarrhea Urethral Cervical Gonococcal Infections Anthrax fluoroquinolones");
    addItem ("Ciprodiazole tab", "Ciprofloxacin 500 mg +Metronidazole 500 mg", "ciprodiazole ciprofloxacin metronidazole 500mg tablets", abColor(context), "intra-abdominal infections pelvic infections diverticulitis");
    addItem ("Ciprofloxacin vial", "Ciprofloxacin 200 mg /100 ml", "Ciprofloxacin ciprosol ciprocinor hectronin rancif 200mg/100ml vial", abColor(context), "Pyelonephritis complicated UTI urinary Plague Cystic Fibrosis Intra-abdominal LRTI lower respiratory tract Skin Acute sinusitis Bone Infections Chronic bacterial prostatitis Empirical therapy in febrile neutropenic patients Nosocomial Pneumonia Anthrax fluoroquinolones");
    addItem ("Cipromega XL 500 tab", "Ciprofloxacin 500 mg", "Cipromega ciprofloxacin ciprotak ciproxil xl 500mg tablets", abColor(context), "UTI urinary tract infections Pyelonephritis fluoroquinolones");
    addItem ("Cipromega XL 1 gm tab", "Ciprofloxacin 1 gm", "cipromega ciprofloxacin cipromega ciprotak xl meraflevet sr ultracipro er 1000mg 1gm tablets", abColor(context), "UTI urinary tract infections Pyelonephritis fluoroquinolones");
    addItem ("Citalo syrup", "Citalopram 2 mg /ml", "citalopram ramdeep 2mg/ml syrup", cnsColor(context), "Depression impulsive aggressive behaviour alcoholism binge-eating generalized anxiety panic disorder hot flashes obsessive-compulsive disorder antidepressants Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Citalo 20 tab", "Citalopram 20 mg", "citalopram ceropram cipram depram puracit sedopram cipramax citalofar depaway lecital ramdeep talopram 20mg 40mg tablets", cnsColor(context), "Depression antidepressants alcoholism binge-eating obsessive-compulsive disorder Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Clexane prefilled syringe", "Enoxaparin", "clexane enoxaparin lowparin prefilled syringes", cvsColor(context), "deep vein thrombosis dvt unstable angina non-q-wave mi myocardial infarction acute coronary syndromes Anticoagulants");
    addItem ("Clindacin 150 cap", "Clindamycin 150 mg", "clindamycin clindacine clinacyn mepaclind 150mg capsules", abColor(context), "Serious Infections caused by anaerobic bacteria Bite wounds Orofacial Infections Pharyngitis tonsillitis Bacterial Vaginosis Endocarditis Prophylaxis Pneumocystis Carinii Gardenerella Vaginalis lincosamides");
    addItem ("Clindacin 300 cap", "Clindamycin 300 mg", "clindacine clinacyn mepaclind alfaclindamycin dalacin c 300mg capsules", abColor(context), "Serious Infections caused by anaerobic bacteria Bite wounds Orofacial Infections Pharyngitis tonsillitis Bacterial Vaginosis Endocarditis Prophylaxis Pneumocystis Carinii Gardenerella Vaginalis lincosamides");
    addItem ("Clomid tab", "Clomiphene 50 mg", "clomid Clomiphene clomifert tecnovula 50mg tablets", hormoneColor(context), "ovulatory failure Selective Estrogen Receptor Modulators SERM");
    addItem ("Clopixol Depot amp", "Zuclopenthixol 200 mg /ml", "clopixol depot zuclopenthixol 200mg/ml ampoule", cnsColor(context), "schizophrenia and paranoid psychoses Antipsychotics");
    addItem ("Clozapex 25 tab", "Clozapine 25 mg", "clozapex clozapine leponex medazepine schizonex zaclo 25mg 100mg tablets", cnsColor(context), "schizophrenia antipsychotics");
    addItem ("Co-Tareg tab", "Valsartan +Hydrochlorothiazide", "cotareg co-tareg valsartan hydrochlorothiazide co-valsartan co-vasotec disartan-co targomash comp valsatens plus valthiazide adwivalsar-co pressval plus sarangiot plus alfabetex co-diovan hydrosartan pressothioval sarablock tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics");
    addItem ("Cobal tab", "Methylcobalamin (Mecobalamin) 0.5 mg", "cobal Methylcobalamin Mecobalamin vitamin b12 adwinerve capsules vivopal 0.500mcg mg tablets", vitColor(context), "Peripheral neuropathy vitamin b12 deficiency supplementation");
    addItem ("Cobal F tab", "Methylcobalamin (Mecobalamin) 0.5 mg +Folic Acid 0.2 mg", "cobal f Methylcobalamin Mecobalamin vitamin b12 0.500mcg mg folic acid vitamin b9 0.200mcg mg tablets", vitColor(context), "Peripheral neuropathy vitamin b12 Megaloblastic macrocytic anaemia folate deficiency supplementation");
    addItem ("Cobalvex B12 amp", "Methylcobalamin (Mecobalamin) 0.5 mg /ml", "Cobalvex B12 Methylcobalamin mecobalamin vitamin b12 0.500mcg mg/ml ampoule", vitColor(context), "peripheral neuropathy vitamin b12 deficiency supplementation megaloblastic anemia");
    addItem ("Codaphen-N syrup", "Dextromethorphan +Chlorpheniramin", "codaphen-n Dextromethorphan Chlorpheniramine neo-pulmolar neopulmolar syrup", resColor(context), "Cough cold");
    addItem ("Codiclyptol cap", "Pholcodine 5 mg +Pseudoephedrine 30 mg +Paracetamol 500 mg", "codiclyptol Paracetamol Pholcodine Pseudoephedrine acetaminophen vesticold capsules", resColor(context), "Common cold influenza Nasal congestion cough decongestants");
    addItem ("Codilar syrup", "Dextromethorphan +Phenylephrine +Chlorpheniramin", "Codilar Dextromethorphan Phenylephrine Chlorpheniramine tussivan n syrup", resColor(context), "Cough common cold nasal congestion decongestants");
    addItem ("Coenzyme Q10 cap", "Coenzyme Q10 30 mg", "coenzyme q10 q-10 forte q-sorb co-q-10 30mg 100mg capsules", vitColor(context), "chf congestive heart failure chronic fatigue syndrome myocardial preservation for heart surgery mi myocardial infarction angina");
    addItem ("Cogetropine amp", "Benztropine 1 mg /ml", "cogetropine benztropine 1mg/ml ampoule", cnsColor(context), "parkinsonism drug-induced extrapyramidal disorders Anticholinergic Agents");
    addItem ("Cogintol tab", "Benztropine 2 mg", "cogintol benztropine 2mg tablets", cnsColor(context), "parkinsonism drug-induced extrapyramidal disorders Anticholinergic Agents");
    addItem ("Colchicine 0.5 tab", "Colchicine 0.5 mg (500 mcg)", "colchicine colmediten 0.500mcg mg tablets", otherColor(context), "Familial Mediterranean Fever fmf gout Post-STEMI Pericarditis");
    addItem ("Cold Control tab", "Paracetamol 500 mg +Diphenhydramine 12.5 mg", "cold control tablets paracetamol acetaminophen diphenhydramine", resColor(context), "common cold influenza analgesics pain insomnia sleeplessness");
    addItem ("Colomycin 1 mIU vial", "Colistimethate sodium 1 million IU", "colomycin colistin colixin colistimethate sodium 1 million miu vial", abColor(context), "serious infections due to selected aerobic Gram -ve negative pathogens");
    addItem ("Colomycin 2 mIU vial", "Colistimethate sodium 2 million IU", "colomycin colistin colixin colistimethate sodium 2 million miu vial", abColor(context), "serious infections due to selected aerobic Gram -ve negative pathogens");
    addItem ("Colona tab", "Mebeverine +Sulpiride", "colona mebeverine sulpiride colovatil colsever tablets", gitColor(context), "spastic colon ibs irritable bowel syndrome colic");
    addItem ("Colosalazine-EC tab", "Sulfasalazine 500 mg", "colosalazine-ec sulfasalazine salazo-sulph pyrine salazopyrine salazosin 500mg tablets", otherColor(context), "ulcerative colitis juvenile rheumatoid arthritis crohn disease 5-Aminosalicylic Acid Derivatives");
    addItem ("Coloverin tab", "Mebeverine 135 mg", "coloverin mebeverine colorelax colospasmin colospatoraz duspatalin kolocurejed mepacolon spasmotalin forte 135mg tablets", gitColor(context), "spasm ibs irritable bowel syndrome colic Antispasmodic Agents");
    addItem ("Coloverin SR cap", "Mebeverine 200 mg", "coloverin sr mebeverine duspatalin retard futagastric mebefac mebezon mepacolon monocolona sr uspaverine capsules", gitColor(context), "spasm ibs irritable bowel syndrome colic Antispasmodic Agents");
    addItem ("Coloverin A tab", "Mebeverine 135 mg +Chlordiazepoxide 5 mg", "coloverin a mebeverine 135mg Chlordiazepoxide 5mg tablets", gitColor(context), "spastic colon ibs irritable bowel syndrome colic anxiety Antispasmodic Agents");
    addItem ("Coloverin D tab", "Mebeverine 135 mg +Dimethicone 40 mg", "coloverin d mebeverine 135mg dimethicone 40mg tablets", gitColor(context), "spastic colon ibs irritable bowel syndrome colic flatulence distension gas retention Antispasmodic Agents");
    addItem ("Combivent inhaler", "Ipratropium Bromide 20 mcg +Salbutamol 120 mcg /actuation", "combivent ipratropium bromide salbutamol albuterol ipravent-s inhaler metered dose", resColor(context), "acute severe bronchospasm bronchial asthma exacerbation copd chronic obstructive pulmonary disease Bronchodilators anticholinergic agents");
    addItem ("Cona-adione tab", "Vitamin K1 10 mg", "conadione cona-adione vitamin k1 phytonadione adcokion epikavit haemokion haya-k k-dion k-sabaa k1 apex origin-k1 phyto k phytonadione unimenadione vitadione 10mg tablets", vitColor(context), "Hypoprothrombinemia due to drugs or factors limiting Absorption or Synthesis bleeding");
    addItem ("Conaz tab", "Norfloxacin +Tinidazole", "conaz norfloxacin 400mg tinidazole 600mg tinidol plus enterolok norfloxacin-tz tablets", abColor(context), "Gastroenteritis fluoroquinolones");
    addItem ("Concerta 18 ER tab", "Methylphenidate 18 mg", "concerta Methylphenidate 18mg 36mg er tablets", cnsColor(context), "adhd attention-deficit/hyperactivity disorder narcolepsy CNS Stimulant");
    addItem ("Concor COR 2.5 tab", "Bisoprolol 2.5 mg", "concor cor bisoprolol bisocard bisolock bistol normocard bisobeta caprol egypro mephacor soprol unibisol 2.5mg 5mg 10mg tablets", cvsColor(context), "Hypertension Heart Failure Beta-1 selective blockers class II 2 antiarrhythmic agents");
    addItem ("Congestal syrup", "Paracetamol +Chlorpheniramine +Pseudoephedrine +Dextromethorphan", "Congestal Paracetamol Chlorpheniramine Pseudoephedrine Dextromethorphan acetaminophen cold stop advipro syrup", resColor(context), "Common cold influenza Nasal congestion Cough rhinitis decongestants");
    addItem ("Congestal tab", "Chlorpheniramine +Pseudoephedrine +Paracetamol", "Congestal Paracetamol Chlorpheniramine Pseudoephedrine acetaminophen cold free cetal cold and flu 123 one two three cold stop n fevano cold fever n flu flustat noflu rhinocalm tablets", resColor(context), "Common cold Nasal congestion rhinitis decongestants");
    addItem ("Conta-Flu tab", "Chlorpheniramine +Pseudoephedrine +Propyphenazone", "conta-flu Propyphenazone Chlorpheniramine Pseudoephedrine contaflu tablets", resColor(context), "Common cold influenza Nasal congestion rhinitis decongestants");
    addItem ("Contafever susp", "Ibuprofen 200 mg /5 ml", "Contafever Ibuprofen 200mg/5ml suspension", analgesicColor(context), "fever pain analgesics antipyretics Juvenile Idiopathic Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Contrahistadin tab", "Bilastine 20 mg", "contrahistadin Bilastine atmiblast bilastigec bilastomed pharmabilast rhinobilastin 20mg tablets", resColor(context), "Allergies allergic rhinitis conjunctivitis Urticaria allergy Non-sedating antihistamines");
    addItem ("Contraplan II tab", "Levonorgestrel 0.75 mg", "contraplan ii levonorgestrel 2 postinor-2 0.75mg tablets", hormoneColor(context), "emergency contraceptive emergency post-coital contraception");
    addItem ("Controloc 20 tab", "Pantoprazole 20 mg", "controloc pantoprazole antopral delpanto maalox control pantoloc pantomerican pantopi protofix protoloc zurcal 20mg tablets", gitColor(context), "Erosive Esophagitis with GERD gastroesophageal reflux disease Hypersecretory Conditions zollinger ellison syndrome Peptic Ulcer Proton Pump Inhibitors PPIs");
    addItem ("Controloc 40 tab", "Pantoprazole 40 mg", "controloc pantoprazole antopral futapan jerdazolin pantazol pantoloc pantomerican pantopi peptoloc perloc protofix stringazole zurcal 40mg tablets", gitColor(context), "Erosive Esophagitis with GERD gastroesophageal reflux disease Hypersecretory Conditions zollinger ellison syndrome Peptic Ulcer Proton Pump Inhibitors PPIs");
    addItem ("Controloc vial", "Pantoprazole 40 mg", "controloc pantoprazole antopral futapan pantazol pantoloc perloc protofix zurcal 40mg vial", gitColor(context), "reflux Esophagitis Hypersecretory Conditions zollinger ellison syndrome gastritis duodenal Ulcer Proton Pump Inhibitors PPIs");
    addItem ("Convagran cap", "Zonisamide 100 mg", "convagran zonisamide zonivan 100mg capsules", cnsColor(context), "partial seizures weight loss anticonvulsants");
    addItem ("Convulex drops", "Sodium Valproate 300 mg /ml", "convulex valproic acid sodium valproate 300mg/ml drops", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Convulex 150 cap", "Sodium Valproate 150 mg", "convulex valproic acid sodium valproate 150mg capsules", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Convulex 300 cap", "Sodium Valproate 300 mg", "convulex valproic acid sodium valproate 300mg capsules", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Corasore drops", "Heptaminol 150 mg /ml", "corasore heptaminol respirin 150mg/ml drops", cvsColor(context), "orthostatic hypotension");
    addItem ("Corasore tab", "Heptaminol 150 mg", "corasore heptaminol 150mg tablets", cvsColor(context), "orthostatic hypotension");
    addItem ("Cortilon tab", "Fludrocortisone 0.1 mg", "cortilon fludrocortisone astonin-h astoninh 0.1mg tablets", strdColor(context), "adrenocortical insufficiency addison disease congenital adrenal hyperplasia congenital adrenogenital syndrome severe orthostatic hypotension Corticosteroids");
    addItem ("Cortiplex B6 adult amp", "Corticoadrenal extract 100 CDU +Vit B6 50 mg /1 ml", "cortiplex cortigen b6 adult corticoadrenal extract pyridoxine vitamin b6 ampoule", strdColor(context), "vomiting hypotension hyperemesis gravidarum radiation sickness antiemetic agents");
    addItem ("Cortiplex B6 pediatric amp", "Corticoadrenal extract 50 CDU +Vit B6 20 mg /1 ml", "cortiplex cortigen b6 pediatric corticoadrenal extract pyridoxine vitamin b6 ampoule", strdColor(context), "vomiting hypotension radiation sickness antiemetic agents");
    addItem ("Cortopect cap", "Acetylcysteine 300 mg", "cortopect acetylcysteine gemacysteine 300mg capsules", resColor(context), "productive cough mucolytics");
    addItem ("Cosentyx prefilled syringe", "Secukinumab 150 mg /ml", "Cosentyx Secukinumab 150mg/ml prefilled syringe", otherColor(context), "active psoriatic arthritis plaque psoriasis scalp psoriasis ankylosing spondylitis non-radiographic axial spondyloarthritis monoclonal antibodies");
    addItem ("Cough cut syrup", "Butamirate 7.5 mg /5 ml", "Cough cut Butamirate sinecod 7.5mg syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Coughsed children supp", "Paracetamol 250 mg +Gelsemium +Grindelia +Niaouli essence", "Coughsed children suppositories Paracetamol acetaminophen 250mg Gelsemium Grindelia Niaouli essence", resColor(context), "Cough");
    addItem ("Coughsed infant supp", "Paracetamol 100 mg +Gelsemium +Grindelia +Niaouli essence", "Coughsed infant suppositories Paracetamol acetaminophen 100mg Gelsemium Grindelia Niaouli essence", resColor(context), "Cough");
    addItem ("Coveram tab", "Amlodipine +Perindopril", "coveram amlodipine perindopril amloveran ancavaz covaprendo tablets", cvsColor(context), "hypertension ace Angiotensin-converting enzyme inhibitors Calcium Channel Blockers CCBs Calcium Channel Blockers CCBs");
    addItem ("Cranberry cap", "Cranberry 270 mg", "cranberry cranberry 270mg capsules", urinaryColor(context), "uti urinary tract infection");
    addItem ("Crestor 5 tab", "Rosuvastatin 5 mg", "crestor rosuvastatin advochol bemastrim cemicresto cholerose crestatin crestolip deconadal epirovastin estero-mep esteromep frositor justechol liporegistate merosatin novistoric pentastatin rositor rosumop rosuvast statirose suvikan vastasiero 5mg 10mg 20mg tablets", cvsColor(context), "familial hypercholesterolemia atherosclerosis cardiovascular disease prevention HMG-CoA Reductase Inhibitor Statins");
    addItem ("Curisafe drops", "Cefadroxil 100 mg /1 ml", "Curisafe Cefadroxil 100mg drops", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Curisafe 125 susp", "Cefadroxil 125 mg /5 ml", "Curisafe Cefadroxil duricef cephadrol ibidroxil 125mg/5ml suspension", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Curisafe 250 susp", "Cefadroxil 250 mg /5 ml", "Curisafe Cefadroxil biodroxil cephadrol duricef ibidroxil longicef roxil 250mg/5ml suspension", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Curisafe 500 susp", "Cefadroxil 500 mg /5 ml", "Curisafe Cefadroxil biodroxil duricef ibidroxil 500mg/5ml suspension", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Curisafe 500 cap", "Cefadroxil 500 mg", "Curisafe Cefadroxil biodroxil duricef ibidroxil longicef cefaxoral durabiotic megadroxil 500mg capsules", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Curisafe 1 gm tab", "Cefadroxil 1 gm", "Curisafe Cefadroxil biodroxil duricef ibidroxil cefaxoral cefex cefix 1000mg 1gm capsules", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Cyclo-Progynova tab", "Estradiol Valerate +Norgestrel", "cyclo-progynova Estradiol Valerate Norgestrel cycloprogynova valgestril tablets", hormoneColor(context), "hormone replacement therapy hormonal replacement therapy Irregular Menstruation");
    addItem ("Cymbalta 30 cap", "Duloxetine 30 mg", "cymbalta duloxetine adwitine cymbatex depretreve duloxeprin karbalta 30mg 60mg capsules", cnsColor(context), "major depressive disorder antidepressants diabetic peripheral neuropathic pain neuropathy generalized anxiety disorder fibromyalgia chronic musculoskeletal pain selective serotonin and norepinephrine reuptake inhibitors SSNRIs");
    addItem ("Cyrinol syrup", "Carbinoxamine +Pholcodine +Ephedrine", "Cyrinol syrup Carbinoxamine Pholcodine Ephedrine", resColor(context), "Dry Cough antitussive");
    addItem ("Cystinol cap", "Solidago Virgaurea 425 mg", "Cystinol Solidago Virgaurea goldenrod 425mg capsules", urinaryColor(context), "urinary calculi urolithiasis urinary stones urinary tract stones uti urinary tract infection");
    addItem ("Cystone tab", "Achyranthes +Cyperus +Didymocarpus +Hajrul yahood bhasma +Onosma +Rubiae +Saxifraga +Shilajeet +Vernonia", "cystone tablets Achyranthes Cyperus Didymocarpus Hajrul yahood bhasma Onosma Rubiae Saxifraga Shilajeet Vernonia", urinaryColor(context), "urinary calculi urolithiasis stones Crystalluria tract stones burning micturition infections uti incontinence Sialolithiasis");

    addItem ("Daclavirocyrl tab", "Daclatasvir 60 mg", "daclavirocyrl daclatasvir andodaclata augidacla clatazev daclahepex daclavirdin daklanork daktavira javidacla zetaciver 60mg tablets", abColor(context), "chronic hepatitis C virus infections hcv antiviral agents");
    addItem ("Daflon tab", "Diosmin 450 mg +Hesperidin 50 mg", "daflon diosmin hesperidin dafrex plus diosed-c veinatonic venowest veno-west tablets", cvsColor(context), "venous insufficiency acute hemorrhoidal attack venotonic varicose veins oedema uterine bleeding");
    addItem ("Dalfarosis ER tab", "Dalfampridine 10 mg", "dalfarosis er dalfampridine pyralerosis 10mg tablets", cnsColor(context), "multiple sclerosis Potassium Channel Blockers");
    addItem ("Dantrelax 25 cap", "Dantrolene 25 mg", "dantrelax Dantrolene dantrone relatrolene 25mg capsules", analgesicColor(context), "musculoskeletal muscle analgesics spasm relaxant Succinylcholine-induced Fasciculations & Post-op Muscle Pain spasticity");
    addItem ("Dapsone 50 tab", "Dapsone 50 mg", "dapsone 50mg tablets", abColor(context), "tb tuberculosis antileprosy dermatitis herpetiformis tuberculoid or lepromatous disease pneumocystis carinii jiroveci");
    addItem ("Dapsone 100 tab", "Dapsone 100 mg", "dapsone 100mg tablets", abColor(context), "tb tuberculosis antileprosy dermatitis herpetiformis tuberculoid or lepromatous disease pneumocystis carinii jiroveci");
    addItem ("Davalindi tab", "Vit D 1000 iu", "davalindi cholecalciferol candy-vit centravita d-trol d.dep vitamin d3 1000iu tablets", vitColor(context), "vitamin d deficiency supplementation osteoporosis");
    addItem ("Debospan syrup", "Marshmallow extract +Ivy extract +Thyme extract +Ginger extract", "debospan syrup Marshmallow Ivy Thyme Ginger extract", resColor(context), "Cough");
    addItem ("Decal B12 syrup", "Calcium +Vit D +Vit B12", "Decal B12 syrup Calcium cobalamin vitamin b12 vitamin d", vitColor(context), "Calcium deficiency supplementation hypocalcemia");
    addItem ("Decancit SR tab", "Cetirizine 5 mg +Pseudoephedrine 120 mg", "Decancit sr cetirizine 5mg pseudoephedrine 120mg clearest pseudozin sr xinase tablets capsules", resColor(context), "Allergic rhinitis nasal congestion decongestants");
    addItem ("Decapeptyl CR prefilled syringe", "Triptorelin 3.75 mg", "decapeptyl cr Triptorelin 3.75mg prefilled syringe", otherColor(context), "Prostate Cancer endometriosis uterine myoma assisted reproductive techniques ivf in vitro fertilization central precocious puberty Gonadotropin Releasing Hormone GNRH Agonists");
    addItem ("Declophen Plus cap", "Chlorzoxazone 250 mg +Diclofenac K 50 mg", "declophen plus capsules diclofenac k potassium 50mg chlorzoxazone 250mg", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Degreasian cap", "Omega-3-Acid Ethyl Esters 90 1000 mg", "Degreasian Omega-3-Acid Ethyl Esters 90 Fatty Acids 1000mg 1gm Omacor capsules", vitColor(context), "Hypertriglyceridemia Omega-3 Fatty Acids Deficiency");
    addItem ("Dekadel syrup", "Sodium Valproate 200 mg /5 ml", "dekadel valproic acid sodium valproate valpokine valponex valprotec 200mg/5ml syrup", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Delostigar SR tab", "Pyridostigmine 180 mg", "delostigar sr Pyridostigmine 180mg tablets", cnsColor(context), "myasthenia gravis Acetylcholinesterase Inhibitors");
    addItem ("Delpedox 875 tab", "Amoxicillin 875 mg", "delpedox amoxicillin 875mg tablets", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Deltasone syrup", "Dexamethasone 0.25 mg /5 ml", "Deltasone Dexamethasone 0.25mg/5ml syrup", strdColor(context), "Inflammation Croup Airway Edema Corticosteroids");
    addItem ("Deltasone tab", "Dexamethasone 0.75 mg", "Deltasone Dexamethasone 0.75mg tablets", strdColor(context), "Inflammation Allergic Conditions Corticosteroid");
    addItem ("Deltavit B12 tab", "Cyanocobalamin 1 mg", "deltavit cyanocobalamin vitamin oravit b12 1000mg 1gm sr tablets capsules", vitColor(context), "vitamin b12 deficiency supplementation");
    addItem ("Demafight 5 tab", "Metolazone 5 mg", "demafight metolazone efectinix metolanix rifky 5mg tablets", cvsColor(context), "Edema Hypertension diuretics");
    addItem ("Dentinox drops", "Simethicone 42 mg /5 ml", "dentinox infant colic simethicone activated dimethicone antifoam 42mg/5ml drops", gitColor(context), "Flatulence colic gas retention");
    addItem ("Depapalin syrup", "Pregabalin 20 mg /ml", "depapalin pregabalin averopreg locikaswab 20mg/ml syrup", cnsColor(context), "partial onset seizures fibromyalgia diabetic peripheral neuropathic pain with spinal cord injury postherpetic neuralgia epilepsy convulsions anticonvulsants");
    addItem ("Depo-Provera vial", "Medroxyprogesterone 150 mg / ml", "Depo-Provera Medroxyprogesterone depoprovera megestron oxyprogest 150mg/ml vial", hormoneColor(context), "Contraception Endometriosis-Associated Pain");
    addItem ("Depovit B12 amp", "Hydroxocobalamin (Vit B12) 1 mg /ml", "depovit hydroxocobalamin vitamin b12 cobalamin depot depofort depolvix hydrovit-b12 longavit b12 emicobal 1000mcg mg ampoule", vitColor(context), "Pernicious anemia Vitamin B12 deficiency supplementation");
    addItem ("Desa syrup", "Desloratadine 2.5 mg /5 ml", "desa Desloratadine alergaway brevy delarex delora deslorastamine deslorex endstamine fernilar lorafast ordesca tendratine stimloric skivalorine silistarkish ordesca hygitadine hygi-tadine embanodex 2.5mg/5ml syrup", resColor(context), "Allergic rhinitis allergy chronic urticaria 2nd second generation antihistamines");
    addItem ("Desa tab", "Desloratadine 5 mg", "desa Desloratadine aerius alergaway dclar d-clar delarex delorastop delora-stop deslargyl deslorex embanodex fernilar hygitadine hygi-tadine nouvonase ordesca silistorkish stimloric 5mg tablets", resColor(context), "Allergic rhinitis allergy chronic urticaria 2nd second generation antihistamines");
    addItem ("Desferal vial", "Deferoxamine 500 mg", "Desferal Deferoxamine desferrioxamine 500mg vial", vitColor(context), "Acute Iron Poisoning Chronic Iron Overload Chelating Agents antidotes");
    addItem ("Detrusitol tab", "Tolterodine 2 mg", "detrusitol Tolterodine noctopex sedoter terodine uricontrol uridry 2mg tablets", urinaryColor(context), "Detrusor Ovaractivity overactive bladder urge incontinence Anticholinergic Agents");
    addItem ("Detrusitol retard cap", "Tolterodine 4 mg", "detrusitol retard Tolterodine blad norm cystoridine incont l.a tolevo mr uricontrol sr 4mg capsules", urinaryColor(context), "Detrusor Ovaractivity overactive bladder urge incontinence Anticholinergic Agents");
    addItem ("Devarol-S amp", "Cholecalciferol (Vit D3) 200000 iu /2 ml", "devarol-s devarols cholecalciferol vitamin d3 davalindi decapreno osavidin devit-3 200000iu/2ml ampoule", vitColor(context), "Osteoporosis Rickets Vitamin D deficiency supplementation");
    addItem ("Dexamethasone amp", "Dexamethasone 8 mg /2 ml", "Dexamethasone epidron dexanocorten dexonium fcortin f-corten fortecortin jectacortin 8mg/2ml ampoule", strdColor(context), "Croup Inflammation Cerebral Edema Spinal Cord Compression Airway Edema Meningitis Corticosteroids");
    addItem ("Dextrafast tab", "Dexketoprofen 25 mg", "dextrafast dexketoprofen dexaprof dexketo care geskaprofen neo-ketadex neoketadex nisaprofen 25mg tablets", analgesicColor(context), "pain analgesics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Dextromethorphan syrup", "Dextromethorphan 10 mg /5 ml", "Dextromethorphan codiphan 10mg/5ml syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Dextrose 5% +NaCl 0.9% solution", "Glucose 50 mg +NaCl 9 mg /ml", "Dextrose glucose 5% NaCl normal saline Sodium Chloride 0.9% iv solution", cvsColor(context), "isotonic extracellular dehydration sodium depletion hypovolemia");
    addItem ("Diaben 5 tab", "Glibenclamide (Glyburide) 5 mg", "diaben glibenclamide glyburide daonil euglumide glibenase 5mg tablets", hormoneColor(context), "type2 diabetes mellitus Sulfonylureas");
    addItem ("Diacerein cap", "Diacerin 50 mg", "diacerein articusafe articu-safe diazocerine osteocerein osteorine 50mg capsules", analgesicColor(context), "knee and hip Osteoarthritis Anthraquinones");
    addItem ("Diaflozimet tab", "Dapagliflozin +Metformin", "Diaflozimet Dapagliflozin metformin dapablix met dapaglif plus xr dapaveldactin diglifloz plus xigduo tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides sodium-glucose co-transporter 2 SGLT2");
    addItem ("Dialy-Cal tab", "Calcium Acetate 500 mg (125 mg elemental calcium)", "Dialy-Cal Calcium Acetate dialycal 500mg tablets", vitColor(context), "hyperphosphatemia in end stage renal failure");
    addItem ("Diamicron 30 tab", "Gliclazide 30 mg", "diamicron gliclazide diabetron diamedizen gli sr glicla mr unocorn controbetic diabyl dianormal glipicrone serviclazid 30mg 40mg 60mg 80mg tablets", hormoneColor(context), "type2 diabetes mellitus Sulfonylureas");
    addItem ("Diane-35 tab", "Cyproterone 2 mg +Ethinylestradiol 35 mcg", "diane-35 tablets cyproterone acetate 2 mg Ethinylestradiol 35 mcg", hormoneColor(context), "moderate to severe acne in women of reproductive age");
    addItem ("Diaphage 850 tab", "Metformin 850 mg", "diaphage metformin cidophage retard diaquit 850 meglucon mepaphage xr 850mg tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides");
    addItem ("Diasmect sach", "Dioctahedral Smectite 3 gm", "Diasmect Dioctahedral Smectite diomecte smecta 3gm sachets", gitColor(context), "Antidiarrheal");
    addItem ("Diasmect susp", "Dioctahedral Smectite 20 gm /100 ml", "Diasmect Dioctahedral Smectite diomecte smecta 20gm/100ml suspension", gitColor(context), "Antidiarrheal");
    addItem ("Diastop susp", "Calcium carbonate +Kaolin +Tincture Belladonna +Tincture catechu +Anise oil +Lemon oil", "Diastop suspension Calcium carbonate Kaolin Tincture Belladonna catechu Anise Lemon oil", gitColor(context), "Antidiarrheal");
    addItem ("Diavance 1.25/250 tab", "Glibenclamide 1.25 mg +Metformin 250 mg", "diavance glibenclamide glyburide 1.25mg metformin 250mg amophage extra metclamide euglumide plus glucovance meburide gluokan glybformin glimet forte glybofen 1.25/250 2.5/400 2.5/500 5/800 5/1000 tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides Sulfonylureas");
    addItem ("Dicynone 500 tab", "Etamsylate 500 mg", "Dicynone etamsylate ethamsylate haemostop etacynone haemostat 500mg tablets", cvsColor(context), "bleeding haemorrhage antihemorrhagic agents menorrhagia");
    addItem ("Dicynone amp", "Etamsylate 250 mg /2 ml", "Dicynone etamsylate ethamsylate cyclona haemostop eselinate etacynone Etasylsunny hemostat 250mg/2ml ampoule", cvsColor(context), "bleeding Periventricular haemorrhage antihemorrhagic agents");
    addItem ("Diflucan 50 cap", "Fluconazole 50 mg", "Diflucan Fluconazole advotinpo amriflucan flocazole triconal 50mg capsules", abColor(context), "Oropharyngeal Esophageal Cryptococcal Meningitis Vaginal Candidiasis Candida UTI Peritonitis antifungals infections");
    addItem ("Diflucan 150 cap", "Fluconazole 150 mg", "Diflucan Fluconazole alkanazole amriflucan flocazole flucoral fludconrizole fungican jenfunga ramefluzole treflucan triconal unifungal 150mg capsules", abColor(context), "Oropharyngeal Esophageal Cryptococcal Meningitis Vaginal Candidiasis Candida UTI Peritonitis antifungals infections");
    addItem ("Diflucan syrup", "Fluconazole 5 mg /1 ml", "Diflucan Fluconazole diflunazole flucazonil 5mg/ml syrup", abColor(context), "Oropharyngeal Esophageal Candidiasis Cryptococcal Meningitis Systemic Candida antifungals infections");
    addItem ("Diflucan vial", "Fluconazole 2 mg /ml", "Diflucan Fluconazole anestacon flucand naviluca fluctobar sunnyfungal 2mg/ml vial", abColor(context), "Systemic Candidiasis Candida Infections Cryptococcal Meningitis antifungals infections");
    addItem ("Digest Eze cap", "Bromelain +Papain +Chamomile +Ginger +Peppermint +Anise +Fennel", "digest eze Bromelain Papain Chamomile Ginger Peppermint Anise Fennel after meals capsules", gitColor(context), "Maldigestion");
    addItem ("Digestin syrup", "Papain +Pepsin +Sanzyme", "digestin Papain Pepsin Sanzyme digenorm neodigestin neo-digestin syrup", gitColor(context), "Maldigestion");
    addItem ("Digestin tab", "Papain +Sanzyme", "digestin Papain Sanzyme digenorm digestozyme tablets", gitColor(context), "Maldigestion");
    addItem ("Diltiazem 60 tab", "Diltiazem 60 mg", "diltiazem altiazem angitect 60mg 120mg 180mg 240mg tablets", cvsColor(context), "angina pectoris class IV 4 antiarrhythmic agents Calcium Channel Blockers CCBs");
    addItem ("Diltiazem 90 SR cap", "Diltiazem 90 mg", "diltiazem delay-tiazem delaytiazem slow-zem slowzem telzim 90mg sr capsules", cvsColor(context), "Hypertension angina pectoris class IV 4 antiarrhythmic agents Calcium Channel Blockers CCBs");
    addItem ("Dimra tab", "Methocarbamol 500 mg +Diclofenac K 50 mg", "dimra methocarbamol 500mg diclofenac potassium 50mg methoquick flexilax movxir tablets", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Dinitra 5 sublingual tab", "Isosorbide Dinitrate 5 mg", "dinitra isosorbide dinitrate anginitra cardiket isorbid 5mg sublingual tablets", cvsColor(context), "angina pectoris nitrates");
    addItem ("Dinitra 10 tab", "Isosorbide Dinitrate 10 mg", "dinitra isosorbide dinitrate cardiket coronit 10mg 20mg tablets", cvsColor(context), "angina pectoris nitrates");
    addItem ("Diprivan amp", "Propofol 10 mg /ml", "diprivan propofol recofol 1% 10mg/ml ampoule vial", cnsColor(context), "Anesthesia mac sedation postoperative nausea vomiting icu patient General Anesthetic");
    addItem ("Disflatyl tab", "Simethicone 40 mg", "disflatyl simethicone flatidyl 40mg tablets", gitColor(context), "Flatulence colic gas retention");
    addItem ("Disprelone-OD 5 tab", "Prednisolone 5 mg", "disprelone-od prednisolone epicopred hostacortin h predilone solupred oro 5mg tablets", strdColor(context), "Inflammation Acute asthma Nephrotic Syndrome Rheumatoid Arthritis Multiple Sclerosis Acute Exacerbation of COPD Bells Palsy Corticosteroids");
    addItem ("Disprelone-OD 20 tab", "Prednisolone 20 mg", "disprelone-od disprelone-d prednisolone epicopred unipricort solupred oro 20mg tablets", strdColor(context), "Inflammation Acute asthma Nephrotic Syndrome Rheumatoid Arthritis Multiple Sclerosis Acute Exacerbation of COPD Bells Palsy Corticosteroids");
    addItem ("Divakote 250 tab", "Sodium Valproate 250 mg", "divakote valproic acid sodium valproate 250mg tablets", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Divakote 500 tab", "Sodium Valproate 500 mg", "divakote valproic acid sodium valproate depakine valpoeast-sr valpokine vedge daviken depacom valproex dekadel chrono 500mg tablets", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Diviton-D drops", "Vit D 4000 iu /ml (200 iu /drop)", "diviton-d cholecalciferol vitamin octa d3 daldrop 4000iu/ml 200iu/drops", vitColor(context), "vitamin d deficiency supplementation osteoporosis rickets");
    addItem ("Diviton-D forte drops", "Vit D 10000 iu /ml", "diviton-d forte cholecalciferol vitamin d bonefit 10000iu/ml drops", vitColor(context), "vitamin d deficiency supplementation osteoporosis rickets");
    addItem ("Dobutrex vial", "Dobutamine 250 mg /20 ml", "dobutrex dobutamine dobuject 250mg/20ml vial ampoule", cvsColor(context), "Cardiac Decompensation inotropic agents");
    addItem ("Dolcyl 1 tab", "Glimepiride 1 mg", "dolcyl glimepiride amaryl diabenor diabride gedimadel glaryl glimadel glimaryl glimitoid sugarfall conida diabetless diabeto glemax glimpir glimerazen glucoless glucoryl reglidib 1mg 2mg 3mg 4mg 6mg tablets", hormoneColor(context), "type2 diabetes mellitus Sulfonylureas");
    addItem ("Dolcyl M tab", "Glimepiride 2 mg +Metformin 500 mg", "dolcyl glimepiride 2mg metformin 500mg amaryl m tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides Sulfonylureas");
    addItem ("Doliprane tab", "Paracetamol 1000 mg", "doliprane novaldol Paracetamol-adco paramol augicetamide acetaminophen awadist cetal 1000mg 1gm tablets sachets", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Dolo-D susp", "Ibuprofen 100 mg +Pseudoephedrine 15 mg /5 ml", "Dolo-D Ibuprofen Pseudoephedrine brufen flu powcold suspension", resColor(context), "Common Cold Nasal congestion decongestants");
    addItem ("Dolo-D tab", "Ibuprofen 200 mg +Pseudoephedrine 30 mg", "Dolo-D Ibuprofen Pseudoephedrine brufen farex marcofen flu tablets", resColor(context), "Common Cold Nasal congestion decongestants");
    addItem ("Dolo-D plus susp", "Ibuprofen 100 mg +Pseudoephedrine 15 mg +Chlorpheniramine 1 mg /5 ml", "Dolo-D plus Ibuprofen Pseudoephedrine Chlorpheniramine westoflow suspension", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Dolo-D plus tab", "Ibuprofen 200 mg +Pseudoephedrine 30 mg +Chlorpheniramine 2 mg", "Dolo-D plus Ibuprofen Pseudoephedrine Chlorpheniramine sinlerg tablets", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Dolphin 12.5 supp", "Diclofenac Na 12.5 mg", "Dolphin diclofenac sodium na babyrelief declophen epifenac 12.5mg suppositories", analgesicColor(context), "Juvenile Idiopathic Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Dolphin 25 supp", "Diclofenac Na 25 mg", "Dolphin Diclofenac sodium na babyrelief epifenac declophen suppofen voltaren romalex 25mg suppositories", analgesicColor(context), "Acute Pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Dolphin 50 supp", "Diclofenac Na 50 mg", "Dolphin Diclofenac sodium na epifenac suppofen 50mg suppositories", analgesicColor(context), "Acute Pain rheumatoid osteoarthritis Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Dopamine amp", "Dopamine 200 mg /5 ml", "dopamine dopasunny intropin 200mg/5ml ampoule", cvsColor(context), "Hemodynamic Conditions as Hypotension inotropic agents");
    addItem ("Dormicum amp", "Midazolam 15 mg /3 ml", "dormicum midazolam midathetic 15mg/3ml ampoule", cnsColor(context), "preoperative sedation anxiolysis with anterograde amnesia anesthesia status epilepticus Benzodiazepines");
    addItem ("Dormival cap", "Valeriana dry extract +Humulus Lupulus extract", "dormival capsules valeriana dry humulus lupulus soft extract", cnsColor(context), "insomnia sleep disorders anxiety nervousness");
    addItem ("Dorofen cap", "Glucosamine +Ginkgo Biloba leaf extract", "dorofen glucosamine Ginkgo ginko Biloba leaf extract arthrosamine cartisamine gincostazen orthoglobe capsules", analgesicColor(context), "Osteoarthritis");
    addItem ("Downoprazol 20 cap", "Omeprazole 20 mg +Sodium Bicarbonate 1100 mg", "Downoprazol omeprazole sodium na bicarbonate 1100mg azgovanc omecarbex opranate opranate stomigas treato-ulc treatoulc zarroprazole 20mg capsules", gitColor(context), "symptomatic GERD gastroesophageal reflux disease Gastric Ulcer duodenal ulcer Peptic Ulcer heartburn Erosive Esophagitis upper gi bleeding Proton Pump Inhibitors PPIs");
    addItem ("Downoprazol 20 sach", "Omeprazole 20 mg +Sodium Bicarbonate 1680 mg", "Downoprazol omeprazole sodium na bicarbonate 1680mg nexipro opranate opranate stomigas zarroprazole 20mg sachets", gitColor(context), "symptomatic GERD gastroesophageal reflux disease Gastric Ulcer duodenal ulcer Peptic Ulcer heartburn Erosive Esophagitis upper gi bleeding Proton Pump Inhibitors PPIs");
    addItem ("Downoprazol 40 cap", "Omeprazole 40 mg +Sodium Bicarbonate 1100 mg", "Downoprazol omeprazole sodium na bicarbonate 1100mg azgovanc dudomez omecarbex omehealth opranate stomigas treato-ulc treatoulc 40mg capsules", gitColor(context), "symptomatic GERD gastroesophageal reflux disease Gastric Ulcer duodenal ulcer Peptic Ulcer heartburn Erosive Esophagitis upper gi bleeding Proton Pump Inhibitors PPIs");
    addItem ("Downoprazol 40 sach", "Omeprazole 40 mg +Sodium Bicarbonate 1680 mg", "Downoprazol omeprazole sodium na bicarbonate 1680mg dudomez opranate stomigas 40mg sachets", gitColor(context), "symptomatic GERD gastroesophageal reflux disease Gastric Ulcer duodenal ulcer Peptic Ulcer heartburn Erosive Esophagitis upper gi bleeding Proton Pump Inhibitors PPIs");
    addItem ("Doxirazol 30 cap", "Dexlansoprazole 30 mg", "Doxirazol Dexlansoprazole dexawest dexilant dexolant lantopep protolans ulcezole 30mg 60mg capsules", gitColor(context), "heartburn GERD gastroesophageal reflux disease Erosive Esophagitis Proton Pump Inhibitors PPIs");
    addItem ("Doxycost 50 tab", "Doxycycline 50 mg", "doxycost doxycycline 50mg tablets", abColor(context), "Malaria Prophylaxis Rickettsial Respiratory Tract Brucellosis Amebiasis Severe acne vulgaris Sexually Transmitted Ophthalmic Infections Syphilis Anthrax tetracyclines");
    addItem ("Doxycost 200 tab", "Doxycycline 200 mg", "doxycost doxycycline 200mg tablets", abColor(context), "Malaria Prophylaxis Rickettsial Respiratory Tract Brucellosis Amebiasis Severe acne vulgaris Sexually Transmitted Ophthalmic Infections Syphilis Anthrax tetracyclines");
    addItem ("Dramenex tab", "Dimenhydrinate 50 mg", "dramenex dimenhydrinate 50mg tablets", resColor(context), "motion sickness meniere's disease 1st first generation antihistamines");
    addItem ("Duodart cap", "Dutasteride 0.5 mg +Tamsulosin 0.4 mg", "Duodart capsules Dutasteride 0.5mg tamsulosin 0.4mg", urinaryColor(context), "benign prostatic hyperplasia bph 5 Alpha-Reductase Inhibitor alpha1 blockers");
    addItem ("Duphalac syrup", "Lactulose", "Duphalac Lactulose farcolac laxolac lactulax sedalac villapurg syrup", gitColor(context), "Constipation osmotic laxative Portal Systemic Encephalopathy");
    addItem ("Duphaston tab", "Dydrogesterone 10 mg", "duphaston dydrogesterone hormston tonadogest 10mg tablets", hormoneColor(context), "regulation of the cycle endometriosis dysmenorrhea infertility due to corpus luteum insufficiency threatened habitual abortion dysfunctional uterine bleeding secondary amenorrhea pre-menstrual syndrome");
    addItem ("Durazac 90 cap", "Fluoxetine 90 mg", "durazac fluoxetine fiesto depezac 90mg capsules", cnsColor(context), "major depressive disorder obsessive-compulsive disorder antidepressants Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Duricef 250 cap", "Cefadroxil 250 mg", "Duricef Cefadroxil ibidroxil 250mg capsules", abColor(context), "Streptococcal Pharyngitis tonsillitis Skin uti urinary tract infections Endocarditis 1st first generation cephalosporins");
    addItem ("Durogesic transdermal patch", "Fentanyl 12/25/50/75/100 mcg /hr", "durogesic fentanyl fentamat sandoz fentanilo 12/25/50/75/100mcg/hr transdermal patch", cnsColor(context), "chronic severe pain Opioids Analgesics");

    addItem ("E-mox 500 vial", "Amoxicillin 500 mg", "E-mox Amoxicillin amoxil biomox farconcil moxynil emox 500mg vial", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("E-mox 1 gm vial", "Amoxicillin 1 gm", "E-mox Amoxicillin emox biomox farconcil 1000mg 1gm vial", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Easycol Baby drops", "Lactase Enzyme", "easycol baby drops lactase enzyme", gitColor(context), "transient lactase deficiency");
    addItem ("Edemex tab", "Bumetanide 1 mg", "edemex bumetanide burinex 1mg tablets", cvsColor(context), "edema loop diuretics");
    addItem ("Edemex amp", "Bumetanide 0.5 mg /2 ml", "edemex bumetanide 0.5mg/2ml ampoule", cvsColor(context), "edema loop diuretics");
    addItem ("Efalex cap", "Fish Oil +Primrose Oil +Vit E +Thyme Oil", "efalex capsules fish omega3 primrose tocopherol vitamin e thyme oil", vitColor(context), "brain performance heart health normal vision");
    addItem ("Efalex syrup", "Fish Oil +Primrose Oil +Vit E +Thyme Oil", "efalex syrup fish omega3 primrose tocopherol vitamin e thyme oil", vitColor(context), "brain performance heart health normal vision");
    addItem ("Effortil drops", "Etilefrine 7.5 mg /ml", "effortil Etilefrine hartifrin tensofor vascon 7.5mg/ml drops", cvsColor(context), "circulatory collapse hypotension");
    addItem ("Effortil tab", "Etilefrine 5 mg", "effortil Etilefrine vascon 5mg tablets", cvsColor(context), "circulatory collapse hypotension");
    addItem ("Egy Dronate tab", "Alendronate 70 mg +Vit D3 2800 iu", "Egydronate alendronate 70mg vitamin d3 cholecalciferol alendronic acid alendomax plus basebone blastoclast calcidronate calendron colicalcedron debosteobone delendrozen fosavance once weekly osteonate plus rotalbone tablets", analgesicColor(context), "osteoporosis bisphosphonates");
    addItem ("Egy Pedical Plus syrup", "Calcium +Vit D3 +Vit K2 +Vit B12", "EgyPedical Plus syrup Calcium Glubionate Monohydrate vitamin d3 Cholecalciferol vitamin k2 Menaquinone-7 vitamin b12 Cyanocobalamin", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Egycusate syrup", "Docusate Na 20 mg /5 ml", "Egycusate Docusate sodium Na 20mg/5ml syrup", gitColor(context), "Constipation laxative");
    addItem ("Elbavit syrup", "Multivitamins +Calcium +Iron", "elbavit syrup Multivitamins a tocopherol e d3 b1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin b5 pantothenic acid b6 pyridoxine b9 folic acid b12 cobalamin c ascorbic acid Iodine Iron Calcium", vitColor(context), "multivitamins calcium iron");
    addItem ("Eliquis 2.5 tab", "Apixaban 2.5 mg", "eliquis apixaban apexawestan apixatrack artixiban elimbosis endlixaban iksaront pixaspire pixcolt sagitrixan strakopina 2.5mg tablets", cvsColor(context), "deep vein thrombosis dvt pulmonary embolism stroke prophylaxis with atrial fibrillation factor Xa inhibitor anticoagulants");
    addItem ("Eliquis 5 tab", "Apixaban 5 mg", "eliquis apixaban apixatrack artixiban elimbosis iksaront pixaspire strakopina 5mg tablets", cvsColor(context), "deep vein thrombosis dvt pulmonary embolism stroke prophylaxis with atrial fibrillation factor Xa inhibitor anticoagulants");
    addItem ("Elonda tab", "Cabergoline 0.5 mg", "elonda cabergoline cabergamoun caberglobe cabergolacto cabrostinex delcabrin Dostinex golinosab golinotech hypolact jakaranda marvigoline nostifix remigoline 0.5mg tablets", hormoneColor(context), "hyperprolactinemia");
    addItem ("Em-Ex amp", "Granisetron 1 mg /ml", "Em-Ex Granisetron emex emetovoid eupivora granitryl kytril mitashe 1mg/ml ampoule", gitColor(context), "Vomiting nausea Selective 5-HT3 Antagonists antiemetic agents");
    addItem ("Emetrex amp", "Cyclizine 50 mg /1 ml", "Emetrex Cyclizine 50mg/ml ampoule", gitColor(context), "Vomiting nausea antiemetic agents");
    addItem ("Emetrex tab", "Cyclizine 50 mg +Vit B6 30 mg", "Emetrex tablets Cyclizine vitamin b6 pyridoxine", gitColor(context), "Vomiting nausea antiemetic agents");
    addItem ("Empacoza 10 tab", "Empagliflozin 10 mg", "empacoza empagliflozin diacurimap Empaglimax Glimpacare Jardiance Mellitofix 10mg 25mg tablets", hormoneColor(context), "type2 diabetes mellitus heart failure sodium-glucose co-transporter 2 SGLT2");
    addItem ("Empacyrl tab", "Empagliflozin +Linagliptin", "empacyrl tablets empagliflozin linagliptin", hormoneColor(context), "type2 diabetes mellitus sodium-glucose co-transporter 2 SGLT2 dipeptidyl peptidase-4 DPP-4 inhibitor");
    addItem ("Enbrel 50 prefilled syringe", "Etanercept 50 mg", "enbrel etanercept 50mg prefilled syringe", otherColor(context), "ankylosing spondylitis psoriatic arthritis plaque psoriasis Tumor Necrosis Factor TNF Blockers");
    addItem ("Endoxan tab", "Cyclophosphamide 50 mg", "endoxan cyclophosphamide cytophosphane alkyloxan 50mg tablets", otherColor(context), "malignant disease nephrotic syndrome Antineoplastic Agents Immunomodulators");
    addItem ("Endoxan 200 vial", "Cyclophosphamide 200 mg", "endoxan cyclophosphamide cytophosphane alkyloxan alkyloxan cycran neophos neophos 200mg vial", otherColor(context), "malignant disease nephrotic syndrome non-hodgkin lymphoma breast cancer juvenile idiopathic arthritis vasculitis lupus nephritis systemic lupus erythematosus sle Antineoplastic Agents Immunomodulators");
    addItem ("Endoxan 1000 vial", "Cyclophosphamide 1 gm", "endoxan cyclophosphamide cytophosphane cycram neophos nephos neophos 1000mg 1gm vial", otherColor(context), "malignant disease nephrotic syndrome non-hodgkin lymphoma breast cancer juvenile idiopathic arthritis vasculitis lupus nephritis systemic lupus erythematosus sle Antineoplastic Agents Immunomodulators");
    addItem ("Enemax enema", "Disodium Phosphate +Monosodium Phosphate", "enemax enema disodium monosodium phosphate", gitColor(context), "Constipation Bowel Cleansing");
    addItem ("Engilor 2.5/500 tab", "Glipizide 2.5 mg +Metformin 500 mg", "engilor glipizide 2.5mg metformin 500mg gliform 2.5/500 tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides Sulfonylureas");
    addItem ("Enrich drops", "Ferric Hydroxide Polymaltose Complex 156.25 mg (Elemental Iron 50 mg) /ml", "Enrich Iron Ferric Hydroxide Polymaltose Complex hydroferrin haemopower 50mg/ml drops", vitColor(context), "iron deficiency anemia supplementation");
    addItem ("Enrich syrup", "Ferric Hydroxide Polymaltose Complex 156.25 mg (Elemental Iron 50 mg) /5 ml", "Enrich Iron Ferric Hydroxide Polymaltose Complex ferose haemojet haemopower golden fer hemaltose 50mg/5ml syrup", vitColor(context), "iron deficiency anemia supplementation");
    addItem ("Enterogermina susp", "Bacillus Clausii Spores", "enterogermina suspension bacillus clausii spores", gitColor(context), "Antidiarrheal");
    addItem ("Entocid tab", "Diiodohydroxyquinoline +Phthalyl Sulfathiazole +Streptomycin", "entocid tablets Di-iodohydroxyquinoline Diiodohydroxyquinoline Phthalyl Sulfathiazole Sulphathiazole Streptomycin Sulphate", abColor(context), "acute chronic bacillary dysentery amebiasis bacterial enteritis colitis");
    addItem ("Entresto tab", "Sacubitril +Valsartan", "entresto Sacubitril Valsartan sacutrend tablets", cvsColor(context), "heart failure ARBs Angiotensin receptor blockers");
    addItem ("Epcimox 125 tab", "Amoxicillin 125 mg", "epcimox amoxicillin 125mg tablets", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Epicogel susp", "Al Hydroxide +Mg Hydroxide +Dimethicone", "epicogel suspension aluminum aluminium hydroxide magnesium hydroxide dimethicone", gitColor(context), "Gastritis Dyspepsia flatulence heartburn Peptic Ulcer antacids");
    addItem ("Epicophylline syrup", "Acefylline Piperazine 125 mg /5 ml", "epicophylline acephylline acefylline piperazine theophylline ethanoate 125mg/5ml syrup", resColor(context), "Bronchospasm bronchial asthma chronic bronchitis");
    addItem ("Epicotil supp", "Tenoxicam 20 mg", "epicotil tenoxicam anoxicam soral tenocam 20mg suppositories", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis ankylosing spondylitis dysmenorrhea inflammations analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Epicotil tab", "Tenoxicam 20 mg", "epicotil tenoxicam anoxicam serelanocam soral tenocam tenoxil 20mg tablets capsules", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis ankylosing spondylitis dysmenorrhea acute gouty arthritis inflammations analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Epicotil vial", "Tenoxicam 20 mg", "epicotil tenoxicam soral tenoxil 20mg vial", analgesicColor(context), "Osteoarthritis Rheumatoid inflammations analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Epicozym syrup", "Vitamin B complex", "Epicozym syrup Vitamin B1 thiamine vitamin b2 riboflavin vitamin b3 nicotinamide vitamin b6 pyridoxine panthenol complex", vitColor(context), "Vitamin B deficiency");
    addItem ("Epifasi amp", "Human Chorionic Gonadotrophin 5000 iu", "epifasi Human Chorionic Gonadotrophin choragon choriofactor choriomon 5000iu vial ampoule", hormoneColor(context), "induction of ovulation pregnancy anovulatory infertility gonadotropins");
    addItem ("Epilat cap", "Nifedipine 10 mg", "epilat nifedipine 10mg capsules", cvsColor(context), "angina pectoris Calcium Channel Blockers CCBs");
    addItem ("Epilat retard SR cap", "Nifedipine 20 mg", "epilat retard nifedipine adalat la 20mg 30mg 60mg capsules", cvsColor(context), "angina pectoris pulmonary hypertension raynaud phenomenon Calcium Channel Blockers CCBs");
    addItem ("Epimag sach", "Magnesium Citrate", "epimag citrocid magnesium citrate diasporal citric acid sachets", urinaryColor(context), "hyperoxaluria oxalate stones laxative constipation");
    addItem ("Epinephrine amp", "Adrenaline 0.25 mg / 1 ml", "Epinephrine Adrenaline 0.25mg/ml ampoule", cvsColor(context), "Anaphylaxis Asystole Pulseless Arrest alpha/beta adrenergic agonist");
    addItem ("Epinor 400 tab", "Norfloxacin 400 mg", "Epinor norfloxacin norbactin neofloxin noracin normesh 400mg tablets", abColor(context), "Dysenteric enterocolitis Prostatitis uti urinary tract infections Gonorrhea fluoroquinolones");
    addItem ("Epinosine-B Forte amp", "ATP +Cocarboxylase +Vit B12 +Nicotinamide", "Epinosine-B Forte ATP adenosine triphosphate Cocarboxylase thiamine vitamin b1 vitamin b12 Nicotinic Acid nicotinamide niacin vitamin b3 adeno sed b forte ampoule", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Epirelefan amp", "Triamcinolone 40 mg /ml", "Epirelefan Triamcinolone acetonide amcinol kenacort-a pharcocinolone synthecortin 40mg/ml ampoule", strdColor(context), "Rheumatic disorders Arthritic Disorders Inflammatory & Allergic Systemic Conditions inflammations Multiple Sclerosis Corticosteroids");
    addItem ("Eprex prefilled syringe", "Erythropoietin Alfa", "eprex recombinant human erythropoietin alpha epoetin alfa epojet eposino prefilled syringe", hormoneColor(context), "ckd associated anemia chronic kidney disease associated anemia zidovudine-related anemia chemotherapy related anemia reduction of allogeneic rbc transfusion");
    addItem ("Erastapex Co tab", "Amlodipine +Olmesartan", "Erastapex co amlodipine olmesartan improflow lezberg-amlo lezbergamlo olmedipine tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers Calcium Channel Blockers CCBs");
    addItem ("Erastapex Trio tab", "Amlodipine +Olmesartan +Hydrochlorothiazide", "Erastapex trio amlodipine olmesartan hydrochlorothiazide amlosazide averothiazide marvitense tribatens tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics Calcium Channel Blockers CCBs");
    addItem ("Erythromycin susp", "Erythromycin Ethylsuccinate 200 mg /5 ml", "Erythromycin ethylsuccinate erythrocid erythrocin erythroriv erythronate 200mg/5ml suspension", abColor(context), "Chlamydial Conjunctivitis Pneumonia Pertussis Mycoplasma Ureaplasma Pharyngitis tonsillitis Intestinal Amebiasis Urethritis Macrolides");
    addItem ("Erythrocin 250 tab", "Erythromycin Ethylsuccinate 250 mg", "Erythrocin Erythromycin Ethylsuccinate 250mg tablets", abColor(context), "Pneumonia Pertussis Pharyngitis tonsillitis Intestinal Amebiasis Urethritis Macrolides");
    addItem ("Erythrocin 500 tab", "Erythromycin Ethylsuccinate 500 mg", "Erythrocin Erythromycin Ethylsuccinate 500mg tablets", abColor(context), "Pneumonia Pertussis Pharyngitis tonsillitis Intestinal Amebiasis Urethritis Macrolides");
    addItem ("Eslizepine 400 tab", "Eslicarbazepine 400 mg", "eslizepine eslicarbazepine eslicarba lepsylief 400mg 800mg tablets", cnsColor(context), "Partial-Onset Seizures convulsions anticonvulsants");
    addItem ("Etaphylline Phenobarbital supp", "Acephylline piperazine 500 mg +Phenobarbital 100 mg", "etaphylline phenobarbital suppositories Acephylline Acefylline piperazine", resColor(context), "chronic respiratory diseases bronchospasm bronchial asthma");
    addItem ("Etaphylline Phenobarbital syrup", "Acephylline piperazine 100 mg +Phenobarbital 3.3 mg /5 ml", "etaphylline phenobarbital Acephylline Acefylline piperazine epicophylline phenobarbitone syrup", resColor(context), "bronchospasm anxiety insomnia bronchial asthma");
    addItem ("Ethoxa syrup", "Ethosuximide 250 mg /5 ml", "ethoxa ethosuximide 250mg/5ml syrup", cnsColor(context), "absence seizures epilepsy convulsions anticonvulsants");
    addItem ("Eucarbon tab", "Charcoal +Rhubarb +Senna +Sulphur", "eucarbon tablets Charcoal Rhubarb Senna Sulphur peppermint fennel oil", gitColor(context), "Constipation laxative flatulence gas retention");
    addItem ("Euthyrox 25 tab", "Levothyroxine 25 mcg", "euthyrox levothyroxine eltroxin t4-thyro t4thyro tyraxine 25mg 50mg 100mg tablets", hormoneColor(context), "Hypothyroidism");
    addItem ("Evastine syrup", "Ebastine 5 mg /5 ml", "evastine Ebastine ebastel 5mg/5ml syrup", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Evastine 10 tab", "Ebastine 10 mg", "evastine Ebastine ebastel 10mg tablets", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Examide 5 tab", "Torsemide 5 mg", "examide torsemide cardiotimide onced torseretic exaretic torasemide torsamolex 5mg 10mg 20mg 100mg tablets", cvsColor(context), "edema hypertension loop diuretics");
    addItem ("Exforge tab", "Amlodipine +Valsartan", "exforge amlodipine valsartan alkapress plus amilo plus avivavasc blokatens elimolivan kemiforge molivart zarlodip zetakardoval nexpress valinopress tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers Calcium Channel Blockers CCBs");
    addItem ("Exforge HCT tab", "Amlodipine +Valsartan +Hydrochlorothiazide", "exforge hct Amlodipine Valsartan Hydrochlorothiazide forgenap lotendor vaslow alkapress trio tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics Calcium Channel Blockers CCBs");
    addItem ("Expaintech-PM tab", "Paracetamol 500 mg +Diphenhydramine 38 mg", "expaintech-pm paracetamol acetaminophen diphenhydramine excedrin p.m. excedrin pm stopadol night tablets", resColor(context), "analgesics pain insomnia sleeplessness");
    addItem ("Ezamol-C tab", "Paracetamol +Phenylephrine +Caffeine +Terpine +Vit C", "ezamol-c tablets Paracetamol acetaminophen Phenylephrine Caffeine Terpine hydrate vitamin c ascorbic acid", resColor(context), "common cold influenza fever antipyretics analgesics pain nasal congestion decongestants");

    addItem ("Farcolin nebulizer solution", "Salbutamol 0.5%", "Farcolin Salbutamol albuterol ventolin salbovent broncholin nebulizer solution respirator", resColor(context), "acute severe bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Farcolin syrup", "Salbutamol +Ammonium chloride", "Farcolin syrup Salbutamol Ammonium chloride albuterol", resColor(context), "Cough Bronchodilators short-acting Beta2 Agonists");
    addItem ("Farcosolvin syrup", "Theophylline +Guaifenesin +Ambroxol", "Farcosolvin syrup Theophylline Guaifenesin Ambroxol tribroxol tri-broxol", resColor(context), "bronchospasm associated with Productive Cough mucolytics expectorant");
    addItem ("Farcovit B12 cap", "Vit B1 +Vit B2 +Vit B6 +Vit B12 +Calcium +Nicotinamide +Inositol +Orotic Acid +Folic Acid +D (+) Biotin +Cynara +Safflower Oil +Essential Phospholipids", "farcovit b12 essential phospholipids Multivitamins B1 thiamine mononitrate B2 riboflavin B6 pyridoxine B12 cyanocobalamin Cynara B5 calcium pantothenate Nicotinic Acid nicotinamide niacin b3 inositol b8 orotic acid folic acid d (+) b9 b7 biotin safflower oil capsules", gitColor(context), "Liver Tonic liver support supplementation");
    addItem ("Faverin 50 tab", "Fluvoxamine 50 mg", "faverin fluvoxamine fluxamine statomain 50mg 100mg tablets", cnsColor(context), "Obsessive-Compulsive Social Phobia Panic Posttraumatic Stress Disorder Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Fawar Fruit sach", "Citric Acid +Na Bicarbonate +Tartaric Acid", "fawar fruit citric acid na sodium bicarbonate tartaric acid effruti fruit epinos pineapple fawar cola fafwar lemon pharocola pharofruit sepcofruit xenos fruit sachets", gitColor(context), "GERD gastroesophageal reflux disease Gastric Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Stress Ulcer");
    addItem ("Feldene 10 cap", "Piroxicam 10 mg", "feldene piroxicam dispercam inflacam 10mg capsules tablets", analgesicColor(context), "rheumatoid osteoarthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Feldene 20 cap", "Piroxicam 20 mg", "feldene flash piroxicam dispercam brexin feldoral inflacam piroxiden piroxifar vendocid 20mg capsules tablets", analgesicColor(context), "rheumatoid osteoarthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Femara tab", "Letrozole 2.5 mg", "femara letrozole femapent letrotume trexozola 2.5mg tablets", otherColor(context), "breast Ovarian Epithelial Cancer Antineoplastic Agents Aromatase Inhibitors");
    addItem ("Femogesal tab", "Ethinyl Estradiol 30 mcg +Gestodene 75 mcg", "femogesal ethinylestradiol gestodene Andoceptive gynera gestranil gynocept 30mcg tablets", hormoneColor(context), "Oral contraception");
    addItem ("Femrose cap", "Black Cohosh 80 mg", "femrose black cohosh cimicifuga racemosa cimipax fiminosan klimadynon menoreif 80mg capsules", otherColor(context), "Cough/sore throat dysmenorrhea dyspepsia labor induction menopausal symptoms nervous tension premenstrual syndrome rheumatism");
    addItem ("Fenistil drops", "Dimethindene 1 mg /1 ml", "Fenistil Dimethindene 1mg/ml drops", resColor(context), "Allergic rhinitis allergy Urticaria 1st first generation antihistamines");
    addItem ("Fentanyl amp", "Fentanyl 0.1 mg /2 ml", "fentanyl 0.1mg/2ml ampoule", cnsColor(context), "surgery premedication general continuous analgesia continuous sedation adjunct anesthesia opioids");
    addItem ("Feroglobin cap", "Folic Acid +Iron +Zinc +Copper +Vit B6 +Vit B12", "Feroglobin capsules Iron Folic Acid vitamin b9 copper zinc vitamin b12 vitamin b6 pyridoxine cobalamin", vitColor(context), "vitamins minerals deficiency supplementation");
    addItem ("Feroglobin syrup", "Iron +Minerals +Vit B complex +Vit C", "Feroglobin syrup Iron zinc copper manganese iodine lysine pantothenic acid vitamin b1 thiamine vitamin b2 riboflavin vitamin b3 niacin vitamin b6 pyridoxine vitamin b9 folic acid vitamin b12 cobalamin vitamin c ascorbic acid complex", vitColor(context), "vitamins deficiency supplementation");
    addItem ("Ferrodep cap", "Sunactive Iron +Vit C", "ferrodep capsules sunactive Iron vitamin c ascorbic acid", vitColor(context), "ida iron deficiency anemia");
    addItem ("Ferrodep syrup", "Sunactive Iron +Vit C +Zinc +Copper +Vit B2 +Vit B6 +Vit B12 +Folic Acid", "ferrodep syrup sunactive Iron vitamin c ascorbic acid Zinc Copper riboflavin Vitamin B2 Vitamin B6 pyridoxine cobalamin Vitamin B12 Folic Acid vitamin b9", vitColor(context), "ida iron deficiency anemia Vitamins Minerals deficiency supplementation");
    addItem ("Ferrotron cap", "Iron +Zinc +Copper +Molybdenum +Vit B1 +Vit B2 +Vit B6 +Vit B12 +Folic Acid +Vit C +Biotin", "ferrotron capsules Iron Zinc Copper cu Molybdenum thiamine vitamin b1 riboflavin vitamin b2 pyridoxine vitamin b6 cobalamin vitamin b12 Folic Acid vitamin b9 vitamin c ascorbic acid vitamin b7 Biotin", vitColor(context), "iron deficiency anemia Vitamins minerals deficiency supplementation");
    addItem ("Fewmig cap", "Feverfew ext 250 mg", "fewmig feverfew extract mig capsules", cnsColor(context), "migraine prophylaxis");
    addItem ("Fitmotus tab", "Collagen +Hyaluronic Acid +Boron", "fitmotus undenatured collagen type2 hyaluronic acid boron moventor tablets", analgesicColor(context), "Rheumatoid Arthritis Acute Pain analgesics Osteoarthritis support bone health joint cartilage");
    addItem ("Flabu drops", "Ibuprofen 40 mg /ml", "flabu Ibuprofen peopobruf 40mg/ml drops", analgesicColor(context), "fever pain analgesics antipyretics Closure of PDA patent ductus arteriosus Juvenile Idiopathic Arthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Flacort 6 tab", "Deflazacort 6 mg", "flacort deflazacort 6mg 30mg tablets", strdColor(context), "duchenne muscular dystrophy dmd Corticosteroids");
    addItem ("Fladazole tab", "Secnidazole 500 mg", "fladazole secnidazole eurozole flagentyl secnida-misr senidal 500mg tablets", abColor(context), "Trichomoniasis Bacterial Vaginosis nitroimidazoles");
    addItem ("Flagellat Forte susp", "Metronidazole 200 mg /5 ml", "flagellat forte Metronidazole 200mg suspension", abColor(context), "Amebiasis Giardiasis Trichomoniasis Clostridium Difficile Colitis Anaerobic infections Bacterial Vaginosis nitroimidazoles");
    addItem ("Flamogen tab", "Bromelain +Rutoside +Trypsin", "flamogen Bromelain Rutoside neutra Trypsin trypsalin zymentern tablets", otherColor(context), "Inflammations Oedema");
    addItem ("Flazol vial", "Metronidazole 500 mg /100 ml", "flazol Metronidazole amrizole bumexazole metroflag trichogel flagyl 500mg/100ml vial", abColor(context), "Giardiasis Trichomoniasis Clostridium Difficile Colitis Anaerobic infections Colorectal Surgical infections Prophylaxis nitroimidazoles");
    addItem ("Fleboton amp", "Troxerutin +Carbazochrome", "Fleboton Troxerutin Carbazochrome trozachrome ampoule", cvsColor(context), "Symptomatic Venous Insufficiency Capillary Fragility in Post-hemorrhoidectomy Patients");
    addItem ("Flexofan cap", "Chlorzoxazone 250 mg +Ketoprofen 50 mg", "Flexofan chlorzoxazone ibuprofen diclorelax capsules", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Flexpro Extra tab", "Methocarbamol 400 mg +Paracetamol 500 mg", "flexpro extra methocarbamol 400mg paracetamol acetaminophen 500mg methobamol methorelax tablets", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Flibanorin tab", "Flibanserin 100 mg", "flibanorin flibanserin aphrofemina flibafemina flibanoact veroxeserin 100mg tablets", urinaryColor(context), "Hypoactive Sexual Desire Disorder in premenopausal women Serotonin 5-HT-Receptor Agonists");
    addItem ("Flixotide Diskus 50", "Fluticasone 50 mcg /dose", "flixotide diskus fluticasone 50mcg/dose", resColor(context), "bronchial asthma corticosteroids");
    addItem ("Flixotide Diskus 100", "Fluticasone 100 mcg /dose", "flixotide diskus fluticasone 100mcg/dose", resColor(context), "bronchial asthma corticosteroids");
    addItem ("Flixotide Diskus 250", "Fluticasone 250 mcg /dose", "flixotide diskus fluticasone 250mcg/dose", resColor(context), "bronchial asthma corticosteroids");
    addItem ("Flixotide Evohaler 50", "Fluticasone 50 mcg /actuation", "flixotide fluticasone 50mcg/actuation evohaler", resColor(context), "bronchial asthma corticosteroids");
    addItem ("Flixotide Evohaler 125", "Fluticasone 125 mcg /actuation", "flixotide fluticasone 125mcg/actuation evohaler", resColor(context), "bronchial asthma corticosteroids");
    addItem ("Flixotide Evohaler 250", "Fluticasone 250 mcg /actuation", "flixotide fluticasone flohale hfa 250mcg/actuation evohaler", resColor(context), "bronchial asthma corticosteroids");
    addItem ("Flopadex 4 cap", "Silodosin 4 mg", "flopadex silodosin congdosin sildocare siloprostate 4mg capsules", urinaryColor(context), "benign prostatic hyperplasia bph alpha1 blockers");
    addItem ("Flopadex 8 cap", "Silodosin 8 mg", "flopadex silodosin congdosin eligodosin lidoflak rikadosin sildocare sympaprost 8mg capsules", urinaryColor(context), "benign prostatic hyperplasia bph alpha1 blockers");
    addItem ("Florax tab", "Vit C 500 mg +Vit D 400 iu +Zinc 25 mg", "florax ascorbic acid vitamin c 500mg vitamin d 400iu Zinc 25mg pieces immurave one tablets capsules", vitColor(context), "immunity enhancer vitamins minerals deficiency supplementation");
    addItem ("Floxa west tab", "Ofloxacin 300 mg", "floxawest ofloxacin 300mg tablets", abColor(context), "Cervicitis Urethritis Prostatitis Traveler's Traveller's Diarrhea fluoroquinolones");
    addItem ("Fluimucil amp", "Acetylcysteine 100 mg /ml", "fluimucil ampoule acetylcysteine 100mg/ml", resColor(context), "acetaminophen paracetamol toxicity overdose antidotes");
    addItem ("Flumox 500 vial", "Amoxicillin 250 mg +Flucloxacillin 250 mg", "Flumox Amoxicillin 250mg Flucloxacillin 250mg flucamox amflux amofluxin flumocin 500mg vial", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Flumox 1 gm vial", "Amoxicillin 500 mg +Flucloxacillin 500 mg", "Flumox Amoxicillin 500mg Flucloxacillin 500mg flucamox amflux amofluxin flumocin 1000mg 1gm vial", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Flumox 250 cap", "Amoxicillin 125 mg +Flucloxacillin 125 mg", "flumox Amoxicillin 125mg Flucloxacillin 125mg flumocin amoflux flucamox curaflux 250mg capsules", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Flumox 500 cap", "Amoxicillin 250 mg +Flucloxacillin 250 mg", "flumox Amoxicillin 250mg Flucloxacillin 250mg flumocin amoflux flucamox curaflux amofluxin famox hiflucil 500mg capsules", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Flumox 1 gm tab", "Amoxicillin 500 mg +Flucloxacillin 500 mg", "flumox Amoxicillin 500mg Flucloxacillin 500mg gramoflux pencillimox floxamo combifloxin amoflux combifloxin 1000mg 1gm tablets", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Flumox susp", "Amoxicillin 125 mg +Flucloxacillin 125 mg /5 ml", "Flumox Amoxicillin 125mg Flucloxacillin 125mg amoflux famox flucamox suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Flurest tab", "Chlorpheniramin +Phenylephrine +Paracetamol", "flurest Chlorpheniramine Phenylephrine paracetamol acetaminophen sineup calmalgine tablets", resColor(context), "Common cold influenza Nasal congestion allergic rhinitis fever antipyretic analgesic pain muscle ache decongestants");
    addItem ("Fluvermal susp", "Flubendazole 100 mg /5 ml", "Fluvermal Flubendazole flubenzole verm-all vermall 100mg/5ml suspension", abColor(context), "Entrobius Pinworm oxyuris roundworm Ascaris whipworm trichuriasis hookworm Ancylostoma");
    addItem ("Fluvermal tab", "Flubendazole 100 mg", "Fluvermal Flubendazole flubenzole verm-all vermall 100mg tablets", abColor(context), "Entrobius Pinworm oxyuris roundworm Ascaris whipworm trichuriasis hookworm Ancylostoma");
    addItem ("Folic Acid 0.5 tab", "Folic Acid 0.5 mg", "folic acid folicap vitamin b9 0.500mcg 2.5mg tablets capsules", vitColor(context), "folic acid deficiency prevention of neural tube defects methotrexate toxicity prophylaxis");
    addItem ("Foradil inhalation caps", "Formoterol Fumarate 12 mcg", "Foradil Formoterol Fumarate foratec dp formohale metrohaler 12mcg inhalation capsules", resColor(context), "bronchial asthma maintenance copd chronic obstructive pulmonary disease long-acting Beta2 Agonists");
    addItem ("Forteo prefilled pen", "Teriparatide 250 mg /ml (20 mcg/80 mcl)", "Forteo Teriparatide 250mg/ml 20mcg/80mcl prefilled pen", otherColor(context), "osteoporosis Parathyroid Hormone Analogs");
    addItem ("Forxiga 5 tab", "Dapagliflozin 5 mg", "Forxiga DapagliflozinO dapablix dapaveldactin diglifloz forflozin zegapets 5mg 10mg tablets", hormoneColor(context), "type2 diabetes mellitus heart failure chronic kidney disease sodium-glucose co-transporter 2 SGLT2");
    addItem ("Fostimon vial", "Urofollitropin", "Fostimon Urofollitropin bravelle metrodin vial ampoule", hormoneColor(context), "ovulation induction art assisted reproductive technology spermatogenesis gonadotropins");
    addItem ("FPI-Zinc cap", "Zinc 50 mg", "fpi-zinc gluconate all one devart green & lean sanso solvazinc zinkeem 50mg capsules", vitColor(context), "zinc deficiency supplementation");
    addItem ("Fruital syrup", "Multivitamins", "fruital syrup Multivitamins a b1 thiamine b2 riboflavin b6 pyridoxine Nicotinic Acid nicotinamide niacin b3 c ascorbic acid d2 e tocopherol", vitColor(context), "multiVitamins deficiency Supplementation");
    addItem ("Furazol tab", "Diloxanide +Metronidazole", "furazol diloxanide metronidazole dilozole flagimide tablets", abColor(context), "Amebiasis Giardiasis");

    addItem ("G.C.Mol sach", "Guaifenesin +Vit C +Paracetamol", "g.c.mol gcmol sachets guaifenesin vitamin c ascorbic acid paracetamol acetaminophen", resColor(context), "common cold influenza cough");
    addItem ("Galvus 50 tab", "Vildagliptin 50 mg", "galvus vildagliptin dibavally gliptus gluvildan icandra sugarlo vildagluse vilgat 50mg tablets", hormoneColor(context), "type2 diabetes mellitus dipeptidyl peptidase-4 DPP-4 inhibitor");
    addItem ("Galvus Met tab", "Vildagliptin +Metformin", "galvus met vildagliptin metformin dibavally gliptus icandra vildaformin vildagluse futavildix sugarlo vilgat plus tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides dipeptidyl peptidase-4 DPP-4 inhibitor");
    addItem ("Ganaton tab", "Itopride 50 mg", "ganaton alkapride ema itopride ganamotil gantolief garopride gastorelive itomash movigit 50mg tablets", gitColor(context), "colic chronic gastritis bloating heartburn prokinetic agents");
    addItem ("Gaptin 300 cap", "Gabapentin 300 mg", "gaptin gabapentin adaptan conventin epicopentin ezapentin gabalepsy gabimash lepticure neuroglopentin neurontin octoconval pentalipsy ramsoom shalgaten stablentin vegapantin 300mg 400mg 600mg 800mg capsules", cnsColor(context), "partial seizures postherpetic neuralgia cocaine withdrawal insomnia diabetic polyneuropathy tremors in multiple sclerosis hot flashes-cancer related epilepsy convulsions anticonvulsants");
    addItem ("Gaptin syrup", "Gabapentin 250 mg /5 ml", "gaptin gabapentin adaptan stablentin vegapantin 250mg/5ml syrup", cnsColor(context), "partial seizures postherpetic neuralgia restless legs syndrome cocaine withdrawal insomnia diabetic polyneuropathy tremors in multiple sclerosis hot flashes-cancer related epilepsy convulsions anticonvulsants");
    addItem ("Garamycin 20 amp", "Gentamicin 20 mg /2 ml", "Garamycin Gentamicin epigent 20mg/2ml ampoule", abColor(context), "Gram -ve negative infections Surgical Prophylaxis Cystic Fibrosis Plague aminoglycosides");
    addItem ("Garamycin 40 amp", "Gentamicin 40 mg /2 ml", "Garamycin Gentamicin refobacin 40mg/2ml ampoule", abColor(context), "Gram -ve negative infections Surgical Prophylaxis Cystic Fibrosis Plague aminoglycosides");
    addItem ("Garamycin 80 amp", "Gentamicin 80 mg /2 ml", "Garamycin Gentamicin epigent refobacin 80mg/2ml ampoule", abColor(context), "Gram -ve negative infections Surgical Prophylaxis Cystic Fibrosis Plague aminoglycosides");
    addItem ("Gaseoflatex tab", "Simethicone 125 mg", "gaseoflatex simethicone 125mg tablets", gitColor(context), "Flatulence colic gas retention");
    addItem ("Gast-reg 100 tab", "Trimebutine 100 mg", "Gast-reg Trimebutine tritone gastreg g-regulator gregulator tribudat 100mg tablets", gitColor(context), "Vomiting gerd gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gast-reg 200 tab", "Trimebutine 200 mg", "Gast-reg Trimebutine tritone gastreg debridat trigenda 200mg tablets", gitColor(context), "Vomiting gerd gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gast-reg susp", "Trimebutine 24 mg /5 ml", "Gast-reg Trimebutine tritone gastreg g-regulator gregulator 24mg/5ml suspension", gitColor(context), "Vomiting gerd gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gast-reg amp", "Trimebutine 50 mg /5 ml", "Gast-reg Trimebutine tritone gastreg 50mg/5ml ampoule", gitColor(context), "Vomiting gerd gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gastrobiotic 200 tab", "Rifaximin 200 mg", "gastrobiotic rifaximin biofaximin fatroxim idiabact normix traveria traviguard trencedia 200mg tablets", abColor(context), "Traveler's Diarrhea caused by Noninvasive Strains of E Coli Hepatic Encephalopathy Irritable Bowel Syndrome");
    addItem ("Gastrobiotic 550 tab", "Rifaximin 550 mg", "gastrobiotic rifaximin fatroxim idiabact rolaximine trencedia 550mg tablets", abColor(context), "Traveller's Diarrhea Traveler's Diarrhea caused by Noninvasive Strains of E Coli Hepatic Encephalopathy Irritable Bowel Syndrome");
    addItem ("Gastrofait 1 gm tab", "Sucralfate 1 gm", "gastrofait sucralfate 1000mg 1gm tablets", gitColor(context), "duodenal ulcer stress ulcer");
    addItem ("Gastromotil 30 supp", "Domperidone 30 mg", "gastromotil Domperidone dompidone motinorm 30mg suppositories", gitColor(context), "Vomiting GERD gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gastromotil susp", "Domperidone 5 mg /5 ml", "gastromotil Domperidone farcotilium motilium motinorm dompidone 5mg/5ml suspension", gitColor(context), "Vomiting GERD gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gastromotil tab", "Domperidone 10 mg", "gastromotil Domperidone dompidone donarax farcotilium morlimin motilium motinorm synchrogit tablets capsules", gitColor(context), "Vomiting GERD gastroesophageal reflux disease improve git motility prokinetic agents");
    addItem ("Gaviscon Advance susp", "K Bicarbonate +Na Alginate", "gaviscon advance algicab potassium k bicarbonate na sodium alginate suspension", gitColor(context), "Heartburn Dyspepsia GERD gastroesophageal reflux disease antacids");
    addItem ("Gemtesa tab", "Vibegron 75 mg", "Gemtesa Vibegron 75mg tablets", urinaryColor(context), "urinary incontinence overactive bladder Beta3 adrenoceptor Agonist");
    addItem ("Geneleukim vial", "Filgrastim 300 mcg (30 mIU) /1 ml", "Geneleukim Filgrastim sedico 300mcg/ml 30mIU/ml vial", otherColor(context), "myelosuppressive chemotherapy treatment induction of consolidation chemotherapy patients with cancer undergoing bone marrow transplantation autologous peripheral blood progenitor cell collection and therapy severe chronic neutropenia severe neutropenia caused by myelosuppressive anticancer drugs acute radiation syndrome");
    addItem ("Genesemide syrup", "Furosemide 20 mg /5 ml", "genesemide furosemide 20mg/5ml syrup", cvsColor(context), "Edema Resistant Hypertension loop diuretics");
    addItem ("Genuphil tab", "Chondroitin +Glucosamine +MSM", "genuphil original chondroitin glucosamine methyl sulphonyl methane msm joint soother jointatic cartiofen joint care sansobiflex sharkilage plus tablets capsules", analgesicColor(context), "Osteoarthritis supports joints performance Improves mobility and flexibility");
    addItem ("Genuphil Advance sach", "Chondroitin +Glucosamine +MSM +Collagen Hydrolysate +Hyaluronic Acid", "genuphil advance Chondroitin Glucosamine sulphate methyl sulphonyl methane MSM gelatin Collagen Hydrolysate Hyaluronic Acid sachets", analgesicColor(context), "Osteoarthritis supports joints performance Improves mobility and flexibility");
    addItem ("Genurin tab", "Flavoxate HCl 200 mg", "genurin flavoxate hydrochloride nephroflam 200mg tablets", urinaryColor(context), "Detrusor Ovaractivity overactive bladder Dysuria Urinary Frequency antispasmodics");
    addItem ("Geo Pota-K tab", "Potassium Chloride 600 mg", "geo pota-k geopotak kcl potassium chloride slow k 600mg tablets", vitColor(context), "hypokalemia potassium deficiency supplementation");
    addItem ("Gilenya cap", "Fingolimod 0.5 mg", "gilenya fingolimod sphingomod 0.5mg capsules", otherColor(context), "Multiple Sclerosis ms");
    addItem ("Ginkgo Biloba cap", "Ginkgo Biloba 260 mg", "Ginkgo ginko biloba 260mg capsules", otherColor(context), "vertigo tinnitus improve memory enhancer");
    addItem ("Ginko Plus cap", "Ginseng 100 mg +Ginkgo Biloba 50 mg", "ginko plus Ginseng 100mg Ginkgo biloba 50mg capsules", otherColor(context), "Cerebrovascular insufficiency Psychobehavioural and mood disturbances Tinnitus dizziness migraine Peripheral vascular disease Improving Physical and Mental Efficiency");
    addItem ("Ginkofit cap", "Ginkgo Biloba +Ginseng +Royal Jelly", "Ginkofit Ginkgo ginko biloba Ginseng Royal Jelly fit brainvita trinutrex capsules", otherColor(context), "Improving Physical and Mental Efficiency Improves Memory concentration enhancer Sexual Dysfunction peripheral blood circulation");
    addItem ("Ginsana cap", "Ginseng 100 mg", "ginsana capsules ginseng 100mg", vitColor(context), "weakness exhaustion tiredness loss of concentration improving physical and mental efficiency");
    addItem ("GIT cap", "Peppermint oil +Caraway oil +Chamomile oil +Fennel oil +Ginger oil", "git Peppermint Caraway Chamomile Fennel Ginger oil espax digetex gesto capsules", gitColor(context), "dyspepsia irritable bowel syndrome ibs bloating improve git motility");
    addItem ("Glomethasone amp", "Betamethasone 8 mg /2 ml", "Glomethasone betamethasone 8mg/2ml ampoule", strdColor(context), "Inflammation Multiple Sclerosis Inflammatory Conditions Tenosynovitis Peritendinitis Bursitis rheumatoid osteoarthritis Corticosteroids");
    addItem ("Glucagen vial", "Glucagon 1 mg /ml", "glucagen glucagon 1mg/ml vial", hormoneColor(context), "Hypoglycemia Diagnostic Aid Beta-Blocker & Calcium Channel Blocker Toxicity");
    addItem ("Glucofer tab", "Ferrous Gluconate 300 mg (Elemental Iron 35 mg)", "Glucofer tablets ferrous gluconate iron", vitColor(context), "iron deficiency anemia");
    addItem ("Glucolight XR 500 tab", "Metformin 500 mg", "glucolight metformin andoglycemic glucophage maxophage xr 500mg 1000mg tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides");
    addItem ("Glucose 5% IV solution", "Dextrose 5%", "glucose dextrose 5% iv solution", hormoneColor(context), "hypoglycemia");
    addItem ("Glucose 10% IV solution", "Dextrose 10%", "glucose dextrose 10% iv solution", hormoneColor(context), "hypoglycemia hyperkalemia");
    addItem ("Glucose 25% IV solution", "Dextrose 25%", "glucose dextrose 25% iv solution", hormoneColor(context), "hypoglycemia sulfonylurea overdose");
    addItem ("Glucose 50% IV solution", "Dextrose 50%", "glucose dextrose 50% iv solution", hormoneColor(context), "insulin induced hypoglycemia acute alcohol intoxication sulfonylurea overdose insulin overdose hyperkalemia");
    addItem ("Glycerin infantile supp", "Glycerin 735 mg", "glycerin glycerol 735mg pediatric paed infantile suppositories", gitColor(context), "constipation osmotic laxative");
    addItem ("Glycerin adult supp", "Glycerin 1.47 gm", "glycerin glycerol 1.47gm adult suppositories", gitColor(context), "constipation osmotic laxative");
    addItem ("Glycodal tab", "Calcium Carbonate +Dimethicone +Glycine", "glycodal Calcium Carbonate Dimethicone Glycine asylon chewable tablets", gitColor(context), "flatulence hyperacidity gas bloating antacids");
    addItem ("Gonapure vial", "Follitropin Alpha", "gonapure follitropin alpha gonal-f pen vial", hormoneColor(context), "ovulation induction art assisted reproductive technology Hypogonadotropic Hypogonadism");
    addItem ("Goutyless tab", "Colchicine 0.5 mg +Probenecid 500 mg", "goutyless Colchicine 0.5mg Probenecid 500mg tablets", otherColor(context), "Chronic Gouty Arthritis antigout agents");
    addItem ("Granitryl syrup", "Granisetron 1 mg /5 ml", "Granitryl Granisetron 1mg/5ml syrup", gitColor(context), "Vomiting nausea Selective 5-HT3 Antagonists antiemetic agents");
    addItem ("Gripe Baby Water", "Terpeneless Dill Seed Oil +Na Bicarbonate", "gripe baby water bambino terpeneless dill seed oil na sodium bicarbonate calminal pedi-water pediwater sansobaby water", gitColor(context), "Colic Flatulence gas retention");
    addItem ("Guava syrup", "Guava +Tilia", "tilia flower guava leaves guaflex-n normass tussinor syrup", resColor(context), "Cough");
    addItem ("Gufidrexn tab", "Guaifenesin 400 mg", "Gufidrexn guaifenesin 400mg tablets", resColor(context), "Productive Cough expectorant");

    addItem ("Haema-caps cap", "Iron +Vitamins +Minerals", "Haema-caps haemacaps capsules Iron ferrous fumarate Multivitamins b1 thiamine b2 riboflavin b6 pyridoxine b12 cyanocobalamin c ascorbic acid d3 cholecalciferol e tocopherol b9 folic acid calcium copper manganese taurine safflower linseed oil linoleic linolenic acid", vitColor(context), "iron vitamins minerals deficiency anemia supplementation");
    addItem ("Hairtonic cap", "Thiamine +Pantothenic Acid +Selenium +Keratin +L-Cystine +Para-Aminobenzoic Acid +Biotin", "hairtonic vitamin b1 thiamine vitamin B5 pantothenic acid selenium keratin l-cystine para aminobenzoic acid paba vitamin b10 vitamin b7 biotin capsules", vitColor(context), "support hair follicles strength & scalp health");
    addItem ("Haldol Decanoas amp", "Haloperidol 50 mg /ml", "Haldol Decanoas haloperidol retard decanoate 50mg/ml ampoule", cnsColor(context), "schizophrenia psychosis sedation acute agitation Antipsychotics");
    addItem ("Halonace 1.5 tab", "Haloperidol 1.5 mg", "Halonace haloperidol safinace 1.5mg tablets", cnsColor(context), "schizophrenia psychosis acute agitation Tourette Disorder Antipsychotics");
    addItem ("Haloperidol amp", "Haloperidol 5 mg /ml", "haloperidol halonace haloprol 5mg/ml ampoule", cnsColor(context), "schizophrenia psychosis sedation acute agitation Antipsychotics");
    addItem ("Halorange syrup", "Cod liver oil +Vit C", "halorange syrup Cod liver oil halibut omega3 vitamin d vitamin a vitamin c ascorbic acid", vitColor(context), "Immunity Enhancer hypercholesterolemia Physical and Mental Exhaustion");
    addItem ("Haemojet cap", "Ferric Hydroxide Polymaltose Complex 322.5 mg (Elemental Iron 100 mg)", "Haemojet iron Ferric Hydroxide Polymaltose Complex haemopower ferose golden fer ferroduonal hemaltose 100mg capsules", vitColor(context), "iron deficiency anemia");
    addItem ("Heli-cure tab", "Omeprazole 20 mg +Tinidazole 500 mg +Clarithromycin 250 mg", "helicure heli-cure omeprazole tinidazole clarithromycin peptic care tablets", gitColor(context), "helicobacter pylori");
    addItem ("Hepa-Merz amp", "L-Ornithine-L-Aspartate 5 gm /10 ml", "hepa-merz L-Ornithine-L-Aspartate hepamerz aspatrend lolawest orniheparate ornitate sunnydetox tigornicine 5gm/10ml ampoule vial", gitColor(context), "Liver cirrhosis fatty liver hepatitis hepatic coma acute chronic liver disease");
    addItem ("Hepa-Merz sach", "L-Ornithine-L-Aspartate 3 gm", "hepa-merz L-Ornithine-L-Aspartate hepamerz aspatrend hepafence lolawest orniheparate ornitate tigornicine 3gm sachets", gitColor(context), "disturbed detoxification of the liver cirrhosis symptoms of latent and manifest hepatic encephalopathy");
    addItem ("Hepaticum cap", "Silymarin 140 mg", "hepaticum silymarin milk thistle extract hepamarin legalon livamarin livoprotect mariagon mepasil silimar 140mg capsules", gitColor(context), "Liver Tonic support supplementation");
    addItem ("Hepaticum susp", "Silymarin 50 mg /5 ml", "hepaticum silymarin milk thistle extract 50mg/5ml suspension", gitColor(context), "Liver Tonic support supplementation");
    addItem ("Hepato-Forte cap", "Essential Phospholipids +Vit B1 +Vit B2 +Vit B3 +Vit B6 +Vit B12 +Vit E", "hepato-forte Essential Phospholipids Multivitamins b1 thiamine b2 riboflavin b3 niacin nicotinic acid nicotinamide b6 pyridoxine b12 cyanocobalamin e tocopherol hepatoforte capsules", vitColor(context), "Liver Tonic support supplementation");
    addItem ("Herba Caf syrup", "Guava +Tilia +Fennel +Liquorice", "herbacaf tilia flower guava leaves fennel oil liquorice root herbacough syrup", resColor(context), "Cough");
    addItem ("Herbana cap", "Fenugreek +Fennel +Dill +Caraway", "herbana capsules Fenugreek Fennel Dill Caraway", vitColor(context), "Improve the function of lactating glands the gastrointestinal function improvement");
    addItem ("Hi-cal syrup", "Calcium glubionate 1200 mg (78 mg elemental calcium) /5 ml", "Hi-cal hical Calcium glubionate 1200mg/5ml syrup", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Hi-cal forte syrup", "Calcium glubionate 1800 mg (115 mg elemental calcium) /5 ml", "Hi-cal hical forte calcium glubionate 1800mg/5ml syrup", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Hi-Potency Formula tab", "Biotin +Vit B12 +Pantothenic Acid +Choline +Copper +Folic Acid +Iodine +Iron +Manganese +Niacin +PABA +Zinc", "hi-potency formula tablets vitamin b7 Biotin vitamin b12 cobalamin vitamin B5 Pantothenic Acid Choline cu Copper Folic Acid vitamin b9 Iodine Iron Manganese vitamin b3 Nicotinic Acid nicotinamide niacin PABA Para aminobenzoic acid Zinc", vitColor(context), "Diffused Hair Loss Telogen effluvium");
    addItem ("Hidonac amp", "Acetylcysteine 200 mg /ml", "hidonac acetylcysteine rotacystein sunnycysteine 200mg/ml ampoule", otherColor(context), "acetaminophen paracetamol toxicity overdose antidotes");
    addItem ("Hidrasec infant sach", "Racecadotril 10 mg", "hidrasec racecadotril acetorphan infant racecarox 10mg sachets", gitColor(context), "antidiarrheal");
    addItem ("Hidrasec children sach", "Racecadotril 30 mg", "hidrasec racecadotril acetorphan children 30mg sachets", gitColor(context), "antidiarrheal");
    addItem ("Hidrasec cap", "Racecadotril 100 mg", "hidrasec capsules racecadotril 100mg", gitColor(context), "antidiarrheal");
    addItem ("Highcef 250 tab", "Cefuroxime 250 mg", "highcef cefuroxime hebiuroxime zenax zinacef 250mg tablets", abColor(context), "UTI urinary gonorrhea early lime disease impetigo sinusitis Throat pharyngitis tonsillitis bronchitis Skin LRTI lower urti upper respiratory tract infections pneumonia 2nd second generation cephalosporins");
    addItem ("Holoxan 1 gm vial", "Ifosfamide 1 gm", "holoxan ifosfamide isoxan 1000mg 1gm vial", otherColor(context), "Germ Cell Testicular Cancer Antineoplastic Agents");
    addItem ("Holoxan 2 gm vial", "Ifosfamide 2 gm", "holoxan ifosfamide isoxan 2000mg 2gm vial", otherColor(context), "Germ Cell Testicular Cancer Antineoplastic Agents");
    addItem ("Homo sach", "Lactoferrin +Colostrum +Zinc +Selenium +Vit C +Vit E +Calcium", "Homo sachets Lactoferrin Colostrum Zinc Selenium Vitamin C ascorbic acid Vitamin E tocopherol Calcium", vitColor(context), "Vitamins minerals iron deficiency supplementation anemia Hair Loss due to Lack Of Ferritin immunity enhancer");
    addItem ("Hopdetox tab", "Lofexidine 0.2 mg", "Hopdetox Lofexidine detoxydine 0.2mg tablets", cnsColor(context), "Opioid Withdrawal");
    addItem ("Humalog kwikpen/cartridges", "Insulin Lispro", "Humalog Insulin Lispro kwikpen cartridges", hormoneColor(context), "type1 type2 diabetes mellitus rapid-acting insulins");
    addItem ("Humalog Mix kwikpen/cartridges", "Insulin Lispro Protamine +Insulin Lispro", "insulin humalog mix Lispro Protamine kwikpen cartridges", hormoneColor(context), "type1 type2 diabetes mellitus rapid-acting insulins");
    addItem ("Human Albumin 20% vial", "Human Albumin 10 gm /50 ml", "human albumin human albapure sk albumin umana albunorm albutein buminate flexbumin plasbumin 20% 10gm/50ml vial", gitColor(context), "Hemolytic Disease of the Newborn Ascites with Hypoalbuminemia Acute Liver Failure Adult Respiratory Distress Syndrome ards Hemodialysis Ovarian Hyperstimulation Syndrome");
    addItem ("Humira prefilled syringe", "Adalimumab 40 mg /0.8 ml", "humira adalimumab amgevita hyrimoz 40mg/0.8ml prefilled syringe", otherColor(context), "juvenile idiopathic arthritis pediatric crohn disease ulcerative colitis uveitis hidradenitis suppurative rheumatoid arthritis psoriatic arthritis ankylosing spondylitis plaque psoriasis Tumor Necrosis Factor TNF Blockers");
    addItem ("Humulin N cartridges", "Insulin NPH 100 units/ml", "Humulin N insulin isophane protamine human insulatard hm bio insulinagypt n insuman basal insulin h nph 100units/ml vial cartridges", hormoneColor(context), "type1 type2 diabetes mellitus intermediate-acting insulins");
    addItem ("Humulin R cartridges", "Insulin Regular Human 100 units/ml", "Humulin R insulin regular human insulin neutral human actrapid hm penfills insuman rapid cartridges", hormoneColor(context), "type1 type2 diabetes mellitus short-acting insulins");
    addItem ("Hyalgan prefilled syringe", "Hyaluronic Acid 20 mg /2 ml", "hyalgan hyaluronic acid ophthalin 20mg/2ml prefilled syringe", otherColor(context), "Osteoarthritis of Knee");
    addItem ("Hyalone prefilled syringe", "Hyaluronic Acid 60 mg /4 ml", "hyalone hyaluronic acid hyalubrix 60mg/4ml prefilled syringe", otherColor(context), "Osteoarthritis of Knee");
    addItem ("Hydroquine tab", "Hydroxychloroquine Sulfate 200 mg", "hydroquine hydroxychloroquine sulfate sulphate futarhomal hydroxytoid plaquenil 200mg tablets", abColor(context), "malaria rheumatoid arthritis sle systemic lupus erythematosus prophyria cutanea tarda");
    addItem ("Hyzaar tab", "Losartan +Hydrochlorothiazide", "hyzaar losartan hydrochlorothiazide hysartan kanzar-h loraz forte losarmepha-plus losartan-comp losazide lozapress-h amosar forte fortzaar losar plus lostapressin plus modazar remtozar-d tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics");

    addItem ("Ibandrocare tab", "Ibandronic Acid 150 mg", "Ibandrocare ibandronic acid ibandronate bonprove bonybella eliandrorica 150mg tablets", otherColor(context), "osteoporosis bisphosphonates");
    addItem ("Ibiamox 200 susp", "Amoxicillin 200 mg /5 ml", "Ibiamox Amoxicillin 200mg/5ml suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Ibiamox 400 susp", "Amoxicillin 400 mg /5 ml", "Ibiamox Amoxicillin organomox delpedox 400mg/5ml suspension", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Ibiamox 250 cap", "Amoxicillin 250 mg", "Ibiamox Amoxicillin amoxicid amoxycillin biomox epcimox hiconcil 250mg capsules", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Ibiamox 500 cap", "Amoxicillin 500 mg", "Ibiamox Amoxicillin amoxicid amoxil amoxycillin biomox moxipen emox e-mox 500mg capsules", abColor(context), "UTI urinary Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin LRTI lower urti upper respiratory tract infections Penicillins");
    addItem ("Icosalip cap", "Icosapent Ethyl 1 gm", "icosalip icosapent ethyl exeedolip icosanectin 1000mg 1gm capsules", cvsColor(context), "hypercholesterolemia hyperlipidemia Severe hypertriglyceridemia");
    addItem ("Imigran amp", "Sumatriptan 6 mg", "imigran sumatriptan sumagraine sumigran 6mg/0.5ml ampoule", cnsColor(context), "migraine treatment Serotonin 5-HT-Receptor Agonists");
    addItem ("Imigran tab", "Sumatriptan 50 mg", "imigran sumatriptan credosan sumagraine sumigran 50mg tablets", cnsColor(context), "migraine treatment Serotonin 5-HT-Receptor Agonists");
    addItem ("Immuguard sach", "Bovine Colostrum", "Immuguard sachets Bovine Colostrum", vitColor(context), "Immunity Enhancer");
    addItem ("Immulant syrup", "Echinacea dry extract +Nigella sativa oil", "Immulant syrup Echinacea dry extract Nigella sativa oil", vitColor(context), "Immunity Enhancer");
    addItem ("Immuno Flu cap", "Echinacea Purpurea +Zinc +Vit C", "ImmunoFlu capsules Echinacea purpurea Zinc citrate vitamin c ascorbic acid", vitColor(context), "Immunity Enhancer");
    addItem ("Immuno-mash tab", "Vit C 500 mg +Zinc 23.9 mg", "Immuno-mash vitamin c ascorbic acid Zinc immunomash tablets", vitColor(context), "antioxidant diarrhea immunity enhancer boosting");
    addItem ("Immunvita drops", "Echinacea purpurea extract", "Immunvita drops Echinacea purpurea extract", vitColor(context), "Immunity Enhancer");
    addItem ("Imodium instant tab", "Loperamide 2 mg", "imodium instant loperamide loperasin lopodium motijust stoprrhea lopranest 2mg tablets capsules odf", gitColor(context), "Traveler's Diarrhea Traveller's Diarrhea");
    addItem ("Imoflora tab", "Loperamide 2 mg +Simethicone 125 mg", "imoflora loperamide simethicone motijust plus capsules tablets", gitColor(context), "Diarrhea flatulence gas retention");
    addItem ("Inderal 10 tab", "Propranolol 10 mg", "inderal propranolol indolol prolol 10mg tablets", cvsColor(context), "portal hypertension migraine angina pheochromocytoma hypertrophic subaortic stenosis supraventricular arrhythmia essential tremor antipsychotic-induced akathisia esophageal variceal bleeding panic disorder aggressive behavior infantile hemangiomas hypercyanotic spells thyrotoxicosis Nonselective beta-blocker class II 2 antiarrhythmic agents");
    addItem ("Inderal 40 tab", "Propranolol 40 mg", "inderal propranolol indolol prolol 40mg tablets", cvsColor(context), "portal hypertension migraine angina pheochromocytoma hypertrophic subaortic stenosis supraventricular arrhythmia essential tremor antipsychotic-induced akathisia esophageal variceal bleeding panic disorder aggressive behavior thyrotoxicosis Nonselective beta-blocker class II 2 antiarrhythmic agents");
    addItem ("Indocid supp", "Indomethacin 100 mg", "indocid indomethacin indacin 100mg suppositories", analgesicColor(context), "Inflammatory Disorders Rheumatoid Disorders Bursitis Tendinitis Acute Gouty Arthritis Nephrogenic DI diabetes insipidus Pain analgesics Bursitis Tendinitis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Indomethacin 25 cap", "Indomethacin 25 mg", "indomethacin indocid indomin 25mg capsules", analgesicColor(context), "Inflammatory Disorders Rheumatoid Disorders Bursitis Tendinitis Acute Gouty Arthritis Nephrogenic DI diabetes insipidus Pain analgesics Bursitis Tendinitis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Indomethacin 50 cap", "Indomethacin 50 mg", "indomethacin 50mg capsules", analgesicColor(context), "Inflammatory Disorders Rheumatoid Disorders Bursitis Tendinitis Acute Gouty Arthritis Nephrogenic DI diabetes insipidus Pain analgesics Bursitis Tendinitis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Inegy tab", "Simvastatin +Ezetimibe", "inegy simvastatin ezetimibe alkor plus altomanira azetasive cazet downstevolin givarorock jestamivam lipidnorm co lipitrin lowtimib comp minalip plus simazet simva-eze simva-map simvastimibe simvaxibe timbestatin vanish vastatinal vetosimvameb zetlip plus zocozet tablets", cvsColor(context), "familial hypercholesterolemia HMG-CoA Reductase Inhibitor Statins Antilipemic Agents");
    addItem ("Influvac Tetra prefilled syringe", "Influenza Vaccine", "influvac tetra quadrivalent inactivated influenza virus haemagglutinin vaccine vaxigrip tetra agrippal s1 vaccine fluarix fluvirin prefilled syringe", abColor(context), "prevention of influenza prevention active immunization");
    addItem ("Inofolic cap", "Myo-inositol 600 mg +Folic Acid 0.24 mg", "inofolic capsules myo-inositol folic acid vitamin b9", vitColor(context), "folic acid deficiency dietary supplementation Prepare and Support Pregnancy");
    addItem ("Inspago tab", "Agomelatine 25 mg", "inspago agomelatine agovald doxanero exomelatine valdoxan 25mg tablets", cnsColor(context), "major depressive episodes antidepressants");
    addItem ("Intrafer tab", "Elemental Iron 15 mg +Folic Acid 0.125 mg", "intrafer tablets iron folic acid vitamin b9", vitColor(context), "iron deficiency anemia");
    addItem ("Invanz 1 gm vial", "Ertapenem 1 gm", "Invanz Ertapenem 1000mg 1gm vial", abColor(context), "Pneumonia UTI urinary tract Intra-abdominal Skin Infections Pyelonephritis PID pelvic inflammatory disease Carbapenems");
    addItem ("Invega 3 XR tab", "Paliperidone 3 mg", "invega paliperidone paliper peridomagic 3mg 6mg xr tablets", cnsColor(context), "schizophrenia schizoaffective disorder Antipsychotics");
    addItem ("Invokana 100 tab", "Canagliflozin 100 mg", "invokana canagliflozin diacanram ivoglita parkflozin 100mg 300mg tablets", hormoneColor(context), "type2 diabetes mellitus sodium-glucose co-transporter 2 SGLT2");
    addItem ("Irospect cap", "Vitamins +Minerals", "irospect capsules pieces Multivitamins b1 thiamine b2 riboflavin b6 pyridoxine b12 cobalamin b5 pantothenic acid c ascorbic acid e tocopherol Nicotinic Acid nicotinamide niacin b3 Folic Acid folate b9 niacinamide magnesium iron zinc selenium manganese chromium", vitColor(context), "Vitamins minerals deficiency supplementation");
    addItem ("Iso Mak Retard 20 tab", "Isosorbide Dinitrate 20 mg", "isomak isosorbide dinitrate cardiket retard sr 20mg 40mg tablets", cvsColor(context), "angina pectoris nitrates");
    addItem ("Isocid tab", "Isoniazid 100 mg", "isocid isoniazid t.b.zide tbzide forte 100mg 200mg 300mg tablets", abColor(context), "Latent Tuberculosis tb infections Active Tuberculosis tb Disease Antitubercular Agents");
    addItem ("Isoprinosine susp", "Isoprinosine 250 mg /5 ml", "Isoprinosine 250mg/5ml suspension", abColor(context), "sspe subacute sclerosing panencephalitis herpes simplex zoster stomatitis viral bronchitis");
    addItem ("Isoprinosine tab", "Isoprinosine 500 mg", "Isoprinosine 500mg tablets", abColor(context), "sspe subacute sclerosing panencephalitis herpes simplex zoster stomatitis viral bronchitis");
    addItem ("Isoptin 80 tab", "Verapamil 80 mg", "isoptin verapamil izoptomil verpamil veratens 80mg tablets", cvsColor(context), "supraventricular tachycardia supraventricular arrhythmia atrial fibrillation atrial flutter class IV 4 antiarrhythmic agents Calcium Channel Blockers CCBs");
    addItem ("Isoptin amp", "Verapamil 5 mg /2 ml", "isoptin verapamil izoptomil 5mg/2ml ampoule", cvsColor(context), "hypertension angina chronic atrial fibrillation paroxysmal supraventricular tachycardia migraine Prophylaxis class IV 4 antiarrhythmic agents Calcium Channel Blockers CCBs");
    addItem ("Itrapex cap", "Itraconazole 100 mg", "itrapex itraconazole arozole fungitranazole itrafungex itrafungizole itranox sporanox terabitat 100mg capsules", abColor(context), "blastomycosis aspergillosis histoplasmosis onychomycosis candidiasis antifungals infections");
    addItem ("Iverzine tab", "Ivermectin 6 mg", "iverzine ivermectin ivermine ivactin 6mg tablets capsules", abColor(context), "Strongyloidiasis of the Intestinal Tract Gnathostomiasis River Blindness Onchocerciasis Head Lice Blepharitis Filariasis Scabies");

    addItem ("Janumet tab", "Sitagliptin +Metformin", "janumet sitagliptin metformin glaptivia gleptomet gliptadalo janaglip janugliptin plus tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides dipeptidyl peptidase-4 DPP-4 inhibitor");
    addItem ("Januvia 100 tab", "Sitagliptin 100 mg", "januvia sitagliptin dibacure glaptivia gliptadalo janaglip janugliptin 100mg tablets", hormoneColor(context), "type2 diabetes mellitus dipeptidyl peptidase-4 DPP-4 inhibitor");
    addItem ("Joint Plus tab", "Chondroitin +Glucosamine +MSM +Collagen Hydrolysate +Hyaluronic Acid", "joint plus tablets Chondroitin sulphate Glucosamine sulphate methyl sulphonyl methane MSM gelatin Collagen Hydrolysate Hyaluronic Acid", analgesicColor(context), "Osteoarthritis supports joints performance Improves mobility and flexibility");
    addItem ("Joypox 30 tab", "Dapoxetine 30 mg", "joypox Dapoxetine andopoxetine dapoxemed dapoxtard delepe derilgy durjoy fortrustep matujac predapox tardanza westoxetin 30mg 60mg tablets", urinaryColor(context), "premature ejaculation selective serotonin reuptake inhibitors SSRIs");
    addItem ("Jusprin tab", "Acetylsalicylic Acid 81 mg", "jusprin acetylsalicylic acid acpophar aspico aspricarlo 81mg tablets", analgesicColor(context), "fever pain analgesics antipyretics Juvenile Rheumatoid Arthritis Inflammations Kawasaki Disease Acute Coronary Syndrome Primary ASCVD Prevention Ischemic Stroke Antiplatelet TIAs transient ischemic attacks Colorectal Cancer Prophylaxis Nonsteroidal Anti-inflammatory Drugs NSAIDs");

    addItem ("Kalobin drops", "Root of pelargonium sidoides", "Kalobin drops Root of pelargonium reniforme sidoides", resColor(context), "Immunity Enhancer improve bronchial function");
    addItem ("Kansartan 75 tab", "Irbesartan 75 mg", "kansartan irbesartan angioblock mono irbedrin aprovel irbefutal irbetan rentensar xtension x-tension irban sartaless 75mg 150mg 300mg tablets", cvsColor(context), "Hypertension Diabetic Nephropathy ARBs Angiotensin receptor blockers");
    addItem ("Kansartan Plus tab", "Irbesartan +Hydrochlorothiazide", "kansartan plus irbesartan hydrochlorothiazide co-irbesartan coirbesartan coaprovel irbedrin-diu irbefutal co irbezide vezidane x-tension xtension irbevasc plus angioblock tablets", cvsColor(context), "hypertension ARBs Angiotensin receptor blockers thiazides Diuretics");
    addItem ("Kapect susp", "Kaolin +Pectin", "Kapect Kaolin Pectin pectokal suspension", gitColor(context), "antidiarrheal");
    addItem ("Kapect comp susp", "Sulfamethoxazole +Trimethoprim +Kaolin +Pectin", "Kapect comp suspension sulphamethoxazole Sulfamethoxazole Trimethoprim Kaolin Pectin", gitColor(context), "Bacterial antidiarrheal");
    addItem ("Kapron tab", "Tranexamic Acid 500 mg", "kapron tranexamic acid cycloxemic hemokapron hemoxamine savibleed tranex trexam 500mg tablets", cvsColor(context), "bleeding haemorrhage hemorrhage menorrhagia hereditary angioedema cone biopsy epistaxis hyphema dental extraction in patients with hemophilia Antifibrinolytic Agents");
    addItem ("Kapron amp", "Tranexamic Acid 500 mg /5 ml", "kapron tranexamic acid bledex hemokapron hemoxamine savibleed taroxatron 500mg/5ml ampoule", cvsColor(context), "dental extraction in patients with hemophilia bleeding haemorrhage hemorrhage Antifibrinolytic Agents");
    addItem ("Katrex syrup", "Levamisole 40 mg /5 ml", "Katrex Levamisole 40mg/5ml wormine syrup", abColor(context), "Intestinal worms");
    addItem ("Katrex tab", "Levamisole 40 mg", "Katrex Levamisole 40mg tablets", abColor(context), "Intestinal worms");
    addItem ("Kaveda drops", "Iron +Vit A +Vit C +Vit D3 +Vit E +Vit B1 +Vit B2 +Vit B3 +Vit B6", "kaveda drops Iron bisglycinate multivitamins a c ascorbic acid d3 e tocopherol b1 thiamine b2 riboflavin b3 niacin b6 pyridoxine", vitColor(context), "iron deficiency anemia helps in mental growth and brain developments.");
    addItem ("Kellagon cap", "Ammivisnaga +Cymbopogon Proximus", "kellagon ammivisnaga extract cymbopogon proximus dry extract khellin capsules", urinaryColor(context), "Urinary renal spasm colic stones Urolithiasis");
    addItem ("Kellagon sach", "Khellin +Cymbopogon Proximus", "kellagon ammivisnaga extract cymbopogon proximus liquid extract khellin sachets", urinaryColor(context), "Urinary renal spasm colic stones Urolithiasis");
    addItem ("Kenacort tab", "Triamcinolone 4 mg", "kenacort Triamcinolone 4mg tablets", strdColor(context), "Rheumatic disorders Arthritic Disorders Inflammatory & Allergic Systemic Conditions inflammations Multiple Sclerosis Corticosteroids");
    addItem ("Keppra 250 tab", "Levetiracetam 250 mg", "keppra levetiracetam futatreat kepilepsy levectam rimstilacetam tiralepsy 250mg tablets", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Kerovit cap", "Vitamins +Minerals", "kerovit capsules arginine lysine l-carnitine l-glutamine l carnitine l glutamine choline bitartarate inositol Multivitamins b8 co-enzyme q 10 lecithin phosphatidylserine epa eicosapentaenoic acid dha docosahexaenoic acid bee pollen wheat germ oil soyphosphatides safflower oil ginkgo ginko biloba extract d cholecalciferol k phytonadione a b1 thiamine b2 riboflavin b6 pyridoxine b12 cobalamin b5 pantothenic acid b7 biotin c ascorbic acid e tocopherol Nicotinic Acid nicotinamide niacin b3 Folic Acid b9 b7 biotin niacinamide magnesium sulphate calcium iron phosphorus iodine zinc copper selenium manganese chromium picolinate molybdenum potassium nickel vanadium boron royal jelly ginseng", vitColor(context), "Vitamins minerals deficiency supplementation");
    addItem ("Ketamine vial", "Ketamine  50 mg /ml", "ketamine keiran ketam ketamar ketalar 50mg/ml vial", cnsColor(context), "anesthesia induction resistant depression sedation antidepressants");
    addItem ("Ketofan 5 susp", "Ketoprofen 5 mg /5 ml", "ketofan ketoprofen ketoprek profenid 5mg/5ml suspension", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan 12.5 susp", "Ketoprofen 15 mg /5 ml", "ketofan ketoprofen 12.5mg/5ml suspension", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan 25 tab", "Ketoprofen 25 mg", "ketofan ketoprofen alcofan ketolgin kupan mepacofen top fam 25mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan 50 cap", "Ketoprofen 50 mg", "ketofan ketoprofen alcofan doloket ketalgipan ketogesic ketolgin kupan profenid 50mg capsules tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan 75 cap", "Ketoprofen 75 mg", "ketofan ketoprofen flamibru flamidose gesiket ketoprek kiti 75mg capsules", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan 100 SR cap", "Ketoprofen 100 mg", "ketofan ketoprofen mepacofen 100mg sr capsules", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan 200 SR cap", "Ketoprofen 200 mg", "ketofan ketoprofen kiti kupan ketogesic ketolgin 200mg sr capsules", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketofan amp", "Ketoprofen 100 mg /2 ml", "ketofan ketoprofen doloket emiprofen ketogesic ketolgin orudis profenid 100mg/2ml ampoule", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketolac amp", "Ketorolac 30 mg /2 ml", "ketolac ketorolac adolor fam ketorolin 30mg/2ml  ampoule", analgesicColor(context), "pain analgesics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketolac tab", "Ketorolac 10 mg", "Ketolac ketorolac fam adolor ketoral ketrac 10mg tablets", analgesicColor(context), "pain analgesics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Ketosteril tab", "Amino Acids", "Ketosteril amino acids Calcium 3-methyl-2-oxovaleric acid Alpha-ketoanalogue of isoleucine Ca-salt Calcium-methyl-2-oxovaleric acid Alpha-ketoanalogue of leucine Calcium-2-oxo-3-phenylpropionic acid Alpha-ketoanalogue of phenylalanine Calcium-3-methyl-2-oxobutyric acid Alpha-ketoanalogue of valine Calcium-DL-2-hydroxy-4-(methylthio)-butyric acid Alpha-hydroxyanalogue of methionine Ca-salt L-lysine acetate L-threonine L-tryptophan L-histidine L-tyrosine aminorenocare tablets", otherColor(context), "Prevention and therapy of damages due to faulty or deficient protein metabolism in chronic renal insufficiency");
    addItem ("Kidicare syrup", "Multivitamins", "kidicare syrup Multivitamins a b1 thiamine b2 riboflavin Nicotinic Acid nicotinamide niacin b3 b6 pyridoxine b12 cobalamin c ascorbic acid d3 e tocopherol B5 calcium d-pantothenate b7 biotin Folic Acid b9", vitColor(context), "multivitamins deficiency Supplementation");
    addItem ("Kids Daily Vit Sleep Syrup", "Melatonin 1 mg /ml", "Kids Daily Vit Sleep melatonin 1mg/ml Syrup", cnsColor(context), "Delayed sleep wake phase disorder DSWPD jet lag Insomnia sedation");
    addItem ("Kisqali tab", "Ribociclib 200 mg", "Kisqali Ribociclib 200mg tablets", otherColor(context), "breast cancer Antineoplastics");
    addItem ("Klacid 125 susp", "Clarithromycin 125 mg /5 ml", "Klacid Clarithromycin klarimix 125mg/5ml suspension", abColor(context), "Otitis media pneumonia bronchitis Sinusitis LRTI lower respiratory tract Mycobacterial Peptic ulcer Pertussis Pharyngitis tonsillitis Skin Infections Endocarditis Prophylaxis Macrolides");
    addItem ("Klacid 250 susp", "Clarithromycin 250 mg /5 ml", "Klacid Clarithromycin klarimix 250mg/5ml suspension", abColor(context), "Otitis media pneumonia bronchitis Sinusitis LRTI lower respiratory tract Mycobacterial Peptic ulcer Pertussis Pharyngitis tonsillitis Skin Infections Endocarditis Prophylaxis Macrolides");
    addItem ("Klacid 250 tab", "Clarithromycin 250 mg", "Klacid Clarithromycin alphaclarin infectocure kapifectin klarimix larithrocin 250mg tablets", abColor(context), "pneumonia bronchitis Sinusitis LRTI lower respiratory tract infections Mycobacterial Peptic ulcer Pertussis Pharyngitis tonsillitis Skin Infections Endocarditis Prophylaxis Macrolides");
    addItem ("Klacid 500 tab", "Clarithromycin 500 mg", "Klacid Clarithromycin infectocure kapifectin klarimix larithrocin clarimycin 500mg tablets", abColor(context), "pneumonia bronchitis Sinusitis LRTI lower respiratory tract infections Mycobacterial Peptic ulcer Pertussis Pharyngitis tonsillitis Skin Infections Endocarditis Prophylaxis Macrolides");
    addItem ("Klacid XL 500 tab", "Clarithromycin 500 mg", "Klacid Clarithromycin alphaclarin bedrevida caprivexin clarikan clariostrong immaculate clarinotion xl sr 500mg tablets", abColor(context), "pneumonia bronchitis Sinusitis LRTI lower respiratory tract infections Macrolides");
    addItem ("Klacid vial", "Clarithromycin 500 mg", "Klacid Clarithromycin 500mg vial", abColor(context), "Sinusitis LRTI lower respiratory tract Pharyngitis tonsillitis Skin Infections community acquired pneumonia acute exacerbation of chronic bronchitis Macrolides");
    addItem ("Klozepam drops", "Clonazepam 2.5 mg /ml", "Klozepam clonazepam rivotril 2.5mg/ml drops", cnsColor(context), "seizure disorders panic disorder essential tremor rem sleep behavior disorder burning mouth syndrome tardive dyskinesia Benzodiazepines");

    addItem ("L-Carnitine amp", "L-Carnitine 1 gm /5 ml", "l-carnitine levocarnitine amricarnitine lcarnitine carnitol carnivita rotacarnite sunnycarnitine 1gm/5ml ampoule", otherColor(context), "carnitine deficiency supplementation end-stage renal disease");
    addItem ("L-Carnitine cap", "L-Carnitine 350 mg", "l-carnitine levocarnitine lcarnitine amricarnitine carnitol levocarnine specsafon 300mg 330mg 350mg 500mg capsules tablets", otherColor(context), "carnitine deficiency supplementation");
    addItem ("L-Carnitine Plus tab", "L-Carnitine L-Tartrate 1000 mg +Zinc Gluconate 50 mg", "L-Carnitine L-Tartrate Zinc Gluconate levocarnitine lcarnitine carnitol plus carnivita forte tablets", otherColor(context), "carnitine zinc deficiency supplementation");
    addItem ("L-Carnitine syrup", "L-Carnitine 30%", "l-carnitine levocarnitine 30% lcarnitine carnitol carnivita 30% syrup drops", otherColor(context), "carnitine deficiency supplementation");
    addItem ("Labipress 100 tab", "Labetalol mg", "Labipress labetalol 100mg 200mg tablets", cvsColor(context), "hypertension nonselective beta-blocker");
    addItem ("Lacteol Forte cap", "Lactobacillus 5 billions", "Lacteol forte capsules Lactobacillus LB 5 billions", gitColor(context), "antidiarrheal");
    addItem ("Lacteol Forte sach", "Lactobacillus 10 billions", "Lacteol forte topro Lactobacillus LB 10 billions sachets", gitColor(context), "antidiarrheal");
    addItem ("Lactodel tab", "Bromocriptine 2.5 mg", "lactodel bromocriptine bromotemia dopagon parlodel tablets", hormoneColor(context), "hyperprolactinemia-associated dysfunctions parkinsonism disease acromegaly neuroleptic malignant syndrome Dopamine Agonists");
    addItem ("Lactomax sach", "Fenugreek +Anise +Chamomile +Fennel", "lactomax Fenugreek anise chamomile Fennel maxi-mum maximum moralin herbolin sachets", vitColor(context), "Improve the function of lactating glands the gastrointestinal function improvement");
    addItem ("Lafurex amp", "Furosemide 40 mg /4 ml", "lafurex furosemide diusex lasiphar lasix salex selectofur 40mg/4ml ampoule", cvsColor(context), "Acute Pulmonary Edema Hypertensive Crisis Increased Intracanial Pressure Hyperkalemia Hypermagnesemia in ACLS loop diuretics");
    addItem ("Lafurex 20 tab", "Furosemide 20 mg", "lafurex furosemide furoretic 20mg tablets", cvsColor(context), "Edema Resistant Hypertension loop diuretics");
    addItem ("Lafurex 40 tab", "Furosemide 40 mg", "lafurex furosemide fruzex furoretic lasix odement salex 40mg tablets", cvsColor(context), "Edema Resistant Hypertension loop diuretics");
    addItem ("Lamidine tab", "Lamivudine", "lamidine lamivudine vudinine zeffix 100mg 150mg tablets", abColor(context), "HIV infections aids Chronic Hepatitis B Nucleoside Reverse Transcriptase Inhibitors");
    addItem ("Lamisil 125 tab", "Terbinafen 125 mg", "Lamisil Terbinafen lamifen 125mg tablets", abColor(context), "Tinea capitis cruris pedis corporis Onychomycosis Sporotrichosis antifungals infections");
    addItem ("Lamisil 250 tab", "Terbinafen 250 mg", "Lamisil Terbinafen lamifen fungisafe mycomic terbifungin trerbi terbinasil unitopfin 250mg tablets", abColor(context), "Tinea capitis cruris pedis corporis Onychomycosis Sporotrichosis antifungals infections");
    addItem ("Lamotrine 2 chew tab", "Lamotrigine 2 mg", "lamotrine lamotrigine lamictal 2mg chewable 25mg 50mg 100mg 200mg tablets", cnsColor(context), "seizure disorder convulsions epilepsy anticonvulsants");
    addItem ("Lamotrine 25 tab", "Lamotrigine 25 mg", "lamotrine lamotrigine controlepsy lamictal larogen leptrogine labileno lamotrotic rowatrigin 25mg 50mg 100mg 200mg tablets", cnsColor(context), "seizure disorder partial onset seizures bipolar disorder convulsions epilepsy anticonvulsants");
    addItem ("Lanoxin amp", "Digoxin 0.5 mg /2 ml", "lanoxin digoxin cardixin 0.500mcg mg/2ml ampoule", cvsColor(context), "Atrial Fibrillation Heart Failure class V 5 antiarrhythmic inotropic agents");
    addItem ("Lanoxin syrup", "Digoxin 0.05 mg /ml", "lanoxin digoxin digoxicard 0.050mcg mg/ml syrup", cvsColor(context), "Atrial Fibrillation Heart Failure class V 5 antiarrhythmic inotropic agents");
    addItem ("Lanoxin tab", "Digoxin 0.25 mg", "lanoxin digoxin cardixin 0.25mg tablets", cvsColor(context), "Atrial Fibrillation Heart Failure class V 5 antiarrhythmic inotropic agents");
    addItem ("Lantus cartridges/pen", "Insulin Glargine 100 units/ml", "Lantus Insulin Glargine toujeo 100units/ml cartridges pen", hormoneColor(context), "type1 type2 diabetes mellitus long-acting insulins");
    addItem ("Lanzofutal 15 cap", "Lansoprazole 15 mg", "lanzofutal lansoprazole lanzor zallanz zollipak 15mg capsules", gitColor(context), "GERD gastroesophageal reflux disease Gastric Erosive Esophagitis Duodenal peptic ulcer Hypersecretory Conditions zollinger ellison syndrome Heartburn Helicobacter Pylori Infection Proton Pump Inhibitors PPIs");
    addItem ("Lanzofutal 30 cap", "Lansoprazole 30 mg", "lanzofutal lansoprazole lanzor gastrocure zollipak lansopro lantanon lopral loral peptazol peptolanz 30mg capsules tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric Erosive Esophagitis Duodenal peptic ulcer Hypersecretory Conditions zollinger ellison syndrome Heartburn Helicobacter Pylori Infection Proton Pump Inhibitors PPIs");
    addItem ("Laxeol PI tab", "Sodium Picosulphate 5 mg", "laxeol pi sodium picosulphate picosulfate 5mg tablets", gitColor(context), "Constipation stimulant laxative");
    addItem ("Laxin tab", "Bisacodyl 10 mg", "laxin bisacodyl 10mg tablets", gitColor(context), "Constipation stimulant laxative");
    addItem ("Lentra sach", "Lactium 150 mg", "lentra lactium whey protein isolate 150mg sachets", vitColor(context), "insomnia stress");
    addItem ("Leukeran tab", "Chlorambucil 2 mg", "leukeran chlorambucil 2mg tablets", otherColor(context), "Chronic Lymphocytic Lymphatic Leukemia Hodgkin's Lymphoma Antineoplastic Agents");
    addItem ("Levanox cap", "Catechu +Lecithin +Turmeric +Silymarin +Dandelion", "levanox Pale Catechu Leaf Soya Lecithin Turmeric powder dried rhizome Milk thistle Silymarin Dandelion Extract capsules", gitColor(context), "Liver Tonic support supplementation");
    addItem ("Levemir flexpen", "Insulin Detemir 100 units/ml", "Levemir Insulin Detemir 100units/ml flexpen", hormoneColor(context), "type1 type2 diabetes mellitus long-acting insulins");
    addItem ("Levocar 25/100 tab", "Carbidopa +Levodopa", "levocar 25/100 tablets carbidopa 25mg levodopa 100mg", cnsColor(context), "parkinsonism parkinson's disease parkinsonlike disorders");
    addItem ("Levocar 25/250 tab", "Carbidopa +Levodopa", "levocar carbidopa 25mg levodopa 250mg lecardopa sinemet parkidopa 25/250 tablets", cnsColor(context), "parkinsonism parkinson's disease parkinsonlike disorders");
    addItem ("Levocar 50/200 CR tab", "Carbidopa +Levodopa", "levocar carbidopa 50mg levodopa 200mg shatoo sinemet 50/200 cr tablets", cnsColor(context), "parkinsonism parkinson's disease parkinsonlike disorders");
    addItem ("Levocarnine syrup", "L-Carnitine 1 gm /10 ml", "levocarnine l-carnitine lcarnitine levocarnitine cartiswab 1000mg 1gm/10ml syrup", otherColor(context), "carnitine deficiency supplementation");
    addItem ("Levoflox 250 tab", "Levofloxacin 250 mg", "levofloxacin floxabact leeflox lee-flox levodel levoxin tavanic unibiotic venaxan 250mg tablets", abColor(context), "Community Acquired Pneumonia Acute bacterial sinusitis Bronchitis skin Plague Epididymitis Nosocomial Pneumonia skin Chronic Bacterial Prostatitis UTI urinary tract infections Pyelonephritis fluoroquinolones");
    addItem ("Levohistam drops", "Levocetirizine 5 mg /1 ml", "Levohistam Levocetirizine 5mg/ml drops", resColor(context), "Allergic rhinitis allergy chronic urticaria 2nd second generation antihistamines");
    addItem ("Levohistam syrup", "Levocetirizine 2.5 mg /5 ml", "Levohistam Levocetirizine allear lergicare allergstop levcet levoctivan linahayzin mervosa xaltec orgitrizine 2.5mg/5ml syrup", resColor(context), "Allergic rhinitis allergy chronic urticaria 2nd second generation antihistamines");
    addItem ("Levohistam tab", "Levocetirizine 5 mg", "Levohistam Levocetirizine allear lergicare allergstop allevo levcet levoctivan xaltec orgitrizine chemicetrizine lergopan levocitrone turnalev zalkevor 5mg tablets", resColor(context), "Allergic rhinitis allergy chronic urticaria 2nd second generation antihistamines");
    addItem ("Levophrine amp", "Noradrenaline 4 mg /4 ml", "Levophrine noradrenaline norepinephrine 4mg/4ml ampoule", cvsColor(context), "Acute Hypotension Cardiac Arrest Sepsis & Septic Shock Alpha/Beta Adrenergic Agonists");
    addItem ("Levoxin vial", "Levofloxacin 500 mg /100 ml", "levoxin levofloxacin alfacef tavanic mylotarg tavacin venaxam 500mg/100ml vial", abColor(context), "Community acquired Pneumonia Acute Bacterial Sinusitis Bronchitis Nosocomial Pneumonia skin Chronic bacterial prostatitis UTI urinary tract infections Plague fluoroquinolones");
    addItem ("Librax tab", "Clidinium +Chlordiazepoxide", "librax clidinium chlordiazepoxide dibrex epirax cloxide clidiaspasm tablets capsules", gitColor(context), "Peptic ulcer IBS irritable bowel syndrome Enterocolitis");
    addItem ("Lidocaine 1% amp", "Lidocaine 1%", "Lidocaine kahicaine 1% ampoule", cnsColor(context), "Regional Infiltration Percutaneous IV regional Anesthesia Peripheral Sympathetic Nerve Blocks Central Neural Blocks Epidural local Anesthetics");
    addItem ("Lidocaine 2% amp", "Lidocaine 2%", "Lidocaine debocaine ultracaine 2% ampoule vial", cnsColor(context), "Regional Infiltration Percutaneous IV regional Anesthesia Peripheral Sympathetic Nerve Blocks Central Neural Blocks Epidural local Anesthetics");
    addItem ("Limitless Allzyme Max tab", "Chymotrypsin +Trypsin +Bromelain", "Limitless Allzyme Max tablets alpha Chymotrypsin Trypsin Bromelain", otherColor(context), "Inflammations Oedema");
    addItem ("Limitless Baby D drops", "Vit D3 1600 iu /ml", "Limitless Baby D cholecalciferol vitamin d3 1600iu/ml drops", vitColor(context), "vitamin d deficiency osteoporosis rickets");
    addItem ("Limitless C-Zinc lozenges", "Vit C 100 mg +Zinc 5 mg", "limitless c-zinc vitamin c ascorbic acid Zinc citra lozenges", vitColor(context), "antioxidant diarrhea immunity enhancer boosting");
    addItem ("Limitless C-Zinc Plus tab", "Vit C +Zinc +Vit D3 +Magnesium +elderberry +Echinacea", "limitless c-zinc plus tablets vitamin c ascorbic acid Zinc vitamin d3 Magnesium mg elderberry Echinacea", vitColor(context), "antioxidant diarrhea immunity enhancer boosting");
    addItem ("Limitless Chromax Cut sach", "Glucomannan +Inulin +Chromium +Green Tea +Green Coffee +Vit B3 +Vit C", "limitless chromax cut sachets Glucomannan Inulin Chromium Green Tea Green Coffee Nicotinic Acid nicotinamide niacin vitamin b3 vitamin c ascorbic acid", vitColor(context), "supports weight control");
    addItem ("Limitless Fortalase syrup", "Alpha amylase 1500 U.CEIP /5 ml", "Limitless Fortalase alpha amylase 1500U.CEIP/5ml syrup", otherColor(context), "Inflammations Oedema");
    addItem ("Limitless Lactoferrin sach", "Lactoferrin 100 mg", "limitless lactoferrin aromix dravo dulefer epicoferrin lacto-mash lactomash lactofer lactoglobin mixolin natrol onaem oravar pravotin provan sanso lactoferrin sweela tala technorrin verony 100mg sachets capsules", vitColor(context), "iron deficiency anemia immunity enhancer");
    addItem ("Limitless Man Max tab", "Vitamins +Minerals", "limitless man max tablets Multivitamins a c ascorbic acid d3 tocopherol e phytonadione k thiamine b1 b2 riboflavin b3 Nicotinic Acid nicotinamide niacin pyridoxine b6 Folic Acid b9 cobalamin b12 b7 biotin B5 pantothenic acid calcium iron p phosphorus iodine mg magnesium Zinc selenium copper cu manganese mn cr chromium molybdenum cl chloride potassium lycopena", vitColor(context), "multivitamin minerals deficiency supplementation immunity enhancer");
    addItem ("Limitless Omega-3 Fish Oil cap", "Fish Oil 2 gm (Omega 3 1400 mg) +Vit D 10 mg", "limitless omega-3 omega3 fish oil capsules dha epa vitamin d", vitColor(context), "support fetal brain and joint health and retina development hypertriglyceridemia");
    addItem ("Limitless Prenatal Max cap", "Vitamins +Minerals", "Limitless Prenatal Max capsules beta carotene Multivitamins a c d3 tocopherol e b1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin pyridoxine b6 Folic Acid b9 b12 cobalamin biotin b7 B5 pantothenic acid calcium iron iodine magnesium zinc copper omega3 fatty acid dha epa", vitColor(context), "optimal support for pregnancy and fetal development lactating ladies");
    addItem ("Limitless Prostanorm Max tab", "Saw Palmetto +Pumpkin Seed Oil +Pygeum Africanum +Stinging Nittle +Zinc +Lycopena +Selenium", "limitless prostanorm max tablets Saw Palmetto Pumpkin Seed Oil powder Pygeum Africanum Stinging Nittle Zinc Lycopena Selenium", urinaryColor(context), "symptomatic relief of bph benign prostatic hyperplasia chronic prostatitis");
    addItem ("Limitless Turmeric cap", "Curcumin (Turmeric) 500 mg +Piperine 2.5 mg", "limitless Turmeric capsules curcumin piperine black pepper", analgesicColor(context), "anti inflammatory analgesics for healthy joints");
    addItem ("Limitless Woman Max tab", "Vitamins +Minerals", "limitless woman max tablets Multivitamins a c ascorbic acid d3 tocopherol e phytonadione k thiamine b1 b2 riboflavin b3 Nicotinic Acid nicotinamide niacin pyridoxine b6 Folic Acid b9 cobalamin b12 b7 biotin B5 pantothenic acid calcium iron phosphorus iodine mg magnesium Zinc selenium copper cu manganese mn cr chromium molybdenum cl chloride potassium", vitColor(context), "multivitamin minerals deficiency supplementation immunity enhancer");
    addItem ("Limitless Zinc tab", "Zinc 25 mg", "limitless octozinc gluconate origin 25mg tablets", vitColor(context), "zinc deficiency supplementation");
    addItem ("Lincocin amp", "Lincomycin 300 mg /ml", "Lincocin Lincomycin lincobiotic 300mg 600mg ampoule", abColor(context), "bacterial infections lincosamides");
    addItem ("Linex adult cap", "Lactobacillus +Bifidobacterium", "Linex adult capsules Lactobacillus acidophilus Bifidobacterium Animalis Subsp. Lactis probiotic", gitColor(context), "Irritable bowel syndrome ibs ulcerative colitis intestinal dysbiosis helps regulate and maintain the balance of the intestinal flora");
    addItem ("Linex sach", "Lactobacillus +Bifidobacterium", "Linex sachets Lactobacillus acidophilus Bifidobacterium Animalis Subsp. Lactis probiotic sticks", gitColor(context), "Irritable bowel syndrome ibs ulcerative colitis intestinal dysbiosis helps regulate and maintain the balance of the intestinal flora");
    addItem ("Liometacen amp", "Indomethacin 50 mg /2 ml", "liometacen indomethacin 50mg/2ml ampoule", analgesicColor(context), "Closure of PDA patent ductus arteriosus Inflammatory Disorders Rheumatoid Disorders Bursitis Tendinitis Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Lipidalon 1 tab", "Pitavastatin 1 mg", "lipidalon pitavastatin jackwell lipovastatin lividemia pivastalo 1mg 2mg 4mg tablets", cvsColor(context), "Heterozygous familial hypercholesterolemia Primary Hyperlipidemia and Mixed Dyslipidemia HMG-CoA Reductase Inhibitor Statins");
    addItem ("Lipifibrate tab", "Fenofibrate 105 mg", "lipifibrate fenofibrate lipanthyl supra lipanthyl fenolip finofib kemifib lipolex lipomedizen 105mg 145mg 300mg capsules tablets", cvsColor(context), "hypercholesterolemia hyperlipidemia hypertriglyceridemia dyslipidemia Antilipemic Agents");
    addItem ("Livabion amp", "Vit B1 +Vit B6 +Vit B12 +Folic Acid +Nicotinamide +D-Panthenol +Orotic Acid", "Livabion vitamin b1 thiamine vitamin b6 pyridoxine vitamin b12 cyanocobalamin Folic Acid vitamin b9 Nicotinic Acid nicotinamide niacin vitamin b3 D-Panthenol Orotic Acid omnevora cyanoheptan ampoule", vitColor(context), "polyneuritis Neuralgia diabetic polyneuropathy pernicious anemia");
    addItem ("Livial tab", "Tibolone 2.5 mg", "livial tibolone hansas oestrolone tibolian 2.5mg tablets", hormoneColor(context), "oestrogen deficiency symptoms in postmenopausal women Prevention of osteoporosis");
    addItem ("Lokelma 5 sach", "Sodium Zirconium Cyclosilicate 5 gm", "Lokelma Sodium Zirconium Cyclosilicate 5gm 10gm sachets", vitColor(context), "Hyperkalemia");
    addItem ("Lomotil syrup", "Diphenoxylate 2.5 mg +Atropine 0.025 mg /5 ml", "lomotil syrup diphenoxylate 2.5mg atropine 0.025mg", gitColor(context), "Diarrhea");
    addItem ("Lomotil tab", "Diphenoxylate 2.5 mg +Atropine 0.025 mg", "lomotil tablets diphenoxylate 2.5mg atropine 0.025mg", gitColor(context), "Diarrhea");
    addItem ("Lomoxen tab", "Lomefloxacin 400 mg", "lomoxen lomefloxacin lomex maxa-flox maxaflox 400mg tablets", abColor(context), "Urinary Tract Infections uti Cystitis Acute bacterial exacerbation of chronic bronchitis preoperative prophylaxis Transrectal prostate biopsy Transurethral surgical procedures fluoroquinolones");
    addItem ("Loprecough syrup", "Acetylcysteine +Chlorpheniramine", "Loprecough syrup acetylcysteine chlorpheniramine", resColor(context), "Dry Cough antitussive");
    addItem ("Lucidril 250 tab", "Meclofenoxate 250 mg", "lucidril meclofenoxate noodril 250mg tablets", cnsColor(context), "vertigo memory enhancement of concentration cerebral atherosclerosis aging insufficiency");
    addItem ("Lucidril 500 tab", "Meclofenoxate 500 mg", "lucidril meclofenoxate 500mg tablets", cnsColor(context), "vertigo memory enhancement of concentration cerebral atherosclerosis aging insufficiency");
    addItem ("Luciforte vial", "Meclofenoxate 500 mg", "luciforte meclofenoxate 500mg vial", cnsColor(context), "stroke cerebrovascular accidents cerebral acute deterioration of atherosclerosis cerebral aging anesthesia");
    addItem ("Lutofolone amp", "Estradiol 2 mg +Progesterone 20 mg", "lutofolone ampoule Estradiol benzoate 2mg Progesterone 20mg", hormoneColor(context), "secondary amenorrhea");

    addItem ("Maalox Plus susp", "Al Hydroxide +Mg Hydroxide +Simethicone", "maalox plus aluminum aluminium hydroxide magnesium hydroxide simethicone acidipan alumatrend loburna suspension", gitColor(context), "Dyspepsia Abdominal bloating antacids");
    addItem ("Maalox Plus tab", "Al Hydroxide +Mg Hydroxide +Simethicone", "maalox plus tablets aluminum aluminium hydroxide magnesium hydroxide simethicone", gitColor(context), "Dyspepsia Abdominal bloating antacids");
    addItem ("MabThera 10 mg/ml vial", "Rituximab 10 mg / ml", "MabThera Rituximab rituxera rixathon 10mg/ml vial", otherColor(context), "non-hodgkin lymphoma chronic lymphocytic leukemia rheumatoid arthritis wegener granulomatosis microscopic polyangiitis pemphigus vulgaris Antineoplastic Agents Monoclonal Antibody");
    addItem ("Maddovit D3 drops", "Vit D 400 iu /ml", "Maddovit cholecalciferol vitamin d3 cadepro dal-port dalport sanso d3 400iu/ml drops", vitColor(context), "vitamin d deficiency osteoporosis");
    addItem ("Magnesium Plus tab", "Mg Gluconate 100 mg + Mg Oxide 400 mg (245 mg elemental Mg)", "Magnesium Plus tablets gluconate magnesium oxide", vitColor(context), "magnesium supplementation antacids");
    addItem ("Magnesium Sulfate amp", "Magnesium Sulphate 1 gm/ 10 ml", "Magnesium Sulfate Sulphate MgSo4 1gm/10ml 10% ampoule", vitColor(context), "magnesium deficiency hypomagnesemia seizures in eclampsia toxemia of pregnancy Severe Acute Nephritis Bronchospasm status asthmaticus bronchial asthma Torsades de Pointes cardiac arrest ventricular tachycardia Preterm Labor class V 5 antiarrhythmic agents");
    addItem ("Malari-Co tab", "Artemether 20 mg +Lumefantrine 120 mg", "malari-co artemether lumefantrine malarico tablets", abColor(context), "malaria");
    addItem ("Mannitol 10%", "Mannitol 10%", "mannitol 10% iv solution", cvsColor(context), "Elevated Intracranial icp Intraocular Pressure");
    addItem ("Mannitol 20%", "Mannitol 20%", "mannitol 20% iv solution", cvsColor(context), "Elevated Intracranial icp Intraocular Pressure");
    addItem ("Marcaine amp", "Bupivacaine 0.5%", "marcaine bupivacaine spinal heavy markyrene sunnypivacaine watevacin 0.5% ampoule", cnsColor(context), "Regional Anesthesia Peripheral nerve Caudal Lumbar epidural block local Anesthetics");
    addItem ("Marcal tab", "Calcium Acetate 700 mg (180 mg elemental calcium)", "marcal Calcium Acetate rendose 700mg tablets", vitColor(context), "hyperphosphatemia in end stage renal failure");
    addItem ("Marcofen 100 supp", "Ibuprofen 100 mg", "Marcofen Ibuprofen 100mg suppositories", analgesicColor(context), "Pain Fever analgesics antipyretics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Marcofen 300 supp", "Ibuprofen 300 mg", "Marcofen Ibuprofen flamotal mepabrufen 300mg suppositories", analgesicColor(context), "Pain Fever analgesics antipyretics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Marcofen 500 supp", "Ibuprofen 500 mg", "Marcofen Ibuprofen flamotal mepabrufen 500mg suppositories", analgesicColor(context), "Pain Fever analgesics antipyretics Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Marevan 1 tab", "Warfarin 1 mg", "marevan warfarin haemofarin marivanil coumadin 1mg 3mg 5mg tablets", cvsColor(context), "venous pulmonary embolism deep vein thrombosis dvt stroke thromboembolism cardiac valve replacement post-myocardial infarction rheumatic valve disease tia anticoagulants");
    addItem ("Martaviva tab", "Dienogest 2 mg +Ethinyl Estradiol 0.03 mg", "martaviva tablets Dienogest 2mg EthinylEstradiol 0.03mg", hormoneColor(context), "contraceptive oral contraception acne vulgaris");
    addItem ("Marvit cap", "Vitamins +Minerals", "Marvit capsules Multivitamins a b1 thiamine b2 riboflavin b6 pyridoxine b12 cobalamin c ascorbic acid E tocopherol Nicotinic Acid nicotinamide niacin b3 Folic Acid b9 b7 biotin calcium magnesium sulphate selenium iron royal jelly ginseng", vitColor(context), "Multivitamins minerals deficiency supplementation");
    addItem ("Marvit syrup", "Vitamins +Minerals", "Marvit syrup Multivitamins a B1 thiamine B2 riboflavin B5 pantothenic acid B6 pyridoxine b12 cobalamin c ascorbic acid d3 E tocopherol Nicotinic Acid nicotinamide niacin b3 b7 biotin calcium fluorine selenium iron", vitColor(context), "Multivitamins minerals deficiency supplementation");
    addItem ("Matrix cap", "Vitamins +Minerals", "matrix capsules pills vitamin k2 vitamin c ascorbic acid vitamin d3 beta carotene vitamin a calcium magnesium potassium zinc manganese boron copper", vitColor(context), "Osteopenia osteoporosis Vitamins minerals deficiency supplementation");
    addItem ("Maxdinir 125 susp", "Cefdinir 125 mg /5 ml", "maxdinir Rame-dinir ramedinir cefathird Cefdinir dinar egynir merbactadin omnicef torbener 125mg/5ml suspension", abColor(context), "Acute otitis media Pharyngitis tonsillitis Sinusitis Skin Infections RTI Pneumonia 3rd third generation cephalosporins");
    addItem ("Maxdinir 250 susp", "Cefdinir 250 mg /5 ml", "maxdinir Rame-dinir ramedinir Cefdinir averofectan merbactadin torbener 250mg/5ml suspension", abColor(context), "Acute otitis media Pharyngitis tonsillitis Sinusitis Skin Infections RTI Pneumonia 3rd third generation cephalosporins");
    addItem ("Maxdinir 300 cap", "Cefdinir 300 mg", "maxdinir cefdinir cefdin omnicef spectracefocure torbener cefathird dinar egynir denrocef merbactadin 300mg capsules", abColor(context), "Acute otitis media Pharyngitis tonsillitis Sinusitis Skin Infections RTI Pneumonia 3rd third generation cephalosporins");
    addItem ("Maxical D susp", "Calcium +Magnesium +Vit D", "Maxical D suspension Calcium Magnesium Vitamin D", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Maxical tab", "Calcium 600 mg +Vit D3 400 IU", "maxical tablets Calcium carbonate vitamin d3", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Maxipime 500 vial", "Cefepime 500 mg", "Maxipime Cefepime forcetex onsime wincef spectracef zovijectin 500mg vial", abColor(context), "Febrile Neutropenia Pneumonia UTI urinary tract Skin Intra-abdominal Infections 4th fourth generation cephalosporins");
    addItem ("Maxipime 1 gm vial", "Cefepime 1 gm", "Maxipime cefepime curafep forcetex onsime pimfast spectracef vanzapro wincef kempopim 1000mg 1gm vial", abColor(context), "Febrile Neutropenia Pneumonia UTI urinary tract Skin Intra-abdominal Infections 4th fourth generation cephalosporins");
    addItem ("Maxipime 2 gm vial", "Cefepime 2 gm", "Maxipime Cefepime curafep forcetex pimfast spectracef vanzapro wincef 2000mg 2gm vial", abColor(context), "Febrile Neutropenia Pneumonia UTI urinary tract Skin Intra-abdominal Infections 4th fourth generation cephalosporins");
    addItem ("Mayestrotense amp", "Propranolol 1 mg /ml", "mayestrotense propranolol inderal 1mg/ml ampoule", cvsColor(context), "hypercyanotic spells supraventricular arrhythmia Nonselective beta-blocker class II 2 antiarrhythmic agents");
    addItem ("Meclizigo odf", "Meclizine 25 mg", "meclizigo meclizine 25mg odf", gitColor(context), "Motion Sickness Vertigo antiemetic agents");
    addItem ("Meclopram amp", "Metoclopramide 10 mg /2 ml", "meclopram Metoclopramide ametic Primperan plemazol sunnypyramid 10mg/2ml ampoule", gitColor(context), "Chemotherapy-Induced Postoperative Nausea & Vomiting Severe Diabetic Gastroparesis Small Bowel Intubation Radiological Examination of upper GIT gerd gastroesophageal reflux disease prokinetic antiemetic agents");
    addItem ("Meclopram drops", "Metoclopramide 2 mg /ml", "meclopram Metoclopramide primperan 2mg/ml drops", gitColor(context), "diabetic gastroparesis gastroesophageal reflux disease gerd prokinetic agents");
    addItem ("Meclopram syrup", "Metoclopramide 5 mg /5 ml", "meclopram Metoclopramide primperan 5mg/5ml syrup", gitColor(context), "diabetic gastroparesis gastroesophageal reflux disease gerd prokinetic agents");
    addItem ("Meclopram tab", "Metoclopramide 10 mg", "meclopram Metoclopramide Primperan plemazol vomaway 10mg tablets", gitColor(context), "diabetic gastroparesis gastroesophageal reflux disease gerd prokinetic agents");
    addItem ("Megace tab", "Megestrol 160 mg", "megace megestrol 160mg tablets", otherColor(context), "AIDS-Related Cachexia Breast cancer Endometrial Cancer Cancer-Related Cachexia antineoplastic agents");
    addItem ("Megafen tab", "Ibuprofen 200 mg +Paracetamol 325 mg", "megafen ibuprofen paracetamol acetaminophen cetafen tablets", analgesicColor(context), "antipyretics fever analgesics pain");
    addItem ("Megalase syrup", "Alpha amylase 1000 U.CEIP /5 ml", "megalase Alpha amylase alphamylase maxilase medmylezen enzymotrex zemylaise 1000U.CEIP/5ml syrup", otherColor(context), "Inflammations Oedema");
    addItem ("Megalase tab", "Alpha amylase 3000 U.CEIP", "megalase Alpha amylase maxilase 3000U.CEIP tablets", otherColor(context), "Inflammations Oedema");
    addItem ("Melacryst odf", "Melatonin 1.5 mg", "melacryst melatonin 1.5mg odf", cnsColor(context), "Insomnia jet lag");
    addItem ("Melatonin 3 cap", "Melatonin 3 mg", "melatonin 3mg capsules", cnsColor(context), "jet lag");
    addItem ("Melatonin 5 tab", "Melatonin 5 mg", "melatonin dozova 5mg tablets", cnsColor(context), "jet lag");
    addItem ("Mena Q-45 cap", "Vitamin K2 45 mcg", "menaq-45 menaquinone-7-vitamin k2 45mcg capsules", vitColor(context), "vitamin k2 deficiency supplementation");
    addItem ("Mepecaine carpules", "Mepivacaine 3%", "Mepecaine Mepivacaine scandonest 3% carpules ampoule", cnsColor(context), "Infiltration Anesthesia Cervical/Brachial/Intercostal or Pudendal Transvaginal Paracervical Block Local Anesthetics");
    addItem ("Merional 75 vial", "Human Menopausal Gonadotrophin 75 iu", "merional human menopausal gonadotrophin hmg fsh lh menotropins epigonal ivf-m ivfm menofactor menogonal menopur meriofert 75iu 150iu vial", hormoneColor(context), "ovulation induction in Patients with Oligoanovulation art assisted reproductive technology spermatogenesis");
    addItem ("Meronem 500 vial", "Meropenem 500 mg", "Meronem Meropenem mirage merostarkyl 500mg vial", abColor(context), "Bacterial meningitis Complicated intra-abdominal Febrile Neutropenia skin Infections Carbapenems");
    addItem ("Meronem 1 gm vial", "Meropenem 1 gm", "Meronem Meropenem mirage merostarkyl nilopenem 1000mg 1gm vial", abColor(context), "Bacterial meningitis Complicated intra-abdominal Febrile Neutropenia skin Infections Carbapenems");
    addItem ("Merti cap", "Chitosan +Vit C +Chromium", "merti capsules Chitosan vitamin c ascorbic acid Chromium picolinate", otherColor(context), "to lower fat and body weight");
    addItem ("Mesna amp", "Mesna 100 mg /ml", "mesna uromes uromitexan 100mg/ml ampoule", otherColor(context), "Prevention of Ifosfamide Induced Hemorrhagic Cystitis Prevention of Cyclophosphamide Induced Hemorrhagic Cystitis");
    addItem ("Mesocept amp", "Norethisterone +Estradiol", "Mesocept ampoule Norethisterone enanthate Estradiol valerate", hormoneColor(context), "Contraception");
    addItem ("Metacardia 20 tab", "Trimetazidine 20 mg", "metacardia trimetazidine tricardia vastor 20mg tablets", cvsColor(context), "stable angina pectoris");
    addItem ("Metacardia 35 MR tab", "Trimetazidine 35 mg", "metacardia trimetazidine eurovasculita spaniela tricardia vastarel 35mg mr tablets", cvsColor(context), "stable angina pectoris");
    addItem ("Methabiogen tab", "Dexamethasone 8 mg", "methabiogen Dexamethasone 8mg tablets", strdColor(context), "Acute Exacerbation of Multiple Sclerosis Myeloma Corticosteroids");
    addItem ("Methadone 5 tab", "Methadone 5 mg", "methadone dolophine 5mg 10mg 20mg 40mg tablets", cnsColor(context), "severe pain detoxification opiate withdrawal opioids analgesics");
    addItem ("Methergin tab", "Methylergometrine Hydrogen Maleate 0.125 mg", "methergin methylergometrine hydrogen maleate methylergonovine 0.125mg tablets", cvsColor(context), "Postpartum Hemorrhage Refractory Cluster Headache");
    addItem ("Methocarbex tab", "Methocarbamol 750 mg +Ibuprofen 400 mg", "methocarbex methocarbamol 750mg ibuprofen 400mg gesirelax ibuflex muslgix tablets capsules", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Methotrexate 50 mg vial", "Methotrexate 50 mg /2 ml", "methotrexate emthexate pf methocip mtx unitrexate 50mg/2ml vial", otherColor(context), "acute lymphoblastic meningeal leukemia non-hodgkin lymphoma osteosarcoma breast cancer squamous cell carcinoma of the head and neck gestational trophoblastic neoplasia rheumatoid arthritis psoriasis pjia polyarticular juvenile idiopathic arthritis antineoplastic agents");
    addItem ("Methyltechno odf", "Methylcobalamin (Mecobalamin) 1 mg", "methyltechno methylcobalamin mecobalamin vitamin b12 novocobal 1000mcg 1mg odf tablets", vitColor(context), "Peripheral neuropathy vitamin b12 deficiency");
    addItem ("Miacalcic amp", "Calcitonin 100 IU /ml", "miacalcic calcitonin salmon stada calcitonium salmocalcin 100iu/ml ampoule", hormoneColor(context), "hypercalcemia paget disease postmenopausal osteoporosis");
    addItem ("Miacalcic nasal spray", "Calcitonin 200 IU /dose", "miacalcic apo-calcitonin apocalcitonin salmon boninasal genecalcin 200iu/dose nasal spray", hormoneColor(context), "postmenopausal osteoporosis");
    addItem ("Micardis 40 tab", "Telmisartan 40 mg", "micardis telmisartan biocardis chartoreg lemsisart zemlet 40mg 80mg tablets", cvsColor(context), "Hypertension cardiovascular risk reduction ARBs Angiotensin receptor blockers");
    addItem ("Microcept tab", "Levonorgestrel 0.15 mg +Ethinyl Estradiol 0.03 mg", "microcept levonorgestrel 0.03mg EthinylEstradiol 0.03mg microdette microgenest microgynon nordette tablets", hormoneColor(context), "contraceptive oral contraception");
    addItem ("Microlut tab", "Levonorgestrel 0.03 mg", "microlut levonorgestrel 0.03mg Lactevenor tablets", hormoneColor(context), "contraceptive oral contraception");
    addItem ("Mictonorm 15 tab", "Propiverine HCl 15 mg", "mictonorm propiverine hydrochloride urimagictam 15mg tablets", urinaryColor(context), "urinary incontinence increased urinary frequency urgency overactive bladder syndrome neurogenic detrusor overactivity hyperreflexia Anticholinergic Agents");
    addItem ("Mictonorm XL 30 tab", "Propiverine HCl 30 mg", "mictonorm xl propiverine hydrochloride 30mg tablets", urinaryColor(context), "urinary incontinence increased urinary frequency urgency overactive bladder syndrome neurogenic detrusor overactivity hyperreflexia Anticholinergic Agents");
    addItem ("Midathetic tab", "Midazolam 7.5 mg", "midathetic midazolam 7.5mg tablets", cnsColor(context), "insomnia preoperative sedation Benzodiazepines");
    addItem ("Midodrine drops", "Midodrine 1%", "midodrine 1% drops", cvsColor(context), "orthostatic hypotension stress incontinence");
    addItem ("Midodrine tab", "Midodrine 2.5 mg", "midodrine 2.5mg tablets", cvsColor(context), "orthostatic hypotension stress incontinence");
    addItem ("Miflonide inhalation caps", "Budesonide 400 mcg", "Miflonide Budesonide budecort budelizer halnide 400mcg inhalation caps", resColor(context), "bronchial asthma maintenance corticosteroids");
    addItem ("Migrostop tab", "Almotriptan 12.5 mg", "migrostop almotriptan forte migratrend triptagrain 12.5mg tablets", cnsColor(context), "migraine treatment Serotonin 5-HT-Receptor Agonists");
    addItem ("Migtriptan tab", "Rizatriptan 5 mg", "Migtriptan Rizatriptan migriza 5mg tablets", cnsColor(context), "migraine treatment Serotonin 5-HT-Receptor Agonists");
    addItem ("Milga tab", "Benfotiamine 40 mg +Vit B6 60 mg +Vit B12 250 mcg", "milga tablets vitamin b1 benfotiamine vitamin b6 pyridoxine vitamin b12 cyanocobalamin", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Milga Advance tab", "Benfotiamine 300 mg +Vit B6 100 mg +Vit B12 250 mcg", "milga advance tablets vitamin b1 benfotiamine vitamin B6 pyridoxine vitamin B12 cyanocobalamin", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Mimpara 30 tab", "Cinacalcet 30 mg", "mimpara cinacalcet paracalcet 30mg 60mg 90mg tablets", otherColor(context), "Primary secondary Hyperparathyroidism Parathyroid Carcinoma");
    addItem ("Minalax tab", "Bisacodyl +Docusate Na", "minalax tablets bisacodyl 5mg docusate sodium 100mg", gitColor(context), "Constipation stimulant laxative");
    addItem ("Mini Guava drops", "Guava +Tilia +Black Seed", "mini-guava n drops tilia guava extract black seed", resColor(context), "Cough");
    addItem ("Minidiab tab", "Glipizide 5 mg", "minidiab glipizide glupizide 5mg tablets", hormoneColor(context), "type2 diabetes mellitus Sulfonylureas");
    addItem ("Minipress 1 tab", "Prazosin 1 mg", "minipress prazosin 1mg 2mg tablets", cvsColor(context), "hypertension ptsd-related nightmares sleep disruption benign prostate hypertrophy raynaud phenomenon alpha1 blockers");
    addItem ("Minirin 0.1 tab", "Desmopressin 0.1 mg", "minirin desmopressin omegapress 0.100mcg mg tablets", urinaryColor(context), "Diabetes Insipidus Nocturnal Enuresis");
    addItem ("Minirin 0.2 tab", "Desmopressin 0.2 mg", "minirin desmopressin omegapress 0.200mcg mg tablets", urinaryColor(context), "Diabetes Insipidus Nocturnal Enuresis");
    addItem ("Minirin Melt 60 mcg", "Desmopressin 60 mcg", "minirin melt desmopressin 60mcg tablets", urinaryColor(context), "Diabetes Insipidus Nocturnal Enuresis");
    addItem ("Minirin Melt 120 mcg", "Desmopressin 120 mcg", "minirin melt desmopressin 120mcg tablets", urinaryColor(context), "Diabetes Insipidus Nocturnal Enuresis");
    addItem ("Minophylline-N amp", "Aminophylline 125 mg /5 ml", "aminophylline-n 2.5% 125mg/5ml ampoule", resColor(context), "Bronchospasm bronchial asthma Neonatal Apnea");
    addItem ("Miopan susp", "Magaldrate 540 mg/ 5 ml", "miopan magaldrate acicone glycodal-m 540mg/5ml suspension", gitColor(context), "Gastritis Dyspepsia flatulence heartburn Peptic Ulcer reflux esophagitis antacids");
    addItem ("Miopan Plus susp", "Magaldrate 540 mg +Simethicone 40 mg/ 5 ml", "miopan plus magaldrate 540mg simethicone 40mg acicone-s suspension", gitColor(context), "Gastritis Dyspepsia flatulence heartburn Peptic Ulcer reflux esophagitis gerd gastroesophageal reflux disease flatulence antacids");
    addItem ("Misotac tab", "Misoprostol 200 mcg", "misotac misoprostol cytotec 200mcg tablets", otherColor(context), "NSAID-Induced Ulcer Pregnancy Termination Stress Ulcer Prophylaxis Postpartum Hemorrhage Treatment of Incomplete Abortion Fat Malabsorption in Cystic Fibrosis Patients");
    addItem ("Mixtard 30 vial", "Insulin Isophane Human 70% +Insulin Regular Human 30%", "insulin mixtard 30 hm isophane insulin regular neutral human humulin insulin h mix insulinagypt insuman comb vial", hormoneColor(context), "type1 type2 diabetes mellitus");
    addItem ("Mobitil 7.5 cap", "Meloxicam 7.5 mg", "mobitil meloxicam anticox anti-cox ii medexaflam melocam mexicam mobic moxen 7.5mg tablets capsules", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Mobitil 15 cap", "Meloxicam 15 mg", "mobitil meloxicam anticox anti-cox ii arthricox medexaflam melocam meloflam mexicam mobic moxen 15mg tablets capsules", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Mobitil amp", "Meloxicam 15 mg /1.5 ml", "mobitil meloxicam anticox anti-cox ii medexaflam melocam meloxicam mexicam mobic 15mg/1.5ml ampoule", analgesicColor(context), "Osteoarthritis Rheumatoid Arthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Moduretic 5/50 tab", "Amiloride 5 mg +Hydrochlorothiazide 50 mg", "moduretic amiloride hydrochlorothiazide hydikal saluretic yostiretic tablets", cvsColor(context), "Hypertension thiazides Potassium Sparing Diuretics");
    addItem ("Mono Mak 20 tab", "Isosorbide Mononitrate 20 mg", "monomak isosorbide-5-mononitrate 20mg tablets", cvsColor(context), "angina pectoris prophylaxis nitrates");
    addItem ("Monopril 10 tab", "Fosinopril 10 mg", "monopril fosinopril 10mg 20mg tablets", cvsColor(context), "hypertension congestive heart failure ace Angiotensin-converting enzyme inhibitors");
    addItem ("Monuril sach", "Fosfomycin 3 gm", "monuril fosfomycin monurol fosforon 3gm sachets", abColor(context), "UTI urinary tract infections acute cystitis prostatitis");
    addItem ("Morphine Sulphate 10 mg/ml amp", "Morphine 10 mg /ml", "morphine sulphate sulfate 10mg/ml ampoule", cnsColor(context), "Analgesia Cyanotic Tetralogy of Fallot Acute Pain opioids analgesics");
    addItem ("Morphine Sulphate 20 mg/ml amp", "Morphine 10 mg /ml", "morphine sulphate sulfate 20mg/ml ampoule", cnsColor(context), "Analgesia Cyanotic Tetralogy of Fallot Acute Pain opioids analgesics");
    addItem ("Mosapride 2.5 tab", "Mosapride 2.5 mg", "mosapride 2.5mg tablets", gitColor(context), "GERD Gastric Ulcer nausea vomiting Heartburn gastritis dyspepsia prokinetic agents");
    addItem ("Mosapride 5 tab", "Mosapride 5 mg", "mosapride fluxopride gasmovac gerdcare 5mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric Ulcer nausea vomiting Heartburn gastritis dyspepsia prokinetic agents");
    addItem ("Mosedin Plus SR cap", "Loratadine 5 mg +Pseudoephedrine 120 mg", "Mosedin Plus SR Loratadine 5mg pseudoephedrine 120mg decongess loratin-d lorin-d clarinase capsules", resColor(context), "Allergic rhinitis allergy Urticaria nasal congestion decongestants");
    addItem ("Mosedin syrup", "Loratadine 5 mg /5 ml", "Mosedin allergiraz lorano loraswab loratan lorine claritine scopallerge uniloratadine 5mg/5ml syrup", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Mosedin tab", "Loratadine 10 mg", "Mosedin allergetone allergiraz histalong lorano loratan lorine claritine sedclarit uniloratadine 10mg tablets", resColor(context), "Allergic rhinitis allergy Urticaria 2nd second generation antihistamines");
    addItem ("Moviprep sach", "Macrogol 3350 +Sodium sulfate anhydrous +NaCl +KCl +Ascorbic Acid +Sodium Ascorbate", "moviprep Macrogol 3350 Sodium sulfate anhydrous NaCl sodium chloride KCl potassium chloride vitamin c Ascorbic Acid Sodium Ascorbate prepawest sachets", gitColor(context), "constipation laxative bowel cleansing prior to any clinical procedures requiring a clean bowel");
    addItem ("Moxiflox tab", "Moxifloxacin 400 mg", "moxifloxacin moxavidex actimoxiflox advancrib adwifloxacen avalox azgoflox delmoxa dolabactin floxepci fluroflox gastamoxacine idelox kinomoxi moflox meramerix mograflox mortapp moxilabact moxitrix primoxizar quinofloxachem quinomoxin raspelocin rightiflox rowamoxiflox shamsomox 400mg tablets", abColor(context), "Acute Bacterial Sinusitis Acute exacerbation of chronic bronchitis Skin Pneumonia Complicated Intra-abdominal Infections Plague fluoroquinolones");
    addItem ("Moxiflox infusion", "Moxifloxacin 400 mg/ 250 ml", "moxifloxacin moxitrix 400mg/250ml iv infusion", abColor(context), "Acute Bacterial Sinusitis Acute exacerbation of chronic bronchitis Skin Pneumonia Complicated Intra-abdominal Infections Plague fluoroquinolones");
    addItem ("Mpiviropack tab", "Sofosbuvir 400 mg", "mpiviropack Sofosbuvir-mup andohepasuvir augispov episovir grateziano gratisovir heterosofir hopforhep myhep nucleobuvir serinosprevir sofocivir sofolanork sofomerase sofovirotal sofozav sovaldi tigaglor 400mg tablets", abColor(context), "chronic hepatitis C virus infections hcv");
    addItem ("Mpiviropack Plus tab", "Ledipasvir 90 mg +Sofosbuvir 400 mg", "mpiviropack Ledipasvir Sofosbuvir geneduovir harvoni heterosofir ledisbuvir sofolanork plus tablets", abColor(context), "hepatitis C virus infections hcv");
    addItem ("MST Continus tab", "Morphine 30 mg", "mst continus morphine 30mg tablets", cnsColor(context), "chronic Pain opioids analgesics");
    addItem ("Mucinex tab", "Guaifenesin 600 mg", "mucinex guaifenesin 600mg tablets", resColor(context), "Productive Cough expectorant");
    addItem ("Mucogel susp", "Al Hydroxide +Mg Hydroxide +Oxethazine", "mucogel aluminum aluminium hydroxide magnesium hydroxide oxethazine mucalgin suspension", gitColor(context), "Gastritis Esophagitis Peptic Ulcer antacids");
    addItem ("Mucophylline syrup", "Bromhexine +Acephylline piperazine", "Mucophylline syrup Bromhexine Acephylline piperazine acefyllin", resColor(context), "Productive Cough mucolytics bronchial asthma bronchospasm");
    addItem ("Mucosol adult syrup", "Carbocisteine 250 mg /5 ml", "Mucosol adult Carbocisteine avichest carboxymethyl cysteine mucolase solvex carbocysteine 5% 250mg/5ml syrup", resColor(context), "Productive Cough mucolytics");
    addItem ("Mucosol ped syrup", "Carbocisteine 125 mg /5 ml", "Mucosol ped Carbocisteine avichest carboxymethyl cysteine carbolase carbocysteine 2% 125mg/5ml syrup", resColor(context), "Productive Cough mucolytics");
    addItem ("Mucosol cap", "Carbocisteine 375 mg", "Mucosol Carbocisteine avichest carboxymethyl cysteine carbolase carbocysteine 375mg capsules", resColor(context), "Productive Cough mucolytics");
    addItem ("Mucosta tab", "Rebamipide 100 mg", "mucosta rebamipide costareb healioreptic ulsorest 100mg tablets", gitColor(context), "Peptic ulcer gastric ulcer");
    addItem ("Mucotec 150 cap", "Erdosteine 150 mg", "mucotec erdosteine 150mg capsules", resColor(context), "Productive Cough mucolytics expectorant");
    addItem ("Mucotec 300 cap", "Erdosteine 300 mg", "mucotec erdosteine erdolytic erdotinol mukemi erdosolvine 300mg capsules", resColor(context), "Productive Cough mucolytics expectorant");
    addItem ("Mucotec susp", "Erdosteine 175 mg /5 ml", "mucotec erdosteine erdolytic 175mg/5ml suspension", resColor(context), "Productive Cough mucolytics expectorant");
    addItem ("Multi-Relax 5 tab", "Cyclobenzaprine 5 mg", "multi-relax multirelax cyclobenzaprine cycloflex moveasy cyclosed 5mg 10mg tablets", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("My-Sweet Baby N syrup", "Dill Oil 2.3 mg +Caraway Oil 0.0183 mg /5 ml", "My-Sweet Baby N Dill Caraway Oil syrup", gitColor(context), "Flatulence colic bloating spasm gas retention");
    addItem ("Mycostatin drops", "Nystatin 100 000 units /1 ml", "Mycostatin Nystatin fungifree fungistatin nocandida orastatin 100000 units/ml drops", abColor(context), "antifungals infections oral candidiasis");
    addItem ("Myfortic 180 tab", "Mycophenolic acid 180 mg", "myfortic mycophenolic acid mycophenolate sodium 180mg tablets", otherColor(context), "kidney transplant Immunosuppressive agents");
    addItem ("Myfortic 360 tab", "Mycophenolic acid 360 mg", "myfortic mycophenolic acid mycophenolate sodium 360mg tablets", otherColor(context), "kidney transplant Immunosuppressive agents");
    addItem ("Mylobac 10 tab", "Baclofen 10 mg", "mylobac baclofen 10mg 25mg tablets", cnsColor(context), "skeletal muscle spasticity relaxant");
    addItem ("Myodonia 25 tab", "Milnacipran 25 mg", "myodonia milnacipran milnavella milnamagic averomilan ixel milnacip 25mg 50mg tablets", cnsColor(context), "fibromyalgia");
    addItem ("Myofen cap", "Chlorzoxazone 250 mg +Ibuprofen 200 mg", "myofen chlorzoxazone 250mg ibuprofen 200mg mark fast profenazone capsules", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");

    addItem ("Na Nitroprusside vial", "Sodium Nitroprusside 50 mg", "na sodium nitroprusside niprid nitriate 50mg vial", cvsColor(context), "hypertensive crisis controlled hypotension during surgery acute heart failure vasodilators");
    addItem ("Nalidram tab", "Nalidixic Acid 500 mg", "nalidram nalidixic acid 500mg tablets", abColor(context), "UTI urinary tract infection quinolones");
    addItem ("Naloxone amp", "Naloxone 0.4 mg /ml", "naloxone rescuerix xeropium 0.4mg/ml ampoule", cnsColor(context), "Postanesthesia Opioid Reversal Acute opioid overdose Reversal of Respiratory Depression with Therapeutic Opioid Doses Postoperative Opioid Depression antagonist antidotes");
    addItem ("Nalufin amp", "Nalbuphine 20 mg /ml", "nalufin Nalbuphine nalfin nalpain 20mg/ml ampoule", cnsColor(context), "pain opioids analgesics anesthesia supplement");
    addItem ("Nanazoxide susp", "Nitazoxanide 100 mg /5 ml", "Nanazoxide Nitazoxanide antidiazox cryptonaz nitazode cryptoper egygastreaz nitclean nitazoxin trustnal uninitaprozax zolifutal 100mg/5ml suspension", abColor(context), "Diarrhea caused by Cryptosporidium Parvum or Giardia Lamblia");
    addItem ("Nanazoxide tab", "Nitazoxanide 500 mg", "Nanazoxide Nitazoxanide antidiazox bactrofight cryptonaz cryptoper cryptosept nitazode egygastreaz nitclean nitazoxin parazoxanide trustnal protostop uninitaprozax xerovirinc zolifutal 500mg tablets capsules", abColor(context), "Diarrhea caused by Cryptosporidium Parvum or Giardia Lamblia");
    addItem ("Nandurabolin 50 amp", "Nandrolone Decanoate 50 mg", "nandurabolin nandrolone decanoate decadurabolin osteobolin 50mg ampoule", hormoneColor(context), "muscle breakdown osteoporosis");
    addItem ("Naprosyn 250 tab", "Naproxen 250 mg", "Naprosyn naproxen myoprox naprofen 250mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis ankylosing spondylitis dysmenorrhea acute gout migraine Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Naprosyn 500 supp", "Naproxen 500 mg", "naprosyn naproxen supusan 500mg suppositories", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis ankylosing spondylitis dysmenorrhea acute gout migraine Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Naprosyn 500 tab", "Naproxen 500 mg", "Naprosyn naproxen naprofen orgoproxen 500mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis ankylosing spondylitis dysmenorrhea acute gout migraine Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Naredrix tab", "Naratriptan 2.5 mg", "naredrix naratriptan 2.5mg tablets", cnsColor(context), "migraine treatment Serotonin 5-HT-Receptor Agonists");
    addItem ("Narkleen cap", "Activated Coconut charcoal +Coconut oil +Peppermint oil", "narkleen capsules Activated Coconut charcoal Peppermint oil", gitColor(context), "gas retention flatulence");
    addItem ("Nashiliv 5 tab", "Obeticholic Acid 5 mg", "nashiliv Obeticholic Acid 5mg 10mg tablets", gitColor(context), "Primary Biliary Cholangitis");
    addItem ("Naso-Cyanocobalamin nasal spray", "Cyanocobalamin 500 mcg /0.1 ml", "Naso-Cyanocobalamin NasoCyanocobalamin vitamin b12 500mcg/0.1ml nasal spray", vitColor(context), "vitamin b12 deficiency Pernicious Anemia");
    addItem ("Nassar tab", "Aloe Vera +Belladonna +Colocynth +Scammony", "nassar tablets Aloe Vera Belladonna Colocynth Scammony", gitColor(context), "constipation laxative");
    addItem ("Natrilix SR 1.5 tab", "Indapamide 1.5 mg", "natrilix sr indapamide indamide natridurin natristazen diurex hypotense 1.5mg 2.5mg tablets", cvsColor(context), "edema hypertension diuretics");
    addItem ("Natural Colon Aid tab", "Natural Herbs +Lactobacillus Acidophilus", "natural colon aid tablets Psyllium husk Bentonite Citrus Pectin cellulose Lactobacillus Acidophilus Wheat Grass Buckthorn bark Goldenseal root Gentian root Black Walnut leaf Orange peel", gitColor(context), "Irritable bowel syndrome IBS Spastic Colon Diverticular Disease Lactose Intolerance Mucous Colitis Anal Fissures Hemorrhoids Rectal Surgery Abnormal Motility Distention and Bloating");
    addItem ("Nausilex amp", "Alizapride 50 mg /2 ml", "nausilex Alizapride 50mg/2ml ampoule", gitColor(context), "nausea Vomiting antiemetic agents");
    addItem ("Naviluca cap", "Fluconazole 200 mg", "naviluca fluconazole actriazole 200mg capsules", abColor(context), "Oropharyngeal candidiasis Esophageal Candidiasis Cryptococcal Meningitis Vaginal Candidiasis Candida UTI Peritonitis fungal infections");
    addItem ("Navoproxin supp", "Meclizine 50 mg", "navoproxin meclizine 50mg suppositories", gitColor(context), "nausea vomiting Vertigo antiemetic agents");
    addItem ("Navoproxin plus tab", "Meclizine +Vit B6", "navoproxin plus meclizine 25mg pyridoxine vitamin b6 50mg dizirest emezine ezadoxine meclodoxine navidoxine postadoxine restine vomidoxine tablets", gitColor(context), "Motion Sickness Vertigo antiemetic agents");
    addItem ("Nebido amp", "Testosterone Undecanoate 1000 mg /4 ml", "nebido Testosterone Undecanoate decafortis 1000mg/4ml vial ampoule", hormoneColor(context), "Testosterone replacement therapy for male hypogonadism androgens");
    addItem ("Nebraglob drops", "Iron +Vit C +Folic Acid +Vit B12", "nebraglob iron vitamin C folic acid B9 B12 lokaglobin drops", vitColor(context), "iron deficiency anemia supplementation");
    addItem ("Neo-Bronchophane syrup", "Diphenhydramine +Guaifenesin +Oxeladin", "neo-bronchophane neobronchophane Diphenhydramine Guaifenesin Oxeladin syrup", resColor(context), "Cough common cold influenza");
    addItem ("Neo Minophylline syrup", "Theophylline +Guaifenesin", "neo minophylline syrup neominophylline Theophylline Guaifenesin tribroxol", resColor(context), "Productive Cough bronchial asthma bronchospasm chronic bronchitis expectorant");
    addItem ("Neocarbon cap", "Charcoal +Anise +Peppermint", "marneys neocarbon capsules activated charcoal Aniseed peppermint", gitColor(context), "flatulence gas retention");
    addItem ("Neomaint solution", "Glucose +NaCl +KCl", "Neomaint glucose dextrose nacl kcl sodium chloride potassium chloride iv solution", cvsColor(context), "dehydration");
    addItem ("Neomycin tab", "Neomycin 500 mg", "neomycin 500mg tablets", abColor(context), "bowel preparation Pre-Op Intestinal Antisepsis Hepatic Encephalopathy Diarrhea Caused by Enteropathogenic E.coli aminoglycosides");
    addItem ("Neopression 1 tab", "Brexpiprazole 1 mg", "Neopression Brexpiprazole clavita pharma 1mg 2mg 4mg tablets", cnsColor(context), "Schizophrenia Depression major depressive disorder antidepressants Agitation Associated With Alzheimer Dementia Serotonin-Dopamine Activity Modulators SDAM");
    addItem ("Neostigmine amp", "Neostigmine 0.5 mg /ml", "Neostigmine amostigmine epistigmin 0.5mg/ml ampoule", cnsColor(context), "Myasthenia Gravis Diagnosis Nondepolarizing Neuromuscular Blockade, Reversal Post-Op Distention or Urinary Retention Acetylcholinesterase Inhibitor");
    addItem ("Neostigmine tab", "Neostigmine 15 mg", "Neostigmine amostigmine 15mg tablets", cnsColor(context), "Myasthenia Gravis Acetylcholinesterase Inhibitor");
    addItem ("Netlook 10 cap", "Isotretinoin 10 mg", "netlook isotretinoin roaccutane roaccutrex 10mg capsules", otherColor(context), "severe acne vulgaris");
    addItem ("Netlook 20 cap", "Isotretinoin 20 mg", "netlook isotretinoin roaccutane roaccutrex iso-acnetin isoacnetin 20mg capsules", otherColor(context), "severe acne vulgaris");
    addItem ("Netlook 40 cap", "Isotretinoin 40 mg", "netlook isotretinoin roaccutrex 40mg capsules", otherColor(context), "severe acne vulgaris");
    addItem ("Neupogen prefilled syringe", "Filgrastim 300 mcg (30 mIU) /0.5 ml", "Neupogen Filgrastim accofil nivestim zarzio 300mcg 30miu/0.5ml prefilled syringe", otherColor(context), "myelosuppressive chemotherapy treatment induction of consolidation chemotherapy patients with cancer undergoing bone marrow transplantation autologous peripheral blood progenitor cell collection and therapy severe chronic neutropenia severe neutropenia caused by myelosuppressive anticancer drugs acute radiation syndrome");
    addItem ("Neurazine 25 tab", "Chlorpromazine 25 mg", "neurazine chlorpromazine promacid 25mg 100mg tablets", cnsColor(context), "behavioral disorders hyperactivity nausea vomiting preoperative apprehension schizophrenia antipsychotics disorders intractable hiccups acute intermittent porphyria");
    addItem ("Neurazine amp", "Chlorpromazine 50 mg /2 ml", "neurazine chlorpromazine 50mg/2ml ampoule", cnsColor(context), "behavioral disorders hyperactivity nausea vomiting preoperative apprehension schizophrenia antipsychotics disorders intraoperative sedation acute intermittent porphyria migraine headache");
    addItem ("Neuril amp", "Diazepam 10 mg /2 ml", "neuril valium diazepam epival valpam 10mg/2ml ampoule", cnsColor(context), "Status Epilepticus Convulsions Neonatal Tetanus Anxiety Preoperative Sedation Endoscopy Muscle Spasm Benzodiazepines");
    addItem ("Neuril 2 tab", "Diazepam 2 mg", "neuril diazepam valpam 2mg tablets", cnsColor(context), "Anxiety Muscle Spasm Seizure Disorder Alcohol Withdrawal Benzodiazepines");
    addItem ("Neuril 5 tab", "Diazepam 5 mg", "neuril diazepam valpam farcozepam valinil 5mg tablets", cnsColor(context), "Anxiety Muscle Spasm Seizure Disorder Alcohol Withdrawal Benzodiazepines");
    addItem ("Neurimax amp", "Vit B1 +Vit B2 +Vit B6 +Vit B12", "Neurimax ampoule thiamine riboflavin pyridoxine cobalamin vitamin b1 vitamin b2 vitamin b6 vitamin b12", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Neuroton tab", "Vit B1 +Vit B2 +Vit B6 +Vit B12 +Folic Acid", "neuroton thiamine riboflavin pyridoxine cyanocobalamin vitamin b1 vitamin b2 vitamin b6 vitamin b12 folic acid vitamin b9 pentaviton theraneurin tablets", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Neurovit amp", "Vit B1 +Vit B6 +Vit B12", "Neurovit neuroton vita3 vita-3 trivarol trivitacid tri-vitacid trib tri-b emicaneurin poly-b-bion neurorubine neurobion tetraviton thiamine pyridoxine cobalamin vitamin b1 vitamin b6 vitamin b12 ampoule", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Neurovit tab", "Vit B1 +Vit B6 +Vit B12", "Neurovit adwinerve plus medvitazen neurobion neurorubine forte thiamine pyridoxine cobalamin vitamin b1 vitamin b6 vitamin b12 tablets capsules", vitColor(context), "polyneuritis Neuralgia polyneuropathy");
    addItem ("Nevilob 5 tab", "Nebivolol 5 mg", "nevilob nebivolol mavilor modulol nebasco nebicard nebilet nebimoun nepvol symbian 5mg tablets", cvsColor(context), "hypertension Beta-1 selective blockers class II 2 antiarrhythmic agents");
    addItem ("Nevilob Plus tab", "Nebivolol +Hydrochlorothiazide", "Nevilob Plus nebivolol Hydrochlorothiazide nebasco nebilet plus tablets", cvsColor(context), "hypertension Beta-1 selective blockers thiazides Diuretics class II 2 antiarrhythmic agents");
    addItem ("Nexa Tic sach", "Lactobacillus +Bifidobacterium + Inulin +Zinc", "nexatic Lactobacillus acidophilus Bifidobacterium longum inulin zinc probiotic sachets", gitColor(context), "Irritable bowel syndrome ibs ulcerative colitis intestinal dysbiosis helps regulate and maintain the balance of the intestinal flora infantile colic gastroenteritis antibiotic associated diarrhea immunity associated disorders");
    addItem ("Nexium 20 tab", "Esomeprazole 20 mg", "nexium esomeprazole atmiprazole biorazo esmatac esmopump esmorap esoprotocol eso-protocol esomelodan esopiroxan ezogast nexicure neximerican orgixium protopan stomapral 20mg tablets capsules", gitColor(context), "GERD gastroesophageal reflux disease Erosive Esophagitis Gastric Ulcer Hypersecretory Conditions zollinger ellison syndrome Heartburn Proton Pump Inhibitors PPIs");
    addItem ("Nexium 40 tab", "Esomeprazole 40 mg", "nexium aig esomeprazole atmiprazole biorazo esmatac esmopump esmorap esoprotocol eso-protocol esogerdazole esomelodan esomepex esomium esopiroxan ezogast klemazice mepradep nexicure neximash neximerican nixprazole orgixium protopan stomapral 40mg tablets capsules", gitColor(context), "GERD Erosive Esophagitis Gastric Ulcer Hypersecretory Conditions zollinger ellison syndrome Heartburn Proton Pump Inhibitors PPIs");
    addItem ("Nexium sach", "Esomeprazole 10 mg", "nexium Esomeprazole esmorap 10mg 40mg sachets", gitColor(context), "GERD Erosive Esophagitis Gastric Ulcer Hypersecretory Conditions zollinger ellison syndrome Heartburn Proton Pump Inhibitors PPIs");
    addItem ("Nexium vial", "Esomeprazole 40 mg", "nexium esomeprazole esmorap esomelodan esomepex megaprazole merazodel  zomegipral 40mg vial", gitColor(context), "gastroesophageal reflux disease GERD With Erosive Esophagitis Gastric or Duodenal Ulcers Following Therapeutic Endoscopy Proton Pump Inhibitors PPIs");
    addItem ("Nimotop tab", "Nimodipine 30 mg", "nimotop nimodipine futanorm 30mg tablets capsules", cvsColor(context), "Subarachnoid Hemorrhage calcium channel blockers CCBs");
    addItem ("Nitroderm TTS 5 patches", "Nitroglycerin 5 mg /24 hours", "nitroderm tts Nitroglycerin deponit nt glyceryl trinitrate 5mg/24hours 10mg/24hours transdermal patches", cvsColor(context), "angina pectoris prophylaxis nitrates");
    addItem ("Nitromak retard 2.5 cap", "Nitroglycerin 2.5 mg", "nitromak retard nitroglycerin glyceryl trinitrate cardiocare coronalax nitrocare nitrotard 2.5mg 5mg 6.5mg 9mg capsules", cvsColor(context), "angina pectoris prophylaxis nitrates");
    addItem ("Nitronal vial", "Nitroglycerin 1 mg /ml", "nitronal nitroglycerin glyceryl trinitrate 1mg/ml vial", cvsColor(context), "angina pectoris nitrates");
    addItem ("Nizatect 150 cap", "Nizatidine 150 mg", "nizatect nizatidine nizatine axin ulcfree 150mg capsules", gitColor(context), "Peptic Ulcer GERD gastroesophageal reflux disease Histamine H2-receptor antagonists blockers");
    addItem ("Nizatect 300 cap", "Nizatidine 300 mg", "nizatect nizatidine nizatine receptoloc 300mg capsules", gitColor(context), "Peptic Ulcer GERD gastroesophageal reflux disease Histamine H2-receptor antagonists blockers");
    addItem ("No Deprine tab", "Tofisopam 50 mg", "nodeprine tofisopam 50mg tablets", cnsColor(context), "Anxiety depression antidepressants perimenopausal symptoms Benzodiazepines");
    addItem ("Noerosive syrup", "Ranitidine 75 mg /5 ml", "Noerosive Ranitidine ranitarigo ranticare ulrantaz vartidochemic 75mg/5ml syrup", gitColor(context), "Peptic Ulcer Erosive Esophagitis GERD gastroesophageal reflux disease Histamine H2-receptor antagonists blockers");
    addItem ("Nono Water syrup", "Caraway Oil +Dill Oil +Na Bicarbonate", "Nonowater caraway dill oil sodium bicarbonate free baby calma king syrup", gitColor(context), "flatulence Colic");
    addItem ("Nopain amp", "Nefopam 20 mg /ml", "nopain nefopam acupan nefopam 20mg/ml ampoule", cnsColor(context), "Analgesia Acute Pain postoperative pain");
    addItem ("Norflex amp", "Orphenadrin 30 mg /ml", "norflex orphenadrin 30mg/ml ampoule", analgesicColor(context), "musculoskeletal muscle spasm pain analgesics leg cramp relaxant");
    addItem ("Norflex tab", "Orphenadrin 100 mg", "norflex orphenadrin 100mg tablets", analgesicColor(context), "musculoskeletal muscle spasm pain analgesics leg cramp relaxant");
    addItem ("Norgesic tab", "Orphenadrin 35 mg +Paracetamol 450 mg", "norgesic orphenadrin paracetamol acetaminophen Orphamol orphenadrine-plus tablets", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Norvasc 5 tab", "Amlodipine 5 mg", "norvasc amlodipine alkapress amilo amvasc coronavine myodura nortens regcor vasonorm vasopine viscal windipine cardiovasc dipotensive pinavasc 5mg 10mg tablets", cvsColor(context), "Hypertension angina pectoris Calcium Channel Blockers CCBs");
    addItem ("Notussil syrup", "Cloperastine 20 mg /5 ml", "Notussil Cloperastine sedatuss 20mg/5ml syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Novomix flexpen/penfills", "Insulin Aspart Protamine +Insulin Aspart", "insulin novomix penfills flexpen Insulin aspart Protamine", hormoneColor(context), "type1 type2 diabetes mellitus rapid-acting insulins");
    addItem ("Novonorm 0.5 tab", "Repaglinide 0.5 mg", "Novonorm Repaglinide diarol gluconorm repaglid repandin rosemond 0.5mg 1mg 2mg tablets", hormoneColor(context), "type2 diabetes mellitus Meglitinides Derivatives");
    addItem ("Novorapid flexpen/penfills", "Insulin Aspart 100 units/ml", "Novorapid insulin novorapid Insulin aspart 100units/ml flexpen penfills", hormoneColor(context), "type1 type2 diabetes mellitus rapid-acting insulins");
    addItem ("Nucleobuvir Velpa tab", "Sofosbuvir 400 mg +Velpatasvir 100 mg", "Nucleobuvir Velpa tablets Sofosbuvir Velpatasvir sovelpak", abColor(context), "chronic hepatitis C virus infections hcv");
    addItem ("Nulivia sach", "Fructo-oligosaccharide 3 gm", "Nulivia Fructo-oligosaccharide 3gm sachets", vitColor(context), "immunity enhancer constipation ibs allergic reactions");

    addItem ("Octatron cap", "Zinc +Selenium +Molybdenum +Vit B7 +Mixed Bioflavonoids +Vit E +Vit A +Vit C", "octatron capsules Zinc Selenium Molybdenum vitamin b7 biotin Mixed Bioflavonoids vitamin e tocopherol vitamin a vitamin c ascorbic acid", vitColor(context), "multiVitamins minerals deficiency Supplementation");
    addItem ("Octomotol tab", "Bumadizone 110 mg", "octomotol bumadizone 110mg tablets", analgesicColor(context), "pain analgesics rheumatoid osteoarthritis dysmenorrhea inflammations");
    addItem ("Octovent Plus syrup", "Guaifenesin 50 mg +Salbutamol 2 mg /5 ml", "Octovent Plus Guaifenesin Salbutamol albuterol bronchovent syrup", resColor(context), "Productive Cough bronchospasm expectorant bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Ocuguard cap", "Ginkgo Biloba +Selenium +Vit A +Vit B12 +Vit C +Vit E +Nicotinamide +Zinc", "Ocuguard capsules Ginkgo Biloba Selenium vitamin a Beta carotene vitamin b12 cyanocobalamin vitamin c ascorbic acid vitamin e Tocopherol Nicotinamide vitamin b3 Zinc gluconate", vitColor(context), "Diabetic Retinopathy mild dementia Neuroprotection");
    addItem ("Omecod syrup", "Cod Liver Oil +Vit A +Vit D3 +Vit E", "omecod syrup cod liver oil omega3 vitamin a vitamin d3 vitamin e tocopherol", vitColor(context), "immunity memory enhancer");
    addItem ("Omega-3 Plus cap", "Omega-3 Fish Oil +Wheat Germ Oil", "omega3 omega-3 plus fish oil wheat germ oil capsules", vitColor(context), "Hyper-lipoproteinaemia Rheumatoid Arthritis");
    addItem ("Omega Rx gummies", "Omega 3 +Vit C +Vit D", "omega-3 omega3 rx gummies fish oil vitamin c ascorbic acid vitamin d dha-epa", vitColor(context), "atherosclerosis immunity memory enhancer");
    addItem ("Omegaddox syrup", "Omega3 Fish Oil +Vit A +Vit B1 +Vit B2 +Vit B3 +Vit B5 +Vit B6 +Vit B7 +Vit C +Vit D3 +Vit E +Iodine +Selenium +Zinc", "omegaddox Omega3 fish Oil Multivitamins a b1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin b5 pantothenic acid b6 pyridoxine b7 biotin c ascorbic acid d3 e tocopherol Iodine Selenium Zinc omegalox omegalox syrup liquid", vitColor(context), "immunity memory enhancer");
    addItem ("Omegaseef cap", "Fish Oil +Flax Seed Oil +Borage Oil +Vit E", "omegaseef capsules Fish Oil omega3 Flax Seed Oil Borage Oil vitamin e tocopherol", vitColor(context), "immunity memory enhancer");
    addItem ("Omez 10 cap", "Omeprazole 10 mg", "omez omeprazole estohalt fastcure healsec losec omepak risek 10mg capsules tablets", gitColor(context), "Erosive Esophagitis Duodenal GERD gastroesophageal reflux disease Erosive Esophagitis peptic Gastric Ulcer Hypersecretory Conditions zollinger ellison syndrome Helicobacter Pylori Infection Proton Pump Inhibitors PPIs");
    addItem ("Omez 20 cap", "Omeprazole 20 mg", "omez omeprazole epirazole fastcure gasec gastrazole healsec losec omepak risek hyposec midagasec napizole omegastazole omepral omisec pepzol ulstop 20mg capsules", gitColor(context), "Erosive Esophagitis Duodenal GERD Erosive Esophagitis peptic Gastric Ulcer Hypersecretory Conditions zollinger ellison syndrome Helicobacter Pylori Infection Proton Pump Inhibitors PPIs");
    addItem ("Omez 40 cap", "Omeprazole 40 mg", "omez omeprazole estohalt fastcure gastroloc healsec losec napizole omepak risek pepzol 40mg capsules", gitColor(context), "Erosive Esophagitis Duodenal GERD gastroesophageal reflux disease Erosive Esophagitis peptic Gastric Ulcer Hypersecretory Conditions zollinger ellison syndrome Helicobacter Pylori Infection Proton Pump Inhibitors PPIs");
    addItem ("Omez vial", "Omeprazole 40 mg", "omez omeprazole losec napizole risek 40mg vial", gitColor(context), "NSAID-associated gastric peptic duodenal ulcer treatment prevention Helicobacter pylori infection reflux esophagitis Hypersecretory Conditions zollinger ellison syndrome GERD gastroesophageal reflux disease Proton Pump Inhibitors PPIs");
    addItem ("Omnitrope 5mg/ 1.5ml cartridge", "Somatropin 5 mg / 1.5 ml", "omnitrope Somatropin norditropin nordilet 5mg/1.5ml cartridges prefilled pen", hormoneColor(context), "growth hormone deficiency idiopathic short stature associated with turner syndrome growth failure with prader-willi syndrome noonan syndrome small for gestational age");
    addItem ("Omnitrope 10mg/ 1.5ml cartridge", "Somatropin 10 mg / 1.5 ml", "omnitrope Somatropin 10mg/1.5ml cartridges", hormoneColor(context), "growth hormone deficiency idiopathic short stature associated with turner syndrome growth failure with prader-willi syndrome noonan syndrome small for gestational age");
    addItem ("Ondalenz 4 odf", "Ondansetron 4 mg", "Ondalenz ondansetron danofran emerest 4mg odf tablets", gitColor(context), "nausea Vomiting Rosacea Cholestatic Pruritus Spinal Opioid-Induced Pruritus uremic pruritus Selective 5-HT3 Antagonists antiemetic agents");
    addItem ("Ondalenz 8 odf", "Ondansetron 8 mg", "Ondalenz ondansetron zofran danofran 8mg odf tablets", gitColor(context), "nausea Vomiting Rosacea Cholestatic Pruritus Spinal Opioid-Induced Pruritus uremic pruritus Selective 5-HT3 Antagonists antiemetic agents");
    addItem ("One alpha drops", "Alfacalcidol 2 mcg /1 ml", "Onealpha Alfacalcidol alfacareno alfabonid taminorig 2mcg/ml drops", vitColor(context), "vitamin d deficiency");
    addItem ("One alpha 0.25 cap", "Alfacalcidol 0.25 mcg", "Onealpha alfacalcidol bon-one calcidol bone care 0.25mcg tablets capsules", vitColor(context), "Osteoporosis Hypoparathyrodism");
    addItem ("One alpha 0.5 cap", "Alfacalcidol 0.5 mcg", "Onealpha alfacalcidol bon-one bone care 0.5mcg tablets capsules", vitColor(context), "Osteoporosis Hypoparathyrodism");
    addItem ("One alpha 1 mcg cap", "Alfacalcidol 1 mcg", "Onealpha alfacalcidol bon-one calcidol bone care 1mcg tablets capsules", vitColor(context), "Osteoporosis Hypoparathyrodism");
    addItem ("One Two Three syrup", "Chlorpheniramine +Pseudoephedrine +Paracetamol", "one two three 123 Chlorpheniramine Pseudoephedrine Paracetamol acetaminophen fever n flu neo-michaelon neomichaleon babyrhino noflu flumol rhinocalm rhinomol-s vegaskine syrup suspension", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Oplex-N syrup", "Oxomemazine +Guaifenesin +Sodium benzoate", "oplex-n Oxomemazine Guaifenesin Sodium benzoate broncoxil-n coughrest-n syrup", resColor(context), "Cough");
    addItem ("Optaminess tab", "Amino Acids", "Optaminess tablets amino acids L-Histidine L-isoleucine L-Leucine L-Lysine acetate L-Methionine L-Phenylalanine L-Threonine L-Tryptophan L-Tyrosine L-Valine", otherColor(context), "Dietary supplement used to support the diet of hemodialysis patients with the essential amino acids");
    addItem ("Oracal tab", "Calcium Carbonate 1250 mg (500 mg elemental calcium)", "oracal Calcium carbonate 1250mg bone-cal bonecal calster calciprex tablets", vitColor(context), "calcium deficiency supplementation hypocalcemia");
    addItem ("Orazone syrup", "Dexamethasone 0.5 mg /5 ml", "Orazone Dexamethasone 0.5mg/5ml syrup", strdColor(context), "Croup inflammation airway edema Corticosteroids");
    addItem ("Orazone tab", "Dexamethasone 0.5 mg", "Orazone Dexamethasone dexazone 0.5mg tablets", strdColor(context), "inflammation allergy allergic conditions Corticosteroids");
    addItem ("Orly cap", "Orlistat 120 mg", "orly chemitrijulie cutdown easyslim fatlose finshape hygi-rexal hygirexal ligofat organo-orlistat orlismart orlistyle quick-slim quickslim regimax slim safe staticap xenical capsules", gitColor(context), "obesity management");
    addItem ("Ornidaz tab", "Ornidazole 500 mg", "ornidazole astranida ornivoda tibezole 500mg tablets", abColor(context), "Amebiasis amebic dysentery Giardiasis Trichomoniasis Anaerobic Infection");
    addItem ("Osipect syrup", "Glyceryl Guaiacolate +K Citrate +Terbutaline +Diphenhydramine", "osipect syrup Glyceryl Guaiacolate K Potassium Citrate Terbutaline sulphate Diphenhydramine hcl", resColor(context), "bronchospasm asthma cough common cold bronchitis");
    addItem ("Ospen susp", "Penecillin V 250 mg (400000 iu) /5 ml", "Ospen Phenoxymethyl Penicillin v 250mg 400000iu/5ml suspension", abColor(context), "Pneumococcal systemic Pneumococcal infections Prophylaxis Streptococcal Pharyngitis Rheumatic Fever Penicillins");
    addItem ("Ossilor-D drops", "Vit D3 400 iu /0.5 ml", "Ossilor-D cholecalciferol vitamin d3 three drops 400iu/0.5ml drops", vitColor(context), "vitamin d deficiency osteoporosis rickets");
    addItem ("Ossofortin 10000 iu tab", "Vit D 10000 iu", "ossofortin original ergocalciferol Breva D3 d.dep liposom-d3 sanso vitamin d3 d2 cholecalciferol davalindi 0.25mg 10000iu tablets", vitColor(context), "Vitamin D-resistant rickets deficiency osteoporosis familial hypophosphatemia");
    addItem ("Ossofortin 50000 iu tab", "Vit D 50000 iu", "ossofortin ergocalciferol breva vitamin d2 d3 cholecalciferol 1.25mg 50000iu tablets", vitColor(context), "Vitamin D-resistant rickets vitamin deficiency osteoporosis familial hypophosphatemia");
    addItem ("Ossofortin Original D3 tab", "Vit D 5000 iu", "ossofortin original vitamin d2 d3 ergocalciferol d.dep cholecalciferol davalindi 0.125mg 5000iu tablets", vitColor(context), "Vitamin D-resistant rickets deficiency osteoporosis familial hypophosphatemia");
    addItem ("Ost-map cap", "Acemetacin  60 mg", "ost-map acemetacin ostmap stada 60mg capsules", analgesicColor(context), "osteoarthritis rheumatoid arthritis anti-inflammation analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Osteo tab", "Raloxifene 60 mg", "osteo raloxifene debista evista 60mg tablets", otherColor(context), "Osteoporosis in Post-menopausal Women Breast Cancer Selective Estrogen Receptor Modulators SERM");
    addItem ("Osteocare syrup", "Calcium +Magnesium +Zinc +Vit D", "Osteocare Calcium Magnesium Zinc caldin zinc vitamin d ostocal syrup", vitColor(context), "Calcium deficiency supplementation hypocalcemia");
    addItem ("Osteocare tab", "Calcium +Magnesium +Zinc +Vit D", "Osteocare inCalcium Magnesium Zinc vitamin d alfa-cal alfacal plus calciprime oster shell pharocal plus r.b.cal tablets", vitColor(context), "Calcium deficiency supplementation hypocalcemia");
    addItem ("Oxifree cap", "Zinc +Selenium +Molybdenum +Vit C +Vit E +Vit A +Proanthocyanidin +Bioflavonoid +Omega 3 +Thioctic Acid", "oxifree capsules Zinc Selenium Molybdenum vitamin C ascorbic acid tocopherol vitamin e vitamin a Proanthocyanidin Bioflavonoid omega3 Thioctic Acid", vitColor(context), "multiVitamins minerals deficiency Supplementation antioxidant immunity memory enhancer improve body function");
    addItem ("Ozempic prefilled pen", "Semaglutide", "ozempic semaglutide prefilled pen", hormoneColor(context), "type2 diabetes mellitus weight management Glucagon-Like Peptide-1 GLP-1 Receptor Agonist");

    addItem ("P.T.B tab", "Pyrazinamide 500 mg", "p.t.b pyrazinamide ptb pyrazide 500mg tablets", abColor(context), "Tuberculosis tb treatment Antitubercular Agents");
    addItem ("Paediment solution", "Glucose +NaCl +KCl +Ca Gluconate", "paediment glucose dextrose nacl kcl sodium chloride potassium chloride calcium gluconate iv solution", cvsColor(context), "dehydration");
    addItem ("Pan-Amin G solution", "Amino Acids", "Pan-Amin D-Sorbitol L-Arginine HCl L-Histidine HCl H2O L-Isoleucine L-Leucine L-Lysine HCl L-Methionine L-Phenylalanine L-Threonine L-Tryptophan L-Valine Glycine Aminoacetic acids panaming iv solution", otherColor(context), "intravenous malnutrition hypoproteinemia disorders of the gastrointestinal tract infections inadequate intake or refusal to eat");
    addItem ("Panadol Acute Head Cold tab", "Brompheniramine 2 mg +Pseudoephedrine 30 mg +Paracetamol 500 mg", "Panadol Acute Head Cold Paracetamol brompheniramine Pseudoephedrine acetaminophen comtrex tablets", resColor(context), "Common cold Nasal congestion rhinitis decongestants");
    addItem ("Panadol Advance tab", "Paracetamol 500 mg", "panadol advance Paracetamol acetaminophen abimol augicetamide pyral paramol cetal febrimol stopadol paragesic 500mg tablets sachets", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Panadol Cold&Flu Day tab", "Paracetamol 500 mg +Caffeine 25 mg +Phenylephrine 5 mg", "Panadol Cold&and Flu Day tablets Paracetamol acetaminophen 500mg caffeine 25mg phenylephrine 5mg", resColor(context), "fever pain analgesics antipyretics Nasal congestion sinus congestion cold flu decongestants");
    addItem ("Panadol Extra tab", "Paracetamol 500 mg +Caffeine 65 mg", "panadol Paracetamol acetaminophen 500mg caffeine 65mg abimol bienadol cefacet cetal jencafemol pronto plus pyral stopadol vetocetamol gescamoli extra capsules tablets", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Panadol Joint tab", "Paracetamol 665 mg", "panadol joint Paracetamol acetaminophen 665mg tablets", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Panadol Migrain tab", "Paracetamol 250 mg +Acetylsalicylic Acid 250 mg +Caffeine 65 mg", "panadol migrain Paracetamol acetaminophen 250mg Acetylsalicylic Acid 250mg Caffeine 65mg aspicure-combi cefacet plus excedrin markedel tablets capsules", analgesicColor(context), "fever pain analgesics antipyretics migrain headache");
    addItem ("Panax Life cap", "Ginseng 25 mg +Ginkgo Biloba 180 mg", "panax life capsules Ginseng 25mg Ginkgo ginko Biloba 180mg", otherColor(context), "Cerebrovascular insufficiency Psychobehavioural and mood disturbances Tinnitus dizziness migraine Peripheral vascular disease Improving Physical and Mental Efficiency");
    addItem ("Pansol solution", "Glucose +NaCl +KCl +Na Lactate", "Pansol glucose dextrose nacl kcl sodium chloride potassium chloride sodium lactate iv solution", cvsColor(context), "dehydration");
    addItem ("Pantogar cap", "Ca Pantothenate +Keratin +L-Cystine +Para-Aminobenzoic Acid +Vit B1 +Yeast", "pantogar capsules vitamin B5 calcium pantothenate keratin l-cystine para aminobenzoic acid paba Para aminobenzoic acid vitamin b10 vitamin B1 thiamine yeast for hair and nails crown hair capsules", vitColor(context), "diffuse hair loss damage");
    addItem ("Paramol supp", "Paracetamol 125 mg", "Paramol Paracetamol paralex acetaminophen 125mg suppositories", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Paramol syrup", "Paracetamol 120 mg /5 ml", "Paramol Paracetamol acetaminophen paragesic baby cetal 120mg/5ml syrup", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Parkicapone tab", "Entacapone 200 mg", "parkicapone entacapone comtapone 200mg tablets", cnsColor(context), "parkinsonism parkinson's disease");
    addItem ("Parkintreat tab", "Rasagiline 1 mg", "parkintreat rasagiline dopaminect rasanopark 1mg tablets", cnsColor(context), "parkinsonism parkinson's disease");
    addItem ("Parofen tab", "Ibuprofen 400 mg +Paracetamol 500 mg", "parofen ibuprofen paracetamol acetaminophen mepabrufen tablets", analgesicColor(context), "antipyretics fever analgesics pain");
    addItem ("Paroxetine 20 tab", "Paroxetine 20 mg", "paroxetine depanx paxetin seroxat xandol 20mg tablets", cnsColor(context), "depression antidepressants obsessive compulsive panic social phobia generalized anxiety posttraumatic stress disorder stuttering vasovagal syncope diabetic neuropathy Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Paroxetine CR 12.5 tab", "Paroxetine 12.5 mg", "paroxetine cr paroxedep seroxat paroxedur seroxat 12.5mg 25mg 37.5mg tablets", cnsColor(context), "depression panic antidepressants social phobia premenstrual dysphoric disorder menopausal vasomotor symptoms Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Pectipro syrup", "Benproperine 15 mg /5 ml", "Pectipro Benproperine tussiglobe 15mg/5ml syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Pedialyte drink", "Electrolytes +Minerals", "pedialyte ors electrolytes minerals Dextrose citric acid potassium citrate sodium chloride sodium citrate, zinc gluconate flexolyte alexolyte drink", gitColor(context), "diarrhea fluid loss rehydration dehydration");
    addItem ("Pencitard vial", "Benzathine penicillin G", "Pencitard Benzathine long acting penicillin G depopen depo-pen benzabiotic durapen hayabenz lastipen retarpen penicid la 1.2million iu vial", abColor(context), "Rheumatic fever Prophylaxis Group A streptococcal infections Syphilis Yaw Bejel Pinta Penicillins");
    addItem ("Pentacold syrup", "Paracetamol +Chlorpheniramine +Dextromethorphan +Phenylephrine", "pentacold syrup Paracetamol acetaminophen Chlorpheniramine Dextromethorphan Phenylephrine", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Pental tab", "Pentoxifylline 400 mg", "pental pentoxifylline normobral pexal rebcoflex trental vasocare vasotal 400mg tablets", cvsColor(context), "intermittent claudication");
    addItem ("Pentamix syrup", "Guava leaves +Tilia leaves +Thyme leaves +Fennel +Eucalyptus", "Pentamix syrup Guava Tilia leaves Thyme leaves Fennel Eucalyptus", resColor(context), "Cough");
    addItem ("Pepon cap", "Pumpkin Seed Oil 300 mg", "pepon master pumpkin seed oil optyprost ronkin 300mg capsules", urinaryColor(context), "improve prostate performance prostatitis benign prostatic hyperplasia bph");
    addItem ("Pepon Plus cap", "Pumpkin Seed Oil +Saw Palmetto Oil +Zinc", "pepon plus capsules pumpkin seed oil saw palmetto oil zinc", urinaryColor(context), "relieve prostate complaints prostatitis benign prostatic hyperplasia bph");
    addItem ("Peptifix chew tab", "Famotidine +Ca Carbonate +Mg Hydroxide", "peptifix famotidine calcium carbonate magnesium hydroxide famoplus famo-plus famtocal-m famotocalm jeparilon plfamtin triacinorm chewable tablets", gitColor(context), "Heart Burn Indigestion");
    addItem ("Perfalgan vial", "Paracetamol 1 gm /100 ml", "Perfalgan Paracetamol injectmol acetaminophen acetalgan eupifalgan medalgesic gesicrest novectamol paracetagen pentamol pyritrust raziphemol rotapyretic targecetal vedraphenal 1000mg 1gm/100ml vial", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Perfectil Original tab", "Vitamins +Minerals", "perfectil original tablets Multivitamins d c ascorbic acid e tocopherol b1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin b6 pyridoxine folic acid b9 b12 cobalamin biotin b7 pantothenic acid b5 magnesium iron zinc copper cu manganese selenium chromium iodine l-cysteine beta carotene a Grape Seed Extract proanthocyanidins", vitColor(context), "vitamin minerals deficiency supplementation");
    addItem ("Pethidine amp", "Pethidine 50 mg /ml", "pethidine meperidine 50mg/ml ampoule", cnsColor(context), "Pain opioids analgesics");
    addItem ("Petro tab", "Caffeine +Drotaverine +Paracetamol", "petro tablets caffeine drotaverine paracetamol acetaminophen", gitColor(context), "Colic spasm pain analgesics dysmenorrhea");
    addItem ("Phara ferro 27 tab", "Multivitamins +Minerals", "pharaferro 27 tablets iron zinc copper molybdenum Multivitamins B1 thiamine b2 riboflavin b3 Nicotinic Acid nicotinamide niacin b5 pantothenic acid b6 pyridoxine b7 biotin b8 inositol b9 folic acid B12 cobalamin c ascorbic acid E tocopherol beta carotene a", vitColor(context), "multiVitamins minerals iron deficiency Supplementation anemia");
    addItem ("Pharmaton Kiddi syrup", "Lysine +Vit B1 +Vit B2 +Vit B6 +Vit D3 +Vit E +Nicotinamide +Dexpanthenol +Calcium", "pharmaton kiddi syrup lysine hcl vitamin B1 thiamine vitamin B2 riboflavin vitamin B6 pyridoxine vitamin d3 vitamin E tocopherol Nicotinic Acid nicotinamide niacin vitamin b3 dexpanthenol calcium", vitColor(context), "multiVitamins minerals deficiency supplementation");
    addItem ("Phenytin amp", "Phenytoin 250 mg /5 ml", "phenytin phenytoin epilog phentolept epanutin 250mg/5ml 100mg/2ml ampoule", cnsColor(context), "Status Epilepticus Tonic-Clonic and Complex Partial Seizures convulsions epilepsy anticonvulsants");
    addItem ("Phenytin 50 cap", "Phenytoin 50 mg", "phenytin phenytoin ipanten pharotoin 50mg capsules", cnsColor(context), "seizures epilepsy convulsions Anticonvulsants");
    addItem ("Phenytin 100 cap", "Phenytoin 100 mg", "phenytin phenytoin ipanten epanutin 100mg capsules", cnsColor(context), "seizures epilepsy convulsions Anticonvulsants");
    addItem ("Phenytin susp", "Phenytoin 30 mg /5 ml", "phenytin phenytoin ipanten 30mg/5ml suspension", cnsColor(context), "seizures epilepsy convulsions Anticonvulsants");
    addItem ("Philozac 10 cap", "Fluoxetine 10 mg", "philozac fluoxetine alzac fluozac 10mg capsules", cnsColor(context), "major depressive antidepressants obsessive-compulsive bulimia nervosa panic premenstrual dysphoric disorder fibromyalgia migraine hot flashes caused by hormonal chemotherapy raynaud phenomenon Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Philozac 20 cap", "Fluoxetine 20 mg", "philozac fluoxetine depreban elevamood florosin flutin octozac prozac 20mg capsules", cnsColor(context), "major depressive antidepressants obsessive-compulsive bulimia nervosa panic premenstrual dysphoric disorder fibromyalgia migraine hot flashes caused by hormonal chemotherapy raynaud phenomenon Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Photericin B vial", "Amphotericin B 50 mg", "conventional amphotericin b 50mg vial", abColor(context), "Systemic antiFungals Infection");
    addItem ("Piascledine cap", "Avocado Oil +Soya Bean Oil", "Piascledine avocado soya bean oil asutec avocapi avoscaldine avosoya capsules", analgesicColor(context), "Osteoarthritis");
    addItem ("Picolax drops", "Sodium Picosulphate 7.5 mg /ml", "picolax sodium picosulphate picosulfate normalax laxeol-p17 bowelocare 0.75% 7.5mg/ml drops", gitColor(context), "Constipation stimulant laxative");
    addItem ("Pirafene amp", "Chlorpheniramine 5 mg /ml", "pirafene chlorpheniramine chlorophenalex 5mg/ml ampoule", resColor(context), "anaphylactic allergic rhinitis allergy acute urticaria Reactions Angioneurotic Edema 1st first generation antihistamines");
    addItem ("Pirfenex tab", "Pirfenidone 200 mg", "Pirfenex Pirfenidone esbriet perdofenex 200mg 267mg tablets capsules", otherColor(context), "Idiopathic Pulmonary Fibrosis");
    addItem ("PK-Merz tab", "Amantadine 100 mg", "pk-merz amantadine pkmerz adamine amantine infex viraflu 100mg tablets capsules", abColor(context), "parkinson's disease parkinsonism drug-induced extrapyramidal symptoms influenza a prophylaxis treatment Dopamine Agonists");
    addItem ("Plavicard tab", "Clopidogrel 75 mg", "plavicard clopidogrel angosmooth blotagril borgavix clatex clopexagrel fibrogrel idiavix itolavix myogrel oncyclopid orgistrok otathromb platenor plavedamol plavictonal plavix sigagrel sigmagrel stroka thrombo vexidogrel 75mg tablets", cvsColor(context), "acute coronary syndrome unstable angina nstemi recent myocardial infarction mi stroke established peripheral arterial disease coronary artery disease cardioembolic stroke carotid artery stenting antiplatelets");
    addItem ("Plendil 2.5 tab", "Felodipine 2.5 mg", "plendil felodipine feloblock plentopine healthplend 2.5mg 10mg tablets", cvsColor(context), "hypertension Calcium Channel Blockers CCBs");
    addItem ("Pletaal 100 tab", "Cilostazol 100 mg", "pletaal cilostazol pletal cilobiogen cilomepatal cilosort cilostalon claudicat claudizol claudol coaguless infarca movigretal sedotazole sercprove stazola stazotrend 100mg tablets", cvsColor(context), "intermittent claudication thrombotic complications of coronary angioplasty antiplatelets");
    addItem ("Podacef susp", "Cefpodoxime 100 mg /5 ml", "Podacef Cefpodoxime maxispect 100mg/5ml suspension", abColor(context), "Bronchitis Acute maxillary sinusitis Pharyngitis tonsillitis Pneumonia UTI urinary tract Skin Infections Gonorrhea 3rd third generation cephalosporins");
    addItem ("Podacef 100 tab", "Cefpodoxime 100 mg", "Podacef Cefpodoxime orelox cefoprox 100mg tablets", abColor(context), "Bronchitis Acute maxillary sinusitis Pharyngitis tonsillitis Pneumonia UTI urinary tract Skin Infections Gonorrhea 3rd third generation cephalosporins");
    addItem ("Podacef 200 tab", "Cefpodoxime 200 mg", "Podacef Cefpodoxime cefoprox cefporesp spectrodoxime 200mg tablets", abColor(context), "Bronchitis Acute maxillary sinusitis Pharyngitis tonsillitis Pneumonia UTI urinary tract Skin Infections Gonorrhea 3rd third generation cephalosporins");
    addItem ("Pono cap", "Mefenamic acid 250 mg", "pono mefenamic acid mefentan 250mg capsules", analgesicColor(context), "Acute Pain analgesics Primary Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Pono forte cap", "Mefenamic acid 500 mg", "ponoforte mefenamic acid ponstan farostan mafepain mefenam mefonil ponagic forte 500mg capsules tablets", analgesicColor(context), "Acute Pain analgesics Primary Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Potassium Chloride 15% amp", "Potassium Chloride 15 %", "potassium chloride kcl 15% ampoule", vitColor(context), "severe hypokalemia potassium deficiency");
    addItem ("Potassium M syrup", "Potassium Chloride 165 mg /5 ml", "potassium chloride m kcl 165mg/5ml syrup", vitColor(context), "hypokalemia potassium deficiency");
    addItem ("Power Caps cap", "Ibuprofen 300 mg +Pseudoephedrine 45 mg", "powercaps capsules Ibuprofen Pseudoephedrine", resColor(context), "Common Cold Nasal congestion decongestants");
    addItem ("Power Cold & Flu tab", "Paracetamol 500 mg +Pseudoephedrine 30 mg +Caffeine 30 mg +Chlorpheniramin 3 mg", "power cold and& flu Paracetamol acetaminophen Pseudoephedrine Caffeine Chlorpheniramin coldact coldex-2 flucutn flustop nova-c-n tablets capsules", resColor(context), "Common Cold Nasal congestion allergic rhinitis decongestants");
    addItem ("Powerecta 10 tab", "Vardenafil 10 mg", "powerecta vardenafil erecanova farorecta levitra rectivard romantigra rowadinafil solvetra turbo vitra vardapex vardarict vardection vigafil vardenorect vardirose varnova verdenodep vivanza westrecta 10mg 20mg tablets", urinaryColor(context), "erectile dysfunction benign prostatic hyperplasia bph pulmonary arterial hypertension Phosphodiesterase-5 Enzyme Inhibitor");
    addItem ("Pradaxa cap", "Dabigatran", "Pradaxa Dabigatran dabiserve inhistrok okandab 75mg 110mg 150mg capsules", cvsColor(context), "Stroke Prophylaxis With Atrial Fibrillation deep vein thrombosis DVT pulmonary embolism PE vte venous thromboembolism anticoagulants");
    addItem ("Praxilene tab", "Naftidrofuryl Oxalate 200 mg", "praxilene naftidrofuryl oxalate cerebromap duranftat furyxel gevarcut naftidur 200mg tablets capsules", cvsColor(context), "Peripheral vascular disorders intermittent claudication night cramps rest pain incipient gangrene trophic ulcers Raynaud's Syndrome diabetic arteriopathy acrocyanosis");
    addItem ("Precedex vial", "Dexmedetomidine 200 mcg /2 ml", "Precedex Dexmedetomidine 200mcg/2ml vial", cnsColor(context), "ICU Procedural Sedation");
    addItem ("Pregavalex 50 cap", "Pregabalin 50 mg", "pregavalex pregabalin andogablin averopreg balinozar convugabalin curapergix depapalin dragonor forpregab gablovac gabsolox globazure glonervya hexgabalin irenypathic kemirica lycrobalin lyribalin lyrica lyrineur lyrolin myafibrol nervagab nervatin nervatyca neuragabalin normolepsy olykraz painica pregabedium pregadurff pregatrend pregavalex pregdin-apex pregdinapex pregesican prenervanex roviaprega queenlept serigabtin snapgab vronogabic 50mg 75mg 100mg 150mg 300mg capsules", cnsColor(context), "partial onset seizures fibromyalgia diabetic peripheral neuropathic pain with spinal cord injury postherpetic neuralgia epilepsy convulsions anticonvulsants");
    addItem ("Prianil 400 CR tab", "Lithium Carbonate 400 mg", "prianil lithium carbonate 400mg cr tablets", cnsColor(context), "bipolar disorder");
    addItem ("Primalan syrup", "Mequitazine 2.5 mg /5 ml", "primalan mequitazine meki ah meki a-h 2.5mg/5ml syrup", resColor(context), "Allergic rhinitis allergy urticaria conjunctivitis");
    addItem ("Primalan tab", "Mequitazine 5 mg", "primalan mequitazine 5mg tablets", resColor(context), "Allergic rhinitis allergy urticaria conjunctivitis");
    addItem ("Primacor amp", "Milrinone 10 mg /10 ml", "Primacor Milrinone 10mg/10ml ampoule", cvsColor(context), "Congestive Heart Failure Low Cardiac Output Septic Shock Phosphodiesterase Enzyme Inhibitors inotropic agents");
    addItem ("Primomycin susp", "Erythromycin 200 mg +Trimethoprim 50 mg /5 ml", "Primomycin Erythromycin 200mg Trimethoprim 50mg erythroprim suspension", abColor(context), "bacterial infections");
    addItem ("Primox 7.5 tab", "Moexipril 7.5 mg", "primox moexipril minotensol 7.5mg 15mg tablets", cvsColor(context), "hypertension ace Angiotensin-converting enzyme inhibitors");
    addItem ("Primafoxin 1 gm vial", "Cefoxitin 1 gm", "primafoxin cefoxitin orfixitin plucefox 1000mg 1gm vial", abColor(context), "infections surgery prophylaxis gas gangrene 2nd second generation cephalosporins");
    addItem ("Primaquine 2.5 tab", "Primaquine 2.5 mg", "primaquine 2.5mg 7.5mg 15mg 30mg tablets", abColor(context), "malaria");
    addItem ("Primrose Plus cap", "Evening Primrose Oil +Vit E", "evening primrose plus oil vitamin e alpha tocopherol capsules", vitColor(context), "premenstrual syndrome mastalgia rheumatoid arthritis atopic dermatitis");
    addItem ("Prinorelax 15 ER cap", "Cyclobenzaprine 15 mg", "prinorelax cyclobenzaprine 15mg 30mg er capsules", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Probric syrup", "Bambuterol 5 mg /5 ml", "Probric Bambuterol bambedil 5mg/5ml syrup", resColor(context), "Bronchospasm bronchial asthma long-acting Beta2 Agonists");
    addItem ("Probric 10 tab", "Bambuterol 10 mg", "Probric Bambuterol bambedil asthmec bambec lelafree noctorelief 10mg tablets", resColor(context), "Bronchospasm bronchial asthma long-acting Beta2 Agonists");
    addItem ("Probric 20 tab", "Bambuterol 20 mg", "Probric Bambuterol asthmec bambec lelafree terventin 20mg tablets", resColor(context), "Bronchospasm bronchial asthma long-acting Beta2 Agonists");
    addItem ("Procoralan 5 tab", "Ivabradine 5 mg", "procoralan ivabradine angiobradine bradipect napibradine savapran 7.5mg tablets", cvsColor(context), "Heart Failure");
    addItem ("Prolia prefilled syringe", "Denosumab 60 mg /ml", "Prolia denosumab 60mg/ml prefilled syringe", otherColor(context), "Osteoporosis Aromatase Inhibitor Induced Bone Loss Androgen Deprivation Induced Bone Loss Glucocorticoid Induced Osteoporosis monoclonal antibodies");
    addItem ("Prolutex vial", "Progesterone 25 mg / ml", "prolutex progesterone lutone 25mg/ml vial ampoule", hormoneColor(context), "Maintenance of pregnancy in art");
    addItem ("Progest 100 cap", "Progesterone 100 mg", "progesterone cyclotrone hystrogest utrocare 100mg 200mg capsules", hormoneColor(context), "secondary amenorrhea Prevention of endometrial hyperplasia prevention");
    addItem ("Prograf 0.5 cap", "Tacrolimus 0.5 mg", "prograf tacrolimus adport 0.5mg 1mg 5mg capsules", otherColor(context), "heart liver kidney lung transplantation immunosuppressive agents");
    addItem ("Prontogest amp", "Progesterone 100 mg /2 ml", "prontogest progesterone progesing 100mg/2ml ampoule", hormoneColor(context), "Dysfunctional uterine bleeding Maintenance of pregnancy");
    addItem ("Prontogest vag pessaries", "Progesterone 200 or 400 mg", "prontogest progesterone cyclogest endometrin 200 400mg vaginal pessaries suppositories tablet", hormoneColor(context), "Recurrent miscarriage surgery during pregnancy premenstrual syndrome Puerperal depression antidepressants");
    addItem ("Proscar tab", "Finasteride 5 mg", "proscar finasteride finastura fincar mixosteride prostat prostec prostride royalsteride 5mg tablets", urinaryColor(context), "benign prostatic hyperplasia bph female hirsutism 5 Alpha-Reductase Inhibitor");
    addItem ("Prostetrol 10 MR tab", "Alfuzosin 10 mg", "prostetrol aig alfuzosin benprostex xatral 10mg mr xl tablets capsules", urinaryColor(context), "benign prostatic hyperplasia bph alpha1 blockers");
    addItem ("Protam vial", "Protamine Sulphate 10 mg /ml", "protamine sulphate 10mg/ml vial", otherColor(context), "Heparine antidotes neutralization dalteparin tinzaparin enoxaparin overdose");
    addItem ("Prothiaden 25 cap", "Dosulepin 25 mg", "Prothiaden Dosulepin dothiepin 25mg capsules", cnsColor(context), "Depressive illness with anxiety tricyclic antidepressants");
    addItem ("Prothiaden 75 tab", "Dosulepin 75 mg", "Prothiaden Dosulepin dothiepin 75mg tablets", cnsColor(context), "Depressive illness with anxiety tricyclic antidepressants");
    addItem ("Protozole tab", "Tinidazole 500 mg", "Protozole tinidazole fasigyn 500mg tablets", abColor(context), "Intestinal amebiasis Amebic Liver Abscess Giardiasis Trichomoniasis Bacterial Vaginosis Nitroimidazoles");
    addItem ("Provera tab", "Medroxyprogesterone 5 mg", "provera medroxyprogesterone 5mg tablets", hormoneColor(context), "Secondary Amenorrhea Abnormal Uterine Bleeding Endometrial Hyperplasia Reduction");
    addItem ("Proviron tab", "Mestrolone 25 mg", "proviron mestrolone cidoviron hormo-6 hormo6 provimest 25mg tablets", hormoneColor(context), "declining physical activity and mental alertness potency disturbance hypogonadism infertility oligozoospermia androgens");
    addItem ("Proximol tab", "Halphabarol 0.4 mg", "proximol halphabarol 0.4mg tablets", urinaryColor(context), "urinary calculi urolithiasis stones tract stones renal colic");
    addItem ("Proximol Compound eff granules", "Hexamine +Piperazine +Proximadiol", "proximol compound effervescent granules Hexamine Piperazine Proximadiol", urinaryColor(context), "urinary calculi urolithiasis stones tract stones crystalluria uti tract infection");
    addItem ("Prucasoft 1 tab", "Prucalopride 1 mg", "prucasoft prucalopride constipride resolor 1mg tablets", gitColor(context), "Chronic Idiopathic constipation laxative prokinetic agents");
    addItem ("Prucasoft 2 tab", "Prucalopride 2 mg", "prucasoft prucalopride conistova constipride resolor 2mg tablets", gitColor(context), "Chronic Idiopathic constipation laxative prokinetic agents");
    addItem ("Pulmicort 0.25 nebulizer solution", "Budesonide 0.25 mg /ml", "pulmicort budesonide budexan 0.250mcg mg/ml nebulizer solution", resColor(context), "bronchial asthma croup corticosteroids");
    addItem ("Pulmicort 0.5 nebulizer solution", "Budesonide 0.5 mg /ml", "pulmicort budesonide budelizer budexan 0.500mcg mg/ml nebulizer solution", resColor(context), "bronchial asthma croup corticosteroids");
    addItem ("Pulmicort 100 turbuhaler", "Budesonide 100 mcg /dose", "pulmicort budesonide 100mcg/dose turbuhaler", resColor(context), "bronchial asthma maintenance corticosteroids");
    addItem ("Pulmicort 200 turbuhaler", "Budesonide 200 mcg /dose", "pulmicort pulmicort budecort 200mcg/dose turbuhaler", resColor(context), "bronchial asthma maintenance corticosteroids");
    addItem ("Purgaton tab", "Calcium Sennoside 20 mg", "purgaton Calcium Sennoside 20mg sennalax senna-lax tablets", gitColor(context), "constipation stimulant laxative");
    addItem ("Pyral supp", "Paracetamol 250 mg", "Pyral Paracetamol acetaminophen 250mg suppositories", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Pystinon tab", "Pyridostigmine 60 mg", "Pystinon Pyridostigmine Mestinon pyriclonerve 60mg tablets", cnsColor(context), "myasthenia gravis pretreatment for soman nerve gas exposure Acetylcholinesterase Inhibitors");

    addItem ("Questran sach", "Cholestyramine 4 gm", "questran cholestyramine cholestran quantamash 4gm sachets", cvsColor(context), "hyperlipidemia");
    addItem ("Quibron T/SR tab", "Theophylline 300 mg", "quibron t/sr theophylline minophylline theofar uniphyllin continus 300mg tablets capsules", resColor(context), "acute Bronchospasm bronchial asthma");
    addItem ("Quinabiotic tab", "Gemifloxacin 320 mg", "Quinabiotic gemifloxacin anthzon factive floxguard furfact gemiloxes gemionce gemique gemoxacin genkystar weptonal 320mg tablets", abColor(context), "Acute Exacerbation of Chronic Bronchitis Pneumonia fluoroquinolones");

    addItem ("Rabicid 10 tab", "Rabeprazole 10 mg", "rabicid rabeprazole burnaway pariet rabezole ulcerostate 10mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Duodenal Ulcer Hypersecretory Conditions zollinger ellison syndromeHelicobacter Pylori Proton Pump Inhibitors PPIs");
    addItem ("Rabicid 20 tab", "Rabeprazole 20 mg", "rabicid rabeprazole bepro hygigastin idizole pacredo pariet rabezole rabegerdazole rabeprakyrl rabgerd 20mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Duodenal Ulcer Hypersecretory Conditions zollinger ellison syndromeHelicobacter Pylori Proton Pump Inhibitors PPIs");
    addItem ("Ramipril 1.25 cap", "Ramipril 1.25 mg", "ramipril bigastus corpril ramacein ramipress rampecardin tritace protect ramitac rampitensive recardopril right-ace rightace 1.25mg 2.5mg 10mg capsules tablets", cvsColor(context), "hypertension heart failure post-myocardial infarction prevention stroke prevention diabetic nephropathy ace Angiotensin-converting enzyme inhibitors");
    addItem ("Ramixole 0.25 tab", "Pramipexole 0.25 mg", "ramixole pramipexole doparoxen kinsoram sifrol sobopexole 0.25mg 1mg tablets", cnsColor(context), "Parkinson's Disease parkinsonism Restless Legs Syndrome Dopamine Agonists");
    addItem ("Ranexa 500 tab", "Ranolazine 500 mg", "ranexa ranolazine 500mg tablets", cvsColor(context), "chronic angina pectoris");
    addItem ("Rebif 44 prefilled syringe", "Interferon Beta-1a 44 mcg/ 0.5 ml", "Rebif interferon beta-1a 44mcg/0.5ml prefilled syringes", otherColor(context), "multiple sclerosis");
    addItem ("Rectoplexil supp", "Oxomemazine +Guaifenesin +Sodium benzoate +Paracetamol", "Rectoplexil Oxomemazine Guaifenesin Sodium benzoate Paracetamol acetaminophen oplex-n plus suppositories", resColor(context), "Productive cough expectorant");
    addItem ("Rehydro Zinc Sach", "ORS", "rehydro zinc ors oral rehydration solution lohydran rehydran glucohydran hydro-safe hydrosafe babylyte nacl kcl glucose na citrate sodium potassium chloride citrate sachets", gitColor(context), "diarrhea fluid loss rehydration dehydration");
    addItem ("Relax cap", "Chlorzoxazone 250 mg +Paracetamol 300 mg", "Relax chlorzoxazone 250mg paracetamol acetaminophen 300mg myolgin myoflex myolax parafon relaxiged relaxon capsules tablets", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant");
    addItem ("Relaxine tab", "Thiocolchicoside 4 mg", "Relaxine Thiocolchicoside 4mg tablets", analgesicColor(context), "musculoskeletal muscle Pain analgesics spasm relaxant Painful muscle contractions");
    addItem ("Remeron tab", "Mirtazapine 30 mg", "Remeron mirtazapine aprimertaz mirtadepine mirtimash mirtofutal ramizipine rapizapine soltab zapimert 30mg tablets", cnsColor(context), "depression post-traumatic stress disorders hot flashes insomnia antidepressants");
    addItem ("Remicade vial", "Infliximab 100 mg", "remicade infliximab 100mg vial", otherColor(context), "crohn disease ulcerative colitis rheumatoid arthritis psoriatic arthritis plaque psoriasis ankylosing spondylitis Tumor Necrosis Factor TNF Blockers");
    addItem ("Renagel tab", "Sevelamer 800 mg", "renagel sevelamer reguphose renavelamer 800mg tablets", otherColor(context), "Serum Phosphorus Regulation");
    addItem ("Renal-S sach", "Hexamine +Khellin +Piperazine", "renal-s sachets hexamine khellin piperazine coli-urinal coliurinal jedcorene uricol sachets", urinaryColor(context), "Urinary spasm urinary stones Urolithiasis");
    addItem ("Reparil tab", "Aescin 40 mg", "reparil aescin 40mg tablets", otherColor(context), "Varicose Haemorrhoids Thrombophlebitis Inflammations Oedema");
    addItem ("Resinokaten powder", "Sodium Polystyrene Sulfonate 454 gm", "resinokaten sodium na polystyrene sulfonate 454gm powder", vitColor(context), "hyperkalemia lithium overdose");
    addItem ("Respipect syrup", "Guaiacol 1 mg +Pholcodine 6.55 mg /5 ml", "Respipect Guaiacol Pholcodine coughpent syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Rheuxicam 4 tab", "Lornoxicam 4 mg", "Rheuxicam lornoxicam toprano xefo zeficam 4mg tablets", analgesicColor(context), "rheumatoid osteoarthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Rheuxicam 8 tab", "Lornoxicam 8 mg", "Rheuxicam lornoxicam eduropan loranovil lorgeque lornicam noxilorn royanoxicam toprano xefo rapid zeficam 8mg tablets", analgesicColor(context), "rheumatoid osteoarthritis analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Rheuxicam vial", "Lornoxicam 8 mg /2 ml", "Rheuxicam lornoxicam xefo zeficam 8mg/2ml vial", analgesicColor(context), "analgesics pain Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Rhinopro cap", "Carbinoxamine 4 mg +Phenylephrine 20 mg", "Rhinopro sr capsules phenylephrine Carbinoxamine", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Rhinopro syrup", "Pseudoephedrine 540 mg +Carbinoxamine 24 mg /90 ml", "Rhinopro syrup Pseudoephedrine Carbinoxamine", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Rhinostop drops", "Pseudoephedrine 25 mg +Carbinoxamine 2 mg /ml", "rhinostop drops Pseudoephedrine Carbinoxamine", resColor(context), "Common cold influenza Nasal congestion decongestants");
    addItem ("Rhinotus syrup", "Pseudoephedrine 540 mg +Carbinoxamine 24 mg +Dextromethorphan 90 mg /90 ml", "Rhinotus syrup Pseudoephedrine Carbinoxamine dextromethorphan", resColor(context), "Common cold influenza Nasal congestion cough decongestants");
    addItem ("Ribavirin 200 cap", "Ribavirin 200 mg", "Ribavirin hepatovirin hepaverin panvirin ribavarin ribazole ribovinal viracure virokan 200mg 400mg capsules", abColor(context), "Chronic Hepatitis C virus infection antiviral agents");
    addItem ("Ribavirin syrup", "Ribavirin 200 mg /5 ml", "Ribavirin 200mg/5ml syrup", abColor(context), "Chronic Hepatitis C virus infection antiviral agents");
    addItem ("Rimactane cap", "Rifampicin 300 mg", "Rimactane Rifampicin rifampin rifabiotic rifactine 300mg capsules", abColor(context), "Tuberculosis tb Neisseria Meningitidis Carrier Leprosy Prophylaxis of contacts of patients with Haemophilus influenzae type B infection Antitubercular Agents");
    addItem ("Rimactane syrup", "Rifampicin 100 mg /5 ml (2%)", "Rimactane Rifampicin rifampin rifactine rifamox 2% 100mg/5ml syrup", abColor(context), "Tuberculosis tb Neisseria Meningitidis Carrier Leprosy Prophylaxis of contacts of patients with Haemophilus influenzae type B infection Antitubercular Agents");
    addItem ("Ringer's solution", "NaCl +KCl +CaCl", "Ringer's nacl kcl CaCl sodium chloride potassium chloride calcium chloride ringers iv solution", cvsColor(context), "Replace extracellular fluid losses Restore the sodium, potassium, calcium and chloride balances, for treatment of isotonic dehydration");
    addItem ("Ritalin tab", "Methylphenidate 10 mg", "Ritalin Methylphenidate 10mg tablets", cnsColor(context), "adhd attention-deficit/hyperactivity disorder narcolepsy CNS Stimulant");
    addItem ("Rivarospire tab", "Rivaroxaban", "rivarospire rivaroxaban andorivaban xanoxiban xarelto eliproxaban orgoroxaban repatoxaban rivaxarelt thromboxiban varoxaban vaxato tablets", cvsColor(context), "deep vein thrombosis dvt pulmonary embolism nonvalvular atrial fibrillation factor Xa inhibitor anticoagulants");
    addItem ("Rogitamine amp", "Phentolamine 10 mg /ml", "rogitamine phentolamine rogitine 10mg/ml ampoule", cvsColor(context), "Pheochromocytoma diagnosis extravasation hypertensive crisis alpha1 blockers");
    addItem ("Rotahelex Advance drops", "Ivy leaf +Thyme +Liquorice", "rotahelex advance drops Ivy leaf leaves extract thyme Liquorice", resColor(context), "Productive Cough mucolytics");
    addItem ("Rotahelex drops", "Ivy leaf extract 21.5 mg /5 ml", "rotahelex Ivy leaf leaves extract 21.5mg/5ml drops", resColor(context), "Productive Cough mucolytics");
    addItem ("Rotahelex syrup", "Ivy leaf extract 35 mg /5 ml", "rotahelex forte Ivy leaf leaves extract ivypront ivyrospan kifpan hipan kafinol biorelixit peopospan sinuc spanomep advohelix hedraledox ivybronch ivypaxal ivyntol monohexal sansobronchi sputal 35mg/5ml syrup", resColor(context), "Productive Cough mucolytics");
    addItem ("Rotahelex tab", "Ivy leaf extract 25 mg", "rotahelex Ivy leaf leaves extract 25mg tablets", resColor(context), "Productive Cough mucolytics");
    addItem ("Rowachol cap", "Pinene +Borneol +Camphene +Cineole +Menthol +Menthone", "rowachol capsules Pinene Borneol Camphene Cineole Menthol Menthone bilichol", gitColor(context), "gallstones dissolution prevention primary biliary cirrhosis");
    addItem ("Royal Jelly cap", "Royal Jelly 1000 mg", "beejaxin montel marnys pure montana now royal jelly 1000mg 1gm capsules", vitColor(context), "fatigue asthenia loss of concentration premature aging erectile dysfunction weakness exhaustion tiredness improving physical and mental efficiency");
    addItem ("Royal Vit G cap", "Ginseng +Royal Jelly +Vitamins +Minerals", "royal vit g capsules ginseng royal jelly Oimethylaminoethanol bitartrate paba Para aminobenzoic acid pollen iron calcium Multivitamins a B1 thiamine B2 riboflavin b3 Nicotinic Acid nicotinamide niacin B6 pyridoxine b7 biotin b12 cobalamin d E tocopherol calcium Pantothenate Soya Lecithin Phosphorus copper cu potassium manganese L-Lysine zinc folic acid b9", vitColor(context), "fatigue asthenia loss of concentration premature aging erectile dysfunction weakness exhaustion tiredness improving physical and mental efficiency");
    addItem ("Ruta-C tab", "Rutin 60 mg +Vit C 160 mg", "ruta-c tablets rutin vitamin c ascorbic acid rutin-c rutalex-c", vitColor(context), "Increased capillary fragility permeability decreased capillary resistance");
    addItem ("Rybelsus tab", "Semaglutide", "rybelsus semaglutide tablets", hormoneColor(context), "type2 diabetes mellitus Glucagon-Like Peptide-1 GLP-1 Receptor Agonist");
    addItem ("Rytmonorm tab", "Propafenone 150 mg", "rytmonorm propafenone 150mg tablets", cvsColor(context), "Ventricular Arrhythmias Paroxysmal Supraventricular Tachycardia Atrial Fibrillation Flutter");

    addItem ("Sacrofer amp", "Iron 100 mg", "sacrofer iron sucrose dextran ampofer euronemia interofer itoferrose ferosac cosmofer fercayl haemopower hydroferrin 100mg/5ml ampoule", vitColor(context), "iron deficiency anemia");
    addItem ("Salbovent tab", "Salbutamol 2 mg", "salbovent Salbutamol albuterol bronchovent farcolin vental ventene ventolin 2mg tablets", resColor(context), "Bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Salbovent forte cap", "Salbutamol 4 mg", "salbovent forte Salbutamol albuterol bronchal mepacovent octovent 4mg capsules", resColor(context), "Bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Salofalk tab", "Mesalazine 500 mg", "salofalk mesalazine mesalamines 5-asa 5-aminosalicylic acid atmosalazine imzacol marsalaz pentasa 500mg tablets capsules", otherColor(context), "ulcerative colitis proctitis crohn disease 5-Aminosalicylic Acid Derivatives");
    addItem ("Sandimmun Neoral 25 cap", "Cyclosporine 25 mg", "sandimmun neoral cyclosporine arpimune me abrammune anabrammune 25mg 50mg 100mg capsules", otherColor(context), "Solid organ transplantation rheumatoid arthritis psoriasis Immunosuppressive Agents");
    addItem ("Sandimmun Neoral syrup", "Cyclosporine 100 mg /ml", "sandimmun neoral cyclosporine abrammune 100mg/ml syrup", otherColor(context), "Solid organ transplantation rheumatoid arthritis psoriasis Immunosuppressive Agents");
    addItem ("Sandostatin amp", "Octreotide 0.1 mg / ml", "sandostatin octreotide bendatreotide octreostat 0.1mg/ml ampoule", hormoneColor(context), "Acromegaly Carcinoid Tumor VIPoma Esophageal Variceal Bleeding gastrointestinal fistula Pancreatic Fistula AIDS-Related Ileostomy-Related Chemotherapy-Related Diarrhea Dumping Syndrome Chylothorax GI Bleeding Hyperinsulinemia of infancy Hypoglycemia of Infancy");
    addItem ("Sanso-C 1 gm cap", "Vit C 1 gm", "Sanso-C ascorbic acid all one ascorbacil c-apex citrivol magic c munito c redox vitamin c reen-c 1000mg 1gm capsules tablets", vitColor(context), "vitamin c deficiency scurvy urinary acidification");
    addItem ("Sansoimune syrup", "Echinacea +Vit C +Zinc", "sansoimune syrup echinacea purpurea vitamin c ascorbic acid zinc", vitColor(context), "immunity enhancer");
    addItem ("Sansovit syrup", "Multivitamins", "Sansovit Multivitamins a B1 thiamine B2 riboflavin B6 pyridoxine c ascorbic acid d3 E tocopherol B3 Nicotinic Acid nicotinamide niacin dexpanthenol Calcium pantothenate pharovit alvital syrup", vitColor(context), "multivitamins deficiency Supplementation");
    addItem ("Sansovit Iron syrup", "Multivitamins +Iron", "Sansovit Multivitamins a B1 thiamine B2 riboflavin B6 pyridoxine c ascorbic acid d3 E tocopherol B3 Nicotinic Acid nicotinamide niacin dexpanthenol Calcium pantothenate ferrous gluconate pharovit with iron syrup", vitColor(context), "multiVitamins iron deficiency Supplementation anemia");
    addItem ("Saxenda prefilled pen", "Liraglutide 18 mg /3 ml", "saxenda liraglutide 18mg/3ml prefilled pen", hormoneColor(context), "obesity Glucagon-Like Peptide-1 GLP-1 Receptor Agonist");
    addItem ("Sayana prefilled syringe", "Medroxyprogesterone 104 mg / 0.65 ml", "Sayana Medroxyprogesterone 104mg/0.65ml prefilled syringe", hormoneColor(context), "Contraception Endometriosis-Associated Pain");
    addItem ("Schisolazine 2.5 tab", "Olanzapine 2.5 mg", "schisolazine olanzapine 2.5mg tablets", cnsColor(context), "agitation associated with schizophrenia and bipolar i mania bipolar depression antidepressants chemotherapy associated nausea vomiting stuttering antipsychotics");
    addItem ("Schistocide susp", "Praziquantel 600 mg /5 ml", "schistocide praziquantel 600mg/5ml suspension", abColor(context), "Schistosomiasis bilharziasis Clonorchiasis Opisthorchiasis Cysticercosis Tapeworms");
    addItem ("Seizolow drops", "Sodium Valproate 200 mg /ml", "seizolow valproic acid sodium valproate daviken depakine 200mg/ml drops", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Seizolow syrup", "Sodium Valproate 250 mg /5 ml", "seizolow valproic acid sodium valproate daviken depakine vedge mentavers xoplict 250mg/5ml syrup", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Selgon drops", "Pipazetate 40 mg /1 ml", "Selgon Pipazetate Pipazethate 40mg/ml drops", resColor(context), "Dry Cough antitussive");
    addItem ("Selgon supp", "Pipazetate 10 mg", "Selgon Pipazetate Pipazethate 10mg suppositories", resColor(context), "Dry Cough antitussive");
    addItem ("Selgon tab", "Pipazetate 20 mg", "Selgon tablets Pipazetate Pipazethate 20mg tablets", resColor(context), "Dry Cough antitussive");
    addItem ("Selokenzoc 25 tab", "Metoprolol Succinate 25 mg", "selokenzoc metoprolol succinate betaloc carditag xl low press 25mg 50mg 100mg 200mg tablets", cvsColor(context), "hypertension heart failure congestive heart failure angina Beta-1 selective blockers class II 2 antiarrhythmic agents");
    addItem ("Selona sach", "Vit A +Vit C +Vit E +Zinc +Mg +Selenium", "selona sachets vitamin a vitamin c ascorbic acid vitamin E tocopherol magnesium selenium zinc", vitColor(context), "Vitamins minerals deficiency supplementation");
    addItem ("Septazole tab", "Sulfamethoxazole 400 mg +Trimethoprim 80 mg", "septazole sulphamethoxazole Sulfamethoxazole 400mg Trimethoprim 80mg cotrimoxazole co-trimoxazole chemotrim coprimosept cotril sutrim bactrim 480mg tablets", abColor(context), "Acute otitis media UTI urinary tract infections Acute Exacerbation of Chronic bronchitis Community Acquired Pneumonia Shigellosis Traveller's Traveler's Diarrhea Skin infections due to Community Acquired MRSA Pneumocystis Carinii Pneumonia Acne Vulgaris Sulfonamides");
    addItem ("Septazole forte tab", "Sulfamethoxazole 800 mg +Trimethoprim 160 mg", "septazole forte sulphamethoxazole Sulfamethoxazole 800mg Trimethoprim 160mg cotrimoxazole co-trimoxazole chemotrim cotril septrin sutaprim ds bactrim sutrim forte 960mg tablets", abColor(context), "Acute otitis media UTI urinary tract infections Acute Exacerbation of Chronic bronchitis Community Acquired Pneumonia Shigellosis Traveller's Traveler's Diarrhea Skin infections due to Community Acquired MRSA Pneumocystis Carinii Pneumonia Acne Vulgaris Sulfonamides");
    addItem ("Septazole susp", "Sulfamethoxazole 200 mg +Trimethoprim 40 mg /5 ml", "septazole suspension sulphamethoxazole Sulfamethoxazole 200mg Trimethoprim 40mg cotrimoxazole co-trimoxazole chemotrim septrin sutrim bactrim suspension", abColor(context), "Acute otitis media UTI urinary tract infections Acute Exacerbation of Chronic bronchitis Community Acquired Pneumonia Shigellosis Traveller's Traveler's Diarrhea Skin infections due to Community Acquired MRSA Pneumocystis Carinii Pneumonia Acne Vulgaris Sulfonamides");
    addItem ("Seretide Diskus 50/100", "Salmeterol +Fluticasone", "seretide diskus salmeterol fluticasone seroflo 50/100", resColor(context), "bronchial asthma long-acting Beta2 Agonists corticosteroids");
    addItem ("Seretide Diskus 50/250", "Salmeterol +Fluticasone", "seretide diskus salmeterol fluticasone seroflo 50/250", resColor(context), "bronchial asthma copd chronic obstructive pulmonary disease long-acting Beta2 Agonists corticosteroids");
    addItem ("Seretide Diskus 50/500", "Salmeterol +Fluticasone", "seretide diskus salmeterol fluticasone seroflo 50/500", resColor(context), "bronchial asthma long-acting Beta2 Agonists corticosteroids");
    addItem ("Seretide Evohaler 25/50", "Salmeterol +Fluticasone", "Seretide salmeterol fluticasone 25/50 evohaler", resColor(context), "bronchial asthma long-acting Beta2 Agonists corticosteroids");
    addItem ("Seretide Evohaler 25/125", "Salmeterol +Fluticasone", "Seretide salmeterol fluticasone 25/125 Evohaler", resColor(context), "bronchial asthma long-acting Beta2 Agonists corticosteroids");
    addItem ("Serinomantine 7 ER cap", "Memantine 7 mg", "serinomantine memantine 7mg 14mg 28mg er capsules", cnsColor(context), "Alzheimer-Type Dementia");
    addItem ("Seroquel 25 tab", "Quetiapine 25 mg", "seroquel quetiapine keepquet psyquel quadel quitapex quitiadel spiraquet quedress 25mg 50mg 100mg 200mg tablets", cnsColor(context), "schizophrenia bipolar 1 disorder mania depressive episodes antidepressants alcohol dependence insomnia psychosis agitation related to alzheimer dementia antipsychotics");
    addItem ("Seroquel 50 XR tab", "Quetiapine 50 mg", "seroquel quetiapine quetiazic quitcool andequepine quitapex 150mg 200mg 300mg 400mg xr tablets", cnsColor(context), "schizophrenia bipolar 1 disorder mania depressive episodes major depressive disorder antidepressants antipsychotics");
    addItem ("Sertraline 25 tab", "Sertraline 25 mg", "sertraline seronorm 25mg tablets", cnsColor(context), "major depressive antidepressants obsessive compulsive panic posttraumatic stress social anxiety premenstrual dysphoric disorder pruritus Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Serpass 50 tab", "Sertraline 50 mg", "serpass sertraline agrelocit depr-stat deprstat lustral moodapex opiraline sertral seserine sirto 50mg 100mg tablets", cnsColor(context), "major depressive antidepressants obsessive compulsive panic posttraumatic stress social anxiety premenstrual dysphoric disorder pruritus Selective Serotonin Reuptake Inhibitors SSRIs");
    addItem ("Silipex cap", "Silymarin lecithin complex 202 mg", "silipex capsules Silymarin lecithin complex milk thistle extract 202mg capsules", gitColor(context), "Liver Tonic support supplementation");
    addItem ("Simedill syrup", "Simethicone 20 mg +Dill Oil 1 mg /1 ml", "simedill syrup simethicone dill oil", gitColor(context), "Colic Flatulence gas retention");
    addItem ("Simethicone drops", "Simethicone 20 mg /1 ml", "Simethicone 20mg/ml drops emulsion", gitColor(context), "flatulence gas retention colic");
    addItem ("Sina Dry syrup", "Grindelia +Pimpinella +Primula +Rosa +Thyme", "sinadry syrup Grindeliae pimpinellae primulae Rosae Thyme extract", resColor(context), "Dry Cough antitussive");
    addItem ("Sina Wet syrup", "Grindelia +Pimpinella +Primula +Quebracho +Thyme", "sinawet syrup Grindeliae pimpinellae primulae quebracho bark tincture Thyme extract", resColor(context), "Productive Cough mucolytics");
    addItem ("Sine up syrup", "Chlorpheniramin +Phenylephrine", "Sineup syrup Chlorpheniramine Phenylephrine", resColor(context), "Common cold influenza Nasal congestion allergic rhinitis decongestants");
    addItem ("Singulair 4 sach", "Montelukast 4 mg", "singulair montelukast asmakast clear air inletair lelipel montelair statukast westair 4mg sachets", resColor(context), "bronchial asthma prophylaxis exercise-induced bronchospasm seasonal perennial allergic rhinitis Leukotriene Receptor Antagonists");
    addItem ("Singulair 4 chew tab", "Montelukast 4 mg", "singulair montelukast clear air kokast montelair montelosab opikast sedokast 4mg chewable tablets", resColor(context), "bronchial asthma prophylaxis exercise-induced bronchospasm seasonal perennial allergic rhinitis Leukotriene Receptor Antagonists");
    addItem ("Singulair 5 chew tab", "Montelukast 5 mg", "singulair montelukast asmakast asmalair clear air delmonkast indulair lelipel montekal montelair montelosab Relikast singukast 5mg chewable tablets", resColor(context), "bronchial asthma prophylaxis exercise-induced bronchospasm seasonal perennial allergic rhinitis Leukotriene Receptor Antagonists");
    addItem ("Singulair 10 tab", "Montelukast 10 mg", "singulair montelukast asmakast asmalair clear air delmonkast indulair inletair kokast lelipel montearab montekal montelosab montelurama oprakast pirontaginist sedokast statukast 10mg tablets", resColor(context), "bronchial asthma prophylaxis exercise-induced bronchospasm seasonal perennial allergic rhinitis Leukotriene Receptor Antagonists");
    addItem ("Sinupret tab", "Elder Flowers +Gentian Root +Primrose Flowers +Vervain +Sorrel Herb", "sinupret tablets Elder Gentian Root Primrose Flowers Vervain Sorrel Herb", resColor(context), "sinusitis");
    addItem ("Sirdalud 2 tab", "Tizanidine 2 mg", "sirdalud tizanidine smr s.m.r myoldin rekan roysan tizyl 2mg 4mg tablets", cnsColor(context), "muscle spasticity Alpha2 Adrenergic Agonists");
    addItem ("Sleep-Aid 5 tab", "Zaleplon 5 mg", "sleep-aid sleepaid zaleplon siesta sleepback zalosed 5mg 10mg tablets capsules", cnsColor(context), "insomnia hypnotics");
    addItem ("Sleepez 1 tab", "Eszopiclone 1 mg", "sleepez eszopiclone night calm nestacoran magicpiclone noctiplone sleepoclone 1mg 2mg 3mg tablets", cnsColor(context), "insomnia hypnotics");
    addItem ("Sodium Bicarbonate 4.2% vial", "NaHCo3 4.2%", "Sodium Bicarbonate NaHCo3 4.2% vial", cvsColor(context), "Cardiac Arrest Hyperkalemia Metabolic Acidosis");
    addItem ("Sodium Bicarbonate 8.4% vial", "NaHCo3 8.4%", "Sodium Bicarbonate NaHCo3 8.4% vial", cvsColor(context), "Cardiac Arrest Hyperkalemia Metabolic Acidosis");
    addItem ("Sodium Chloride 0.9% solution", "NaCl 9 mg /ml", "Sodium Chloride nacl normal saline 0.9% iv solution", cvsColor(context), "isotonic extracellular dehydration sodium depletion");
    addItem ("Sofenacin 5 tab", "Solifenacin 5 mg", "sofenacin solifenacin impronacin nanofreq solitract tormeel urginafect vesicare slowurge 5mg 10mg tablets", urinaryColor(context), "overactive bladder Neurogenic Detrusor Overactivity Anticholinergic Agents");
    addItem ("Soliqua 100/33 prefilled pen", "Insulin Glargine +Lixisenatide", "soliqua Insulin Glargine Lixisenatide prefilled pen", hormoneColor(context), "type2 diabetes mellitus Glucagon-Like Peptide-1 GLP-1 Receptor Agonist long-acting insulins");
    addItem ("Solu-cortef vial", "Hydrocortisone 100 mg", "Solu-cortef Hydrocortisone solucortef 100mg vial", strdColor(context), "Inflammation Status asthmaticus Acute Adrenal Crisis Corticosteroids");
    addItem ("Solu-medrol 500 vial", "Methylprednisolone 500 mg", "Solu-medrol solumedrol globisolone methylprednisolone mylan 500mg vial", strdColor(context), "acute exacerbation of multiple sclerosis pneumocystis carinii jiroveci pneumonia in aids patients severe lupus nephritis inflammation Status asthmaticus Corticosteroids");
    addItem ("Solu-medrol 1 gm vial", "Methylprednisolone 1 gm", "Solu-medrol solumedrol globisolone methylprednisolone mylan 1000mg 1gm vial", strdColor(context), "acute exacerbation of multiple sclerosis pneumocystis carinii jiroveci pneumonia in aids patients severe lupus nephritis inflammation Status asthmaticus Corticosteroids");
    addItem ("Solvimyst syrup", "Acetylcysteine 100 mg /5 ml", "solvimyst acetylcysteine acesolv 100mg/5ml syrup", resColor(context), "productive cough mucolytics");
    addItem ("Somazina amp", "Citicoline 500 mg /4 ml", "somazina citicoline fortamind shancita 500mg/4ml ampoule", cnsColor(context), "recent head traumatism subacute cerebrovascular accidents");
    addItem ("Somazina drops", "Citicoline 100 mg /ml", "somazina citicoline cerebroprove fortamind shancita talantoline 100mg/ml drops", cnsColor(context), "cognitive sensory motor neuropsychological disorders subacute cerebrovascular accidents");
    addItem ("Sominaletta amp", "Phenobarbital 40 mg /ml", "sominaletta phenobarbital phenobarbitone 40mg/ml ampoule", cnsColor(context), "Status Epilepticus Seizures Preoperative Sedation Hyperbilirubinemia Hypnotics");
    addItem ("Sominaletta syrup", "Phenobarbital 15 mg /5 ml", "sominaletta phenobarbital phenobarbitone 15mg/5ml syrup", cnsColor(context), "Seizures Sedation Preoperative Sedation Hyperbilirubinemia Insomnia Hypnotics");
    addItem ("Sominaletta tab", "Phenobarbital 15 mg", "sominaletta phenobarbital phenobarbitone 15mg tablets", cnsColor(context), "Seizures Sedation Preoperative Sedation Insomnia Hypnotics");
    addItem ("SpasColon 50 tab", "Pinaverium Bromide 50 mg", "SpasColon royaverium spasmopinaver 50mg tablets", gitColor(context), "ibs irritable bowel syndrome colic biliary spasms Preparation of Endoscopy");
    addItem ("SpasColon 100 tab", "Pinaverium Bromide 100 mg", "SpasColon dicetel spasmopinaver 100mg tablets", gitColor(context), "ibs irritable bowel syndrome colic biliary spasms Preparation of Endoscopy");
    addItem ("Spasmo-Amrase tab", "Ox Bile +Pancreatin +Papain +Dimethicone +Mebeverine", "spasmo-amrase spasmoamrase ox bile pancreatin papain Dimethicone mebeverine tablets", gitColor(context), "maldigestion flatulence dyspepsia malabsorption");
    addItem ("Spasmo-digestin tab", "Dicyclomine +Papain +Sanzyme +Simethicone +Sodium Dehydrocholate", "spasmodigestin spasmo-digestin tablets Dicyclomine Papain Sanzyme Simethicone Sodium Dehydrocholate", gitColor(context), "Irritable Bowel Syndrome ibs Dyspepsia Spasm");
    addItem ("Spasmocin amp", "Hyoscine-N-butylebromide 20 mg /ml", "spasmocin Hyoscine-N-butylebromide butacid farcorelaxin hyosenil hyospasmol nuspasm nu-spasm sigmastinal buscopan 20mg/ml ampoule", gitColor(context), "Severe Colic acute spasm");
    addItem ("Spasmocin tab", "Hyoscine-N-butylebromide 10 mg", "spasmocin Hyoscine-N-butylebromide buscopan butacid nu-spasm nuspasm 10mg tablets", gitColor(context), "spasm Colic ibs irritable bowel syndrome");
    addItem ("Spasmocure amp", "Drotaverine 40 mg /2 ml", "spasmocure Drotaverine do-spa dospa 40mg/2ml ampoule", gitColor(context), "Colic spasms");
    addItem ("Spasmocure tab", "Drotaverine 60 mg", "spasmocure Drotaverine do-spa dospa 60mg tablets", gitColor(context), "Colic spasms");
    addItem ("Spasmofen amp", "Hyoscine 20 mg +Ketoprofen 100 mg /2 ml", "spasmofen fast free hyoscine ketoprofen ampoule", gitColor(context), "Severe colic");
    addItem ("Spasmomen tab", "Otilonium Bromide 40 mg", "spasmomen Otilonium Bromide spasmomin 40mg tablets", gitColor(context), "colic spasms");
    addItem ("Spasmopyralgin-M tab", "Camylofin +Dipyrone", "spasmopyralgin-m tablets camylofin dipyrone metamizole analgin", gitColor(context), "colic analgesics pain fever antipyretics dysmenorrhea");
    addItem ("Spasmorest syrup", "Dicyclomine 10 mg /5 ml", "spasmorest dicyclomine 2% 10mg/5ml syrup", gitColor(context), "Irritable Bowel Syndrome ibs Anticholinergic Agents");
    addItem ("Spasmorest 10 tab", "Dicyclomine 10 mg", "spasmorest dicyclomine 10mg tablets", gitColor(context), "Irritable Bowel Syndrome ibs Anticholinergic Agents");
    addItem ("Spasmorest 20 tab", "Dicyclomine 20 mg", "spasmorest dicyclomine 20mg tablets", gitColor(context), "Irritable Bowel Syndrome ibs Anticholinergic Agents");
    addItem ("Spasmorest amp", "Dicyclomine 10 mg /ml", "spasmorest dicyclomine 10mg/ml ampoule", gitColor(context), "Irritable Bowel Syndrome ibs Anticholinergic Agents");
    addItem ("Spasulance odf", "Simethicone 62.5 mg", "spasulance simethicone 62.5mg odf", gitColor(context), "Flatulence colic gas retention");
    addItem ("Sperience sach", "Lactoferrin +Zinc +Vit C +Iron +Folic Acid +Calcium +Vit B1 +Vit B6 +Vit B12", "sperience sachets Lactoferrin Zinc vitamin c ascorbic acid Iron Folic Acid vitamin b9 Calcium vitamin b1 thiamine vitamin b6 pyridoxine vitamin b12 cobalamin", vitColor(context), "Vitamins minerals iron deficiency supplementation anemia Hair Loss due to Lack Of Ferritin immunity enhancer");
    addItem ("Spinobac syrup", "Baclofen 5 mg /5 ml", "Spinobac baclofen 5mg/5ml syrup", cnsColor(context), "spasticity Skeletal Muscle Relaxant");
    addItem ("Spirex 1.5 tab", "Spiramycin 1.5 million iu", "spirex spiramycin aspram rovac rovamycin unispira 1.5million iu tablets", abColor(context), "urti lrti upper lower respiratory tract skin genital periodontal chlamydial meningococcal meningitis ent infections ear nose throat toxoplasmosis macrolides");
    addItem ("Spirex 3 tab", "Spiramycin 3 million iu", "spirex spiramycin rovac rovamycin rovapex unispira 3million iu", abColor(context), "urti lrti upper lower respiratory tract skin genital periodontal chlamydial meningococcal meningitis ent infections ear nose throat toxoplasmosis macrolides");
    addItem ("Spirex Plus tab", "Spiramycin 1.5 miu +Metronidazole 250 mg", "spirex plus spiramycin 1.5million iu metronidazole 250mg flagymycin ds spirazole forte tablets", abColor(context), "urti upper respiratory tract periodontal odontogenic ent infections ear nose throat toxoplasmosis macrolides");
    addItem ("Spiromide 20/50 tab", "Furosemide 20 mg +Spironolactone 50 mg", "spiromide furosemide 20mg spironolactone 50mg frusetone lasilactone odespiron 20/50 tablets", cvsColor(context), "hypertension edema loop Potassium Sparing Diuretics");
    addItem ("Spiromide 20/100 tab", "Furosemide 20 mg +Spironolactone 100 mg", "spiromide furosemide 20mg spironolactone 100mg frusetone lasilactone odespiron 20/100 tablets", cvsColor(context), "hypertension edema loop Potassium Sparing Diuretics");
    addItem ("Stablon tab", "Tianeptine 12.5 mg", "stablon tianeptine frustless 12.5mg tablets", cnsColor(context), "depression antidepressants");
    addItem ("Starkoprex 5 tab", "Tadalafil 5 mg", "starkoprex tadalafil cipalafil diamonrecta tadagold tadanerfi cialong cialis cialong erectalis erectamax erectoback kemporic snafi tada tadalong 5mg 10mg 20mg tablets", urinaryColor(context), "erectile dysfunction benign prostatic hyperplasia bph pulmonary arterial hypertension Phosphodiesterase-5 Enzyme Inhibitor");
    addItem ("Stalevo tab", "Levodopa +Carbidopa +Entacapone", "stalevo tablets levodopa carbidopa entacapone", cnsColor(context), "parkinsonism parkinson's disease");
    addItem ("Staturic 40 tab", "Febuxostat 40 mg", "staturic febuxostat donifoxate effeturin feburic goutifade unsiatem xanthibux 40mg 80mg tablets", otherColor(context), "chronic antigout agents");
    addItem ("Stelara prefilled syringe/vial", "Ustekinumab", "Stelara ustekinumab prefilled syringe vial", otherColor(context), "Plaque Psoriasis Psoriatic Arthritis Crohn Disease Ulcerative Colitis monoclonal antibodies");
    addItem ("Stellasil 1 tab", "Trifluoperazine 1 mg", "stellasil Trifluoperazine Trifluperazine 1mg 5mg tablets", cnsColor(context), "Schizophrenia Non Psychotic Anxiety Psychosis Antipsychotics");
    addItem ("Sterogyl 15 H amp", "Ergocalciferol (Vit D3) 600000 iu /1.5 ml", "Sterogyl 15 h Ergocalciferol vitamin d3 600000iu/1.5ml ampoule", vitColor(context), "Osteoporosis Rickets Vitamin D deficiency");
    addItem ("Steronate tab", "Norethisterone Acetate 5 mg", "steronate Norethisterone norethindrone acetate cidolut nor Primolut nor 5mg 10mg tablets", hormoneColor(context), "amenorrhea uterine bleeding endometriosis");
    addItem ("Stigmide syrup", "Pyridostigmine 60 mg /5 ml", "Stigmide Pyridostigmine 60mg/5ml syrup", cnsColor(context), "myasthenia gravis Acetylcholinesterase Inhibitors");
    addItem ("Stimulan 400 cap", "Piracetam 400 mg", "stimulan piracetam cerebrocetam memoral neurocet nootropil cerebrocetam cerebroforte egyram memoral nootropil oxitropil 400mg 800mg 1200mg capsules tablets", cnsColor(context), "cerebrovascular insult insufficiency delayed milestones memory enhancement of concentration cerebral infarction");
    addItem ("Stimulan amp", "Piracetam 1 gm / 5 ml", "stimulan piracetam cerebrocetam memoral nootropil pharmatropil 1000mg/5ml ampoule", cnsColor(context), "cerebrovascular insult insufficiency delayed milestones memory enhancement of concentration cerebral infarction");
    addItem ("Stimulan syrup", "Piracetam 1 gm / 5 ml", "stimulan piracetam cerebrocetam cerebroforte egyram neurocet nootropil 1000mg/5ml syrup", cnsColor(context), "cerebrovascular insult insufficiency delayed milestones memory enhancement of concentration cerebral infarction");
    addItem ("Stopspasm tab", "Phloroglucinol 62 mg +Trimethylphloroglucinol 80 mg", "stopspasm tablets Phloroglucinol 62mg Trimethylphloroglucinol 80mg", gitColor(context), "Colic spasm");
    addItem ("Streptomycin vial", "Streptomycin 1 gm", "Streptomycin sulphate 1000mg 1gm vial", abColor(context), "Moderate to Severe Infections Tuberculosis tb Plague Brucellosis Tularemia Streptococcal Enterococcal Endocarditis Antitubercular Agents aminoglycosides");
    addItem ("Streptoquin syrup", "Diiodohydroxyquinoline +Homatropine +Phthalyl Sulfathiazole +Streptomycin", "streptoquin syrup Diiodohydroxyquinoline homatropine phthalyl sulfathiazole sulphathiazole streptomycin", abColor(context), "chronic intestinal amebiasis bacillary dysentery diarrhea colic");
    addItem ("Streptoquin tab", "Diiodohydroxyquinoline +Homatropine +Phthalyl Sulfathiazole +Streptomycin", "streptoquin tablets Diiodohydroxyquinoline homatropine phthalyl sulfathiazole sulphathiazole streptomycin", abColor(context), "chronic intestinal amebiasis bacillary dysentery diarrhea colic");
    addItem ("Stugeron tab", "Cinnarizine 25 mg", "stugeron cinnarizine cerebal cinibral cinnazin stuval 25mg tablets", cnsColor(context), "cerebral circulatory disorders peripheral circulatory disorders motion sickness balance disorders");
    addItem ("Sulfozinc 10 syrup", "Zinc 10 mg /5 ml", "Sulfozinc sulfate zincorigin gluconate zinc-sedico zincomist 10mg/5ml syrup", vitColor(context), "Diarrhea Wilson's Disease");
    addItem ("Sulfozinc 20 syrup", "Zinc 20 mg /5 ml", "Sulfozinc sulfate salfoverose zincorhea zinc-sedico agnatix 20mg/5ml syrup", vitColor(context), "Diarrhea Wilson's Disease");
    addItem ("Supravit cap", "Vitamins +Minerals", "Supravit capsules Multivitamins a B1 thiamine B2 riboflavin B6 pyridoxine B12 cobalamin d3 c ascorbic acid E tocopherol Nicotinic Acid nicotinamide niacin b3 Folic Acid b9 b7 biotin B5 calcium pantothenate paba Para aminobenzoic acid b10 l-lysine rutin iron potassium cu copper zinc mn manganese pollen extract ca", vitColor(context), "multivitamins minerals deficiency supplementation");
    addItem ("Suprax 200 cap", "Cefixime 200 mg", "suprax cefixime hebixime ximacef cefabrum cefalotrigerex viodrilnex 200mg capsules", abColor(context), "Bronchitis Otitis media Pharyngitis tonsillitis Gonorrhea UTI urinary tract infections Typhoid Fever 3rd third generation cephalosporins");
    addItem ("Suprax 400 cap", "Cefixime 400 mg", "suprax cefixime hebixime ximacef 400mg capsules", abColor(context), "Bronchitis Otitis media Pharyngitis tonsillitis Gonorrhea UTI urinary tract infections Typhoid Fever 3rd third generation cephalosporins");
    addItem ("Suprax susp", "Cefixime 100 mg /5 ml", "Suprax Cefixime flavicef hebixime oracef viodrilnex ximacef 10mg/5ml suspension", abColor(context), "Bronchitis Otitis media Pharyngitis tonsillitis Gonorrhea UTI urinary tract infections Typhoid Fever 3rd third generation cephalosporins");
    addItem ("Swabivent nebulizer solution", "Ipratropium Bromide 500 mcg +Salbutamol 2.5 mg /2.5 ml", "swabivent ipratropium bromide salbutamol albuterol aerotropia breathovance nebulizer solution", resColor(context), "acute severe bronchospasm bronchial asthma exacerbation copd chronic obstructive pulmonary disease Bronchodilators anticholinergic agents short-acting Beta2 Agonists");
    addItem ("Symbicort 80/4.5 turbuhaler", "Budesonide 80 mcg +Formoterol 4.5 mcg /dose", "Symbicort 80/4.5 turbuhaler Budesonide 80mcg Formoterol 4.5mcg /dose mdicorval 100/6 metered actuation", resColor(context), "bronchial asthma copd chronic obstructive pulmonary disease long-acting Beta2 Agonists corticosteroids");
    addItem ("Symbicort 160/4.5 turbuhaler", "Budesonide 160 mcg +Formoterol 4.5 mcg /dose", "Symbicort 160/4.5 turbuhaler Budesonide 160mcg Formoterol 4.5mcg /dose mdicorval 200/6 metered actuation", resColor(context), "bronchial asthma copd chronic obstructive pulmonary disease long-acting Beta2 Agonists corticosteroids");
    addItem ("Symbicort 320/9 turbuhaler", "Budesonide 320 mcg +Formoterol 9 mcg /dose", "Symbicort 320/9 turbuhaler Budesonide 320mcg Formoterol 9mcg /dose forbudes 400/12 inhalation caps", resColor(context), "bronchial asthma copd chronic obstructive pulmonary disease long-acting Beta2 Agonists corticosteroids");
    addItem ("Symmebact-D drops", "Lactobacillus Reuteri 100 million CFU +Vit D3 400 IU /5 drops", "Symmebact-D Lactobacillus Reuteri 100 million CFU Vitamin D3 400IU twinidro conmala zinobacilly drops", gitColor(context), "helps regulate and maintain the balance of the intestinal flora immunity enhancer");
    addItem ("Synjardy tab", "Empagliflozin +Metformin", "Synjardy Empagliflozin Metformin empagliform mellitofix met 12.5/850 12.5/500 12.5/1000 tablets", hormoneColor(context), "type2 diabetes mellitus Biguanides sodium-glucose co-transporter 2 SGLT2");
    addItem ("Syntocinon 5 iu amp", "Oxytocin 5 iu /ml", "syntocinon oxytocin oxytoflex sunnylabcin 5iu/ml ampoule", hormoneColor(context), "Postpartum Hemorrhage Labor Induction Incomplete Inevitable Abortion");
    addItem ("Syntocinon 10 iu amp", "Oxytocin 10 iu /ml", "syntocinon oxycinon oxytoflex sunnylabcin 10iu/ml ampoule", hormoneColor(context), "Postpartum Hemorrhage Labor Induction Incomplete Inevitable Abortion");

    addItem ("Taminil-N cap", "Oseltamivir 75 mg", "taminil-n tamiflu oseltamivir epimiraflu tamilavir 75mg capsules", abColor(context), "Influenza A & B Swine Flu antiviral agents");
    addItem ("Taminil-N susp", "Oseltamivir 60 mg /5 ml", "Taminil-N Oseltamivir tamiflu 60mg/5ml suspension", abColor(context), "Influenza A & B Swine Flu antiviral agents");
    addItem ("Tamoxifen 10 tab", "Tamoxifen 10 mg", "tamoxifen nolvadex 10mg tablets", otherColor(context), "Metastatic adjuvant breast cancer prevention ductal carcinoma in situ Selective Estrogen Receptor Modulators SERM");
    addItem ("Tamoxifen 20 tab", "Tamoxifen 20 mg", "tamoxifen 20mg tablets", otherColor(context), "Metastatic adjuvant breast cancer prevention ductal carcinoma in situ Selective Estrogen Receptor Modulators SERM");
    addItem ("Tamsulin cap", "Tamsulosin 0.4 mg", "tamsulin block alpha curepro firamazin kemprost losiprost magitamsulosin omnic ocas tamic tamsunorm 0.4mg capsules", urinaryColor(context), "benign prostatic hyperplasia bph bladder outlet obstruction ureteral stones alpha1 blockers");
    addItem ("Tamsulin Plus tab", "Tamsulosin 0.4 mg +Solifenacin 6 mg", "tamsulin plus tablets tamsulosin 0.4mg Solifenacin 6mg", urinaryColor(context), "benign prostatic hyperplasia bph alpha1 blockers");
    addItem ("Tareg 40 tab", "Valsartan 40 mg", "tareg valsartan lasaromep valsatens vasotec cardovaldon disartan idisartan sarangiot targomash valsar adwivalsar cardovaldon disartan pressval sordevan 40mg 80mg 160mg 320mg tablets capsules", cvsColor(context), "hypertension heart failure post-myocardial infarction ARBs Angiotensin receptor blockers");
    addItem ("Targocid 200 vial", "Teicoplanin 200 mg", "targocid teicoplanin rotaplanin 200mg vial", abColor(context), "Complicated skin pneumonia urinary tract uti bone infections Infective endocarditis");
    addItem ("Targocid 400 vial", "Teicoplanin 400 mg", "targocid teicoplanin 400mg vial", abColor(context), "Complicated skin pneumonia urinary tract uti bone infections Infective endocarditis");
    addItem ("Tariflox 200 tab", "Ofloxacin 200 mg", "tariflox ofloxacin epicoflocin jedcoflacin kiroll oflicin ofloxin tarivan tarivid 200mg tablets", abColor(context), "Cervicitis Urethritis Prostatitis Traveler's Traveller's Diarrhea Bronchitis exacerbation Pneumonia Skin acute PID pelvic inflammatory disease UTI urinary tract infections Gonorrhea fluoroquinolones");
    addItem ("Tariflox 400 tab", "Ofloxacin 400 mg", "tariflox ofloxacin cemiflox cemi-flox healthibact grand q ofloguide unitarqin 400mg tablets", abColor(context), "Cervicitis Urethritis Prostatitis Traveler's Traveller's Diarrhea Bronchitis exacerbation Pneumonia Skin acute PID pelvic inflammatory disease UTI urinary tract infections Gonorrhea fluoroquinolones");
    addItem ("Tavacin 500 tab", "Levofloxacin 500 mg", "Tavacin Levofloxacin alfaspect bioticaflox cinoflokeen debacolev exacinop floxabact kevork larivex leeflox lee-flox levanic levodel levomagictam levoxin megabio monosho royafloxacin tavanic tavoniflox unibiotic unitoxam venaxam 500mg tablets", abColor(context), "Community Acquired Pneumonia Acute bacterial sinusitis Bronchitis skin Infections Plague Epididymitis Prostatitis fluoroquinolones");
    addItem ("Tavacin 750 tab", "Levofloxacin 750 mg", "Tavacin Levofloxacin alfacef alfaspect bioticaflox debacolev exacinop kevork leeflox lee-flox levanic levodel megabio mepafloxin naglovic quinostarmax respiflox targofloxin tavoniflox unitoxam 750mg tablets", abColor(context), "Nosocomial Pneumonia Acute bacterial sinusitis UTI urinary tract Pyelonephritis Community Acquired Pneumonia Bronchitis Skin Infections Prostatitis Plague Epididymitis fluoroquinolones");
    addItem ("Tavegyl syrup", "Clemastine 0.5 mg /5 ml", "tavegyl clemastine histatop hista-top 0.5mg/5ml syrup", resColor(context), "Allergic rhinitis Urticaria angioedema 1st first generation antihistamines");
    addItem ("Tavegyl tab", "Clemastine 1 mg", "tavegyl clemastine histatop hista-top 1mg tablets", resColor(context), "Allergic rhinitis Urticaria angioedema 1st first generation antihistamines");
    addItem ("Tazocin vial", "Piperacillin 4 gm +Tazobactam 500 mg", "Tazocin PiperacillinTazobactam advoctam piprataz 4500mg 4.5gm vial", abColor(context), "Nosocomial Pneumonia Intra-abdominal Community-acquired Pneumonia Skin Infections PID pelvic inflammatory disease Penicillins");
    addItem ("Tebofortin 40 tab", "Ginkgo Biloba 40 mg", "tebofortin ginkgo gincofar ginkobonina biloba tanakan tebonina 40mg tablets", otherColor(context), "altitude sickness cognitive function dementia intermittent claudication premenstrual syndrome ssri-induced sexual dysfunction vertigo tinnitus raynaud's phenomenon normal tension glaucoma");
    addItem ("Tebofortin 80 tab", "Ginkgo Biloba 80 mg", "tebofortin ginkgo ginko biloba 80mg tablets", otherColor(context), "altitude sickness cognitive function dementia intermittent claudication premenstrual syndrome ssri-induced sexual dysfunction vertigo tinnitus raynaud's phenomenon normal tension glaucoma");
    addItem ("Tebofortin drops", "Ginkgo Biloba 40 mg /ml", "tebofortin ginkgo ginko biloba tanakan 40mg/ml drops", otherColor(context), "altitude sickness cognitive function dementia intermittent claudication premenstrual syndrome ssri-induced sexual dysfunction vertigo tinnitus raynaud's phenomenon normal tension glaucoma");
    addItem ("Tecavir 0.5 tab", "Entecavir 0.5 mg", "entecavir baraclude caviclude cludinetech hepaclude ludnovir tecentacav 0.5mg 1mg tablets capsules", abColor(context), "Chronic Hepatitis B");
    addItem ("Tegretol syrup", "Carbamazepine 100 mg /5 ml", "tegretol carbamazepine alextol arbateg epimazepine tegrapin 100mg/5ml syrup", cnsColor(context), "epilepsy convulsions seizures trigeminal neuralgia bipolar mania restless legs syndrome schizophrenia postherpatic neuralgia anticonvulsants");
    addItem ("Tegretol 200 tab", "Carbamazepine 200 mg", "tegretol carbamazepine arbateg carbapex carbatol mazemal neurotop tegral tonoclone 200mg 400mg tablets", cnsColor(context), "epilepsy convulsions seizures trigeminal neuralgia bipolar mania restless legs syndrome schizophrenia postherpatic neuralgia anticonvulsants");
    addItem ("Tegretol 200 CR tab", "Carbamazepine 200 mg", "tegretol carbamazepine carbapex epimazepine mazemal tonoclone neurotop arbateg neurofutal tegrapin retard 200mg 300mg 400mg 600mg cr xr sr er tablets", cnsColor(context), "epilepsy convulsions seizures trigeminal neuralgia bipolar mania restless legs syndrome schizophrenia postherpatic neuralgia anticonvulsants");
    addItem ("Telfast Decongestant tab", "Fexofenadine 60 mg + Pseudoephedrine 120 mg", "telfast decongestant tablets fexofenadine pseudoephedrine", resColor(context), "Seasonal Allergic Rhinitis with Nasal Congestion decongestants");
    addItem ("Temodal cap", "Temozolomide", "temodal chemtheraz temozolomide-accord capsules", otherColor(context), "Anaplastic Astrocytoma Glioblastoma Multiforme Antineoplastic Agents");
    addItem ("Tempra syrup", "Paracetamol 160 mg /5 ml", "Tempra Paracetamol acetaminophen 160mg/5ml syrup", analgesicColor(context), "fever pain analgesics antipyretics");
    addItem ("Tenaviron tab", "Tenofovir DF 300 mg", "tenaviron Tenofovir df disoproxil fumarate viraproxen viread zeeloras 300mg tablets", abColor(context), "HIV infections AIDS Hepatitis B Infection");
    addItem ("Tenedone tab", "Atenolol +Chlorthalidone", "tenedone atenolol chlorthalidone ateno-c atenoc tenolidone blokium diu tenoretic tenotens plus tablets", cvsColor(context), "hypertension Beta-1 selective blockers class II 2 antiarrhythmic agents");
    addItem ("Tenormin 25 tab", "Atenolol 25 mg", "tenormin atenolol amotenolol atelol blokium tenotens tensolol 25mg 50mg 100mg tablets", cvsColor(context), "hypertension heart failure post mi Beta-1 selective blockers class II 2 antiarrhythmic agents");
    addItem ("Tensopleron 25 tab", "Eplerenone 25 mg", "tensopleron eplerenone carfalone eplorefix eraloner 25mg 50mg tablets", cvsColor(context), "hypertension Potassium Sparing Diuretics");
    addItem ("Tentavair 80 inhaler", "Ciclesonide 80 mcg /actuation", "Tentavair Ciclesonide alvesco 80mcg/actuation 160mcg/actuation inhaler", resColor(context), "bronchial asthma maintenance corticosteroids");
    addItem ("Testonon amp", "Testosterone 250 mg /ml", "testonon testosterone gonateston 250mg/ml ampoule", hormoneColor(context), "Testosterone replacement therapy for male hypogonadism supportive therapy for female-to-male transsexuals androgens");
    addItem ("Tetracid 250 cap", "Tetracycline 250 mg", "tetracid tetracycline 250mg capsules", abColor(context), "acute exacerbation of chronic Bronchitis acne vulgaris brucellosis syphilis gonorrhea urethral endocervical rectal infection");
    addItem ("Teveten 600 tab", "Eprosartan 600 mg", "teveten eprosartan cosarnomid tensrelive 600mg tablets", cvsColor(context), "Hypertension ARBs Angiotensin receptor blockers");
    addItem ("Thiazopril 20/12.5 tab", "Enalapril 20 mg +Hydrochlorothiazide 12.5 mg", "Thiazopril enalapril hydrochlorothiazide co-renitec corenitec combipress ezapril-co thiapril 20/12.5 tablets", cvsColor(context), "Hypertension ace Angiotensin-converting enzyme inhibitors thiazides Diuretics");
    addItem ("Thiopental 500 vial", "Thiopental 500 mg", "anapental Thiopental sodium 500mg vial", cnsColor(context), "general Anesthesia short duration anesthesia convulsions seizures");
    addItem ("Thiopental 1 gm vial", "Thiopental 1000 mg", "Thiopental sodium 1000mg 1gm vial", cnsColor(context), "general Anesthesia short duration anesthesia convulsions seizures");
    addItem ("Thiotacid 300 tab", "Alpha Lipoic Acid 300 mg", "thiotacid alpha lipoic thioctic acid saboctic saboxidant thiolkan thionerv thiotex 300mg tablets capsules", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Thiotacid 600 tab", "Alpha Lipoic Acid 600 mg", "thiotacid alpha lipoic thioctic acid saboctic saboxidant thiolkan neuropatex thiotex forte trolipon 600mg tablets capsules", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Thiotacid amp", "Alpha Lipoic Acid 300 mg /10 ml", "thiotacid alpha lipoic acid 300mg/10ml ampoule", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Thiotacid Compound 300 cap", "Alpha Lipoic Acid 300 mg +Benfotiamine 40 mg +Vit B12 250 mcg", "thiotacid compound alpha lipoic acid vitamin b1 benfotiamine thiamine vitamin b1 cyanocobalamin vitamin b12 300mg capsules", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Thiotacid Compound 600 cap", "Alpha Lipoic Acid 600 mg +Benfotiamine 80 mg +Vit B12 500 mcg", "thiotacid compound alpha lipoic acid vitamin b1 benfotiamine thiamine vitamin b1 cyanocobalamin vitamin b12 600mg capsules", vitColor(context), "polyneuritis polyneuropathy neuralgia");
    addItem ("Thrombexx amp", "Recombinant Hirudin 15 mg /ml", "Thrombexx Recombinant Hirudin REFLUDAN 15mg/ml ampoule", cvsColor(context), "prophylaxis of DVT deep vein thrombosis prophylaxis heparin induced thrombocytopenia hit");
    addItem ("Thyrocil 50 tab", "Propylthiouracil 50 mg", "thyrocil propylthiouracil 50mg tablets", hormoneColor(context), "hyperthyroidism thyrotoxic crisis graves disease antithyroid agents");
    addItem ("Tienam vial", "Imipenem 500 mg +Cilastatin 500 mg", "tienam ayapenem supranem imipenem/cilastatin-kab vial", abColor(context), "Non-CNS Cystic Fibrosis Complicated UTI urinary tract Pseudomonas Severe Intra-abdominal Infections Carbapenems");
    addItem ("Tinifloxacin tab", "Ciprofloxacin 500 mg +Tinidazole 600 mg", "tinifloxacin ciprofloxacin 500mg tinidazole 600mg conaz conafutal plus floxotinazole queenciprozole tablets", abColor(context), "enteric fever gastroenteritis Intestinal amebiasis amebic dysentery pid pelvic inflammatory diseases Trichomoniasis Bacterial Vaginosis urinary tract uti giardiasis git infections");
    addItem ("Tiratam syrup", "Levetiracetam 100 mg /ml", "tiratam levetiracetam futatreat kepilepsy keppra kepradil levectam levepex levepsy seizurless sycocetam tiralepsy 100mg/ml syrup", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Tiratam 500 tab", "Levetiracetam 500 mg", "tiratam levetiracetam futatreat kepilepsy keppra kepradil levepex levepsy seizurless sycocetam tiralepsy trinovume 500mg tablets", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Tiratam 500 XR tab", "Levetiracetam 500 mg", "tiratam levetiracetam liptitam seizurless tiralepsy 500mg xr sr tablets", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Tiratam 750 tab", "Levetiracetam 750 mg", "tiratam levetiracetam futatreat kepilepsy kepradil levepex liptitam tiralepsy trinovume 750mg xr tablets", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Tiratam 1000 tab", "Levetiracetam 1000 mg", "tiratam levetiracetam kepilepsy keppra kepradil levectam levepex liptitam tiralepsy 1000mg 1gm xr tablets", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Tiratam vial", "Levetiracetam 500 mg /5 ml", "tiratam levetiracetam kepilepsy 500mg/5ml vial ampoule", cnsColor(context), "partial onset primary generalized tonic-clonic myoclonic seizures convulsions epilepsy anticonvulsants");
    addItem ("Tobolanza cap", "Alverine Citrate +Simethicone", "tobolanza alverine citrate simethicone meteospasmyl capsules", gitColor(context), "colic abdominal pain in irritable bowel syndrome ibs");
    addItem ("Tofranil 25 tab", "Imipramine 25 mg", "tofranil imipramine 25mg tablets", cnsColor(context), "Enuresis Depression antidepressants");
    addItem ("Topamax 25 tab", "Topiramate 25 mg", "topamax topiramate conviban epimate nancydal sprinkazen topilept topnotch delpiramate 25mg 50mg 100mg 200mg tablets", cnsColor(context), "partial-onset primary generalized tonic clonic seizures epilepsy convulsions lennox-gastaut syndrome migraine cluster headache alcoholism anticonvulsants");
    addItem ("Topging cap", "Green Tea extract +Garcinia Cambogia extract +Ginger +Chromium", "topging Green Tea Garcinia Cambogia extract Ginger Chromium catechin top ging capsules", otherColor(context), "dietary supplement during weight control programs");
    addItem ("Toplexil syrup", "Oxomemazine +Guaifenesin", "toplexil Oxomemazine Guaifenesin syrup", resColor(context), "Cough");
    addItem ("Topmode cap", "Sulpiride 50 mg", "topmode sulpiride dogmatil dogmapride neuropride 50mg capsules", cnsColor(context), "anxiety schizophrenia depression vertigo antidepressants");
    addItem ("Topmode forte cap", "Sulpiride 200 mg", "topmode sulpiride dogmatil dogmapride forte 200mg capsules", cnsColor(context), "anxiety schizophrenia depression vertigo antidepressants");
    addItem ("Toria sach", "Colostrum +Lactoferrin +Vit C +Vit E +Selenium +Zinc", "toria immunity boost colostrum vitamin c ascorbic acid tocopherol vitamin e zinc selenium lactoferrin sachets", vitColor(context), "Vitamins minerals iron deficiency anemia immunity enhancer");
    addItem ("Total syrup", "Cod liver oil (Omega 3 +Vit A +Vit D)", "Total omega3 vitamin d vitamin a high seas cod liver oil hypol mount on seas omegamix sansocod tonic emulsion ultraseas syrup", vitColor(context), "Immunity Enhancer hypercholesterolemia Physical and Mental Exhaustion");
    addItem ("Totavit syrup", "Vitamins +Minerals", "totavit Multivitamins a d3 E tocopherol b1 thiamine B2 riboflavin B6 pyridoxine B12 cobalamin c ascorbic acid calcium b7 biotin Folic Acid b9 iron syrup", vitColor(context), "Multivitamins minerals deficiency supplementation");
    addItem ("Tremfya prefilled syringe", "Guselkumab 100 mg /ml", "Tremfya Guselkumab 100mg/ml prefilled syringe", otherColor(context), "psoriatic arthritis plaque psoriasis Monoclonal Antibodies");
    addItem ("Trendo tab", "Betaine HCL +L-Glutamic acid +Dandelion +Rosemary +Fennel seed +Peppermint", "trendo tablets Betaine HCL L-Glutamic acid Dandelion Rosemary Fennel seed Peppermint", gitColor(context), "Liver Tonic support supplementation");
    addItem ("Tresiba prefilled pen", "Insulin Degludec 100 units/ml", "tresiba Insulin degludec prefilled pen", hormoneColor(context), "type1 type2 diabetes mellitus ultra long-acting insulins");
    addItem ("Triactin syrup", "Cyproheptadine 2 mg /5 ml", "triactin cyproheptadine 2mg/5ml syrup", resColor(context), "hypersensitivity reactions spasticity associated with spinal cord migraine prophylaxis decreased appetite secondary to chronic disease drug induced sexual dysfunction serotonin syndrome anorexia nervosa 1st first generation antihistamines");
    addItem ("Triactin tab", "Cyproheptadine 4 mg", "triactin cyproheptadine cyptadine 4mg tablets", resColor(context), "hypersensitivity reactions spasticity associated with spinal cord migraine prophylaxis decreased appetite secondary to chronic disease drug induced sexual dysfunction serotonin syndrome anorexia nervosa 1st first generation antihistamines");
    addItem ("Triaminic drops", "Pseudoephedrine 7.5 mg /0.8 ml", "triaminic pseudoephedrine 7.5mg/0.8ml drops", resColor(context), "nasal congestion decongestants");
    addItem ("Trib Gold cap", "Tribulus Terrestris 250 mg", "Trib Gold Tribulus Terrestris Protodioscin 250mg capsules", urinaryColor(context), "Improving Sexual Interest Libido Performance Spermatogenesis Oligozoospermia Asthenozoospermia Andropause Female Sexual Dysfunction");
    addItem ("Tridil vial", "Nitroglycerin 5 mg /ml", "tridil nitroglycerin glyceryl trinitrate 5mg/ml vial", cvsColor(context), "angina pectoris nitrates");
    addItem ("Triguard cap", "Vit C 500 mg +Vit D 500 iu +Zinc 10 mg", "triguard capsules ascorbic acid vitamin c 500mg vitamin d 500iu Zinc 10mg", vitColor(context), "immunity enhancer vitamins minerals");
    addItem ("Trileptal susp", "Oxcarbazepine 300 mg/ 5 ml", "Trileptal Oxcarbazepine oxaleptal 300mg/5ml suspension", cnsColor(context), "Partial Seizures Bipolar Disorder Diabetic Neuropathy Neuralgia Neuropathy convulsions anticonvulsants");
    addItem ("Trileptal tab", "Oxcarbazepine 150-300-600 mg", "Trileptal Oxcarbazepine andoxezine shorsalin oxaleptal oxatrilepazine oxigrex 150mg 300mg 600mg tablets", cnsColor(context), "Partial Seizures Bipolar Disorder Diabetic Neuropathy Neuralgia Neuropathy convulsions anticonvulsants");
    addItem ("Trimed Flu tab", "Loratadine +Paracetamol +Pseudoephedrine", "trimed flu loratadine paracetamol acetaminophen pseudoephedrine atshi tablets", resColor(context), "allergic rhinitis sinusitis common cold influenza nasal congestion decongestants");
    addItem ("Trio-Clar cap", "Omeprazole 20 mg +Tinidazole 500 mg +Clarithromycin 500 mg", "trio-clar trioclar omeprazole tinidazole clarithromycin capsules tablets", gitColor(context), "helicobacter pylori");
    addItem ("Triocept tab", "Levonorgestrel +Ethinyl Estradiol", "triocept tablets levonorgestrel EthinylEstradiol", hormoneColor(context), "contraceptive oral contraception");
    addItem ("Trittico 50 tab", "Trazodone 50 mg", "Trittico Trazodone 50mg 100mg tablets", cnsColor(context), "Depression Insomnia aggressive behaviour cocaine alcohol withdrawal migraine prophylaxis antidepressants");
    addItem ("Trivarol tab", "Vit B1 +Vit B6 +Vit B12 +Folic Acid", "Trivarol tablets vitamin b1 thiamine vitamin b6 pyridoxine cobalamin vitamin b6 vitamin b12 cyanocobalamin Folic Acid vitamin b9 tri-b trib olisup 50mg tablets", vitColor(context), "polyneuritis Neuralgia polyneuropathy pernicious hemolytic anemia");
    addItem ("Trivastal Retard tab", "Piribedil 50 mg", "Trivastal Retard Piribedil 50mg tablets", cnsColor(context), "chronic pathological cognitive and neurosensorial deficits in elderly intermittent claudication parkinson's disease dopamine agonists");
    addItem ("Trospamexin tab", "Trospium Chloride 20 mg", "trospamexin Trospium Chloride trospikan 20mg tablets", urinaryColor(context), "overactive bladder anticholinergic agents");
    addItem ("Trulicity 0.75 prefilled pen", "Dulaglutide 0.75 mg /0.5 ml", "Trulicity dulaglutide 0.75mg/0.5ml 1.5mg/0.5ml prefilled pen", hormoneColor(context), "type2 diabetes mellitus Glucagon-Like Peptide-1 GLP-1 Receptor Agonist");
    addItem ("Trypsican tab", "Pancreatin +Papain +Bromelain +Trypsin +Alpha chymotrypsin +Sophora Japonica", "trypsican Pancreatin Papain Bromelain Alpha chymotrypsin Sophora Japonica groza tablets", gitColor(context), "Maldigestion inflammations");
    addItem ("Tryptizol 10 tab", "Amitriptyline 10 mg", "tryptizol Amitriptyline 10mg tablets", cnsColor(context), "depression Postherpetic Neuralgia Migraine Prophylaxis Eating Disorder Analgesia for Chronic Pain antidepressants");
    addItem ("Tryptizol 25 tab", "Amitriptyline 25 mg", "tryptizol Amitriptyline 25mg tablets", cnsColor(context), "depression Postherpetic Neuralgia Migraine Prophylaxis Eating Disorder Analgesia for Chronic Pain antidepressants");
    addItem ("Tudasidone 40 tab", "Lurasidone 40 mg", "Tudasidone Lurasidone elbaluran 40mg 80mg 120mg tablets", cnsColor(context), "Schizophrenia Bipolar Depression antidepressants");
    addItem ("Tusscapine syrup", "Noscapine 15 mg /5 ml", "tusscapine noscapine 15mg/5ml syrup", resColor(context), "Dry Cough antitussive");
    addItem ("Tussi ibm syrup", "Ivy leaves +Thyme", "tussi ibm Ivy leaf leaves extract thyme thymotal plus ivylife astracalmito ivycare getaherb bronchinova syrup", resColor(context), "Cough");
    addItem ("Tussin syrup", "Diphenhydramine +Guaifenesin", "Tussin syrup Diphenhydramine Guaifenesin", resColor(context), "cough");
    addItem ("Tussistop syrup", "Levodropropizine 30 mg /5 ml", "tussistop levodropropizine globaprop omegacough 30mg/5ml syrup", resColor(context), "dry cough antitussive");
    addItem ("Tussistop tab", "Levodropropizine 60 mg", "tussistop levodropropizine 60mg tablets", resColor(context), "dry cough antitussive");
    addItem ("Twins D3 drops", "Vit D3 400 iu +Vit K2 5 mcg /4 drops", "twins vitamins d3 cholecalciferol k2 menaquinone-7 drops", vitColor(context), "vitamin d deficiency osteoporosis rickets supports bone health");
    addItem ("Tygacil vial", "Tigecycline 50 mg", "tygacil tigecycline standiga tegasterk 50mg vial", abColor(context), "Skin Infections community-acquired pneumonia complicated Intra-abdominal Infections");
    addItem ("Tysabri vial", "Natalizumab 300 mg", "tysabri natalizumab 300mg vial", otherColor(context), "multiple sclerosis crohn disease monoclonal antibodies");

    addItem ("Ultragriseofulvin susp", "Griseofulvin 125 mg /5 ml", "ultragriseofulvin Griseovin 125mg/5ml suspension", abColor(context), "Tinea corporis cruris capitis pedis unguium antifungals infections");
    addItem ("Ultragriseofulvin tab", "Griseofulvin 125 mg", "ultragriseofulvin ultrafulvin 125mg tablets", abColor(context), "Tinea corporis cruris capitis pedis unguium antifungals infections");
    addItem ("Ultrasolv syrup", "Carbocysteine +Guaifenesin +Oxomemazine", "Ultrasolv syrup Carbocysteine Guaifenesin Oxomemazine", resColor(context), "Productive Cough mucolytics");
    addItem ("Ultrasolv tab", "Carbocysteine +Guaifenesin +Oxomemazine", "Ultrasolv tablets Carbocysteine Guaifenesin Oxomemazine", resColor(context), "Productive Cough mucolytics");
    addItem ("Unictam 375 vial", "Ampicillin 250 mg +Sulbactam 125 mg", "Unictam Ampicillin 250mg Sulbactam 125mg sulbin ultracillin unasyn 375mg vial", abColor(context), "skin Epiglottitis Meningitis peritonsillar abscess retropharyngeal abscess gynecological intra-abdominal Orbital cellulitis PID pelvic inflammatory disease Pyelonephritis Pneumonia uti urinary tract infections acute bacterial rhinosinusitis endocarditis Penicillins");
    addItem ("Unictam 750 vial", "Ampicillin 500 mg +Sulbactam 250 mg", "Unictam Ampicillin 500mg Sulbactam 250mg ampictam novactam sabect sigmacyn synerpen ultracillin unasyn sulbin 750mg vial", abColor(context), "skin Epiglottitis Meningitis peritonsillar abscess retropharyngeal abscess gynecological intra-abdominal Orbital cellulitis PID pelvic inflammatory disease Pyelonephritis Pneumonia uti urinary tract infections acute bacterial rhinosinusitis endocarditis Penicillins");
    addItem ("Unictam 1.5 gm vial", "Ampicillin 1 gm +Sulbactam 500 mg", "Unictam Ampicillin 1000mg 1gm Sulbactam 500mg ampictam fortibiotic novactam sabect sigmacyn synerpen ultracillin sulbin unasyn 1500mg 1.5gm vial", abColor(context), "skin Epiglottitis Meningitis peritonsillar abscess retropharyngeal abscess gynecological intra-abdominal Orbital cellulitis PID pelvic inflammatory disease Pyelonephritis Pneumonia uti urinary tract infections acute bacterial rhinosinusitis endocarditis Penicillins");
    addItem ("Unictam 3 gm vial", "Ampicillin 2 gm +Sulbactam 500 mg", "Unictam Ampicillin 2000mg 2gm Sulbactam 500mg unasyn 3000mg 3gm vial", abColor(context), "skin Epiglottitis Meningitis peritonsillar abscess retropharyngeal abscess gynecological intra-abdominal Orbital cellulitis PID pelvic inflammatory disease Pyelonephritis Pneumonia uti urinary tract infections acute bacterial rhinosinusitis endocarditis Penicillins");
    addItem ("Unictam susp", "Sultamicillin 250 mg /5 ml", "Unictam Sultamicillin Ampicillin 167mg Sulbactam 83mg sigmacyn novactam synerpen unasyn 250mg/5ml suspension", abColor(context), "bacterial skin Epiglottitis Meningitis peritonsillar abscess retropharyngeal abscess gynecological intra-abdominal Orbital cellulitis PID pelvic inflammatory disease Pyelonephritis Pneumonia uti urinary tract infections acute bacterial rhinosinusitis endocarditis Penicillins");
    addItem ("Unictam 375 tab", "Sultamicillin 375 mg", "unictam Sultamicillin ampicillin 250mg sulbactam 125mg ampictam novactam sigmacyn unasyn synerpen 375mg tablets", abColor(context), "bacterial skin Epiglottitis Meningitis peritonsillar abscess retropharyngeal abscess gynecological intra-abdominal Orbital cellulitis PID pelvic inflammatory disease Pyelonephritis Pneumonia uti urinary tract infections acute bacterial rhinosinusitis endocarditis Penicillins");
    addItem ("Unictam 750 tab", "Sultamicillin 750 mg", "unictam Sultamicillin 750mg ampicillin 500mg sulbactam 250mg 750mg tablets", abColor(context), "bacterial infections Penicillins");
    addItem ("Unovit syrup", "Royal Jelly 100 mg +Honey 4 gm /5 ml", "unovit syrup royal jelly honey", vitColor(context), "fatigue asthenia loss of concentration premature aging erectile dysfunction weakness exhaustion tiredness improving physical and mental efficiency");
    addItem ("Uralyt-U granules", "Potassium Sodium Hydrogen Citrate 6:6:3:5", "uralyt-u potassium sodium hydrogen citrate uralytu alkalipurin carelyte citraforte soditrate granules", urinaryColor(context), "uric acid urate stones cystinurea");
    addItem ("Urinex cap", "Camphene +Pinene +Borneol +Cineole +Anethol +Fenchone", "urinex Camphene Alfa-Pinene Beta-Pinene Borneol Cineole Anethol Fenchone rowatinex capsules", urinaryColor(context), "Urinary spasm stones Urolithiasis");
    addItem ("Uripan 5 tab", "Oxybutynin 5 mg", "uripan oxybutynin detronin detrusan dry tropan oxybin 5mg tablets capsules", urinaryColor(context), "Detrusor Ovaractivity overactive bladder antispasmodics");
    addItem ("Uripan 10 tab", "Oxybutynin 10 mg", "uripan oxybutynin dry tropan 10mg tablets capsules", urinaryColor(context), "Detrusor Ovaractivity overactive bladder antispasmodics");
    addItem ("Uripan syrup", "Oxybutynin 5 mg /5 ml", "Uripan Oxybutynin detronin contimax detrusan dry tropan oxurate oxybin 5mg/5ml syrup", urinaryColor(context), "Detrusor Ovaractivity overactive bladder antispasmodics");
    addItem ("Urivin sach", "Atropine Sulphate +Colchicine +Piperazine +Khellin", "urivin atropine sulphate colchicine piperazine khellin solvaure solvinal ur-aid uraid urosolvin sachets", urinaryColor(context), "acute gouty arthritis urate stones antigout agents");
    addItem ("Uro-Vaxom cap", "Bacterial Lysate 6 mg", "uro-vaxom Lyophilized Bacterial Lysates of e.coli urovaxom 6mg capsules", urinaryColor(context), "prevention of recurrent urinary tract infections uti");
    addItem ("Ursofalk cap", "Ursodeoxycholic Acid 250 mg", "ursofalk ursodiol ursodeoxycholic acid egyresolve ursochol ursodol galldepedra ursogall ursocholic biliver livagoal egyurso udexpan ursosernox ursotwin exosirylic 250mg 450mg 500mg capsules tablets", gitColor(context), "gallstones dissolution prevention primary biliary cirrhosis");
    addItem ("Ursoplus cap", "Ursodeoxycholic acid 250 mg +Silymarin 140 mg", "ursoplus capsules Ursodeoxycholic acid Silymarin milk thistle extract", gitColor(context), "Liver Tonic support supplementation cholestatic liver diseases cholesterol gallstones reflux gastritis");
    addItem ("Uvamin retard cap", "Nitrofurantoin 100 mg", "uvamin retard nitrofurantoin macrofuran mepafuran mepa-furan colifuran 100mg capsules", abColor(context), "uti urinary tract infection");

    addItem ("Valponex tab", "Sodium Valproate 200 mg", "valponex sodium Valproate valproic acid daviken dekadel depakine valpokine valprotec 200mg tablets", cnsColor(context), "complex partial absence seizures convulsions epilepsy migraine bipolar mania anticonvulsants");
    addItem ("Valysernex 500 tab", "Valacyclovir 500 mg", "valysernex valacyclovir herpacut valtrex viroclear 500mg tablets caplets", abColor(context), "Chickenpox Genital Herpes Labialis Zoster antivirals");
    addItem ("Valysernex 1 gm tab", "Valacyclovir 1 gm", "valysernex valacyclovir cicloherp valtrovir 1000mg 1gm tablets", abColor(context), "Chickenpox Genital Herpes Labialis Zoster antivirals");
    addItem ("Vamid 10 tab", "Leflunomide 10 mg", "vamid leflunomide avara rafix 10mg tablets", analgesicColor(context), "Rheumatoid arthritis");
    addItem ("Vamid 20 tab", "Leflunomide 20 mg", "vamid leflunomide avara rafix apetoid arthfree leflumine 20mg tablets", analgesicColor(context), "Rheumatoid arthritis");
    addItem ("Vamid 100 tab", "Leflunomide 100 mg", "vamid leflunomide avara rafix apetoid arthfree leflumine 100mg tablets", analgesicColor(context), "Rheumatoid arthritis");
    addItem ("Vancomycin-Lyomark susp", "Vancomycin 1 gm /20 ml", "Vancomycin-Lyomark 1000mg 1gm/20ml suspension", abColor(context), "Staphylococcal Enterocolitis Clostridium difficile-associated Diarrhea glycopeptides");
    addItem ("Vancomycin 500 vial", "Vancomycin 500 mg", "vancomycin vancomix edicin vancozin vancobact vancolon kempovancom 500mg vial", abColor(context), "Infective Endocarditis Septicemia Skin Bone LRTI lower respiratory tract infections Bacterial meningitis Surgical Prophylaxis glycopeptides");
    addItem ("Vancomycin 1 gm vial", "Vancomycin 1 gm", "vancomycin vancomix edicin vetovancin 1000mg 1gm vial", abColor(context), "Infective Endocarditis Septicemia Skin Bone LRTI lower respiratory tract infections Bacterial meningitis Surgical Prophylaxis glycopeptides");
    addItem ("Vapozol solution", "Benzoin Tincture +Camphor +Eucalyptus +Peppermint Oil", "vapozol solution for inhalation Benzoin Tincture Camphor Eucalyptus Peppermint Oil", resColor(context), "laryngitis bronchitis");
    addItem ("Vascular tab", "Isoxsuprine 20 mg", "vascular isoxsuprine duvadilan 20mg tablets", cvsColor(context), "cerebrovascular insufficiency peripheral vascular disease arteriosclerosis obliterans thromboangitis obliterans buerger's burger's raynaud's disease vasodilators");
    addItem ("Velosef 125 susp", "Cephradine 125 mg /5 ml", "Velosef Cephradine cefadrine 125mg/5ml suspension", abColor(context), "Pneumonia Skin UTI urinary tract Bone Infections 1st first generation cephalosporins");
    addItem ("Velosef 250 susp", "Cephradine 250 mg /5 ml", "Velosef Cephradine cefadrine 250mg/5ml suspension", abColor(context), "Pneumonia Skin UTI urinary tract Bone Infections 1st first generation cephalosporins");
    addItem ("Velosef 500 cap", "Cephradine 500 mg", "Velosef Cephradine cefadron 500mg capsules", abColor(context), "Pneumonia Skin UTI urinary tract Bone Infections 1st first generation cephalosporins");
    addItem ("Velosef 1 gm cap", "Cephradine 1 gm", "Velosef Cephradine cephraforte fortecef mepadrin 1000mg 1gm tablets capsules", abColor(context), "Pneumonia Skin UTI urinary tract Bone Infections 1st first generation cephalosporins");
    addItem ("Velosef 500 vial", "Cephradine 500 mg", "velosef Cephradine cefadrin cephramedin farcosef mepadrin velosef 500mg vial", abColor(context), "Pneumonia Skin UTI urinary tract Bone Infections 1st first generation cephalosporins");
    addItem ("Velosef 1 gm vial", "Cephradine 1 gm", "velosef Cephradine cefadrin cephramedin farcosef mepadrin 1000mg 1gm vial", abColor(context), "Pneumonia Skin UTI urinary tract Bone Infections 1st first generation cephalosporins");
    addItem ("Venlatrin 37.5 tab", "Venlafaxine 37.5 mg", "venlatrin venlafaxine delvena globexor idixor venoxor venlaxine effoxbelle 37.5mg 75mg 100mg 150mg tablets", cnsColor(context), "depression antidepressants hot flashes due to hormonal chemotherapy attention deficit disorder neuropathic pain selective serotonin and norepinephrine reuptake inhibitors SSNRIs");
    addItem ("Vental inhaler", "Salbutamol 100 mcg /dose", "vental Salbutamol albuterol aerolin butalin ventolin viasalmol 100mcg/dose inhaler evohaler", resColor(context), "Bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Vental Compositum inhaler", "Salbutamol 100 mcg +Beclomethasone 50 mcg /dose", "vental salbutamol 100mcg beclomethasone 50mcg clenil compositum viasalmol plus inhaler", resColor(context), "bronchial asthma chronic bronchitis Bronchodilators short-acting Beta2 Agonists");
    addItem ("Ventocough syrup", "Salbutamol +Bromhexine +Guaifenesin", "ventocough syrup salbutamol albuterol bromhexine guaifenesin", resColor(context), "Bronchospasm bronchial asthma bronchitis copd Bronchodilators short-acting Beta2 Agonists");
    addItem ("Ventolin syrup", "Salbutamol 2 mg /5 ml", "Ventolin Salbutamol bronchoterol albuterol mepacovent opichestal salbovent vental 2mg/5ml syrup", resColor(context), "Bronchospasm bronchial asthma Bronchodilators short-acting Beta2 Agonists");
    addItem ("Ventolin expectorant syrup", "Guaifenesin 50 mg +Salbutamol 1 mg /5 ml", "Ventolin expectorant syrup Guaifenesin Salbutamol albuterol", resColor(context), "Cough Bronchodilators short-acting Beta2 Agonists");
    addItem ("Verm-1 tab", "Mebendazole 500 mg", "verm-1 verm1 Mebendazole 500mg tablets", abColor(context), "roundworm Ascaris whipworm trichuriasis");
    addItem ("Vermizole susp", "Albendazole 200 mg /5 ml", "Vermizole Albendazole 200mg/5ml suspension", abColor(context), "Entrobius Pinworm oxyuris Ancylostoma Ascariasis Hookworm Trichostrongylus Taenia solium Echinococcus Capillariasis Trichuriasis whipworm Cutaneous Visceral Larva Migrans Fluke Gnathostomiasis Microsporidiosis");
    addItem ("Verpamil 40 tab", "Verapamil 40 mg", "verpamil verapamil veratens 40mg tablets", cvsColor(context), "hypertension angina chronic atrial fibrillation paroxysmal supraventricular tachycardia tardive dyskinesia migraine prophylaxis class IV 4 antiarrhythmic agents Calcium Channel Blockers CCBs");
    addItem ("Vexamod 37.5 SR cap", "Venlafaxine 37.5 mg", "vexamod venlafaxine efexor effegad idixor venllamash 37.5mg 75mg 150mg sr xr er capsules", cnsColor(context), "depression antidepressants generalized anxiety social anxiety panic disorder hot flashes due to hormonal chemotherapy post-traumatic stress disorder selective serotonin and norepinephrine reuptake inhibitors SSNRIs");
    addItem ("Viagra 50 tab", "Sildenafil 50 mg", "viagra sildenafil andagra brilliant ectagor erecta ezequel faroviga kemagra napifit nerhasilda oragawell orgodenafil phragra respatio satenafil silagra silanil sildava sildinax sildinova silvagra silvigo spika stimu-max stimumax v-gone vgone veora vetoyagra viavag vigadol vigorama vigoran vigorex virecta 50mg 100mg tablets", urinaryColor(context), "erectile dysfunction Phosphodiesterase-5 Enzyme Inhibitor");
    addItem ("Vibramycin tab", "Doxycycline 100 mg", "Vibramycin doxycycline mr doxydox doxymycin farcodoxin granudoxy tabocine 100mg tablets", abColor(context), "Malaria Prophylaxis Rickettsial Respiratory Tract rti Brucellosis Amebiasis Severe acne vulgaris Sexually Transmitted Ophthalmic Infections Syphilis Anthrax tetracyclines");
    addItem ("Victoza prefilled pen", "Liraglutide 18 mg /3 ml", "victoza liraglutide 18mg/3ml prefilled pen", hormoneColor(context), "type2 diabetes mellitus Glucagon-Like Peptide-1 GLP-1 Receptor Agonist");
    addItem ("Vidrop drops", "Vit D3 2800 iu /ml", "vidrop cholecalciferol vitamin d3 oneferol bone oridal 2800iu/ml drops", vitColor(context), "vitamin d deficiency osteoporosis rickets");
    addItem ("Vilaphoria 10 tab", "Vilazodone 10 mg", "Vilaphoria Vilazodone vilazoprine vilazover 10mg 20mg 40mg tablets", cnsColor(context), "Major Depressive Disorder antidepressants");
    addItem ("Vinporal tab", "Vinpocetine 5 mg", "vinporal vinpocetine angiovan cavalpha cavestin cavinil circufit veinpo 5mg 10mg tablets capsules", cnsColor(context), "Cognitive Impairment due to Vascular Disease");
    addItem ("Virinrest 400 tab", "Ribavirin 400 mg", "Virinrest Ribavirin 400mg tablets", abColor(context), "Chronic Hepatitis C virus infections HIV/HCV coinfection");
    addItem ("Virustat 200 susp", "Acyclovir 200 mg /5 ml", "Virustat Acyclovir borgavirax zovirax 200mg/5ml suspension", abColor(context), "Chickenpox shingles Genital Herpes varicella Zoster antivirals");
    addItem ("Virustat 200 tab", "Acyclovir 200 mg", "virustat acyclovir novirus 200mg tablets capsules", abColor(context), "Chickenpox shingles Genital Herpes varicella Zoster antivirals");
    addItem ("Virustat 400 tab", "Acyclovir 400 mg", "virustat acyclovir zovirax 400mg tablets", abColor(context), "Chickenpox shingles Genital Herpes varicella Zoster antivirals");
    addItem ("Virustat 800 tab", "Acyclovir 800 mg", "virustat acyclovirAl acivirax 800mg tablets", abColor(context), "Chickenpox shingles Genital Herpes varicella Zoster antivirals");
    addItem ("Visanne tab", "Dienogest 2 mg", "visanne dienogest endodrava gynoprogest 2mg tablets", hormoneColor(context), "endometriosis");
    addItem ("Visceralgine amp", "Tiemonium methylsulfate 5 mg /2 ml", "Visceralgine Tiemonium methylsulfate antikramp spasmofree 5mg/2ml ampoule", gitColor(context), "Colic spasm");
    addItem ("Visceralgine supp", "Tiemonium methylsulfate 20 mg", "Visceralgine Tiemonium methylsulfate 20mg suppository", gitColor(context), "Colic spasm");
    addItem ("Visceralgine syrup", "Tiemonium methylsulfate 10 mg /5 ml", "Visceralgine Tiemonium methylsulfate timogen spasmofree 10mg/5ml syrup", gitColor(context), "Colic spasm");
    addItem ("Visceralgine tab", "Tiemonium methylsulfate 50 mg", "Visceralgine Tiemonium methylsulfate spasmofree mepaspasmin musclorginic 50mg tablets", gitColor(context), "Colic spasm");
    addItem ("Vitacid C 500 sach", "Vit C 500 mg", "vitacid vitamin c ascorbic acid 500mg sachets", vitColor(context), "vitamin c deficiency scurvy urinary acidification");
    addItem ("Vitacid C 1 gm eff tab", "Vit C 1 gm", "vitacid vitamin c ascorbic acid amovit-c cevitil fawar cevitil ascorbovit immucyrl lora redoxon rota power vit c 1000mg 1gm effervescent tablets sachets", vitColor(context), "vitamin c deficiency scurvy urinary acidification");
    addItem ("Vitacid Calcium tab", "Vit C 1 gm +Calcium 320 mg", "vitacid ascorbic acid amovit calcium and vitamin c ester-c tablets", vitColor(context), "vitamin c deficiency scurvy calcium deficiency");
    addItem ("Vitaferrol cap", "Iron +Cyanocobalamin +Folic Acid +Vit C +Manganese +Zinc", "vitaferrol capsules Iron Cyanocobalamin vitamin b12 Folic Acid vitamin b9 Vitamin C ascorbic acid Manganese Zinc", vitColor(context), "iron deficiency anemia Vitamins minerals");
    addItem ("Vitaferrol syrup", "Iron +Thiamine +Riboflavin +Pyridoxine +Cyanocobalamin +Panthenol +Nicotinamide", "vitaferrol syrup Iron vitamin B1 thiamine vitamin B2 riboflavin Pyridoxine Cyanocobalamin vitamin b12 Panthenol Nicotinic Acid nicotinamide niacin vitamin b3", vitColor(context), "iron deficiency anemia Vitamins");
    addItem ("Vitamount for men cap", "Multivitamins +Minerals", "vitamount for men capsules Multivitamins a B1 thiamine B2 riboflavin B6 pyridoxine B12 cobalamin c ascorbic acid d E tocopherol k phytonadione B5 calcium pantothenate Folic Acid b9 zinc selenium Chromium60 copper", vitColor(context), "multivitamins minerals deficiency Supplementation");
    addItem ("Vitamount for women cap", "Multivitamins +Minerals", "vitamount for women capsules Multivitamins a B1 thiamine B2 riboflavin B6 pyridoxine B12 cobalamin c ascorbic acid d E tocopherol k phytonadione B5 calcium pantothenate Folic Acid b9 b3 Niacinamide niacin Nicotinic Acid copper zinc iron magnesium citrate", vitColor(context), "multiVitamins minerals deficiency Supplementation");
    addItem ("Vitamount syrup", "Multivitamins +Minerals", "vitamount syrup Multivitamins a b1 thiamine B2 riboflavin Nicotinic Acid nicotinamide niacin b3 B6 pyridoxine B12 cobalamin c ascorbic acid d E tocopherol B5 calcium pantothenate iodine iron zinc manganese chromium", vitColor(context), "multiVitamins minerals deficiency Supplementation");
    addItem ("Vitayami tab", "Multivitamins +Minerals", "vitayami tablets Multivitamins A B1 thiamine B2 riboflavin b3 Nicotinic Acid nicotinamide niacin B5 pantothenic acid B6 pyridoxine b7 biotin B12 cobalamin C ascorbic acid D E tocopherol Folic Acid b9 Calcium Chromium Copper cu Iodine Iron Magnesium Manganese Molybdenum Selenium Zinc", vitColor(context), "multiVitamins minerals deficiency Supplementation");
    addItem ("Vitifect syrup", "Calcium +Vit A +Vit B1 +Vit B2 +Vit B3 +Vit B6 +Vit C +Vit D +Vit E", "vitifect syrup Calcium Multivitamins a thiamine b1 riboflavin b2 Nicotinic Acid nicotinamide niacin b3 pyridoxine b6 c ascorbic acid d3 tocopherol e", vitColor(context), "calcium Vitamins deficiency supplementation");
    addItem ("Vitosel sach", "Lactoferrin +Ferrous Fumarate +Colostrum +Folic Acid +Vit A +Vit B1 +Vit B2 +Vit B3 +Vit B6 +Vit B12 +Vit E", "Vitosel sachets Lactoferrin Iron ferrous fumarate colostrum Folic Acid Multivitamins b9 a b1 thiamine b2 riboflavin b3 niacin b6 pyridoxine b12 cobalamin e tocopherol", vitColor(context), "iron multiVitamins minerals deficiency Supplementation anemia Hair Loss due to Lack Of Ferritin improve immunity enhancer Prevent Breast Cancer");
    addItem ("Vokanamet tab", "Canagliflozin +Metformin", "vokanamet tablets canagliflozin metformin", hormoneColor(context), "type2 diabetes mellitus Biguanides sodium-glucose co-transporter 2 SGLT2");
    addItem ("Voltaren 25 tab", "Diclofenac Na 25 mg", "voltaren diclofenac sodium na declofenac declophen epifenac olfen rheumafen rheumarene 25mg tablets", analgesicColor(context), "rheumatoid osteoarthritis Ankylosing Spondylitis Pain analgesics Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Voltaren 50 tab", "Diclofenac Na 50 mg", "voltaren diclofenac sodium na anuva declofenac declophen dicloferaz epifenac olfen rheumafen rheumarene vantomor 50mg tablets", analgesicColor(context), "rheumatoid osteoarthritis Ankylosing Spondylitis Pain analgesics Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Voltaren SR 75 tab", "Diclofenac Na 75 mg", "voltaren diclofenac sodium na diclac diclonatrium diclosp divido flotac goldfenac epifenac sigmafenac rheumafen 75mg tablets capsules", analgesicColor(context), "rheumatoid osteoarthritis Ankylosing Spondylitis Pain analgesics Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Voltaren SR 100 tab", "Diclofenac Na 100 mg", "voltaren diclofenac sodium na fenaclomex declophen epifenac olfen rheumafen 100mg tablets capsules", analgesicColor(context), "rheumatoid osteoarthritis Ankylosing Spondylitis Pain analgesics Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Voltaren 100 supp", "Diclofenac Na 100 mg", "voltaren Diclofenac sodium na epifenac suppofen declophen pharofen rheumarene romalex 100mg suppositories", analgesicColor(context), "Acute Pain rheumatoid osteoarthritis Dysmenorrhea Nonsteroidal Anti-inflammatory Drugs NSAIDs");
    addItem ("Vomibreak tab", "Doxylamine 10 mg +Pyridoxine 10 mg", "vomibreak doxylamine succinate pyridoxine hcl vitamin b6 mornigag doxytroler zetadidox tablets", gitColor(context), "nausea vomiting antiemetic agents");
    addItem ("Vomistop cap", "Metoclopramide 7.5 mg +Vit B6 40 mg +Dimethicone 50 mg", "vomistop capsules Metoclopramide pyridoxine vitamin b6 Dimethicone", gitColor(context), "vomiting nausea dyspepsia prokinetic antiemetic agents");
    addItem ("Vonaspire 10 tab", "Vonoprazan 10 mg", "vonaspire vonoprazan vonseca vonacidan 10mg tablets", gitColor(context), "gastric duodenal peptic ulcer reflux esophagitis helicobacter pylori");
    addItem ("Vonaspire 20 tab", "Vonoprazan 20 mg", "vonaspire vonoprazan topoprazan vonseca vonacidan 20mg tablets", gitColor(context), "gastric duodenal peptic ulcer reflux esophagitis helicobacter pylori");
    addItem ("Vosevi tab", "Sofosbuvir 400 mg +Velpatasvir 100 mg +Voxilaprevir 100 mg", "vosevi tablets Sofosbuvir Velpatasvir Voxilaprevir", abColor(context), "chronic hepatitis C virus infections hcv");

    addItem ("Wellinta SR tab", "Bupropion 150 mg", "Wellinta Bupropion abstain fumipan vixadep wellbutrin 150mg SR tablets", cnsColor(context), "Major Depressive Disorder Smoking Cessation adhd attention-deficit/hyperactivity disorder Neuropathic Pain antidepressants");
    addItem ("Westabreath tab", "Roflumilast 0.5 mg", "westabreath roflumilast 0.5mg roflumilast 500mcg andomilast dalivent daxas tablets", resColor(context), "Chronic Obstructive Pulmonary Disease copd Phosphodiesterase-4 Enzyme Inhibitors");

    addItem ("Xanax 0.25 tab", "Alprazolam 0.25 mg", "xanax alprazolam restolam zolapar prazonex alprax alizolam 0.25mg 0.5mg 1mg 2mg tablets", cnsColor(context), "anxiety associated with depression panic disorder antidepressants premenstrual syndrome Benzodiazepines");
    addItem ("Xanax 0.5 XR tab", "Alprazolam 0.5 mg", "xanax alprazolam tibazolax zolapar alprax 0.5mg 1mg 3mg xr sr tablets", cnsColor(context), "panic disorder Benzodiazepines");
    addItem ("Xgeva vial", "Denosumab 120 mg /1.7 ml", "Xgeva denosumab 120mg/1.7ml vial", otherColor(context), "Giant Cell Tumor Skeletal-Related Events bone fractures and pain Hypercalcemia of Malignancy monoclonal antibodies");
    addItem ("Xilone syrup", "Prednisolone 5 mg /5 ml", "Xilone Prednisolone predsol pedicort unipridol 5mg/5ml syrup", strdColor(context), "Inflammation Acute asthma Nephrotic Syndrome Rheumatoid Arthritis Multiple Sclerosis Acute Exacerbation of COPD Bells Palsy Corticosteroids");
    addItem ("Xilone forte syrup", "Prednisolone 15 mg /5 ml", "Xilone Prednisolone predsol unipridol pedicort forte 15mg/5ml syrup", strdColor(context), "Inflammation Acute asthma Nephrotic Syndrome Rheumatoid Arthritis Multiple Sclerosis Acute Exacerbation of COPD Bells Palsy Corticosteroids");
    addItem ("Xolair vial", "Omalizumab 150 mg", "xolair omalizumab 150mg vial", resColor(context), "asthma chronic idiopathic urticaria nasal polyps monoclonal antibodies");
    addItem ("Xultophy prefilled pen", "Liraglutide +Insulin Degludec", "Xultophy prefilled pen liraglutide Insulin Degludec", hormoneColor(context), "type2 diabetes mellitus Glucagon-Like Peptide-1 GLP-1 Receptor Agonist long-acting insulins");
    addItem ("Xyntha vial", "Blood Coagulation Factor 8", "xyntha blood coagulation octanate beriate p dried factor 8 fraction 8y green-viii inj haemoctin sdh koate-dvi kogenate-fs novoeight vial", cvsColor(context), "Hemophilia A");

    addItem ("Yasmin tab", "Drospirenone 3 mg +Ethinyl Estradiol 0.03 mg", "yasmin Drospirenone 3mg Ethinylestradiol 0.03mg dormovarin drospadiol mozanglic norocarmena technospirone tablets", hormoneColor(context), "oral contraceptive contraception");
    addItem ("Yaz tab", "Drospirenone 3 mg +Ethinyl Estradiol 0.02 mg", "yaz Drospirenone Ethinylestradiol norocarmena 3mg tablets", hormoneColor(context), "oral contraceptive contraception moderate acne vulgaris premenstrual dysphoric disorder");
    addItem ("Yomesan chew tab", "Niclosamide 500 mg", "Yomesan Niclosamide niclosan 500mg chewable tablets", abColor(context), "taenia saginata solium Diphyllobothrium Latum hymenolepis nana");

    addItem ("Zaditen syrup", "Ketotifen 1 mg /5 ml", "Zaditen Ketotifen allerban zylofen zedotefen prophallerge 1mg/5ml syrup", resColor(context), "Chronic Urticaria Rhinitis Conjunctivitis Prophylaxis of Bronchial asthma mast cell stabilizers");
    addItem ("Zaditen tab", "Ketotifen 1 mg", "Zaditen Ketotifen zylofen zedotefen prophallerge 1mg tablets", resColor(context), "Chronic Urticaria Rhinitis Conjunctivitis Prophylaxis of Bronchial asthma mast cell stabilizers");
    addItem ("Zandros cap", "Omega 3 600 mg +Vit E 19 iu", "zandros capsules omega3 fish oil vitamin e tocopherol", vitColor(context), "hypertriglyceridemia regulate lipids profile");
    addItem ("Zanoglide 2/30 tab", "Glimepiride 2 mg +Pioglitazone 30 mg", "zanoglide glimepiride 2mg pioglitazone 30mg amaglust azgodiabeto glimepiride plus piompride 2/30 4/30 tablets", hormoneColor(context), "type2 diabetes mellitus Thiazolidinediones Sulfonylureas");
    addItem ("Zantac 150 tab", "Ranitidine 150 mg", "zantac ranitidine acilight histac gastroprotect ranitak rantiblock rantidol 150mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric Ulcer Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Stress Ulcer Histamine H2-receptor antagonists blockers");
    addItem ("Zantac 300 tab", "Ranitidine 300 mg", "zantac ranitidine aciloc histac gastroprotect ranitak osmoran 300mg tablets", gitColor(context), "GERD gastroesophageal reflux disease Gastric Ulcer Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Stress Ulcer Histamine H2-receptor antagonists blockers");
    addItem ("Zantac amp", "Ranitidine 50 mg /2 ml", "Zantac Ranitidine ranitak gastproct histac gastroprotect peptrelief taural 50mg/2ml ampoule", gitColor(context), "GERD gastroesophageal reflux disease Gastric Ulcer Erosive Esophagitis Hypersecretory Conditions zollinger ellison syndrome Stress Ulcer Histamine H2-receptor antagonists blockers");
    addItem ("Zestoretic 20/12.5 tab", "Lisinopril 20 mg +Hydrochlorothiazide 12.5 mg", "zestoretic lisinopril hydrochlorothiazide linopril-h lisitens sedoretic sinopril-co tablets", cvsColor(context), "Hypertension ace Angiotensin-converting enzyme inhibitors thiazides Diuretics");
    addItem ("Zestril 5 tab", "Lisinopril 5 mg", "zestril lisinopril maxipril lisopril 5mg 10mg 20mg tablets", cvsColor(context), "acute myocardial infarction Hypertension Heart Failure Diabetic Nephropathy ace Angiotensin-converting enzyme inhibitors");
    addItem ("Zimocefox 250 susp", "Cefuroxime 250 mg /5 ml", "zimocefox cefuroxime ceroxim 250mg/5ml suspension", abColor(context), "impetigo Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin Infections 2nd second generation cephalosporins");
    addItem ("Zinctron cap", "Zinc +Copper +Vit C +Vit B6 +Citrus Bioflavonoids", "zinctron capsules cu Copper vitamin c ascorbic acid vitamin b6 pyridoxine Citrus Bioflavonoids", vitColor(context), "Vitamin minerals deficiency supplementation");
    addItem ("Zinol 500 vial", "Cefazolin 500 mg", "Zinol cefazolin 500mg vial", abColor(context), "bacterial Infections With Gram +ve positive cocci Endocarditis Prophylaxis 1st first generation cephalosporins");
    addItem ("Zithrokan 500 cap", "Azithromycin 500 mg", "zithrokan azithromycin azalide azitanad azithromash azrolid azatribact azindamon delzosin epizithro gigazocin infectomycin rame-zithro ramezithro systymycin unizithrin xerexomair xithrobiotic xithrone zisrocin zithromax zathrotrue zeramerate zithrodose zithropro zithrotac 500mg capsules tablets", abColor(context), "Pharyngitis tonsillitis Acute otitis media Community-acquired Pneumonia Cat Scratch Disease Acute Bacterial Exacerbation of COPD Sinusitis Uncomplicated Skin infections Pertussis Chancroid Urethritis Cervicitis Endocarditis Prophylaxis Macrolides");
    addItem ("Zithrokan 100 susp", "Azithromycin 100 mg /5 ml", "zithrokan Azithromycin unizithrin Zisrocin zithrodose xerexomair 100mg/5ml suspension", abColor(context), "Pharyngitis tonsillitis Acute otitis media Community-acquired Pneumonia Cat Scratch Disease Acute Bacterial Exacerbation of COPD Sinusitis Uncomplicated Skin infections Pertussis Chancroid Urethritis Cervicitis Endocarditis Prophylaxis Macrolides");
    addItem ("Zithrokan 200 susp", "Azithromycin 200 mg /5 ml", "zithrokan Azithromycin azionce azi-once azalide azatribact aziwok azomycin azrolid epizithro gigazocin ramezithro xithrone Zithromax zithrophate unizithrin unizithrocure badozithro 200mg/5ml suspension", abColor(context), "Pharyngitis tonsillitis Acute otitis media Community-acquired Pneumonia Cat Scratch Disease Acute Bacterial Exacerbation of COPD Sinusitis Uncomplicated Skin infections Pertussis Chancroid Urethritis Cervicitis Endocarditis Prophylaxis Macrolides");
    addItem ("Zocef 125 susp", "Cefuroxime 125 mg /5 ml", "zocef cefuroxime hebiuroxime highcef zimocefox zinacef 125mg/5ml suspension", abColor(context), "impetigo Ear otitis media Nose sinusitis Throat pharyngitis tonsillitis Skin Infections 2nd second generation cephalosporins");
    addItem ("Zocor 10 tab", "Simvastatin 10 mg", "zocor simvastatin alkor amristatin corvast low-sterol lowsterol minalip simvacor simvaged 10mg 20mg 40mg 80mg tablets", cvsColor(context), "familial hypercholesterolemia hyperlipidemia hypertriglyceridemia cardiovascular disease prevention HMG-CoA Reductase Inhibitor Statins");
    addItem ("Zodium tab", "Zolpidem 10 mg", "zodium zolpidem 10mg tablets", cnsColor(context), "insomnia hypnotics");
    addItem ("Zofran amp", "Ondansetron 2 mg /ml", "Zofran Ondansetron danset danasetron danofran emerest ondametic zofatrone 2mg/ml ampoule", gitColor(context), "nausea Vomiting Hyperemesis Gravidarum Rosacea Cholestatic Pruritus Spinal Opioid-Induced Pruritus Selective 5-HT3 Antagonists antiemetic agents");
    addItem ("Zofran syrup", "Ondansetron 4 mg /5 ml", "zofran ondansetron 4mg/5ml syrup", gitColor(context), "nausea Vomiting Rosacea Cholestatic Pruritus Spinal Opioid-Induced Pruritus uremic pruritus Selective 5-HT3 Antagonists antiemetic agents");
    addItem ("Zolidocyrl tab", "Tedizolid 200 mg", "Zolidocyrl Tedizolid phosphate cubizolid tedimerp 200mg tablets", abColor(context), "Skin Infections Oxazolidinones");
    addItem ("Zonactam vial", "Cefoperazone 1 gm +Sulbactam 0.5 gm", "zonactam cefoperazone sulbactam bactirix cefoctam peractam sulbacef sulperazon trexotaz 1500mg 1.5gm vial", abColor(context), "respiratory urti lrti uti urinary tract cystitis pyelonephritis intra-abdominal septicemia Meningitis skin bone infections PID pelvic inflammatory disease Pneumonia Sepsis 3rd third generation cephalosporins");
    addItem ("Zovirax 400 susp", "Acyclovir 400 mg /5 ml", "Zovirax AcyclovirAl 400mg/5ml suspension", abColor(context), "Chickenpox shingles Genital Herpes varicella Zoster antivirals");
    addItem ("Zovirax 250 vial", "Acyclovir 250 mg", "Zovirax Acyclovir aciclovir supraviran 250mg vial", abColor(context), "Neonatal Mucocutaneous Herpes Simplex Encephalitis shingles Chickenpox varicella zoster antivirals");
    addItem ("Zovirax 500 vial", "Acyclovir 500 mg", "Zovirax Acyclovir aciclovir mylan 500mg vial", abColor(context), "Neonatal Mucocutaneous Herpes Simplex Encephalitis shingles Chickenpox varicella zoster antivirals");
    addItem ("Zyloric 100 tab", "Allopurinol 100 mg", "zyloric allopurinol lessuric nouric no-uric pure 100mg tablets", otherColor(context), "Antineoplastic-induced Hyperuricemia antigout agents");
    addItem ("Zyloric 300 tab", "Allopurinol 300 mg", "zyloric allopurinol lessuric nouric no-uric pure crystasol purinol 300mg tablets capsules", otherColor(context), "Antineoplastic-induced Hyperuricemia antigout agents");
    addItem ("Zyprexa 5 tab", "Olanzapine 5 mg", "zyprexa olanzapine integrol olapex prexal schisolazine 5mg tablets", cnsColor(context), "agitation associated with schizophrenia and bipolar i mania depression antidepressants chemotherapy associated nausea vomiting stuttering antipsychotics");
    addItem ("Zyprexa 7.5 tab", "Olanzapine 7.5 mg", "zyprexa olanzapine bioprex 7.5mg tablets", cnsColor(context), "agitation associated with schizophrenia and bipolar i mania depression antidepressants chemotherapy associated nausea vomiting stuttering antipsychotics");
    addItem ("Zyprexa 10 tab", "Olanzapine 10 mg", "zyprexa olanzapine integrol olapex olazine schisolazine 10mg tablets", cnsColor(context), "agitation associated with schizophrenia and bipolar i mania depression antidepressants chemotherapy associated nausea vomiting stuttering antipsychotics");
    addItem ("Zyrtec drops", "Cetirizine 10 mg /1 ml", "Zyrtec Cetirizine histazine alerid 10mg/ml drops", resColor(context), "Allergies Hay fever Urticaria allergy 2nd second generation antihistamines");
    addItem ("Zyrtec syrup", "Cetirizine 5 mg /5 ml", "Zyrtec Cetirizine alerid cetritin epirizine histazine lergfree tomazine cetrak 5mg/5ml syrup", resColor(context), "Allergies Hay fever Urticaria allergy 2nd second generation antihistamines");
    addItem ("Zyrtec tab", "Cetirizine 10 mg", "Zyrtec Cetirizine alerid cetritin epirizine histazine cetrichew histachew tomazine cetrak 10mg tablets", resColor(context), "Allergies Hay fever Urticaria allergy 2nd second generation antihistamines");
    addItem ("Zyrovazet tab", "Rosuvastatin +Ezetimibe", "zyrovazet rosuvastatin Ezetimibe cholerose plus lipocomb tablets", cvsColor(context), "Homozygous Familial hypercholesterolemia Hyperlipidemia HMG-CoA Reductase Inhibitor Statins Antilipemic Agents");
    addItem ("Zytiga 250 tab", "Abiraterone 250 mg", "zytiga Abiraterone mantroxate 250mg 500mg tablets", otherColor(context), "Prostate Cancer antineoplastic agents");
  }

  void buttonClickShortcut (String title, String generic) {
    searchEditFocus.unfocus(); weightFocus.unfocus(); crclFocus.unfocus(); gerFocus.unfocus(); postNataFocus.unfocus();
    bool result = drugsNeedWeight.any((string) => generic.toLowerCase().contains(string.toLowerCase()));
    if (comingFromInjections) {
      comingFromInjections = false;
      if (result) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text("Confirm weight"),
              content: Text("This drug require the actual weight for the dose to be calculated accurately.\n\nAre you sure that the weight of the patient is ${removeDecimalIfZero(myVar)} kg?"),
              actions: [
                TextButton(onPressed: () {
                  Navigator.of(context).pop();
                  if (myVar > 0) {
                    points = points-1;
                    if (points < 0) points = 0;
                    savePoints(points);
                  }
                  buttonClickShortcutFinal(title, generic);
                }, child: const Text("Yes, continue"),
                ),
                TextButton(onPressed: () {
                  Navigator.of(context).pop();
                }, child: const Text("No, go back"),
                ),
              ],
            );
          },
        );
      }
      else {
        if (myVar > 0) {
          points = points-1;
          if (points < 0) points = 0;
          savePoints(points);
        }
        buttonClickShortcutFinal(title, generic);
      }
    }
    else {
      if (result) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text("Confirm weight"),
              content: Text("This drug require the actual weight for the dose to be calculated accurately.\n\nAre you sure that the weight of the patient is ${removeDecimalIfZero(myVar)} kg?"),
              actions: [
                TextButton(onPressed: () {
                  Navigator.of(context).pop();
                  buttonClickShortcutFinal(title, generic);
                }, child: const Text("Yes, continue"),
                ),
                TextButton(onPressed: () {
                  Navigator.of(context).pop();
                }, child: const Text("No, go back"),
                ),
              ],
            );
          },
        );
      }
      else {
        buttonClickShortcutFinal(title, generic);
      }
    }
  }

  void buttonClickShortcutFinal (String title, String generic) {
    if ((modeVar == "normal" && selectedAge == 0) || (modeVar == "renal" && selectedAge == 0) || (modeVar == "hepatic" && selectedAge == 0)) {
      BotToast.showText(text: "Please select age"); setState(() {ageBorder = Colors.red;});
    }
    else {
      if (myVar == 0) {
        BotToast.showText(text: "Please enter weight"); setState(() {weightBorder = Colors.red;});
      }
      else {
        if (modeVar == "renal" && crcl == 0) {
          BotToast.showText(text: "Please enter CrCl value"); setState(() {crclBorder = Colors.red;});
        }
        else {
          if (modeVar == "geriatric" && gerAge < 60) {
            BotToast.showText(text: "Please enter valid age"); setState(() {gerBorder = Colors.red;});
          }
          else {
            Future.delayed(const Duration(milliseconds: 400), () async {
              searchEditFocus.unfocus(); weightFocus.unfocus(); crclFocus.unfocus(); gerFocus.unfocus(); postNataFocus.unfocus();
              showInterstitialEvery3Sec = showInterstitialEvery3Sec + 1;
              final returnedAlt = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) =>  DosePage(mode: selectedMode, title: title, generic: generic, weight: myVar, selectedAge: selectedAgeTextVar, selectedAgeNum: selectedAge, gestAge: selectedGestAgeVar, gestNum: gestAgeNumber, pretermAge: pretermAge, crcl: crcl, gerAge: gerAge, pugh: pughScore, dialysis: selectedDialysis, returnedAlt: '', premium: premiumTo, unityBannerID: unityBannerID, shdone: shdo)),
              );
              showInterstitial();
              if (returnedAlt != null) {
                if (favContentDescription == "active") {
                  setState(() {
                    favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
                    favDrugListV = false; sortManually = false;
                    mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
                    favAddTextV = false;
                    filterBannerV = true; bannerHeight = 45;
                  });}
                if (searchHint == "search by indication") { searchHint = 'search trade or generic name';}
                setState(() {
                  searchEditText.text = returnedAlt.toString().replaceAll("+", " ");
                  if (saveSearchChecked) {
                    SharedPreferences.getInstance().then((prefs) {
                      prefs.setString(saveSearchCheckboxValue, searchEditText.text);
                    });
                  } else {
                    SharedPreferences.getInstance().then((prefs) {
                      prefs.setString(saveSearchCheckboxValue, '');
                    });
                  }
                  showAllDrugsShortcut();
                  filterItemsByName(returnedAlt.toString().replaceAll("+", " "));
                });
              }
            });
          }
        }
      }
    }
  }

  void injectionClickShortcut (final String title, final String generic) {
    if (!premium && points < 1) {
      if (Platform.isIOS || Platform.isAndroid) {watchVideoV = true;}
      else {watchVideoV = false;}
      adPayDiag();
    }
    else {
      comingFromInjections = true;
      buttonClickShortcut (title, generic);
    }
  }

  void getDose () {
    if (selectedDrug.toLowerCase().startsWith('a') || selectedDrug.toLowerCase().startsWith('b') || selectedDrug.toLowerCase().startsWith('c')) {
      getDoseABC();
    } else if (selectedDrug.toLowerCase().startsWith('d') || selectedDrug.toLowerCase().startsWith('e') || selectedDrug.toLowerCase().startsWith('f') || selectedDrug.toLowerCase().startsWith('g') || selectedDrug.toLowerCase().startsWith('h') || selectedDrug.toLowerCase().startsWith('i')) {
      getDoseDEFGHI();
    } else if (selectedDrug.toLowerCase().startsWith('j') || selectedDrug.toLowerCase().startsWith('k') || selectedDrug.toLowerCase().startsWith('l') || selectedDrug.toLowerCase().startsWith('m') || selectedDrug.toLowerCase().startsWith('n') || selectedDrug.toLowerCase().startsWith('o')) {
      getDoseJKLMNO();
    } else if (selectedDrug.toLowerCase().startsWith('p') || selectedDrug.toLowerCase().startsWith('q') || selectedDrug.toLowerCase().startsWith('r') || selectedDrug.toLowerCase().startsWith('s') || selectedDrug.toLowerCase().startsWith('t') || selectedDrug.toLowerCase().startsWith('u') || selectedDrug.toLowerCase().startsWith('v') || selectedDrug.toLowerCase().startsWith('w') || selectedDrug.toLowerCase().startsWith('x') || selectedDrug.toLowerCase().startsWith('y') || selectedDrug.toLowerCase().startsWith('z')) {
      getDosePQRSTUVWXYZ();
    }

  }

  void getDoseABC () {
    if (selectedDrug == "A-viton cap") {buttonClickShortcut("A-viton cap", "Vitamin A 50000 IU");}
    else if (selectedDrug == "Abilaxine 10 supp") {buttonClickShortcut("Abilaxine 10 supp", "Bisacodyl 10 mg");}
    else if (selectedDrug == "Abimol supp") {buttonClickShortcut("Abimol supp", "Paracetamol 300 mg");}
    else if (selectedDrug == "Abimol syrup") {buttonClickShortcut("Abimol syrup", "Paracetamol 150 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Abstral sublingual tab") {buttonClickShortcut("Abstral sublingual tab", "Fentanyl 100/200/400 mcg");}
    else if (selectedDrug == "Acapril 5 tab") {buttonClickShortcut("Acapril 5 tab", "Enalapril 5 mg");}
    else if (selectedDrug == "Acetapax sach") {buttonClickShortcut("Acetapax sach", "N-Acetylcysteine 300 mg + Thyme 100 mg + Vit C 80 mg");}
    else if (selectedDrug == "Acetylcistein 200 sach") {buttonClickShortcut("Acetylcistein 200 sach", "Acetylcysteine 200 mg");}
    else if (selectedDrug == "Acetylcistein 600 sach") {buttonClickShortcut("Acetylcistein 600 sach", "Acetylcysteine 600 mg");}
    else if (selectedDrug == "Achtenon tab") {buttonClickShortcut("Achtenon tab", "Biperiden 2 mg");}
    else if (selectedDrug == "Aciloc 75 tab") {buttonClickShortcut("Aciloc 75 tab", "Ranitidine 75 mg");}
    else if (selectedDrug == "Acitretin 10 cap") {buttonClickShortcut("Acitretin 10 cap", "Acitretin 10 mg");}
    else if (selectedDrug == "Acitretin 25 cap") {buttonClickShortcut("Acitretin 25 cap", "Acitretin 25 mg");}
    else if (selectedDrug == "Acti-folic tab") {buttonClickShortcut("Acti-folic tab", "L-methylfolate 1 mg");}
    else if (selectedDrug == "Actifed syrup") {buttonClickShortcut("Actifed syrup", "Pseudoephedrine 30 mg + Triprolidine 1.25 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Actifed expectorant syrup") {buttonClickShortcut("Actifed expectorant syrup", "Pseudoephedrine 30 mg + Triprolidine 1.25 mg + Guaifenesin 100 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Actifed tab") {buttonClickShortcut("Actifed tab", "Pseudoephedrine 60 mg + Triprolidine 2.5 mg");}
    else if (selectedDrug == "Actilyse vial") {injectionClickShortcut("Actilyse vial", "Alteplase 50 mg");}
    else if (selectedDrug == "Actonel 5 tab") {buttonClickShortcut("Actonel 5 tab", "Risedronate 5 mg");}
    else if (selectedDrug == "Actonel 35 tab") {buttonClickShortcut("Actonel 35 tab", "Risedronate 35 mg");}
    else if (selectedDrug == "Actos 15 tab") {buttonClickShortcut("Actos 15 tab", "Pioglitazone 15 mg");}
    else if (selectedDrug == "Actrapid HM vial") {injectionClickShortcut("Actrapid HM vial", "Insulin Regular Human 100 units / ml");}
    else if (selectedDrug == "Adancor 10 tab") {buttonClickShortcut("Adancor 10 tab", "Nicorandil 10 mg");}
    else if (selectedDrug == "Adol Sinus tab") {buttonClickShortcut("Adol Sinus tab", "Paracetamol 325 mg + Pseudoephedrine 30 mg");}
    else if (selectedDrug == "Adrenaline amp") {injectionClickShortcut("Adrenaline amp", "Adrenaline 1 mg / 1 ml (1/1000)");}
    else if (selectedDrug == "Adrenocortine amp") {injectionClickShortcut("Adrenocortine amp", "Tetracosactide 1 mg / 1 ml");}
    else if (selectedDrug == "Adwipril 4 tab") {buttonClickShortcut("Adwipril 4 tab", "Perindopril 4 mg");}
    else if (selectedDrug == "Aggrastat vial") {injectionClickShortcut("Aggrastat vial", "Tirofiban 12.5 mg / 50 ml");}
    else if (selectedDrug == "Agiolax sach") {buttonClickShortcut("Agiolax sach", "Ispaghula Husk + Plantago Seed + Senna");}
    else if (selectedDrug == "Agnucaston tab") {buttonClickShortcut("Agnucaston tab", "Dry extract of the fruit of the chaste tree (Agni Casti Fructus) 20 mg");}
    else if (selectedDrug == "Aironyl syrup") {buttonClickShortcut("Aironyl syrup", "Terbutaline 1.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Aironyl tab") {buttonClickShortcut("Aironyl tab", "Terbutaline 2.5 mg");}
    else if (selectedDrug == "Alambuphine amp") {injectionClickShortcut("Alambuphine amp", "Nalbuphine 20 mg / 2 ml");}
    else if (selectedDrug == "Aldactazide 25/25 tab") {buttonClickShortcut("Aldactazide 25/25 tab", "Spironolactone 25 mg + Hydrochlorothiazide 25 mg");}
    else if (selectedDrug == "Aldactone 25 tab") {buttonClickShortcut("Aldactone 25 tab", "Spironolactone 25 mg");}
    else if (selectedDrug == "Aldomet 250 tab") {buttonClickShortcut("Aldomet 250 tab", "Methyldopa 250 mg");}
    else if (selectedDrug == "Alemox 750 tab") {buttonClickShortcut("Alemox 750 tab", "Amoxicillin 750 mg");}
    else if (selectedDrug == "Alemox 1 gm tab") {buttonClickShortcut("Alemox 1 gm tab", "Amoxicillin 1 gm");}
    else if (selectedDrug == "Alergoliber syrup") {buttonClickShortcut("Alergoliber syrup", "Rupatadine 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Alergoliber tab") {buttonClickShortcut("Alergoliber tab", "Rupatadine 10 mg");}
    else if (selectedDrug == "Alertam 60 tab") {buttonClickShortcut("Alertam 60 tab", "Fexofenadine 60 mg");}
    else if (selectedDrug == "Alertam 120 tab") {buttonClickShortcut("Alertam 120 tab", "Fexofenadine 120 mg");}
    else if (selectedDrug == "Alertam 180 tab") {buttonClickShortcut("Alertam 180 tab", "Fexofenadine 180 mg");}
    else if (selectedDrug == "Alertam susp") {buttonClickShortcut("Alertam susp", "Fexofenadine 30 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Alexoquine tab") {buttonClickShortcut("Alexoquine tab", "Chloroquine Phosphate 250 mg");}
    else if (selectedDrug == "Alfaclindamycin amp") {injectionClickShortcut("Alfaclindamycin amp", "Clindamycin 600 mg / 4 ml Or\nClindamycin 300 mg / 2 ml");}
    else if (selectedDrug == "All-Vent syrup") {buttonClickShortcut("All-Vent syrup", "Terbutaline 1.25 mg + Bromhexine 4 mg + Guaifenesin 50 mg + Menthol 2.5 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Allerban tab") {buttonClickShortcut("Allerban tab", "Ketotifen 2 mg");}
    else if (selectedDrug == "Allergex tab") {buttonClickShortcut("Allergex tab", "Chlorphenoxamine 20 mg");}
    else if (selectedDrug == "Allergyl syrup") {buttonClickShortcut("Allergyl syrup", "Chlorpheniramine 2 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Allergyl tab") {buttonClickShortcut("Allergyl tab", "Chlorpheniramine 4 mg");}
    else if (selectedDrug == "Alphavim 300 cap") {buttonClickShortcut("Alphavim 300 cap", "Alpha Lipoic Acid 300 mg + Vit B6 15 mg + Vit B12 0.5 mg + Folic Acid 0.8 mg + Ginko Biloba 120 mg + Bacopa extract 150 mg");}
    else if (selectedDrug == "Alphavim 600 cap") {buttonClickShortcut("Alphavim 600 cap", "Alpha Lipoic Acid 600 mg + Vit B6 15 mg + Vit B12 0.5 mg + Folic Acid 0.8 mg + Ginko Biloba 120 mg + Bacopa extract 150 mg");}
    else if (selectedDrug == "Alphintern tab") {buttonClickShortcut("Alphintern tab", "Chymotrypsin 5 mg + Trypsin 5 mg");}
    else if (selectedDrug == "Alveolin syrup") {buttonClickShortcut("Alveolin syrup", "Grindelia + Primula + Pimpinella + Thyme + Flora Rose + Eucalyptus\n(100 ml)");}
    else if (selectedDrug == "Alveolin-P syrup") {buttonClickShortcut("Alveolin-P syrup", "Grindelia + Primula + Pimpinella + Thyme + Flora Rose + Anise\n(100 ml)");}
    else if (selectedDrug == "Alzental susp") {buttonClickShortcut("Alzental susp", "Albendazole 100 mg / 5 ml\n(20 ml)");}
    else if (selectedDrug == "Alzental tab") {buttonClickShortcut("Alzental tab", "Albendazole 200 mg");}
    else if (selectedDrug == "Alzmenda drops") {buttonClickShortcut("Alzmenda drops", "Memantine 10 mg / 1 ml\n(20 ml)");}
    else if (selectedDrug == "Alzmenda 5 tab") {buttonClickShortcut("Alzmenda 5 tab", "Memantine 5 mg");}
    else if (selectedDrug == "Ambisome vial") {injectionClickShortcut("Ambisome vial", "Amphotericin B Liposomal 50 mg");}
    else if (selectedDrug == "Ambroxol 30 tab") {buttonClickShortcut("Ambroxol 30 tab", "Ambroxol 30 mg");}
    else if (selectedDrug == "Ambroxol 75 cap") {buttonClickShortcut("Ambroxol 75 cap", "Ambroxol 75 mg");}
    else if (selectedDrug == "Ambroxol drops") {buttonClickShortcut("Ambroxol drops", "Ambroxol 7.5 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Ambroxol syrup") {buttonClickShortcut("Ambroxol syrup", "Ambroxol 15 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Amebazole tab") {buttonClickShortcut("Amebazole tab", "Secnidazole 1 gm");}
    else if (selectedDrug == "Amigraine tab") {buttonClickShortcut("Amigraine tab", "Caffeine 100 mg + Dipyrone (Metamizole) 300 mg + Ergotamine 1 mg");}
    else if (selectedDrug == "Amigrawest tab") {buttonClickShortcut("Amigrawest tab", "Zolmitriptan 2.5 mg");}
    else if (selectedDrug == "Amikacin 100 vial") {injectionClickShortcut("Amikacin 100 vial", "Amikacin 100 mg / 2 ml");}
    else if (selectedDrug == "Amikacin 250 vial") {injectionClickShortcut("Amikacin 250 vial", "Amikacin 250 mg / 2 ml");}
    else if (selectedDrug == "Amikacin 500 vial") {injectionClickShortcut("Amikacin 500 vial", "Amikacin 500 mg / 2 ml");}
    else if (selectedDrug == "Aminoleban solution") {injectionClickShortcut("Aminoleban solution", "L-Threonine + L-Serine + L-Proline + L-Cysteine HCl.H2O + Aminoacetic acid + L-Alanine + L-Valine + L-Methionine + L-Isoleucine + L-Leucine + L-Phenylalanine + L-Tryptophan + L-Histidine HCl.H2O + Lysine HCl + L-Arginine HCl");}
    else if (selectedDrug == "Amipride 50 tab") {buttonClickShortcut("Amipride 50 tab", "Amisulpride 50 mg");}
    else if (selectedDrug == "Amiprostone 8 cap") {buttonClickShortcut("Amiprostone 8 cap", "Lubiprostone 8 mcg");}
    else if (selectedDrug == "Amiprostone 24 cap") {buttonClickShortcut("Amiprostone 24 cap", "Lubiprostone 24 mcg");}
    else if (selectedDrug == "Amitriptine 50 tab") {buttonClickShortcut("Amitriptine 50 tab", "Amitriptyline 50 mg");}
    else if (selectedDrug == "Amocerebral Plus tab") {buttonClickShortcut("Amocerebral Plus tab", "Cinnarizine 20 mg + Dimenhydrinate 40 mg");}
    else if (selectedDrug == "Amosar 50 tab") {buttonClickShortcut("Amosar 50 tab", "Losartan 50 mg");}
    else if (selectedDrug == "Amoxil 125 susp") {buttonClickShortcut("Amoxil 125 susp", "Amoxicillin 125 mg / 5 ml \n(60 ml & 100 ml)");}
    else if (selectedDrug == "Amoxil 250 susp") {buttonClickShortcut("Amoxil 250 susp", "Amoxicillin 250 mg / 5 ml \n(60 ml & 100 ml)");}
    else if (selectedDrug == "Ampicillin 125 susp") {buttonClickShortcut("Ampicillin 125 susp", "Ampicillin 125 mg / 5 ml \n(30 ml & 60 ml)");}
    else if (selectedDrug == "Ampicillin 250 susp") {buttonClickShortcut("Ampicillin 250 susp", "Ampicillin 250 mg / 5 ml \n(60 ml)");}
    else if (selectedDrug == "Ampicillin 250 cap") {buttonClickShortcut("Ampicillin 250 cap", "Ampicillin 250 mg");}
    else if (selectedDrug == "Ampicillin 500 cap") {buttonClickShortcut("Ampicillin 500 cap", "Ampicillin 500 mg");}
    else if (selectedDrug == "Ampicillin 250 vial") {injectionClickShortcut("Ampicillin 250 vial", "Ampicillin 250 mg");}
    else if (selectedDrug == "Ampicillin 500 vial") {injectionClickShortcut("Ampicillin 500 vial", "Ampicillin 500 mg");}
    else if (selectedDrug == "Ampicillin 1 gm vial") {injectionClickShortcut("Ampicillin 1 gm vial", "Ampicillin 1 gm");}
    else if (selectedDrug == "Ampiflux cap") {buttonClickShortcut("Ampiflux cap", "Ampicillin 250 mg + Flucloxacillin 250 mg");}
    else if (selectedDrug == "Ampiflux susp") {buttonClickShortcut("Ampiflux susp", "Ampicillin 125 mg + Flucloxacillin 125 mg / 5 ml \n(60 ml)");}
    else if (selectedDrug == "Amri-K amp") {injectionClickShortcut("Amri-K amp", "Vitamin K1 10 mg / 1 ml");}
    else if (selectedDrug == "Amrizole 250 tab") {buttonClickShortcut("Amrizole 250 tab", "Metronidazole 250 mg");}
    else if (selectedDrug == "Amrizole 500 tab") {buttonClickShortcut("Amrizole 500 tab", "Metronidazole 500 mg");}
    else if (selectedDrug == "Amrizole susp") {buttonClickShortcut("Amrizole susp", "Metronidazole 125 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Anafronil 25 tab") {buttonClickShortcut("Anafronil 25 tab", "Clomipramine 25 mg");}
    else if (selectedDrug == "Andogonium syrup") {buttonClickShortcut("Andogonium syrup", "Pelargonium Sidoides 13.3 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Andovimpamide syrup") {buttonClickShortcut("Andovimpamide syrup", "Lacosamide 50 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Andovimpamide 50 tab") {buttonClickShortcut("Andovimpamide 50 tab", "Lacosamide 50 mg");}
    else if (selectedDrug == "Andovimpamide vial") {injectionClickShortcut("Andovimpamide vial", "Lacosamide 10 mg / 1 ml");}
    else if (selectedDrug == "Androcur tab") {buttonClickShortcut("Androcur tab", "Cyproterone 50 mg");}
    else if (selectedDrug == "Anexate amp") {injectionClickShortcut("Anexate amp", "Flumazenil 0.5 mg / 5 ml");}
    else if (selectedDrug == "Angiofox 25 PR cap") {buttonClickShortcut("Angiofox 25 PR cap", "Isosorbide Mononitrate 25 mg)");}
    else if (selectedDrug == "Angiosartan 10 tab") {buttonClickShortcut("Angiosartan 10 tab", "Olmesartan 10 mg");}
    else if (selectedDrug == "Angiosartan Plus tab") {buttonClickShortcut("Angiosartan Plus tab", "Olmesartan +Hydrochlorothiazide\n(20 / 12.5)\n(40 / 12.5)\n(20 / 25)\n(40 / 25)");}
    else if (selectedDrug == "Anschlarin syrup") {buttonClickShortcut("Anschlarin syrup", "Ferric Fumarate 140 mg (Elemental Iron 45 mg) / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Antiflu cap") {buttonClickShortcut("Antiflu cap", "Ibuprofen 200 mg + Pseudoephedrine 60 mg + Chlorpheniramine 3 mg +Caffeine 25 mg");}
    else if (selectedDrug == "Antinal cap") {buttonClickShortcut("Antinal cap", "Nifuroxazide 200 mg");}
    else if (selectedDrug == "Antinal susp") {buttonClickShortcut("Antinal susp", "Nifuroxazide 220 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Antiver susp") {buttonClickShortcut("Antiver susp", "Mebendazole 100 mg / 5 ml\n(30 ml)");}
    else if (selectedDrug == "Antiver tab") {buttonClickShortcut("Antiver tab", "Mebendazole 100 mg");}
    else if (selectedDrug == "Antodine 10 tab") {buttonClickShortcut("Antodine 10 tab", "Famotidine 10 mg");}
    else if (selectedDrug == "Antodine 20 tab") {buttonClickShortcut("Antodine 20 tab", "Famotidine 20 mg");}
    else if (selectedDrug == "Antodine 40 tab") {buttonClickShortcut("Antodine 40 tab", "Famotidine 40 mg");}
    else if (selectedDrug == "Antodine amp") {injectionClickShortcut("Antodine amp", "Famotidine 20 mg /2 ml");}
    else if (selectedDrug == "Antodine susp") {buttonClickShortcut("Antodine susp", "Famotidine 40 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Antox tab") {buttonClickShortcut("Antox tab", "Selenium + Vit A + Vit C + Vit E");}
    else if (selectedDrug == "Apetryl 0.5 tab") {buttonClickShortcut("Apetryl 0.5 tab", "Clonazepam 0.5 mg");}
    else if (selectedDrug == "Apexidone syrup") {buttonClickShortcut("Apexidone syrup", "Risperidone 1 mg / 1 ml\n(100 ml)");}
    else if (selectedDrug == "Apexidone 0.5 tab") {buttonClickShortcut("Apexidone 0.5 tab", "Risperidone 0.5 mg");}
    else if (selectedDrug == "Apidone syrup") {buttonClickShortcut("Apidone syrup", "Dexamethasone 0.5 mg + Chlorpheniramine 2 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Apidra cartridges/prefilled pen") {injectionClickShortcut("Apidra cartridges/prefilled pen", "Insulin Glulisine 100 units / ml");}
    else if (selectedDrug == "Apifortyl cap") {buttonClickShortcut("Apifortyl cap", "Vit A + Vit B1 + Vit B2 + Vit B6 + Vit B12 + Vit C + Vit D3 + Vit E + Folic Acid + Nicotinic Acid + Calcium Pantothenate + Biotin + CU + Co + Mn + Royal Jelly + Biopterin");}
    else if (selectedDrug == "Apo-Mefloquine tab") {buttonClickShortcut("Apo-Mefloquine tab", "Mefloquine 250 mg");}
    else if (selectedDrug == "Appe-raise syrup") {buttonClickShortcut("Appe-raise syrup", "Menthol 2% + Thymol 1% + Pinene 100 mg + Camphene 50 mg + Anise 200 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Apple-Lite tab") {buttonClickShortcut("Apple-Lite tab", "Apple Fibers 500 mg + Apple Pectin 50 mg");}
    else if (selectedDrug == "Apresoline amp") {injectionClickShortcut("Apresoline amp", "Hydralazine 20 mg");}
    else if (selectedDrug == "Apresoline 25 tab") {buttonClickShortcut("Apresoline 25 tab", "Hydralazine 25 mg");}
    else if (selectedDrug == "Apresoline 50 tab") {buttonClickShortcut("Apresoline 50 tab", "Hydralazine 50 mg");}
    else if (selectedDrug == "Aqua Plus syrup") {buttonClickShortcut("Aqua Plus syrup", "Chamomile + Dill Oil + Sodium Bicarbonate + Caraway Oil + Fennel Oil");}
    else if (selectedDrug == "Arcalion tab") {buttonClickShortcut("Arcalion tab", "Sulbutiamine 200 mg");}
    else if (selectedDrug == "Arcoxia 60 tab") {buttonClickShortcut("Arcoxia 60 tab", "Etoricoxib 60 mg");}
    else if (selectedDrug == "Arcoxia 90 tab") {buttonClickShortcut("Arcoxia 90 tab", "Etoricoxib 90 mg");}
    else if (selectedDrug == "Aricept 5 tab") {buttonClickShortcut("Aricept 5 tab", "Donepezil 5 mg");}
    else if (selectedDrug == "Aripiprazole 5 tab") {buttonClickShortcut("Aripiprazole 5 tab", "Aripiprazole 5 mg");}
    else if (selectedDrug == "Aripiprex syrup") {buttonClickShortcut("Aripiprex syrup", "Aripiprazole 1 mg / 1 ml\n(100 ml)");}
    else if (selectedDrug == "Arixtra prefilled syringe") {injectionClickShortcut("Arixtra prefilled syringe", "Fondaparinux\n2.5 mg / 0.5 ml\n5 mg / 0.4 ml\n7.5 mg / 0.6 ml\n10 mg / 0.8 ml");}
    else if (selectedDrug == "Armowake 50 tab") {buttonClickShortcut("Armowake 50 tab", "Armodafinil 50 mg");}
    else if (selectedDrug == "Armowake 150 tab") {buttonClickShortcut("Armowake 150 tab", "Armodafinil 150 mg");}
    else if (selectedDrug == "Artec tab") {buttonClickShortcut("Artec tab", "Chondroitin 500 mg + Glucosamine 500 mg");}
    else if (selectedDrug == "Arthineur cap") {buttonClickShortcut("Arthineur cap", "Diclofenac Na 50 mg + Vit B1 50 mg + Vit B6 50 mg + Vit B12 0.25 mg");}
    else if (selectedDrug == "Arthrofast 150 SR tab") {buttonClickShortcut("Arthrofast 150 SR tab", "Diclofenac Sodium 150 mg");}
    else if (selectedDrug == "Aspocid 75 tab") {buttonClickShortcut("Aspocid 75 tab", "Acetylsalicylic Acid 75 mg");}
    else if (selectedDrug == "Aspocid 300 tab") {buttonClickShortcut("Aspocid 300 tab", "Acetylsalicylic Acid 300 mg");}
    else if (selectedDrug == "Aspirin Protect tab") {buttonClickShortcut("Aspirin Protect tab", "Acetylsalicylic Acid 100 mg");}
    else if (selectedDrug == "Aspirin 500 tab") {buttonClickShortcut("Aspirin 500 tab", "Acetylsalicylic Acid 500 mg");}
    else if (selectedDrug == "Asthmarelief 2.5 nebulizer solution") {buttonClickShortcut("Asthmarelief 2.5 nebulizer solution", "Salbutamol 0.1% (2.5 mg /2.5 ml)");}
    else if (selectedDrug == "Asthmarelief 5 nebulizer solution") {buttonClickShortcut("Asthmarelief 5 nebulizer solution", "Salbutamol 0.2% (5 mg /2.5 ml)");}
    else if (selectedDrug == "Atacand 4 tab") {buttonClickShortcut("Atacand 4 tab", "Candesartan 4 mg");}
    else if (selectedDrug == "Atacand Plus tab") {buttonClickShortcut("Atacand Plus tab", "Candesartan +Hydrochlorothiazide\n(16 / 12.5)\n(32 / 12.5)\n(32 / 25)");}
    else if (selectedDrug == "Atconafil 100 tab") {buttonClickShortcut("Atconafil 100 tab", "Avanafil 100 mg");}
    else if (selectedDrug == "Atenoretic cap") {buttonClickShortcut("Atenoretic cap", "Atenolol 50 mg + Hydrochlorothiazide 25 mg + Amiloride 25 mg");}
    else if (selectedDrug == "Atimos inhalation solution") {buttonClickShortcut("Atimos inhalation solution", "Formoterol Fumarate 12 mcg");}
    else if (selectedDrug == "Ativan tab") {buttonClickShortcut("Ativan tab", "Lorazepam 1 mg");}
    else if (selectedDrug == "Atomorelax syrup") {buttonClickShortcut("Atomorelax syrup", "Atomoxetine 20 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Atomox apex 10 cap") {buttonClickShortcut("Atomox apex 10 cap", "Atomoxetine 10 mg");}
    else if (selectedDrug == "Ator 10 tab") {buttonClickShortcut("Ator 10 tab", "Atorvastatin 10 mg");}
    else if (selectedDrug == "Atoreza tab") {buttonClickShortcut("Atoreza tab", "Atorvastatin + Ezetimibe\n(10 / 10)\n(20 / 10)\n(40 / 10)");}
    else if (selectedDrug == "Atropine amp") {injectionClickShortcut("Atropine amp", "Atropine Sulphate 1 mg / 1 ml");}
    else if (selectedDrug == "Atrovent 0.25 nebulizer solution") {buttonClickShortcut("Atrovent 0.25 nebulizer solution", "Ipratropium Bromide 250 mcg / 2 ml");}
    else if (selectedDrug == "Atrovent 0.5 nebulizer solution") {buttonClickShortcut("Atrovent 0.5 nebulizer solution", "Ipratropium Bromide 500 mcg / 2 ml");}
    else if (selectedDrug == "Augmentin 62.5 drops") {buttonClickShortcut("Augmentin 62.5 drops", "Amoxicillin 50 mg + Clavulanate 12.5 mg / 1 ml \n(20 ml)");}
    else if (selectedDrug == "Augmentin 156.25 susp") {buttonClickShortcut("Augmentin 156.25 susp", "Amoxicillin 125 mg + Clavulanate 31.25 mg / 5 ml \n(80 ml)");}
    else if (selectedDrug == "Augmentin duo 228.5 susp") {buttonClickShortcut("Augmentin 228.5 susp", "Amoxicillin 200 mg + Clavulanate 28.5 mg/ 5 ml \n(70 ml)");}
    else if (selectedDrug == "Augmentin 312.5 susp") {buttonClickShortcut("Augmentin 312.5 susp", "Amoxicillin 250 mg + Clavulanate 62.5 mg / 5 ml \n(80 ml)");}
    else if (selectedDrug == "Augmentin 457 susp") {buttonClickShortcut("Augmentin 457 susp", "Amoxicillin 400 mg + Clavulanate 57 mg / 5 ml \n(70 ml)");}
    else if (selectedDrug == "Augmentin ES 600 susp") {buttonClickShortcut("Augmentin ES 600 susp", "Amoxicillin 600 mg + Clavulanate 42.9 mg / 5 ml \n(75 ml)");}
    else if (selectedDrug == "Augmentin 375 tab") {buttonClickShortcut("Augmentin 375 tab", "Amoxicillin 250 mg + Clavulanate 125 mg");}
    else if (selectedDrug == "Augmentin 625 tab") {buttonClickShortcut("Augmentin 625 tab", "Amoxicillin 500 mg + Clavulanate 125 mg");}
    else if (selectedDrug == "Augmentin 1 gm tab") {buttonClickShortcut("Augmentin 1 gm tab", "Amoxicillin 875 mg + Clavulanate 125 mg");}
    else if (selectedDrug == "Augmentin 600 vial") {injectionClickShortcut("Augmentin 600 vial", "Amoxicillin 500 mg + Clavulanic acid 100 mg");}
    else if (selectedDrug == "Augmentin 1.2 gm vial") {injectionClickShortcut("Augmentin 1.2 gm vial", "Amoxicillin 1000 mg + Clavulanic acid 200 mg");}
    else if (selectedDrug == "Avastin vial") {injectionClickShortcut("Avastin vial", "Bevacizumab 100 mg / 4 ml\nBevacizumab 400 mg / 16 ml");}
    else if (selectedDrug == "Averozolid susp") {buttonClickShortcut("Averozolid susp", "Linezolid 100 mg / 5 ml\n(60 ml & 150 ml)");}
    else if (selectedDrug == "Averozolid tab") {buttonClickShortcut("Averozolid tab", "Linezolid 600 mg");}
    else if (selectedDrug == "Averozolid vial") {injectionClickShortcut("Averozolid vial", "Linezolid 2 mg / ml");}
    else if (selectedDrug == "Avil amp") {injectionClickShortcut("Avil amp", "Pheniramine 45.5 mg / 2 ml");}
    else if (selectedDrug == "Avipect syrup") {buttonClickShortcut("Avipect syrup", "Ammonium Chloride 125 mg + Pheniramine 15 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Avipiravir tab") {buttonClickShortcut("Avipiravir tab", "Favipiravir 200 mg");}
    else if (selectedDrug == "Avodart cap") {buttonClickShortcut("Avodart cap", "Dutasteride 0.5 mg");}
    else if (selectedDrug == "Avonex syringes") {injectionClickShortcut("Avonex syringes", "Interferon Beta-1a 30 mcg / 0.5 ml");}
    else if (selectedDrug == "Azathioprine 50 tab") {buttonClickShortcut("Azathioprine 50 tab", "Azathioprine 50 mg");}
    else if (selectedDrug == "Azomycin 250 cap") {buttonClickShortcut("Azomycin 250 cap", "Azithromycin 250 mg");}
    else if (selectedDrug == "B-com amp") {injectionClickShortcut("B-com amp", "Vit B1 10 mg + Vit B2 5.47 mg + Vit B3 40 mg + Vit B5 6 mg + Vit B6 4 mg");}
    else if (selectedDrug == "Babeton syrup") {buttonClickShortcut("Babeton syrup", "Thyme + Fennel + Bee Propolis + Rose Hips\n(120 ml)");}
    else if (selectedDrug == "Baby rest drops") {buttonClickShortcut("Baby rest drops", "Simethicone 40 mg / 0.6 ml\n(15 ml)");}
    else if (selectedDrug == "Balsam syrup") {buttonClickShortcut("Balsam syrup", "Guava Leaves + Tilia Flower + Fennel oil + Honey + Thyme\n(120 ml)");}
    else if (selectedDrug == "Bebe-vit drops") {buttonClickShortcut("Bebe-vit drops", "Vit A + Vit B1 + Vit B2 + Vit B6 + Nicotinamide + Vit C + Vit D3 + Vit E\n(30 ml)");}
    else if (selectedDrug == "Beclosone inhaler") {buttonClickShortcut("Beclosone inhaler", "Beclomethasone 50 mcg / dose");}
    else if (selectedDrug == "Beclosone forte inhaler") {buttonClickShortcut("Beclosone forte inhaler", "Beclomethasone 100 mcg / dose");}
    else if (selectedDrug == "Bedremine 50 ER tab") {buttonClickShortcut("Bedremine 50 ER tab", "Desvenlafaxine 50 mg");}
    else if (selectedDrug == "Betacor tab") {buttonClickShortcut("Betacor tab", "Sotalol 80 mg");}
    else if (selectedDrug == "Betafos amp") {injectionClickShortcut("Betafos amp", "Betamethasone 14 mg / 2 ml");}
    else if (selectedDrug == "Betallerge tab") {buttonClickShortcut("Betallerge tab", "Betamethasone 0.25 mg + Dexchlorpheniramine Maleate 2 mg");}
    else if (selectedDrug == "Betaserc 8 tab") {buttonClickShortcut("Betaserc 8 tab", "Betahistine 8 mg");}
    else if (selectedDrug == "Betaxolol 10 tab") {buttonClickShortcut("Betaxolol 10 tab", "Betaxolol 10 mg");}
    else if (selectedDrug == "Betmiga 25 tab") {buttonClickShortcut("Betmiga 25 tab", "Mirabegron 25 mg");}
    else if (selectedDrug == "Betolvex amp") {injectionClickShortcut("Betolvex amp", "Cyanocobalamin (Vit b12) 1 mg / 1 ml");}
    else if (selectedDrug == "Bi-Alcofan tab") {buttonClickShortcut("Bi-Alcofan tab", "Ketoprofen 150 mg");}
    else if (selectedDrug == "Biltricide tab") {buttonClickShortcut("Biltricide tab", "Praziquantel 600 mg");}
    else if (selectedDrug == "Bioglita Plus 15/500 tab") {buttonClickShortcut("Bioglita Plus 15/500 tab", "Pioglitazone 15 mg + Metformin 500 mg");}
    else if (selectedDrug == "Bional cap") {buttonClickShortcut("Bional cap", "Silymarin 200 mg + Lecithin 300 mg + Astragalus 20 mg + Zinc Ascorbate 12.5 mg + Selenium 25 mcg + Vit C 30 mg");}
    else if (selectedDrug == "Biostrong cap") {buttonClickShortcut("Biostrong cap", "Ginseng 100 mg + Royal Jelly 500 mg + Wheat Germ Oil 400 mg");}
    else if (selectedDrug == "Biotin Forte cap") {buttonClickShortcut("Biotin Forte cap", "Biotin (Vit B7) 5 mg");}
    else if (selectedDrug == "Biovit-12 Depot amp") {injectionClickShortcut("Biovit-12 Depot amp", "Hydroxocobalamin (Vit b12) 1 mg + Folic Acid 1 mg + Vit B6 20 mg / 2 ml");}
    else if (selectedDrug == "Biovita gummies") {buttonClickShortcut("Biovita gummies", "Vitamin B12 + Biotin + Pantothenic acid + Iodine + Zinc + Choline +Inositol + Vitamin A + Vitamin C + Vitamin D + Vitamin E + Niacin -Vitamin B6 + Folic acid.");}
    else if (selectedDrug == "Bisadyl 5 tab") {buttonClickShortcut("Bisadyl 5 tab", "Bisacodyl 5 mg");}
    else if (selectedDrug == "Bisadyl 5 supp") {buttonClickShortcut("Bisadyl 5 supp", "Bisacodyl 5 mg");}
    else if (selectedDrug == "Bismuth Oxide tab") {buttonClickShortcut("Bismuth Oxide tab", "Bismuth Oxide 120 mg");}
    else if (selectedDrug == "Bisolvon amp") {injectionClickShortcut("Bisolvon amp", "Bromhexine 4 mg / 2 ml");}
    else if (selectedDrug == "Bisolvon drops") {buttonClickShortcut("Bisolvon drops", "Bromhexine 2 mg / 1 ml\n(40 ml)");}
    else if (selectedDrug == "Bisolvon syrup") {buttonClickShortcut("Bisolvon syrup", "Bromhexine 4 mg / 5 ml\n(115 ml)");}
    else if (selectedDrug == "Bisolvon tab") {buttonClickShortcut("Bisolvon tab", "Bromhexine 8 mg");}
    else if (selectedDrug == "Bistol Plus tab") {buttonClickShortcut("Bistol Plus tab", "Bisoprolol +Hydrochlorothiazide\n(2.5 / 6.25)\n(5 / 6.25)\n(10 / 6.25)\n(5 / 12.5)\n(10 / 25)");}
    else if (selectedDrug == "Bonapex 70 tab") {buttonClickShortcut("Bonapex 70 tab", "Alendronate 70 mg");}
    else if (selectedDrug == "Bonidon cap") {buttonClickShortcut("Bonidon cap", "Indomethacin 75 mg");}
    else if (selectedDrug == "Bran cap") {buttonClickShortcut("Bran cap", "Bran 400 mg");}
    else if (selectedDrug == "Bravamax tab") {buttonClickShortcut("Bravamax tab", "Modafinil 200 mg");}
    else if (selectedDrug == "Brestto tab") {buttonClickShortcut("Brestto tab", "Fenugreek + Caraway + Anise + Chamomile + Dill + Fennel + Beta Carotene + Vit B complex + Vit C + Vit D + Vit E");}
    else if (selectedDrug == "Brilique tab") {buttonClickShortcut("Brilique tab", "Ticagrelor 60 mg\nTicagrelor 90 mg");}
    else if (selectedDrug == "Bristaflam tab") {buttonClickShortcut("Bristaflam tab", "Aceclofenac 100 mg");}
    else if (selectedDrug == "Bronchicum syrup") {buttonClickShortcut("Bronchicum syrup", "Thyme Fluid Extract + Primula Root Fluid Extracts\n(100 ml)");}
    else if (selectedDrug == "Broncho-vaxom adult cap") {buttonClickShortcut("Broncho-vaxom adult cap", "Bacterial lysates 7 mg\nLyophilized Bacterial Lysates of H. Influenzae, Diplococcus Pneumoniae, Klebsiella Pneumonia and Ozaenae, Staph. Aureus, Strept. Pyogenes and Viridans, Neisseria Catarrhalis");}
    else if (selectedDrug == "Broncho-vaxom children cap") {buttonClickShortcut("Broncho-vaxom children cap", "Bacterial lysates 3.5 mg\nLyophilized Bacterial Lysates of H. Influenzae, Diplococcus Pneumoniae, Klebsiella Pneumonia and Ozaenae, Staph. Aureus, Strept. Pyogenes and Viridans, Neisseria Catarrhalis");}
    else if (selectedDrug == "Broncho-vaxom children sach") {buttonClickShortcut("Broncho-vaxom children sach", "Bacterial lysates 3.5 mg\nLyophilized Bacterial Lysates of H. Influenzae, Diplococcus Pneumoniae, Klebsiella Pneumonia and Ozaenae, Staph. Aureus, Strept. Pyogenes and Viridans, Neisseria Catarrhalis");}
    else if (selectedDrug == "Bronchotec syrup") {buttonClickShortcut("Bronchotec syrup", "Dextromethorphan 10 mg + Guaifenesin 100 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Bronchophane syrup") {buttonClickShortcut("Bronchophane syrup", "Guaifenesin 50 mg + Ephedrine 7.5 mg + Diphenhydramine 5 mg + Dextromethorphan 4.56 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Broleaves syrup") {buttonClickShortcut("Broleaves syrup", "Ivy leaves 35 mg + Thyme 21.5 mg + Liquorice 21.7 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Brufen 200 tab") {buttonClickShortcut("Brufen 200 tab", "Ibuprofen 200 mg");}
    else if (selectedDrug == "Brufen 400 tab") {buttonClickShortcut("Brufen 400 tab", "Ibuprofen 400 mg");}
    else if (selectedDrug == "Brufen 600 tab") {buttonClickShortcut("Brufen 600 tab", "Ibuprofen 600 mg");}
    else if (selectedDrug == "Brufen Retard 800 tab") {buttonClickShortcut("Brufen Retard 800 tab", "Ibuprofen 800 mg");}
    else if (selectedDrug == "Brufen susp") {buttonClickShortcut("Brufen susp", "Ibuprofen 100 mg / 5 ml\n(150 ml)");}
    else if (selectedDrug == "Brufen Cold tab") {buttonClickShortcut("Brufen Cold tab", "Ibuprofen 400 mg + Pseudoephedrine 60 mg");}
    else if (selectedDrug == "Buspar 10 tab") {buttonClickShortcut("Buspar 10 tab", "Buspirone 10 mg");}
    else if (selectedDrug == "Byetta 5 prefilled pen") {injectionClickShortcut("Byetta 5 prefilled pen", "Exenatide 5 mg");}
    else if (selectedDrug == "C-retard 500 cap") {buttonClickShortcut("C-retard 500 cap", "Vit C 500 mg");}
    else if (selectedDrug == "C-vit drops") {buttonClickShortcut("C-vit drops", "Vit C 100 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Cabella syrup") {buttonClickShortcut("Cabella syrup", "Pentoxyverine 10.6 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Caffeinospire vial") {injectionClickShortcut("Caffeinospire vial", "Caffeine 20 mg / 1 ml");}
    else if (selectedDrug == "Cal-Heparine 5000 iu amp") {injectionClickShortcut("Cal-Heparine 5000 iu amp", "Heparin 5000 iu / 1 ml");}
    else if (selectedDrug == "Cal-Mag tab") {buttonClickShortcut("Cal-Mag tab", "Calcium 140 mg + Magnesium 45 mg");}
    else if (selectedDrug == "Cal-Preg tab") {buttonClickShortcut("Cal-Preg tab", "Calcium Carbonate 1600 mg\n(640 mg elemental Calcium)");}
    else if (selectedDrug == "Calcifolinon vial") {injectionClickShortcut("Calcifolinon vial", "Folinic Acid (Leucovorin) 50 mg / 5 ml");}
    else if (selectedDrug == "Calcimate tab") {buttonClickShortcut("Calcimate tab", "Calcium Carbonate 500 mg\n(200 mg elemental Calcium)");}
    else if (selectedDrug == "Calcitron cap") {buttonClickShortcut("Calcitron cap", "Calcium + Magnesium + Potassium + Phosphorus + Zinc + Manganese + Boron + Silicon + Copper + Vit A + Vit D + Vit C");}
    else if (selectedDrug == "Calcium Chloride 10% amp") {injectionClickShortcut("Calcium Chloride amp", "Calcium Chloride 1 gm / 10 ml (10%)");}
    else if (selectedDrug == "Calcium Gluconate 10% amp") {injectionClickShortcut("Calcium Gluconate amp", "Calcium Gluconate 1 gm / 10 ml (10%)");}
    else if (selectedDrug == "Calcium Pharco tab") {buttonClickShortcut("Calcium Pharco tab", "Calcium Citrate 950 mg\n(200 mg elemental calcium)");}
    else if (selectedDrug == "Calcivit D3 syrup") {buttonClickShortcut("Calcivit D3 syrup", "Calcium 50 mg + Vit B12 100 mcg + Vit D3 1000 iu / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Caldin C tab") {buttonClickShortcut("Caldin C tab", "Calcium 400 mg + Magnesium 48.5 mg + Vit D3 200 iu + Vit C 90 mg");}
    else if (selectedDrug == "Calmepam 1.5 tab") {buttonClickShortcut("Calmepam 1.5 tab", "Bromazepam 1.5 mg");}
    else if (selectedDrug == "Capoten 25 tab") {buttonClickShortcut("Capoten 25 tab", "Captopril 25 mg");}
    else if (selectedDrug == "Capozide 50/25 tab") {buttonClickShortcut("Capozide 50/25 tab", "Captopril 50 mg + Hydrochlorothiazide 25 mg");}
    else if (selectedDrug == "Carbapex 100 tab") {buttonClickShortcut("Carbapex 100 tab", "Carbamazepine 100 mg");}
    else if (selectedDrug == "Carbimazole 5 tab") {buttonClickShortcut("Carbimazole 5 tab", "Carbimazole 5 mg");}
    else if (selectedDrug == "Cardio-Mep 200 tab") {buttonClickShortcut("Cardio-Mep 200 tab", "Amiodarone 200 mg");}
    else if (selectedDrug == "Cardio-Mep amp") {injectionClickShortcut("Cardio-Mep amp", "Amiodarone 150 mg / 3 ml");}
    else if (selectedDrug == "Cardiomil 120 SR cap") {buttonClickShortcut("Cardiomil 120 SR cap", "Verapamil 120 mg");}
    else if (selectedDrug == "Cardioton tab") {buttonClickShortcut("Cardioton tab", "Crataegus (Hawthorn) extract 300 mg");}
    else if (selectedDrug == "Cardura 1 tab") {buttonClickShortcut("Cardura 1 tab", "Doxazosin 1 mg");}
    else if (selectedDrug == "Cardura XL 4 tab") {buttonClickShortcut("Cardura XL 4 tab", "Doxazosin 4 mg");}
    else if (selectedDrug == "Caredalud SR tab") {buttonClickShortcut("Caredalud SR tab", "Tizanidine 6 mg");}
    else if (selectedDrug == "Carminex sach") {buttonClickShortcut("Carminex sach", "Caraway Oil 15 mg + Cinnamon Oil 10 mg + Fennel Oil 15 mg");}
    else if (selectedDrug == "Carminex syrup") {buttonClickShortcut("Carminex syrup", "Caraway Oil + Cinnamon Oil + Fennel Oil");}
    else if (selectedDrug == "Carvipress 6.25 tab") {buttonClickShortcut("Carvipress 6.25 tab", "Carvedilol 6.25 mg");}
    else if (selectedDrug == "Casodex tab") {buttonClickShortcut("Casodex tab", "Bicalutamide 50 mg");}
    else if (selectedDrug == "Catafast sach") {buttonClickShortcut("Catafast sach", "Diclofenac K 50 mg");}
    else if (selectedDrug == "Cataflam 25 tab") {buttonClickShortcut("Cataflam 25 tab", "Diclofenac K 25 mg");}
    else if (selectedDrug == "Cataflam 50 tab") {buttonClickShortcut("Cataflam 50 tab", "Diclofenac K 50 mg");}
    else if (selectedDrug == "Cataflam amp") {injectionClickShortcut("Cataflam amp", "Diclofenac 75 mg / 3 ml");}
    else if (selectedDrug == "Catafly syrup") {buttonClickShortcut("Catafly syrup", "Diclofenac K 10 mg / 5 ml\n(100 ml & 140 ml)");}
    else if (selectedDrug == "Catapresan 0.15 tab") {buttonClickShortcut("Catapresan 0.15 tab", "Clonidine 150 mcg");}
    else if (selectedDrug == "Caventol syrup") {buttonClickShortcut("Caventol syrup", "Honey + Thyme Oil White + Vit C + Fennel Oil + Eucalyptus Oil + Marshmallow Extract + Ivy Extract + Zinc Gluconate + Propolis Extract\n(120 ml)");}
    else if (selectedDrug == "Ceclor 125 susp") {buttonClickShortcut("Ceclor 125 susp", "Cefaclor 125 mg / 5 ml\n(75 ml)");}
    else if (selectedDrug == "Ceclor 250 susp") {buttonClickShortcut("Ceclor 250 susp", "Cefaclor 250 mg / 5 ml\n(75 ml)");}
    else if (selectedDrug == "Cefaxone 250 vial") {injectionClickShortcut("Cefaxone 250 vial", "Ceftriaxone 250 mg");}
    else if (selectedDrug == "Cefaxone 500 vial") {injectionClickShortcut("Cefaxone 500 vial", "Ceftriaxone 500 mg");}
    else if (selectedDrug == "Cefaxone 1 gm vial") {injectionClickShortcut("Cefaxone 1 gm vial", "Ceftriaxone 1000 mg");}
    else if (selectedDrug == "Cefaxone 2 gm vial") {injectionClickShortcut("Cefaxone 2 gm vial", "Ceftriaxone 2000 mg");}
    else if (selectedDrug == "Cefotax 250 vial") {injectionClickShortcut("Cefotax 250 vial", "Cefotaxime 250 mg");}
    else if (selectedDrug == "Cefotax 500 vial") {injectionClickShortcut("Cefotax 500 vial", "Cefotaxime 500 mg");}
    else if (selectedDrug == "Cefotax 1 gm vial") {injectionClickShortcut("Cefotax 1 gm vial", "Cefotaxime 1000 mg");}
    else if (selectedDrug == "Cefotax 2 gm vial") {injectionClickShortcut("Cefotax 2 gm vial", "Cefotaxime 2000 mg");}
    else if (selectedDrug == "Cefozon 1 gm vial") {injectionClickShortcut("Cefozon 1 gm vial", "Cefoperazone 1 gm");}
    else if (selectedDrug == "Cefozon 2 gm vial") {injectionClickShortcut("Cefozon 2 gm vial", "Cefoperazone 2 gm");}
    else if (selectedDrug == "Cefumax 250 vial") {injectionClickShortcut("Cefumax 250 vial", "Cefuroxime 250 mg");}
    else if (selectedDrug == "Cefumax 750 vial") {injectionClickShortcut("Cefumax 750 vial", "Cefuroxime 750 mg");}
    else if (selectedDrug == "Cefumax 1500 vial") {injectionClickShortcut("Cefumax 1500 vial", "Cefuroxime 1500 mg");}
    else if (selectedDrug == "Cefzil 125 susp") {buttonClickShortcut("Cefzil 125 susp", "Cefprozil 125 mg / 5 ml\n(50 ml & 75 ml)");}
    else if (selectedDrug == "Cefzil 250 susp") {buttonClickShortcut("Cefzil 250 susp", "Cefprozil 250 mg / 5 ml\n(50 ml & 75 ml)");}
    else if (selectedDrug == "Cefzil 250 tab") {buttonClickShortcut("Cefzil 250 tab", "Cefprozil 250 mg");}
    else if (selectedDrug == "Cefzil 500 tab") {buttonClickShortcut("Cefzil 500 tab", "Cefprozil 500 mg");}
    else if (selectedDrug == "Cefzim 500 vial") {injectionClickShortcut("Cefzim 500 vial", "Ceftazidime 500 mg");}
    else if (selectedDrug == "Cefzim 1 gm vial") {injectionClickShortcut("Cefzim 1 gm vial", "Ceftazidime 1000 mg");}
    else if (selectedDrug == "Cefzim 2 gm vial") {injectionClickShortcut("Cefzim 2 gm vial", "Ceftazidime 2000 mg");}
    else if (selectedDrug == "Celebrex 100 cap") {buttonClickShortcut("Celebrex 100 cap", "Celecoxib 100 mg");}
    else if (selectedDrug == "Celebrex 200 cap") {buttonClickShortcut("Celebrex 200 cap", "Celecoxib 200 mg");}
    else if (selectedDrug == "Cellcept 250 cap") {buttonClickShortcut("Cellcept 250 cap", "Mycophenolate Mofetil 250 mg");}
    else if (selectedDrug == "Cellcept 500 tab") {buttonClickShortcut("Cellcept 500 tab", "Mycophenolate Mofetil 500 mg");}
    else if (selectedDrug == "Centronerve tab") {buttonClickShortcut("Centronerve tab", "Alpha Lipoic Acid (Thioctic Acid) 600 mg + Benfotiamine 150 mg + Vit B6 30.39 mg + Vit B12 500 mcg + Vit D 1000 iu");}
    else if (selectedDrug == "Centrum tab") {buttonClickShortcut("Centrum tab", "Vitamins + Minerals");}
    else if (selectedDrug == "Ceporex 125 susp") {buttonClickShortcut("Ceporex 125 susp", "Cephalexin 125 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Ceporex 250 susp") {buttonClickShortcut("Ceporex 250 susp", "Cephalexin 250 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Ceporex 250 tab") {buttonClickShortcut("Ceporex 250 tab", "Cephalexin 250 mg");}
    else if (selectedDrug == "Ceporex 500 tab") {buttonClickShortcut("Ceporex 500 tab", "Cephalexin 500 mg");}
    else if (selectedDrug == "Ceporex 1 gm tab") {buttonClickShortcut("Ceporex 1 gm tab", "Cephalexin 1 gm");}
    else if (selectedDrug == "Cerazette tab") {buttonClickShortcut("Cerazette tab", "Desogestrel 75 mcg");}
    else if (selectedDrug == "Cerebrine cap") {buttonClickShortcut("Cerebrine cap", "Vinburnine 20 mg");}
    else if (selectedDrug == "Cerebrolysin amp") {injectionClickShortcut("Cerebrolysin amp", "Cerebrolysin 215.2 mg / 1 ml");}
    else if (selectedDrug == "Ceroxim 500 tab") {buttonClickShortcut("Ceroxim 500 tab", "Cefuroxime 500 mg");}
    else if (selectedDrug == "Cervitam cap") {buttonClickShortcut("Cervitam cap", "Piracetam 400 mg + Vincamine 20 mg");}
    else if (selectedDrug == "Cetafen Plus tab") {buttonClickShortcut("Cetafen Plus tab", "Ibuprofen 400 mg + Paracetamol 500 mg + Caffeine 65 mg");}
    else if (selectedDrug == "Cetal drops") {buttonClickShortcut("Cetal drops", "Paracetamol 100 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Cetal Sinus tab") {buttonClickShortcut("Cetal Sinus tab", "Paracetamol 500 mg + Pseudoephedrine 30 mg");}
    else if (selectedDrug == "Cetal supp") {buttonClickShortcut("Cetal supp", "Paracetamol 120 mg");}
    else if (selectedDrug == "Cetal susp") {buttonClickShortcut("Cetal susp", "Paracetamol 250 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Cevamol eff tab") {buttonClickShortcut("Cevamol eff tab", "Paracetamol 400 mg + Vit C 250 mg");}
    else if (selectedDrug == "CH Alpha sach") {buttonClickShortcut("CH Alpha sach", "Collagen Hydrolysate 10 gm + Vit C 85 mg");}
    else if (selectedDrug == "CH Alpha Plus sach") {buttonClickShortcut("CH Alpha Plus sach", "Collagen Hydrolysate + Vit C + Rosehip extract");}
    else if (selectedDrug == "Champix 0.5 tab") {buttonClickShortcut("Champix 0.5 tab", "Varenicline 0.5 mg");}
    else if (selectedDrug == "Chitocal cap") {buttonClickShortcut("Chitocal cap", "Chitosan 500 mg + Vit C 100 mg + Gymnema Sylvestre 50 mg");}
    else if (selectedDrug == "Chloral syrup") {buttonClickShortcut("Chloral syrup", "Chloral Hydrate 500 mg / 5 ml\n(30 ml)");}
    else if (selectedDrug == "Choletimb tab") {buttonClickShortcut("Choletimb tab", "Ezetimibe 10 mg");}
    else if (selectedDrug == "Choletrix-D3 drops") {buttonClickShortcut("Choletrix-D3 drops", "Vit D3 (Cholecalciferol) 400 iu / 1 drop\n(30 ml)");}
    else if (selectedDrug == "Chromax cap") {buttonClickShortcut("Chromax cap", "Chromium Picolinate 281.5 mcg + Garcinia Cambogia Fruit extract 500 mg");}
    else if (selectedDrug == "Chromitron cap") {buttonClickShortcut("Chromitron cap", "Chromium + L.Cysteine + L.Glycine + L.Glutamic Acid + Vit B3 + Biotin + Citrus Bioflavonoids + Vit E + Vit A + Vit C");}
    else if (selectedDrug == "Chromium cap") {buttonClickShortcut("Chromium cap", "Chromium Picolinate 200 mcg");}
    else if (selectedDrug == "Cidamex tab") {buttonClickShortcut("Cidamex tab", "Acetazolamide 250 mg");}
    else if (selectedDrug == "Cidodian Depot amp") {injectionClickShortcut("Cidodian Depot amp", "Estradiol Valerate 20 mg +Prasterone Enanthate 200 mg / 1 ml");}
    else if (selectedDrug == "Cidolut Depot amp") {injectionClickShortcut("Cidolut Depot amp", "Hydroxyprogesterone Caproate 250 mg / ml");}
    else if (selectedDrug == "Cimzia prefilled syringe") {injectionClickShortcut("Cimzia prefilled syringe", "Certolizumab Pegol 200 mg / ml");}
    else if (selectedDrug == "Cidophage 500 tab") {buttonClickShortcut("Cidophage 500 tab", "Metformin 500 mg");}
    else if (selectedDrug == "Cidoteston amp") {injectionClickShortcut("Cidoteston amp", "Testosterone Enantate 250 mg / 1 ml\n(the equivalent of about 180 mg testosterone)");}
    else if (selectedDrug == "Cilest tab") {buttonClickShortcut("Cilest tab", "Norgestimate 0.25 mg (250 mcg) + Ethinyl Estradiol 0.035 mg (35 mcg)");}
    else if (selectedDrug == "Cimetidine 200 tab") {buttonClickShortcut("Cimetidine 200 tab", "Cimetidine 200 mg");}
    else if (selectedDrug == "Cipralex 10 tab") {buttonClickShortcut("Cipralex 10 tab", "Escitalopram 10 mg");}
    else if (selectedDrug == "Ciprocin 250 tab") {buttonClickShortcut("Ciprocin 250 tab", "Ciprofloxacin 250 mg");}
    else if (selectedDrug == "Ciprocin 500 tab") {buttonClickShortcut("Ciprocin 500 tab", "Ciprofloxacin 500 mg");}
    else if (selectedDrug == "Ciprocin 750 tab") {buttonClickShortcut("Ciprocin 750 tab", "Ciprofloxacin 750 mg");}
    else if (selectedDrug == "Ciprodiazole tab") {buttonClickShortcut("Ciprodiazole tab", "Ciprofloxacin 500 mg + Metronidazole 500 mg");}
    else if (selectedDrug == "Ciprofloxacin vial") {injectionClickShortcut("Ciprofloxacin vial", "Ciprofloxacin 200 mg / 100 ml");}
    else if (selectedDrug == "Cipromega XL 500 tab") {buttonClickShortcut("Cipromega XL 500 tab", "Ciprofloxacin 500 mg");}
    else if (selectedDrug == "Cipromega XL 1 gm tab") {buttonClickShortcut("Cipromega XL 1 gm tab", "Ciprofloxacin 1 gm");}
    else if (selectedDrug == "Citalo syrup") {buttonClickShortcut("Citalo syrup", "Citalopram 2 mg / 1 ml\n(120 ml)");}
    else if (selectedDrug == "Citalo 20 tab") {buttonClickShortcut("Citalo 20 tab", "Citalopram 20 mg");}
    else if (selectedDrug == "Clexane prefilled syringe") {injectionClickShortcut("Clexane prefilled syringe", "Enoxaparin\n20 mg / 0.2 ml\n40 mg / 0.4 ml\n60 mg / 0.6 ml\n80 mg / 0.8 ml");}
    else if (selectedDrug == "Clindacin 150 cap") {buttonClickShortcut("Clindacin 150 cap", "Clindamycin 150 mg");}
    else if (selectedDrug == "Clindacin 300 cap") {buttonClickShortcut("Clindacin 300 cap", "Clindamycin 300 mg");}
    else if (selectedDrug == "Clomid tab") {buttonClickShortcut("Clomid tab", "Clomiphene 50 mg");}
    else if (selectedDrug == "Clopixol Depot amp") {injectionClickShortcut("Clopixol Depot amp", "Zuclopenthixol 200 mg / 1 ml");}
    else if (selectedDrug == "Clozapex 25 tab") {buttonClickShortcut("Clozapex 25 tab", "Clozapine 25 mg");}
    else if (selectedDrug == "Co-Tareg tab") {buttonClickShortcut("Co-Tareg tab", "Valsartan +Hydrochlorothiazide\n(80 / 12.5)\n(160 / 12.5)\n(160 / 25)\n(320 / 12.5)\n(320 + 25)");}
    else if (selectedDrug == "Cobal tab") {buttonClickShortcut("Cobal tab", "Methylcobalamin (Mecobalamin) 500 mcg");}
    else if (selectedDrug == "Cobal F tab") {buttonClickShortcut("Cobal F tab", "Methylcobalamin (Mecobalamin) 500 mcg + Folic Acid 200 mcg");}
    else if (selectedDrug == "Cobalvex B12 amp") {injectionClickShortcut("Cobalvex B12 amp", "Methylcobalamin (Mecobalamin) 0.5 mg / 1 ml");}
    else if (selectedDrug == "Codaphen-N syrup") {buttonClickShortcut("Codaphen-N syrup", "Chlorpheniramine 1 mg + Dextromethorphan 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Codiclyptol cap") {buttonClickShortcut("Codiclyptol cap", "Pholcodine 5 mg + Pseudoephedrine 30 mg + Paracetamol 500 mg");}
    else if (selectedDrug == "Codilar syrup") {buttonClickShortcut("Codilar syrup", "Dextromethorphan 5 mg + Phenylephrine 2 mg + Chlorpheniramine 1 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Coenzyme Q10 cap") {buttonClickShortcut("Coenzyme Q10 cap", "Coenzyme Q10 30 mg");}
    else if (selectedDrug == "Cogetropine amp") {injectionClickShortcut("Cogetropine amp", "Benztropine 1 mg / 1 ml");}
    else if (selectedDrug == "Cogintol tab") {buttonClickShortcut("Cogintol tab", "Benztropine 2 mg");}
    else if (selectedDrug == "Colchicine 0.5 tab") {buttonClickShortcut("Colchicine tab", "Colchicine 0.5 mg (500 mcg)");}
    else if (selectedDrug == "Cold Control tab") {buttonClickShortcut("Cold Control tab", "Paracetamol 500 mg + Diphenhydramine 12.5 mg");}
    else if (selectedDrug == "Colomycin 1 mIU vial") {injectionClickShortcut("Colomycin 1 mIU vial", "Colistimethate sodium 1 million IU");}
    else if (selectedDrug == "Colomycin 2 mIU vial") {injectionClickShortcut("Colomycin 2 mIU vial", "Colistimethate sodium 2 million IU");}
    else if (selectedDrug == "Colona tab") {buttonClickShortcut("Colona tab", "Mebeverine 100 mg + Sulpiride 25 mg");}
    else if (selectedDrug == "Colosalazine-EC tab") {buttonClickShortcut("Colosalazine-EC tab", "Sulfasalazine 500 mg");}
    else if (selectedDrug == "Coloverin tab") {buttonClickShortcut("Coloverin tab", "Mebeverine 135 mg");}
    else if (selectedDrug == "Coloverin SR cap") {buttonClickShortcut("Coloverin SR cap", "Mebeverine 200 mg");}
    else if (selectedDrug == "Coloverin A tab") {buttonClickShortcut("Coloverin A tab", "Mebeverine 135 mg + Chlordiazepoxide 5 mg");}
    else if (selectedDrug == "Coloverin D tab") {buttonClickShortcut("Coloverin D tab", "Mebeverine 135 mg + Dimethicone 40 mg");}
    else if (selectedDrug == "Combivent inhaler") {buttonClickShortcut("Combivent inhaler", "Ipratropium Bromide 20 mcg + Salbutamol 120 mcg / actuation");}
    else if (selectedDrug == "Cona-adione tab") {buttonClickShortcut("Cona-adione tab", "Vitamin K1 10 mg");}
    else if (selectedDrug == "Conaz tab") {buttonClickShortcut("Conaz tab", "Norfloxacin 400 mg + Tinidazole 600 mg");}
    else if (selectedDrug == "Concerta 18 ER tab") {buttonClickShortcut("Concerta 18 ER tab", "Methylphenidate 18 mg");}
    else if (selectedDrug == "Concor COR 2.5 tab") {buttonClickShortcut("Concor COR 2.5 tab", "Bisoprolol 2.5 mg");}
    else if (selectedDrug == "Congestal syrup") {buttonClickShortcut("Congestal syrup", "Paracetamol 160 mg + Chlorpheniramine 1 mg + Pseudoephedrine 15 mg + Dextromethorphan 4.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Congestal tab") {buttonClickShortcut("Congestal tab", "Chlorpheniramine 4 mg + Pseudoephedrine 60 mg + Paracetamol 650 mg");}
    else if (selectedDrug == "Conta-Flu tab") {buttonClickShortcut("Conta-Flu tab", "Chlorpheniramine 3 mg + Pseudoephedrine 30 mg + Propyphenazone 200 mg");}
    else if (selectedDrug == "Contrahistadin tab") {buttonClickShortcut("Contrahistadin tab", "Bilastine 20 mg");}
    else if (selectedDrug == "Contafever susp") {buttonClickShortcut("Contafever susp", "Ibuprofen 200 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Contraplan II tab") {buttonClickShortcut("Contraplan II tab", "Levonorgestrel 0.75 mg");}
    else if (selectedDrug == "Controloc 20 tab") {buttonClickShortcut("Controloc 20 tab", "Pantoprazole 20 mg");}
    else if (selectedDrug == "Controloc 40 tab") {buttonClickShortcut("Controloc 40 tab", "Pantoprazole 40 mg");}
    else if (selectedDrug == "Controloc vial") {injectionClickShortcut("Controloc vial", "Pantoprazole 40 mg");}
    else if (selectedDrug == "Convagran cap") {buttonClickShortcut("Convagran cap", "Zonisamide 100 mg");}
    else if (selectedDrug == "Convulex drops") {buttonClickShortcut("Convulex drops", "Sodium Valproate 300 mg / 1 ml\n(100 ml)");}
    else if (selectedDrug == "Convulex 150 cap") {buttonClickShortcut("Convulex 150 cap", "Sodium Valproate 150 mg");}
    else if (selectedDrug == "Convulex 300 cap") {buttonClickShortcut("Convulex 300 cap", "Sodium Valproate 300 mg");}
    else if (selectedDrug == "Corasore drops") {buttonClickShortcut("Corasore drops", "Heptaminol 150 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Corasore tab") {buttonClickShortcut("Corasore tab", "Heptaminol 150 mg");}
    else if (selectedDrug == "Cortilon tab") {buttonClickShortcut("Cortilon tab", "Fludrocortisone 0.1 mg");}
    else if (selectedDrug == "Cortiplex B6 adult amp") {injectionClickShortcut("Cortiplex B6 adult amp", "Corticoadrenal extract 100 CDU + Vit B6 50 mg / 1 ml");}
    else if (selectedDrug == "Cortiplex B6 pediatric amp") {injectionClickShortcut("Cortiplex B6 pediatric amp", "Corticoadrenal extract 50 CDU + Vit B6 20 mg / 1 ml");}
    else if (selectedDrug == "Cortopect cap") {buttonClickShortcut("Cortopect cap", "Acetylcysteine 300 mg");}
    else if (selectedDrug == "Cosentyx prefilled syringe") {injectionClickShortcut("Cosentyx prefilled syringe", "Secukinumab 150 mg / ml");}
    else if (selectedDrug == "Cough cut syrup") {buttonClickShortcut("Cough cut syrup", "Butamirate 7.5 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Coughsed children supp") {buttonClickShortcut("Coughsed children supp", "Paracetamol 250 mg + Gelsemium extract + Grindelia extract + Niaouli essence");}
    else if (selectedDrug == "Coughsed infant supp") {buttonClickShortcut("Coughsed infant supp", "Paracetamol 100 mg + Gelsemium extract + Grindelia extract + Niaouli essence");}
    else if (selectedDrug == "Coveram tab") {buttonClickShortcut("Coveram tab", "Amlodipine +Perindopril\n(5 / 5)\n(10 / 5)\n(5 / 10)\n(10 / 10)");}
    else if (selectedDrug == "Cranberry cap") {buttonClickShortcut("Cranberry cap", "Cranberry 270 mg");}
    else if (selectedDrug == "Crestor 5 tab") {buttonClickShortcut("Crestor 5 tab", "Rosuvastatin 5 mg");}
    else if (selectedDrug == "Curisafe drops") {buttonClickShortcut("Curisafe drops", "Cefadroxil 100 mg / 1 ml\n(10 ml)");}
    else if (selectedDrug == "Curisafe 125 susp") {buttonClickShortcut("Curisafe 125 susp", "Cefadroxil 125 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Curisafe 250 susp") {buttonClickShortcut("Curisafe 250 susp", "Cefadroxil 250 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Curisafe 500 susp") {buttonClickShortcut("Curisafe 500 susp", "Cefadroxil 500 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Curisafe 500 cap") {buttonClickShortcut("Curisafe 500 cap", "Cefadroxil 500 mg");}
    else if (selectedDrug == "Curisafe 1 gm tab") {buttonClickShortcut("Curisafe 1 gm tab", "Cefadroxil 1 gm");}
    else if (selectedDrug == "Cyclo-Progynova tab") {buttonClickShortcut("Cyclo-Progynova tab", "-11 white tablets: Estradiol Valerate 2 mg\n-10 light brown tablets: Estradiol Valerate 2 mg + Norgestrel 0.5 mg");}
    else if (selectedDrug == "Cymbalta 30 cap") {buttonClickShortcut("Cymbalta 30 cap", "Duloxetine 30 mg");}
    else if (selectedDrug == "Cyrinol syrup") {buttonClickShortcut("Cyrinol syrup", "Carbinoxamine 2 mg + Pholcodine 4 mg + Ephedrine 7 mg / 5 ml\n(60 ml & 120 ml)");}
    else if (selectedDrug == "Cystinol cap") {buttonClickShortcut("Cystinol cap", "Solidago Virgaurea 425 mg");}
    else if (selectedDrug == "Cystone tab") {buttonClickShortcut("Cystone tab", "Achyranthes + Cyperus + Didymocarpus + Hajrul yahood bhasma + Onosma + Rubiae + Saxifraga + Shilajeet + Vernonia");}
    else if (favContentDescription == "active") {generalDiag("Warning", "This drug either removed from the main list or the name has been changed\n\nRemove it from the favourite list then add it again");}
  }
  void getDoseDEFGHI () {
    if (selectedDrug == "Daclavirocyrl tab") {buttonClickShortcut("Daclavirocyrl tab", "Daclatasvir 60 mg");}
    else if (selectedDrug == "Daflon tab") {buttonClickShortcut("Daflon tab", "Diosmin 450 mg + Hesperidin 50 mg");}
    else if (selectedDrug == "Dalfarosis ER tab") {buttonClickShortcut("Dalfarosis ER tab", "Dalfampridine 10 mg");}
    else if (selectedDrug == "Dantrelax 25 cap") {buttonClickShortcut("Dantrelax 25 cap", "Dantrolene 25 mg");}
    else if (selectedDrug == "Dapsone 50 tab") {buttonClickShortcut("Dapsone 50 tab", "Dapsone 50 mg");}
    else if (selectedDrug == "Dapsone 100 tab") {buttonClickShortcut("Dapsone 100 tab", "Dapsone 100 mg");}
    else if (selectedDrug == "Davalindi tab") {buttonClickShortcut("Davalindi tab", "Vit D 1000 iu");}
    else if (selectedDrug == "Debospan syrup") {buttonClickShortcut("Debospan syrup", "Marshmallow extract 20 mg + Ivy extract 20 mg + Thyme extract 16.75 mg + Ginger extract 6 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Decal B12 syrup") {buttonClickShortcut("Decal B12 syrup", "Calcium 50 mg + Vit D 1000 iu + Vit B12 0.01 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Decancit SR tab") {buttonClickShortcut("Decancit SR tab", "Cetirizine 5 mg +Pseudoephedrine 120 mg");}
    else if (selectedDrug == "Decapeptyl CR prefilled syringe") {injectionClickShortcut("Decapeptyl CR prefilled syringe", "Triptorelin 3.75 mg");}
    else if (selectedDrug == "Declophen Plus cap") {buttonClickShortcut("Declophen Plus cap", "Chlorzoxazone 250 mg + Declofenac K 50 mg");}
    else if (selectedDrug == "Degreasian cap") {buttonClickShortcut("Degreasian cap", "Omega-3-Acid Ethyl Esters 90 1000 mg");}
    else if (selectedDrug == "Dekadel syrup") {buttonClickShortcut("Dekadel syrup", "Sodium Valproate 200 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Delostigar SR tab") {buttonClickShortcut("Delostigar SR tab", "Pyridostigmine 180 mg");}
    else if (selectedDrug == "Delpedox 875 tab") {buttonClickShortcut("Delpedox 875 tab", "Amoxicillin 875 mg");}
    else if (selectedDrug == "Deltasone syrup") {buttonClickShortcut("Deltasone syrup", "Dexamethasone 0.25 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Deltasone tab") {buttonClickShortcut("Deltasone tab", "Dexamethasone 0.75 mg");}
    else if (selectedDrug == "Deltavit B12 tab") {buttonClickShortcut("Deltavit B12 tab", "Cyanocobalamin 1 mg");}
    else if (selectedDrug == "Demafight 5 tab") {buttonClickShortcut("Demafight 5 tab", "Metolazone 5 mg");}
    else if (selectedDrug == "Dentinox drops") {buttonClickShortcut("Dentinox drops", "Simethicone 42 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Depapalin syrup") {buttonClickShortcut("Depapalin syrup", "Pregabalin 20 mg / 1 ml\n(250 ml)");}
    else if (selectedDrug == "Depo-Provera vial") {injectionClickShortcut("Depo-Provera vial", "Medroxyprogesterone 150 mg / 1 ml");}
    else if (selectedDrug == "Depovit B12 amp") {injectionClickShortcut("Depovit B12 amp", "Hydroxocobalamin (Vit B12) 1 mg / 1 ml");}
    else if (selectedDrug == "Desa syrup") {buttonClickShortcut("Desa syrup", "Desloratadine 2.5 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Desa tab") {buttonClickShortcut("Desa tab", "Desloratadine 5 mg");}
    else if (selectedDrug == "Desferal vial") {injectionClickShortcut("Desferal vial", "Deferoxamine 500 mg");}
    else if (selectedDrug == "Detrusitol tab") {buttonClickShortcut("Detrusitol tab", "Tolterodine 2 mg");}
    else if (selectedDrug == "Detrusitol retard cap") {buttonClickShortcut("Detrusitol retard cap", "Tolterodine 4 mg");}
    else if (selectedDrug == "Devarol-S amp") {injectionClickShortcut("Devarol-S amp", "Cholecalciferol (Vit D3) 200000 iu / 2 ml");}
    else if (selectedDrug == "Dexamethasone amp") {injectionClickShortcut("Dexamethasone amp", "Dexamethasone 8 mg / 2 ml");}
    else if (selectedDrug == "Dextrafast tab") {buttonClickShortcut("Dextrafast tab", "Dexketoprofen 25 mg");}
    else if (selectedDrug == "Dextromethorphan syrup") {buttonClickShortcut("Dextromethorphan syrup", "Dextromethorphan 10 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Dextrose 5% +NaCl 0.9% solution") {injectionClickShortcut("Dextrose 5% +NaCl 0.9% solution", "Glucose 50 mg +NaCl 9 mg /ml");}
    else if (selectedDrug == "Diaben 5 tab") {buttonClickShortcut("Diaben 5 tab", "Glibenclamide (Glyburide) 5 mg");}
    else if (selectedDrug == "Diacerein cap") {buttonClickShortcut("Diacerein cap", "Diacerin 50 mg");}
    else if (selectedDrug == "Diaflozimet tab") {buttonClickShortcut("Diaflozimet tab", "Dapagliflozin + Metformin\n(5/500)\n(5/1000)\n(10/500)\n(10/1000)");}
    else if (selectedDrug == "Dialy-Cal tab") {buttonClickShortcut("Dialy-Cal tab", "Calcium Acetate 500 mg\n(125 mg elemental calcium)");}
    else if (selectedDrug == "Diamicron 30 tab") {buttonClickShortcut("Diamicron 30 tab", "Gliclazide 30 mg");}
    else if (selectedDrug == "Diane-35 tab") {buttonClickShortcut("Diane-35 tab", "Cyproterone 2 mg + Ethinylestradiol 35 mcg");}
    else if (selectedDrug == "Diaphage 850 tab") {buttonClickShortcut("Diaphage 850 tab", "Metformin 850 mg");}
    else if (selectedDrug == "Diasmect sach") {buttonClickShortcut("Diasmect sach", "Dioctahedral Smectite 3 gm");}
    else if (selectedDrug == "Diasmect susp") {buttonClickShortcut("Diasmect susp", "Dioctahedral Smectite 1 gm / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Diastop susp") {buttonClickShortcut("Diastop susp", "Calcium carbonate 8 gm + Kaolin 8 gm + Tincture Belladonna 2 ml + Tincture catechu 15 ml + Anise oil 0.2 ml + Lemon oil 1 ml / 100 ml\n(60 ml)");}
    else if (selectedDrug == "Diavance 1.25/250 tab") {buttonClickShortcut("Diavance 1.25/250 tab", "Glibenclamide (Glyburide) 1.25 mg + Metformin 250 mg");}
    else if (selectedDrug == "Dicynone 500 tab") {buttonClickShortcut("Dicynone 500 tab", "Etamsylate 500 mg");}
    else if (selectedDrug == "Dicynone amp") {injectionClickShortcut("Dicynone amp", "Etamsylate 250 mg / 2 ml");}
    else if (selectedDrug == "Diflucan 50 cap") {buttonClickShortcut("Diflucan 50 cap", "Fluconazole 50 mg");}
    else if (selectedDrug == "Diflucan 150 cap") {buttonClickShortcut("Diflucan 150 cap", "Fluconazole 150 mg");}
    else if (selectedDrug == "Diflucan syrup") {buttonClickShortcut("Diflucan syrup", "Fluconazole 5 mg / 1 ml\n(70 ml)");}
    else if (selectedDrug == "Diflucan vial") {injectionClickShortcut("Diflucan vial", "Fluconazole 2 mg / ml\n(50 ml)");}
    else if (selectedDrug == "Digest Eze cap") {buttonClickShortcut("Digest Eze cap", "Bromelain + Papain + Chamomile + Ginger + Peppermint + Anise + Fennel");}
    else if (selectedDrug == "Digestin syrup") {buttonClickShortcut("Digestin syrup", "Papain 80 mg + Pepsin 40 mg + Sanzyme 10 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Digestin tab") {buttonClickShortcut("Digestin tab", "Papain 100 mg + Sanzyme 30 mg");}
    else if (selectedDrug == "Diltiazem 60 tab") {buttonClickShortcut("Diltiazem 60 tab", "Diltiazem 60 mg");}
    else if (selectedDrug == "Diltiazem 90 SR cap") {buttonClickShortcut("Diltiazem 90 SR cap", "Diltiazem 90 mg");}
    else if (selectedDrug == "Dimra tab") {buttonClickShortcut("Dimra tab", "Methocarbamol 500 mg + Diclofenac Potassium 50 mg");}
    else if (selectedDrug == "Dinitra 5 sublingual tab") {buttonClickShortcut("Dinitra 5 sublingual tab", "Isosorbide Dinitrate 5 mg");}
    else if (selectedDrug == "Dinitra 10 tab") {buttonClickShortcut("Dinitra 10 tab", "Isosorbide Dinitrate 10 mg");}
    else if (selectedDrug == "Diprivan amp") {injectionClickShortcut("Diprivan amp", "Propofol 10 mg / 1 ml (1%)");}
    else if (selectedDrug == "Disflatyl tab") {buttonClickShortcut("Disflatyl tab", "Simethicone 40 mg");}
    else if (selectedDrug == "Disprelone-OD 5 tab") {buttonClickShortcut("Disprelone-OD 5 tab", "Prednisolone 5 mg");}
    else if (selectedDrug == "Disprelone-OD 20 tab") {buttonClickShortcut("Disprelone-OD 20 tab", "Prednisolone 20 mg");}
    else if (selectedDrug == "Divakote 250 tab") {buttonClickShortcut("Divakote 250 tab", "Sodium Valproate 250 mg");}
    else if (selectedDrug == "Divakote 500 tab") {buttonClickShortcut("Divakote 500 tab", "Sodium Valproate 500 mg");}
    else if (selectedDrug == "Diviton-D drops") {buttonClickShortcut("Diviton-D drops", "Vit D 4000 iu / 1 ml (200 iu /drop)\n(10 ml)");}
    else if (selectedDrug == "Diviton-D forte drops") {buttonClickShortcut("Diviton-D forte drops", "Vit D 10000 iu / 1 ml\n(10 ml)");}
    else if (selectedDrug == "Dobutrex vial") {injectionClickShortcut("Dobutrex vial", "Dobutamine 250 mg / 20 ml");}
    else if (selectedDrug == "Dolcyl 1 tab") {buttonClickShortcut("Dolcyl 1 tab", "Glimepiride 1 mg");}
    else if (selectedDrug == "Dolcyl M tab") {buttonClickShortcut("Dolcyl M tab", "Glimepiride 2 mg + Metformin 500 mg");}
    else if (selectedDrug == "Doliprane tab") {buttonClickShortcut("Doliprane tab", "Paracetamol 1000 mg");}
    else if (selectedDrug == "Dolo-D susp") {buttonClickShortcut("Dolo-D susp", "Ibuprofen 100 mg + Pseudoephedrine 15 mg / 5 ml\n(115 ml)");}
    else if (selectedDrug == "Dolo-D tab") {buttonClickShortcut("Dolo-D tab", "Ibuprofen 200 mg + Pseudoephedrine 30 mg");}
    else if (selectedDrug == "Dolo-D plus susp") {buttonClickShortcut("Dolo-D plus susp", "Ibuprofen 100 mg + Pseudoephedrine 15 mg + Chlorpheniramine 1 mg / 5 ml\n(115 ml)");}
    else if (selectedDrug == "Dolo-D plus tab") {buttonClickShortcut("Dolo-D plus tab", "Ibuprofen 200 mg + Pseudoephedrine 30 mg + Chlorpheniramine 2 mg");}
    else if (selectedDrug == "Dolphin 12.5 supp") {buttonClickShortcut("Dolphin 12.5 supp", "Diclofenac Na 12.5 mg");}
    else if (selectedDrug == "Dolphin 25 supp") {buttonClickShortcut("Dolphin 25 supp", "Diclofenac Na 25 mg");}
    else if (selectedDrug == "Dolphin 50 supp") {buttonClickShortcut("Dolphin 50 supp", "Diclofenac Na 50 mg");}
    else if (selectedDrug == "Dopamine amp") {injectionClickShortcut("Dopamine amp", "Dopamine 200 mg / 5 ml");}
    else if (selectedDrug == "Dormicum amp") {injectionClickShortcut("Dormicum amp", "Midazolam 15 mg / 3 ml (5 mg /ml)");}
    else if (selectedDrug == "Dormival cap") {buttonClickShortcut("Dormival cap", "Valeriana Dry extract 100 mg + Humulus Lupulus Soft extract 25 mg");}
    else if (selectedDrug == "Dorofen cap") {buttonClickShortcut("Dorofen cap", "Glucosamine 500 mg + Ginkgo Biloba leaf extract 50 mg");}
    else if (selectedDrug == "Downoprazol 20 cap") {buttonClickShortcut("Downoprazol 20 cap", "Omeprazole 20 mg + Sodium Bicarbonate 1100 mg");}
    else if (selectedDrug == "Downoprazol 20 sach") {buttonClickShortcut("Downoprazol 20 sach", "Omeprazole 20 mg + Sodium Bicarbonate 1680 mg");}
    else if (selectedDrug == "Downoprazol 40 cap") {buttonClickShortcut("Downoprazol 40 cap", "Omeprazole 40 mg + Sodium Bicarbonate 1100 mg");}
    else if (selectedDrug == "Downoprazol 40 sach") {buttonClickShortcut("Downoprazol 40 sach", "Omeprazole 40 mg + Sodium Bicarbonate 1680 mg");}
    else if (selectedDrug == "Doxirazol 30 cap") {buttonClickShortcut("Doxirazol 30 cap", "Dexlansoprazole 30 mg");}
    else if (selectedDrug == "Doxycost 50 tab") {buttonClickShortcut("Doxycost 50 tab", "Doxycycline 50 mg");}
    else if (selectedDrug == "Doxycost 200 tab") {buttonClickShortcut("Doxycost 200 tab", "Doxycycline 200 mg");}
    else if (selectedDrug == "Dramenex tab") {buttonClickShortcut("Dramenex tab", "Dimenhydrinate 50 mg");}
    else if (selectedDrug == "Duodart cap") {buttonClickShortcut("Duodart cap", "Dutasteride 0.5 mg + Tamsulosin 0.4 mg");}
    else if (selectedDrug == "Duphalac syrup") {buttonClickShortcut("Duphalac syrup", "Lactulose 3.35 gm / 5 ml\n(120 ml & 200 ml)");}
    else if (selectedDrug == "Duphaston tab") {buttonClickShortcut("Duphaston tab", "Dydrogesterone 10 mg");}
    else if (selectedDrug == "Durazac 90 cap") {buttonClickShortcut("Durazac 90 cap", "Fluoxetine 90 mg");}
    else if (selectedDrug == "Duricef 250 cap") {buttonClickShortcut("Duricef 250 cap", "Cefadroxil 250 mg");}
    else if (selectedDrug == "Durogesic transdermal patch") {buttonClickShortcut("Durogesic transdermal patch", "Fentanyl (12/25/50/75/100) mcg / hour");}
    else if (selectedDrug == "E-mox 500 vial") {injectionClickShortcut("E-mox 500 vial", "Amoxicillin 500 mg");}
    else if (selectedDrug == "E-mox 1 gm vial") {injectionClickShortcut("E-mox 1 gm vial", "Amoxicillin 1000 mg");}
    else if (selectedDrug == "Easycol Baby drops") {buttonClickShortcut("Easycol Baby drops", "Lactase Enzyme\n(15 ml)");}
    else if (selectedDrug == "Edemex tab") {buttonClickShortcut("Edemex tab", "Bumetanide 1 mg");}
    else if (selectedDrug == "Edemex amp") {injectionClickShortcut("Edemex amp", "Bumetanide 0.5 mg / 2 ml");}
    else if (selectedDrug == "Efalex cap") {buttonClickShortcut("Efalex cap", "Fish Oil +Primrose Oil +Vit E +Thyme Oil");}
    else if (selectedDrug == "Efalex syrup") {buttonClickShortcut("Efalex syrup", "Fish Oil +Primrose Oil +Vit E +Thyme Oil\n(120 ml)");}
    else if (selectedDrug == "Effortil drops") {buttonClickShortcut("Effortil drops", "Etilefrine 7.5 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Effortil tab") {buttonClickShortcut("Effortil tab", "Etilefrine 5 mg");}
    else if (selectedDrug == "Egy Dronate tab") {buttonClickShortcut("Egy Dronate tab", "Alendronate 70 mg + Vit D3 2800 iu");}
    else if (selectedDrug == "Egy Pedical Plus syrup") {buttonClickShortcut("Egy Pedical Plus syrup", "Calcium Glubionate 770 mg (Elemental calcium 50 mg) + Vit D3 600 iu + Vit K2 7 mcg + Vit B12 1.4 mcg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Egycusate syrup") {buttonClickShortcut("Egycusate syrup", "Docusate Na 20 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Elbavit syrup") {buttonClickShortcut("Elbavit syrup", "Vit A + Vit E + Vit D3 + Vit B1 + Vit B2 + Vit B3 + Vit B5 + Vit B6 + Vit B9 + Vit B12 + Vit C + Iodine + Iron + Calcium\n(60 ml)");}
    else if (selectedDrug == "Eliquis 2.5 tab") {buttonClickShortcut("Eliquis 2.5 tab", "Apixaban 2.5 mg");}
    else if (selectedDrug == "Eliquis 5 tab") {buttonClickShortcut("Eliquis 5 tab", "Apixaban 5 mg");}
    else if (selectedDrug == "Elonda tab") {buttonClickShortcut("Elonda tab", "Cabergoline 0.5 mg");}
    else if (selectedDrug == "Em-Ex amp") {injectionClickShortcut("Em-Ex amp", "Granisetron 1 mg / 1 ml OR\nGranisetron 3 mg / 3 ml");}
    else if (selectedDrug == "Emetrex amp") {injectionClickShortcut("Emetrex amp", "Cyclizine 50 mg / 1 ml");}
    else if (selectedDrug == "Emetrex tab") {buttonClickShortcut("Emetrex tab", "Cyclizine 50 mg + Vit B6 30 mg");}
    else if (selectedDrug == "Empacoza 10 tab") {buttonClickShortcut("Empacoza 10 tab", "Empagliflozin 10 mg");}
    else if (selectedDrug == "Empacyrl tab") {buttonClickShortcut("Empacyrl tab", "Empagliflozin +Linagliptin\n(10/5)\n(25/5)");}
    else if (selectedDrug == "Enbrel 50 prefilled syringe") {injectionClickShortcut("Enbrel 50 prefilled syringe", "Etanercept 50 mg");}
    else if (selectedDrug == "Endoxan tab") {buttonClickShortcut("Endoxan tab", "Cyclophosphamide 50 mg");}
    else if (selectedDrug == "Endoxan 200 vial") {injectionClickShortcut("Endoxan 200 vial", "Cyclophosphamide 200 mg");}
    else if (selectedDrug == "Endoxan 1000 vial") {injectionClickShortcut("Endoxan 1000 vial", "Cyclophosphamide 1 gm");}
    else if (selectedDrug == "Enemax enema") {buttonClickShortcut("Enemax enema", "Disodium Phosphate 6 gm + Monosodium Phosphate 16 gm / 100 ml\n(120 ml)");}
    else if (selectedDrug == "Engilor 2.5/500 tab") {buttonClickShortcut("Engilor 2.5/500 tab", "Glipizide 2.5 mg + Metformin 500 mg");}
    else if (selectedDrug == "Enrich drops") {buttonClickShortcut("Enrich drops", "Ferric Hydroxide Polymaltose Complex 156.25 mg (Elemental Iron 50 mg) / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Enrich syrup") {buttonClickShortcut("Enrich syrup", "Ferric Hydroxide Polymaltose Complex 156.25 mg (Elemental Iron 50 mg) / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Enterogermina susp") {buttonClickShortcut("Enterogermina susp", "Bacillus Clausii Spores 2 billions / vial (5 ml)");}
    else if (selectedDrug == "Entocid tab") {buttonClickShortcut("Entocid tab", "Diiodohydroxyquinoline 200 mg +Phthalyl Sulfathiazole 200 mg +Streptomycin Sulphate 200 mg");}
    else if (selectedDrug == "Entresto tab") {buttonClickShortcut("Entresto tab", "Sacubitril + Valsartan\n(24/26)\n(49/51)\n(97/103)");}
    else if (selectedDrug == "Epcimox 125 tab") {buttonClickShortcut("Epcimox 125 tab", "Amoxicillin 125 mg");}
    else if (selectedDrug == "Epicogel susp") {buttonClickShortcut("Epicogel susp", "Aluminium Hydroxide 405 mg + Magnesium Hydroxide 100 mg + Dimethicone 125 mg / 5 ml\n(180 ml)");}
    else if (selectedDrug == "Epicophylline syrup") {buttonClickShortcut("Epicophylline syrup", "Acefylline Piperazine 125 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Epicotil supp") {buttonClickShortcut("Epicotil supp", "Tenoxicam 20 mg");}
    else if (selectedDrug == "Epicotil tab") {buttonClickShortcut("Epicotil tab", "Tenoxicam 20 mg");}
    else if (selectedDrug == "Epicotil vial") {injectionClickShortcut("Epicotil vial", "Tenoxicam 20 mg");}
    else if (selectedDrug == "Epicozym syrup") {buttonClickShortcut("Epicozym syrup", "Vitamin B complex\n(125 ml)");}
    else if (selectedDrug == "Epifasi amp") {injectionClickShortcut("Epifasi amp", "Human Chorionic Gonadotrophin 5000 iu");}
    else if (selectedDrug == "Epilat cap") {buttonClickShortcut("Epilat cap", "Nifedipine 10 mg");}
    else if (selectedDrug == "Epilat retard SR cap") {buttonClickShortcut("Epilat retard SR cap", "Nifedipine 20 mg");}
    else if (selectedDrug == "Epimag sach") {buttonClickShortcut("Epimag sach", "Magnesium Citrate 2.125 gm");}
    else if (selectedDrug == "Epinephrine amp") {injectionClickShortcut("Epinephrine amp", "Adrenaline 0.25 mg / 1 ml");}
    else if (selectedDrug == "Epinor 400 tab") {buttonClickShortcut("Epinor 400 tab", "Norfloxacin 400 mg");}
    else if (selectedDrug == "Epinosine-B Forte amp") {injectionClickShortcut("Epinosine-B Forte amp", "ATP 10 mg + Cocarboxylase 50 mg + Vit B12 0.5 mg + Nicotinamide 20 mg");}
    else if (selectedDrug == "Epirelefan amp") {injectionClickShortcut("Epirelefan amp", "Triamcinolone 40 mg / 1 ml");}
    else if (selectedDrug == "Eprex prefilled syringe") {injectionClickShortcut("Eprex prefilled syringe", "Erythropoietin Alpha\n2000 iu / 0.5 ml\n3000 iu / 0.3 ml\n4000 iu / 0.4 ml\n10000 iu / 1 ml\n40000 iu / 1 ml");}
    else if (selectedDrug == "Erastapex Co tab") {buttonClickShortcut("Erastapex Co tab", "Amlodipine +Olmesartan\n(5 / 20)\n(5 / 40)\n(10 / 40)");}
    else if (selectedDrug == "Erastapex Trio tab") {buttonClickShortcut("Erastapex Trio tab", "Amlodipine +Olmesartan +Hydrochlorothiazide\n(5 / 20 / 12.5)\n(5 / 40 / 12.5)\n(5 / 40 / 25)\n(10 / 40 / 12.5)\n(10 / 40 / 25)");}
    else if (selectedDrug == "Erythromycin susp") {buttonClickShortcut("Erythromycin susp", "Erythromycin Ethylsuccinate 200 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Erythrocin 250 tab") {buttonClickShortcut("Erythrocin 250 tab", "Erythromycin Ethylsuccinate 250 mg");}
    else if (selectedDrug == "Erythrocin 500 tab") {buttonClickShortcut("Erythrocin 500 tab", "Erythromycin Ethylsuccinate 500 mg");}
    else if (selectedDrug == "Eslizepine 400 tab") {buttonClickShortcut("Eslizepine 400 tab", "Eslicarbazepine 400 mg");}
    else if (selectedDrug == "Etaphylline Phenobarbital supp") {buttonClickShortcut("Etaphylline Phenobarbital supp", "Acefylline Piperazine 500 mg + Phenobarbital 100 mg");}
    else if (selectedDrug == "Etaphylline Phenobarbital syrup") {buttonClickShortcut("Etaphylline Phenobarbital syrup", "Acefylline Piperazine 100 mg + Phenobarbital 3.3 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Ethoxa syrup") {buttonClickShortcut("Ethoxa syrup", "Ethosuximide 250 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Eucarbon tab") {buttonClickShortcut("Eucarbon tab", "Charcoal + Rhubarb + Senna + Sulphur");}
    else if (selectedDrug == "Euthyrox 25 tab") {buttonClickShortcut("Euthyrox 25 tab", "Levothyroxine 25 mcg");}
    else if (selectedDrug == "Evastine syrup") {buttonClickShortcut("Evastine syrup", "Ebastine 5 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Evastine 10 tab") {buttonClickShortcut("Evastine 10 tab", "Ebastine 10 mg");}
    else if (selectedDrug == "Examide 5 tab") {buttonClickShortcut("Examide 5 tab", "Torsemide 5 mg");}
    else if (selectedDrug == "Exforge tab") {buttonClickShortcut("Exforge tab", "Amlodipine +Valsartan\n(5 / 160)\n(10 / 160)\n(5 / 320)\n(10 / 320)");}
    else if (selectedDrug == "Exforge HCT tab") {buttonClickShortcut("Exforge HCT tab", "Amlodipine +Valsartan +Hydrochlorothiazide\n(5 / 160 / 12.5)\n(10 / 160 / 12.5)\n(10 / 160 / 25)");}
    else if (selectedDrug == "Expaintech-PM tab") {buttonClickShortcut("Expaintech-PM tab", "Paracetamol 500 mg + Diphenhydramine 38 mg");}
    else if (selectedDrug == "Ezamol-C tab") {buttonClickShortcut("Ezamol-C tab", "Paracetamol 500 mg + Phenylephrine 5 mg + Caffeine 25 mg + Terpine hydrate 20 mg + Vit C 30 mg");}
    else if (selectedDrug == "Farcolin nebulizer solution") {buttonClickShortcut("Farcolin nebulizer solution", "Salbutamol 0.5% (5 mg / 1 ml)\n(20 ml)");}
    else if (selectedDrug == "Farcolin syrup") {buttonClickShortcut("Farcolin syrup", "Salbutamol 2 mg + Ammonium chloride 100 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Farcosolvin syrup") {buttonClickShortcut("Farcosolvin syrup", "Theophylline 50 mg + Guaifenesin 30 mg + Ambroxol 15 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Farcovit B12 cap") {buttonClickShortcut("Farcovit B12 cap", "Vit B1 + Vit B2 + Vit B6 + Vit B12 + Calcium + Nicotinamide + Inositol + Orotic Acid + Folic Acid + D (+) Biotin + Cynara + Safflower Oil + Essential Phospholipids");}
    else if (selectedDrug == "Faverin 50 tab") {buttonClickShortcut("Faverin 50 tab", "Fluvoxamine 50 mg");}
    else if (selectedDrug == "Fawar Fruit sach") {buttonClickShortcut("Fawar Fruit sach", "Citric Acid + Na Bicarbonate +Tartaric Acid");}
    else if (selectedDrug == "Feldene 10 cap") {buttonClickShortcut("Feldene 10 cap", "Piroxicam 10 mg");}
    else if (selectedDrug == "Feldene 20 cap") {buttonClickShortcut("Feldene 20 cap", "Piroxicam 20 mg");}
    else if (selectedDrug == "Femara tab") {buttonClickShortcut("Femara tab", "Letrozole 2.5 mg");}
    else if (selectedDrug == "Femogesal tab") {buttonClickShortcut("Femogesal tab", "Ethinyl Estradiol 0.03 mg + Gestodene 0.075 mg");}
    else if (selectedDrug == "Femrose cap") {buttonClickShortcut("Femrose cap", "Black Cohosh (Cimicifuga Racemosa) 80 mg");}
    else if (selectedDrug == "Fenistil drops") {buttonClickShortcut("Fenistil drops", "Dimethindene 1 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Fentanyl amp") {injectionClickShortcut("Fentanyl amp", "Fentanyl 0.1 mg / 2 ml");}
    else if (selectedDrug == "Feroglobin cap") {buttonClickShortcut("Feroglobin cap", "Folic Acid + Iron + Zinc + Copper + Vit B6 + Vit B12");}
    else if (selectedDrug == "Feroglobin syrup") {buttonClickShortcut("Feroglobin syrup", "Iron + Minerals + Vit B complex + Vit C\n(120 ml)");}
    else if (selectedDrug == "Ferrodep cap") {buttonClickShortcut("Ferrodep cap", "Sunactive Iron + Vit C");}
    else if (selectedDrug == "Ferrodep syrup") {buttonClickShortcut("Ferrodep syrup", "Sunactive Iron + Vit C + Zinc + Copper + Vit B2 + Vit B6 + Vit B12 + Folic Acid\n(150 ml)");}
    else if (selectedDrug == "Ferrotron cap") {buttonClickShortcut("Ferrotron cap", "Iron + Zinc + Copper + Molybdenum + Vit B1 + Vit B2 + Vit B6 + Vit B12 + Folic Acid + Vit C + Biotin");}
    else if (selectedDrug == "Fewmig cap") {buttonClickShortcut("Fewmig cap", "Feverfew 250 mg");}
    else if (selectedDrug == "Fitmotus tab") {buttonClickShortcut("Fitmotus tab", "Undenatured Collagen Type II 40 mg + Hyaluronic Acid 3.3 mg + Boron 5 mg");}
    else if (selectedDrug == "Flabu drops") {buttonClickShortcut("Flabu drops", "Ibuprofen 40 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Flacort 6 tab") {buttonClickShortcut("Flacort 6 tab", "Deflazacort 6 mg");}
    else if (selectedDrug == "Fladazole tab") {buttonClickShortcut("Fladazole tab", "Secnidazole 500 mg");}
    else if (selectedDrug == "Flagellat Forte susp") {buttonClickShortcut("Flagellat Forte susp", "Metronidazole 200 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Flamogen tab") {buttonClickShortcut("Flamogen tab", "Bromelain 90 mg + Rutoside 100 mg + Trypsin 48 mg");}
    else if (selectedDrug == "Flazol vial") {injectionClickShortcut("Flazol vial", "Metronidazole 500 mg / 100 ml");}
    else if (selectedDrug == "Fleboton amp") {injectionClickShortcut("Fleboton amp", "Troxerutin 150 mg +Carbazochrome 1.5 mg / 3 ml");}
    else if (selectedDrug == "Flexofan cap") {buttonClickShortcut("Flexofan cap", "Chlorzoxazone 250 mg + Ketoprofen 50 mg");}
    else if (selectedDrug == "Flexpro Extra tab") {buttonClickShortcut("Flexpro Extra tab", "Methocarbamol 400 mg + Paracetamol 500 mg");}
    else if (selectedDrug == "Flibanorin tab") {buttonClickShortcut("Flibanorin tab", "Flibanserin 100 mg");}
    else if (selectedDrug == "Flixotide Diskus 50") {buttonClickShortcut("Flixotide Diskus 50", "Fluticasone 50 mcg / dose");}
    else if (selectedDrug == "Flixotide Diskus 100") {buttonClickShortcut("Flixotide Diskus 100", "Fluticasone 100 mcg / dose");}
    else if (selectedDrug == "Flixotide Diskus 250") {buttonClickShortcut("Flixotide Diskus 250", "Fluticasone 250 mcg / dose");}
    else if (selectedDrug == "Flixotide Evohaler 50") {buttonClickShortcut("Flixotide Evohaler 50", "Fluticasone 50 mcg / actuation");}
    else if (selectedDrug == "Flixotide Evohaler 125") {buttonClickShortcut("Flixotide Evohaler 125", "Fluticasone 125 mcg / actuation");}
    else if (selectedDrug == "Flixotide Evohaler 250") {buttonClickShortcut("Flixotide Evohaler 250", "Fluticasone 250 mcg / actuation");}
    else if (selectedDrug == "Flopadex 4 cap") {buttonClickShortcut("Flopadex 4 cap", "Silodosin 4 mg");}
    else if (selectedDrug == "Flopadex 8 cap") {buttonClickShortcut("Flopadex 8 cap", "Silodosin 8 mg");}
    else if (selectedDrug == "Florax tab") {buttonClickShortcut("Florax tab", "Vit C 500 mg + Vit D 400 iu + Zinc 25 mg");}
    else if (selectedDrug == "Floxa west tab") {buttonClickShortcut("Floxa west tab", "Ofloxacin 300 mg");}
    else if (selectedDrug == "Fluimucil amp") {injectionClickShortcut("Fluimucil amp", "Acetylcysteine 100 mg / ml");}
    else if (selectedDrug == "Flumox 500 vial") {injectionClickShortcut("Flumox 500 vial", "Amoxicillin 250 mg + Flucloxacillin 250 mg");}
    else if (selectedDrug == "Flumox 1 gm vial") {injectionClickShortcut("Flumox 1 gm vial", "Amoxicillin 500 mg + Flucloxacillin 500 mg");}
    else if (selectedDrug == "Flumox 250 cap") {buttonClickShortcut("Flumox 250 cap", "Amoxicillin 125 mg + Flucloxacillin 125 mg");}
    else if (selectedDrug == "Flumox 500 cap") {buttonClickShortcut("Flumox 500 cap", "Amoxicillin 250 mg + Flucloxacillin 250 mg");}
    else if (selectedDrug == "Flumox 1 gm tab") {buttonClickShortcut("Flumox 1 gm tab", "Amoxicillin 500 mg + Flucloxacillin 500 mg");}
    else if (selectedDrug == "Flumox susp") {buttonClickShortcut("Flumox susp", "Amoxicillin 125 mg + Flucloxacillin 125 mg / 5 ml \n(100 ml)");}
    else if (selectedDrug == "Flurest tab") {buttonClickShortcut("Flurest tab", "Chlorpheniramine 2 mg + Phenylephrine 5 mg + Paracetamol 500 mg");}
    else if (selectedDrug == "Fluvermal susp") {buttonClickShortcut("Fluvermal susp", "Flubendazole 100 mg / 5 ml\n(30 ml)");}
    else if (selectedDrug == "Fluvermal tab") {buttonClickShortcut("Fluvermal tab", "Flubendazole 100 mg");}
    else if (selectedDrug == "Folic Acid 0.5 tab") {buttonClickShortcut("Folic Acid 0.5 tab", "Folic Acid 0.5 mg (500 mcg)");}
    else if (selectedDrug == "Foradil inhalation caps") {buttonClickShortcut("Foradil inhalation caps", "Formoterol Fumarate 12 mcg");}
    else if (selectedDrug == "Forteo prefilled pen") {injectionClickShortcut("Forteo prefilled pen", "Teriparatide 250 mcg / 1 ml (20 mcg / 80 mcl)\n(2.4 ml)");}
    else if (selectedDrug == "Forxiga 5 tab") {buttonClickShortcut("Forxiga 5 tab", "Dapagliflozin 5 mg");}
    else if (selectedDrug == "Fostimon vial") {injectionClickShortcut("Fostimon vial", "Urofollitropin\n75 iu\n150 iu");}
    else if (selectedDrug == "FPI-Zinc cap") {buttonClickShortcut("FPI-Zinc cap", "Zinc 50 mg");}
    else if (selectedDrug == "Fruital syrup") {buttonClickShortcut("Fruital syrup", "Vit A + Vit B1 + Vit B2 + Vit B6 + Nicotinamide + Vit C + Vit D2 + Vit E\n(120 ml)");}
    else if (selectedDrug == "Furazol tab") {buttonClickShortcut("Furazol tab", "Diloxanide 250 mg + Metronidazole 250 mg");}
    else if (selectedDrug == "G.C.Mol sach") {buttonClickShortcut("G.C.Mol sach", "Guaifenesin 100 mg + Vit C 250 mg + Paracetamol 325 mg");}
    else if (selectedDrug == "Galvus 50 tab") {buttonClickShortcut("Galvus 50 tab", "Vildagliptin 50 mg");}
    else if (selectedDrug == "Galvus Met tab") {buttonClickShortcut("Galvus Met tab", "Vildagliptin +Metformin\n(50/500)\n(50/850)\n(50/1000)");}
    else if (selectedDrug == "Ganaton tab") {buttonClickShortcut("Ganaton tab", "Itopride 50 mg");}
    else if (selectedDrug == "Gaptin 300 cap") {buttonClickShortcut("Gaptin 300 cap", "Gabapentin 300 mg");}
    else if (selectedDrug == "Gaptin syrup") {buttonClickShortcut("Gaptin syrup", "Gabapentin 250 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Garamycin 20 amp") {injectionClickShortcut("Garamycin 20 amp", "Gentamicin 20 mg / 2 ml");}
    else if (selectedDrug == "Garamycin 40 amp") {injectionClickShortcut("Garamycin 40 amp", "Gentamicin 40 mg / 2 ml");}
    else if (selectedDrug == "Garamycin 80 amp") {injectionClickShortcut("Garamycin 80 amp", "Gentamicin 80 mg / 2 ml");}
    else if (selectedDrug == "Gaseoflatex tab") {buttonClickShortcut("Gaseoflatex tab", "Simethicone 125 mg");}
    else if (selectedDrug == "Gast-reg 100 tab") {buttonClickShortcut("Gast-reg 100 tab", "Trimebutine 100 mg");}
    else if (selectedDrug == "Gast-reg 200 tab") {buttonClickShortcut("Gast-reg 200 tab", "Trimebutine 200 mg");}
    else if (selectedDrug == "Gast-reg susp") {buttonClickShortcut("Gast-reg susp", "Trimebutine 24 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Gast-reg amp") {injectionClickShortcut("Gast-reg amp", "Trimebutine 50 mg / 5 ml");}
    else if (selectedDrug == "Gastrobiotic 200 tab") {buttonClickShortcut("Gastrobiotic 200 tab", "Rifaximin 200 mg");}
    else if (selectedDrug == "Gastrobiotic 550 tab") {buttonClickShortcut("Gastrobiotic 550 tab", "Rifaximin 550 mg");}
    else if (selectedDrug == "Gastrofait 1 gm tab") {buttonClickShortcut("Gastrofait 1 gm tab", "Sucralfate 1 gm");}
    else if (selectedDrug == "Gastromotil 30 supp") {buttonClickShortcut("Gastromotil 30 supp", "Domperidone 30 mg");}
    else if (selectedDrug == "Gastromotil susp") {buttonClickShortcut("Gastromotil susp", "Domperidone 5 mg / 5 ml\n(200 ml)");}
    else if (selectedDrug == "Gastromotil tab") {buttonClickShortcut("Gastromotil tab", "Domperidone 10 mg");}
    else if (selectedDrug == "Gaviscon Advance susp") {buttonClickShortcut("Gaviscon Advance susp", "Potassium Bicarbonate 100 mg + Sodium Alginate 500 mg / 5 ml\n(150 ml)");}
    else if (selectedDrug == "Gemtesa tab") {buttonClickShortcut("Gemtesa tab", "Vibegron 75 mg");}
    else if (selectedDrug == "Geneleukim vial") {injectionClickShortcut("Geneleukim vial", "Filgrastim 300 mcg (30 mIU) / 1 ml");}
    else if (selectedDrug == "Genesemide syrup") {buttonClickShortcut("Genesemide syrup", "Furosemide 20 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Genuphil tab") {buttonClickShortcut("Genuphil tab", "Chondroitin 300 mg + Glucosamine 375 mg + Methyl Sulphonyl Methane (MSM) 375 mg");}
    else if (selectedDrug == "Genuphil Advance sach") {buttonClickShortcut("Genuphil Advance sach", "Chondroitin 1000 mg + Glucosamine 1500 mg + Methyl Sulphonyl Methane (MSM) 1000 mg + Collagen Hydrolysate 2000 mg + Hyaluronic Acid 100 mg");}
    else if (selectedDrug == "Genurin tab") {buttonClickShortcut("Genurin tab", "Flavoxate Hydrochloride 200 mg");}
    else if (selectedDrug == "Geo Pota-K tab") {buttonClickShortcut("Geo Pota-K tab", "Potassium Chloride 600 mg (8 mEq)");}
    else if (selectedDrug == "Gilenya cap") {buttonClickShortcut("Gilenya cap", "Fingolimod 0.5 mg");}
    else if (selectedDrug == "Ginkgo Biloba cap") {buttonClickShortcut("Ginkgo Biloba cap", "Ginkgo Biloba 260 mg");}
    else if (selectedDrug == "Ginko Plus cap") {buttonClickShortcut("Ginko Plus cap", "Ginseng 100 mg +Ginkgo Biloba 50 mg");}
    else if (selectedDrug == "Ginkofit cap") {buttonClickShortcut("Ginkofit cap", "Ginkgo Biloba 60 mg + Ginseng 100 mg + Royal Jelly 300 mg");}
    else if (selectedDrug == "Ginsana cap") {buttonClickShortcut("Ginsana cap", "Ginseng 100 mg");}
    else if (selectedDrug == "GIT cap") {buttonClickShortcut("GIT cap", "Peppermint oil + Caraway oil + Chamomile oil + Fennel oil + Ginger oil");}
    else if (selectedDrug == "Glomethasone amp") {injectionClickShortcut("Glomethasone amp", "Betamethasone 8 mg / 2 ml");}
    else if (selectedDrug == "Glucagen vial") {injectionClickShortcut("Glucagen vial", "Glucagon 1 mg / 1 ml");}
    else if (selectedDrug == "Glucofer tab") {buttonClickShortcut("Glucofer tab", "Ferrous Gluconate 300 mg (Elemental Iron 35 mg)");}
    else if (selectedDrug == "Glucolight XR 500 tab") {buttonClickShortcut("Glucolight XR 500 tab", "Metformin 500 mg");}
    else if (selectedDrug == "Glucose 5% IV solution") {injectionClickShortcut("Glucose 5% IV solution", "Dextrose 5%");}
    else if (selectedDrug == "Glucose 10% IV solution") {injectionClickShortcut("Glucose 10% IV solution", "Dextrose 10%");}
    else if (selectedDrug == "Glucose 25% IV solution") {injectionClickShortcut("Glucose 25% IV solution", "Dextrose 25%");}
    else if (selectedDrug == "Glucose 50% IV solution") {injectionClickShortcut("Glucose 50% IV solution", "Dextrose 50%");}
    else if (selectedDrug == "Glycerin infantile supp") {buttonClickShortcut("Glycerin infantile supp", "Glycerin 735 mg");}
    else if (selectedDrug == "Glycerin adult supp") {buttonClickShortcut("Glycerin adult supp", "Glycerin 1.47 gm");}
    else if (selectedDrug == "Glycodal tab") {buttonClickShortcut("Glycodal tab", "Calcium Carbonate 420 mg + Dimethicone 10 mg + Glycine 180 mg");}
    else if (selectedDrug == "Gonapure vial") {injectionClickShortcut("Gonapure vial", "Follitropin Alpha\n75 iu\n150 iu");}
    else if (selectedDrug == "Goutyless tab") {buttonClickShortcut("Goutyless tab", "Colchicine 0.5 mg + Probenecid 500 mg");}
    else if (selectedDrug == "Granitryl syrup") {buttonClickShortcut("Granitryl syrup", "Granisetron 1 mg / 5 ml\n(30 ml)");}
    else if (selectedDrug == "Gripe Baby Water") {buttonClickShortcut("Gripe Baby Water", "Terpeneless Dill Seed oil 2.3 mg + Sodium Bicarbonate 52 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Guava syrup") {buttonClickShortcut("Guava syrup", "Guava Leaves extract+ Tilia Flower extract\n(120 ml)");}
    else if (selectedDrug == "Gufidrexn tab") {buttonClickShortcut("Gufidrexn tab", "Guaifenesin 400 mg");}
    else if (selectedDrug == "Haema-caps cap") {buttonClickShortcut("Haema-caps cap", "Iron 115 mg + Vit B1 + Vit B2 + Vit B6 + Vit B12 + Vit C + Vit D3 + Vit E + Folic Acid + Calcium + Copper + Manganese + Taurine + Linoleic Acid + Linolenic Acid");}
    else if (selectedDrug == "Hairtonic cap") {buttonClickShortcut("Hairtonic cap", "Thiamine 60 mg + Pantothenic acid 60 mg + Selenium 100 mg + L-cystine 20 mg + Keratin 20 mg + Para-aminobenzoic acid 20 mg + Biotin 0.15 mg");}
    else if (selectedDrug == "Haldol Decanoas amp") {injectionClickShortcut("Haldol Decanoas amp", "Haloperidol 50 mg / 1 ml");}
    else if (selectedDrug == "Halonace 1.5 tab") {buttonClickShortcut("Halonace 1.5 tab", "Haloperidol 1.5 mg");}
    else if (selectedDrug == "Haloperidol amp") {injectionClickShortcut("Haloperidol amp", "Haloperidol 5 mg / 1 ml");}
    else if (selectedDrug == "Halorange syrup") {buttonClickShortcut("Halorange syrup", "Cod (Halibut) liver oil 75 mg + Vit C 52 mg\n(60 & 120 ml)");}
    else if (selectedDrug == "Haemojet cap") {buttonClickShortcut("Haemojet cap", "Ferric Hydroxide Polymaltose Complex 322.5 mg (Elemental Iron 100 mg)");}
    else if (selectedDrug == "Heli-cure tab") {buttonClickShortcut("Heli-cure tab", "Omeprazole 20 mg + Tinidazole 500 mg + Clarithromycin 250 mg");}
    else if (selectedDrug == "Hepa-Merz amp") {injectionClickShortcut("Hepa-Merz amp", "L-Ornithine-L-Aspartate 5 gm / 10 ml");}
    else if (selectedDrug == "Hepa-Merz sach") {buttonClickShortcut("Hepa-Merz sach", "L-Ornithine-L-Aspartate 3 gm");}
    else if (selectedDrug == "Hepaticum cap") {buttonClickShortcut("Hepaticum cap", "Silymarin 140 mg");}
    else if (selectedDrug == "Hepaticum susp") {buttonClickShortcut("Hepaticum susp", "Silymarin 50 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Hepato-Forte cap") {buttonClickShortcut("Hepato-Forte cap", "Essential Phospholipids + Vit B1 + Vit B2 + Vit B3 + Vit B6 + Vit B12 + Vit E");}
    else if (selectedDrug == "Herba Caf syrup") {buttonClickShortcut("Herba Caf syrup", "Guava Leaves + Tilia Flower + Fennel Oil +Liquorice Root");}
    else if (selectedDrug == "Herbana cap") {buttonClickShortcut("Herbana cap", "Fenugreek 250 mg + Fennel 50 mg + Dill 50 mg + Caraway 150 mg");}
    else if (selectedDrug == "Hi-cal syrup") {buttonClickShortcut("Hi-cal syrup", "Calcium glubionate 1200 mg / 5 ml\n78 mg elemental calcium / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Hi-cal forte syrup") {buttonClickShortcut("Hi-cal forte syrup", "Calcium glubionate 1800 mg / 5 ml\n115 mg elemental calcium / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Hi-Potency Formula tab") {buttonClickShortcut("Hi-Potency Formula tab", "Biotin + Vit B12 + Pantothenic Acid + Choline + Copper + Folic Acid + Iodine + Iron + Manganese + Niacin + PABA + Zinc");}
    else if (selectedDrug == "Hidonac amp") {injectionClickShortcut("Hidonac amp", "Acetylcysteine 200 mg / ml");}
    else if (selectedDrug == "Hidrasec infant sach") {buttonClickShortcut("Hidrasec infant sach", "Racecadotril 10 mg");}
    else if (selectedDrug == "Hidrasec children sach") {buttonClickShortcut("Hidrasec children sach", "Racecadotril 30 mg");}
    else if (selectedDrug == "Hidrasec cap") {buttonClickShortcut("Hidrasec cap", "Racecadotril 100 mg");}
    else if (selectedDrug == "Highcef 250 tab") {buttonClickShortcut("Highcef 250 tab", "Cefuroxime 250 mg");}
    else if (selectedDrug == "Holoxan 1 gm vial") {injectionClickShortcut("Holoxan 1 gm vial", "Ifosfamide 1 gm");}
    else if (selectedDrug == "Holoxan 2 gm vial") {injectionClickShortcut("Holoxan 2 gm vial", "Ifosfamide 2 gm");}
    else if (selectedDrug == "Homo sach") {buttonClickShortcut("Homo sach", "Lactoferrin + Colostrum + Zinc + Selenium + Vit C + Vit E + Calcium");}
    else if (selectedDrug == "Hopdetox tab") {buttonClickShortcut("Hopdetox tab", "Lofexidine 0.2 mg");}
    else if (selectedDrug == "Humalog kwikpen/cartridges") {injectionClickShortcut("Humalog kwikpen/cartridges", "Insulin Lispro 100 units / ml\nInsulin Lispro 200 units / ml");}
    else if (selectedDrug == "Humalog Mix kwikpen/cartridges") {injectionClickShortcut("Humalog Mix kwikpen/cartridges", "Insulin Lispro Protamine 75 units + Insulin Lispro 25 units / ml\nInsulin Lispro Protamine 50 units + Insulin Lispro 50 units / ml");}
    else if (selectedDrug == "Human Albumin 20% vial") {injectionClickShortcut("Human Albumin 20% vial", "Human Albumin 10 gm / 50 ml");}
    else if (selectedDrug == "Humira prefilled syringe") {injectionClickShortcut("Humira prefilled syringe", "Adalimumab 40 mg / 0.8 ml");}
    else if (selectedDrug == "Humulin N cartridges") {injectionClickShortcut("Humulin N cartridges", "Insulin NPH 100 units / ml");}
    else if (selectedDrug == "Humulin R cartridges") {injectionClickShortcut("Humulin R cartridges", "Insulin Regular Human 100 units / ml");}
    else if (selectedDrug == "Hyalgan prefilled syringe") {injectionClickShortcut("Hyalgan prefilled syringe", "Hyaluronic Acid 20 mg / 2 ml");}
    else if (selectedDrug == "Hyalone prefilled syringe") {injectionClickShortcut("Hyalone prefilled syringe", "Hyaluronic Acid 60 mg / 4 ml");}
    else if (selectedDrug == "Hydroquine tab") {buttonClickShortcut("Hydroquine tab", "Hydroxychloroquine Sulfate 200 mg");}
    else if (selectedDrug == "Hyzaar tab") {buttonClickShortcut("Hyzaar tab", "Losartan +Hydrochlorothiazide\n(50 / 12.5)\n(100 / 12.5)\n(100 / 25)");}
    else if (selectedDrug == "Ibandrocare tab") {buttonClickShortcut("Ibandrocare tab", "Ibandronate 150 mg");}
    else if (selectedDrug == "Ibiamox 200 susp") {buttonClickShortcut("Ibiamox 200 susp", "Amoxicillin 200 mg / 5 ml \n(80 ml)");}
    else if (selectedDrug == "Ibiamox 400 susp") {buttonClickShortcut("Ibiamox 400 susp", "Amoxicillin 400 mg / 5 ml \n(80 ml)");}
    else if (selectedDrug == "Ibiamox 250 cap") {buttonClickShortcut("Ibiamox 250 cap", "Amoxicillin 250 mg");}
    else if (selectedDrug == "Ibiamox 500 cap") {buttonClickShortcut("Ibiamox 500 cap", "Amoxicillin 500 mg");}
    else if (selectedDrug == "Icosalip cap") {buttonClickShortcut("Icosalip cap", "Icosapent Ethyl 1 gm");}
    else if (selectedDrug == "Imigran amp") {injectionClickShortcut("Imigran amp", "Sumatriptan 6 mg / 0.5 ml");}
    else if (selectedDrug == "Imigran tab") {buttonClickShortcut("Imigran tab", "Sumatriptan 50 mg");}
    else if (selectedDrug == "Immuguard sach") {buttonClickShortcut("Immuguard sach", "Bovine Colostrum");}
    else if (selectedDrug == "Immulant syrup") {buttonClickShortcut("Immulant syrup", "Echinacea dry extract 83.5 mg + Nigella sativa oil 0.008 ml / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Immuno Flu cap") {buttonClickShortcut("Immuno Flu cap", "Echinacea Purpurea + Zinc + Vit C");}
    else if (selectedDrug == "Immuno-mash tab") {buttonClickShortcut("Immuno-mash tab", "Vit C 500 mg + Zinc 23.5 mg");}
    else if (selectedDrug == "Immunvita drops") {buttonClickShortcut("Immunvita drops", "Echinacea dry extract 4.7 gm / 25 ml\n(25 ml)");}
    else if (selectedDrug == "Imodium instant tab") {buttonClickShortcut("Imodium instant tab", "Loperamide 2 mg");}
    else if (selectedDrug == "Imoflora tab") {buttonClickShortcut("Imoflora tab", "Loperamide 2 mg + Simethicone 125 mg");}
    else if (selectedDrug == "Inderal 10 tab") {buttonClickShortcut("Inderal 10 tab", "Propranolol 10 mg");}
    else if (selectedDrug == "Inderal 40 tab") {buttonClickShortcut("Inderal 40 tab", "Propranolol 40 mg");}
    else if (selectedDrug == "Indocid supp") {buttonClickShortcut("Indocid supp", "Indomethacin 100 mg");}
    else if (selectedDrug == "Indomethacin 25 cap") {buttonClickShortcut("Indomethacin 25 cap", "Indomethacin 25 mg");}
    else if (selectedDrug == "Indomethacin 50 cap") {buttonClickShortcut("Indomethacin 50 cap", "Indomethacin 50 mg");}
    else if (selectedDrug == "Inegy tab") {buttonClickShortcut("Inegy tab", "Simvastatin + Ezetimibe\n(10 / 10)\n(20 / 10)\n(40 / 10)\n(80 / 10)");}
    else if (selectedDrug == "Influvac Tetra prefilled syringe") {injectionClickShortcut("Influvac Tetra prefilled syringe", "Influenza Vaccine 15 mcg / 0.5 ml");}
    else if (selectedDrug == "Inofolic cap") {buttonClickShortcut("Inofolic cap", "Myo-inositol 600 mg + Folic Acid 0.24 mg");}
    else if (selectedDrug == "Inspago tab") {buttonClickShortcut("Inspago tab", "Agomelatine 25 mg");}
    else if (selectedDrug == "Intrafer tab") {buttonClickShortcut("Intrafer tab", "Elemental Iron 15 mg + Folic Acid 0.125 mg");}
    else if (selectedDrug == "Invanz 1 gm vial") {injectionClickShortcut("Invanz 1 gm vial", "Ertapenem 1 gm");}
    else if (selectedDrug == "Invega 3 XR tab") {buttonClickShortcut("Invega 3 XR tab", "Paliperidone 3 mg");}
    else if (selectedDrug == "Invokana 100 tab") {buttonClickShortcut("Invokana 100 tab", "Canagliflozin 100 mg");}
    else if (selectedDrug == "Irospect cap") {buttonClickShortcut("Irospect cap", "Iron + Mg + Zinc + Selenium + Chromium + Mn + Vit B2 + Vit B3 + Vit B5 + Vit B6 + Folate + Vit B12 + Vit C + Vit E");}
    else if (selectedDrug == "Iso Mak Retard 20 tab") {buttonClickShortcut("Iso Mak Retard 20 tab", "Isosorbide Dinitrate 20 mg");}
    else if (selectedDrug == "Isocid tab") {buttonClickShortcut("Isocid tab", "Isoniazid 100 mg");}
    else if (selectedDrug == "Isoprinosine susp") {buttonClickShortcut("Isoprinosine susp", "Isoprinosine 250 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Isoprinosine tab") {buttonClickShortcut("Isoprinosine tab", "Isoprinosine 500 mg");}
    else if (selectedDrug == "Isoptin 80 tab") {buttonClickShortcut("Isoptin 80 tab", "Verapamil 80 mg");}
    else if (selectedDrug == "Isoptin amp") {injectionClickShortcut("Isoptin amp", "Verapamil 5 mg / 2 ml");}
    else if (selectedDrug == "Itrapex cap") {buttonClickShortcut("Itrapex cap", "Itraconazole 100 mg");}
    else if (selectedDrug == "Iverzine tab") {buttonClickShortcut("Iverzine tab", "Ivermectin 6 mg");}
    else if (favContentDescription == "active") {generalDiag("Warning", "This drug either removed from the main list or the name has been changed\n\nRemove it from the favourite list then add it again");}
  }
  void getDoseJKLMNO () {
    if (selectedDrug == "Janumet tab") {buttonClickShortcut("Janumet tab", "Sitagliptin + Metformin\n(50/500)\n(50/850)\n(50/1000)");}
    else if (selectedDrug == "Januvia 100 tab") {buttonClickShortcut("Januvia 100 tab", "Sitagliptin 100 mg");}
    else if (selectedDrug == "Joint Plus tab") {buttonClickShortcut("Joint Plus tab", "Chondroitin + Glucosamine + Methyl Sulphonyl Methane (MSM) + Collagen Hydrolysate + Hyaluronic Acid");}
    else if (selectedDrug == "Joypox 30 tab") {buttonClickShortcut("Joypox 30 tab", "Dapoxetine 30 mg");}
    else if (selectedDrug == "Jusprin tab") {buttonClickShortcut("Jusprin tab", "Acetylsalicylic Acid 81 mg");}
    else if (selectedDrug == "Kalobin drops") {buttonClickShortcut("Kalobin drops", "Root of pelargonium sidoides\n(20 ml)");}
    else if (selectedDrug == "Kansartan 75 tab") {buttonClickShortcut("Kansartan 75 tab", "Irbesartan 75 mg");}
    else if (selectedDrug == "Kansartan Plus tab") {buttonClickShortcut("Kansartan Plus tab", "Irbesartan +Hydrochlorothiazide\n(150 / 12.5)\n(300 / 12.5)\n(300 / 25)");}
    else if (selectedDrug == "Kapect susp") {buttonClickShortcut("Kapect susp", "Kaolin 1 gm + Pectin 21.5 mg / 5 ml\n (120 ml)");}
    else if (selectedDrug == "Kapect comp susp") {buttonClickShortcut("Kapect comp susp", "Sulfamethoxazole 100 mg + Trimethoprim 20 mg + Kaolin 1 gm + Pectin 21.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Kapron tab") {buttonClickShortcut("Kapron tab", "Tranexamic Acid 500 mg");}
    else if (selectedDrug == "Kapron amp") {injectionClickShortcut("Kapron amp", "Tranexamic Acid 500 mg / 5 ml");}
    else if (selectedDrug == "Katrex syrup") {buttonClickShortcut("Katrex syrup", "Levamisole 40 mg / 5 ml\n(15 ml)");}
    else if (selectedDrug == "Katrex tab") {buttonClickShortcut("Katrex tab", "Levamisole 40 mg");}
    else if (selectedDrug == "Kaveda drops") {buttonClickShortcut("Kaveda drops", "Iron 55 mg + Vit A 250 mcg + Vit C 50 mg + Vit D3 400 iu + Vit E 5 mg + Vit B1 0.3 mg + Vit B2 0.4 mg + Vit B3 4 mg + Vit B6 0.4 mg/ 1 ml\n(30 ml)");}
    else if (selectedDrug == "Kellagon cap") {buttonClickShortcut("Kellagon cap", "Ammivisnaga extract 180 mg + Cymbopogon Proximus dry extract 72 mg");}
    else if (selectedDrug == "Kellagon sach") {buttonClickShortcut("Kellagon sach", "Khellin 20 mg + Cymbopogon Proximus 0.1 ml");}
    else if (selectedDrug == "Kenacort tab") {buttonClickShortcut("Kenacort tab", "Triamcinolone 4 mg");}
    else if (selectedDrug == "Keppra 250 tab") {buttonClickShortcut("Keppra 250 tab", "Levetiracetam 250 mg");}
    else if (selectedDrug == "Kerovit cap") {buttonClickShortcut("Kerovit cap", "Vitamins + Minerals");}
    else if (selectedDrug == "Ketamine vial") {injectionClickShortcut("Ketamine vial", "Ketamine 50 mg / 1 ml");}
    else if (selectedDrug == "Ketofan 5 susp") {buttonClickShortcut("Ketofan 5 susp", "Ketoprofen 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Ketofan 12.5 susp") {buttonClickShortcut("Ketofan 12.5 susp", "Ketoprofen 12.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Ketofan 25 tab") {buttonClickShortcut("Ketofan 25 tab", "Ketoprofen 25 mg");}
    else if (selectedDrug == "Ketofan 50 cap") {buttonClickShortcut("Ketofan 50 cap", "Ketoprofen 50 mg");}
    else if (selectedDrug == "Ketofan 75 cap") {buttonClickShortcut("Ketofan 75 cap", "Ketoprofen 75 mg");}
    else if (selectedDrug == "Ketofan 100 SR cap") {buttonClickShortcut("Ketofan 100 SR cap", "Ketoprofen 100 mg");}
    else if (selectedDrug == "Ketofan 200 SR cap") {buttonClickShortcut("Ketofan 200 SR cap", "Ketoprofen 200 mg");}
    else if (selectedDrug == "Ketofan amp") {injectionClickShortcut("Ketofan amp", "Ketoprofen 100 mg / 2 ml");}
    else if (selectedDrug == "Ketolac amp") {injectionClickShortcut("Ketolac amp", "Ketorolac 30 mg / 2 ml");}
    else if (selectedDrug == "Ketolac tab") {buttonClickShortcut("Ketolac tab", "Ketorolac 10 mg");}
    else if (selectedDrug == "Ketosteril tab") {buttonClickShortcut("Ketosteril tab", "Alpha-ketoanalogue of (Isoleucine + Leucine + Phenylalanine + Valine + Methionine) + L-lysine + L-threonine + L-tryptophan + L-histidine + L-tyrosine");}
    else if (selectedDrug == "Kidicare syrup") {buttonClickShortcut("Kidicare syrup", "Vit A + Vit B1 + Vit B2 + Vit B3 + Vit B6 + Vit B12 + Vit C + Vit D3 + Vit E + Biotin + Ca pantothenate + Folic Acid\n(120 ml)");}
    else if (selectedDrug == "Kids Daily Vit Sleep Syrup") {buttonClickShortcut("Kids Daily Vit Sleep Syrup", "Melatonin 1 mg / 1 ml\n(60 ml)");}
    else if (selectedDrug == "Kisqali tab") {buttonClickShortcut("Kisqali tab", "Ribociclib 200 mg");}
    else if (selectedDrug == "Klacid 125 susp") {buttonClickShortcut("Klacid 125 susp", "Clarithromycin 125 mg / 5 ml\n(70 ml)");}
    else if (selectedDrug == "Klacid 250 susp") {buttonClickShortcut("Klacid 250 susp", "Clarithromycin 250 mg / 5 ml\n(70 ml)");}
    else if (selectedDrug == "Klacid 250 tab") {buttonClickShortcut("Klacid 250 tab", "Clarithromycin 250 mg");}
    else if (selectedDrug == "Klacid 500 tab") {buttonClickShortcut("Klacid 500 tab", "Clarithromycin 500 mg");}
    else if (selectedDrug == "Klacid XL 500 tab") {buttonClickShortcut("Klacid XL 500 tab", "Clarithromycin 500 mg");}
    else if (selectedDrug == "Klacid vial") {injectionClickShortcut("Klacid vial", "Clarithromycin 500 mg");}
    else if (selectedDrug == "Klozepam drops") {buttonClickShortcut("Klozepam drops", "Clonazepam 2.5 mg / 1 ml");}
    else if (selectedDrug == "L-Carnitine amp") {injectionClickShortcut("L-Carnitine amp", "L-Carnitine (Levocarnitine) 1000 mg / 5 ml");}
    else if (selectedDrug == "L-Carnitine cap") {buttonClickShortcut("L-Carnitine cap", "L-Carnitine (Levocarnitine) 350 mg");}
    else if (selectedDrug == "L-Carnitine Plus tab") {buttonClickShortcut("L-Carnitine Plus tab", "L-Carnitine L-Tartrate 1000 mg +Zinc Gluconate 50 mg");}
    else if (selectedDrug == "L-Carnitine syrup") {buttonClickShortcut("L-Carnitine syrup", "L-Carnitine (Levocarnitine) 30% (300 mg/ml)\n(30 ml)");}
    else if (selectedDrug == "Labipress 100 tab") {buttonClickShortcut("Labipress 100 tab", "Labetalol 100 mg");}
    else if (selectedDrug == "Lacteol Forte cap") {buttonClickShortcut("Lacteol Forte cap", "Lactobacillus 5 billion");}
    else if (selectedDrug == "Lacteol Forte sach") {buttonClickShortcut("Lacteol Forte sach", "Lactobacillus 10 billion");}
    else if (selectedDrug == "Lactodel tab") {buttonClickShortcut("Lactodel tab", "Bromocriptine 2.5 mg");}
    else if (selectedDrug == "Lactomax sach") {buttonClickShortcut("Lactomax sach", "Fenugreek + Anise + Chamomile + Fennel");}
    else if (selectedDrug == "Lafurex amp") {injectionClickShortcut("Lafurex amp", "Furosemide 40 mg / 4 ml Or\nFurosemide 20 mg / 2 ml");}
    else if (selectedDrug == "Lafurex 20 tab") {buttonClickShortcut("Lafurex 20 tab", "Furosemide 20 mg");}
    else if (selectedDrug == "Lafurex 40 tab") {buttonClickShortcut("Lafurex 40 tab", "Furosemide 40 mg");}
    else if (selectedDrug == "Lamidine tab") {buttonClickShortcut("Lamidine tab", "Lamivudine 100 mg\nLamivudine 150 mg");}
    else if (selectedDrug == "Lamisil 125 tab") {buttonClickShortcut("Lamisil 125 tab", "Terbinafen 125 mg");}
    else if (selectedDrug == "Lamisil 250 tab") {buttonClickShortcut("Lamisil 250 tab", "Terbinafen 250 mg");}
    else if (selectedDrug == "Lamotrine 2 chew tab") {buttonClickShortcut("Lamotrine 2 chew tab", "Lamotrigine 2 mg");}
    else if (selectedDrug == "Lamotrine 25 tab") {buttonClickShortcut("Lamotrine 25 tab", "Lamotrigine 25 mg");}
    else if (selectedDrug == "Lanoxin amp") {injectionClickShortcut("Lanoxin amp", "Digoxin 0.5 mg / 2 ml");}
    else if (selectedDrug == "Lanoxin syrup") {buttonClickShortcut("Lanoxin syrup", "Digoxin 0.05 mg / 1 ml\n(60 ml)");}
    else if (selectedDrug == "Lanoxin tab") {buttonClickShortcut("Lanoxin tab", "Digoxin 0.25 mg");}
    else if (selectedDrug == "Lantus cartridges/pen") {injectionClickShortcut("Lantus cartridges/pen", "Insulin Glargine 100 units / ml");}
    else if (selectedDrug == "Lanzofutal 15 cap") {buttonClickShortcut("Lanzofutal 15 cap", "Lansoprazole 15 mg");}
    else if (selectedDrug == "Lanzofutal 30 cap") {buttonClickShortcut("Lanzofutal 30 cap", "Lansoprazole 30 mg");}
    else if (selectedDrug == "Laxeol PI tab") {buttonClickShortcut("Laxeol PI tab", "Sodium Picosulphate 5 mg");}
    else if (selectedDrug == "Laxin tab") {buttonClickShortcut("Laxin tab", "Bisacodyl 10 mg");}
    else if (selectedDrug == "Lentra sach") {buttonClickShortcut("Lentra sach", "Lactium 150 mg");}
    else if (selectedDrug == "Leukeran tab") {buttonClickShortcut("Leukeran tab", "Chlorambucil 2 mg");}
    else if (selectedDrug == "Levanox cap") {buttonClickShortcut("Levanox cap", "Catechu + Lecithin + Turmeric + Silymarin + Dandelion");}
    else if (selectedDrug == "Levemir flexpen") {injectionClickShortcut("Levemir flexpen", "Insulin Detemir 100 units / ml");}
    else if (selectedDrug == "Levocar 25/100 tab") {buttonClickShortcut("Levocar 25/100 tab", "Carbidopa 25 mg + Levodopa 100 mg");}
    else if (selectedDrug == "Levocar 25/250 tab") {buttonClickShortcut("Levocar 25/250 tab", "Carbidopa 25 mg + Levodopa 250 mg");}
    else if (selectedDrug == "Levocar 50/200 CR tab") {buttonClickShortcut("Levocar 50/200 CR tab", "Carbidopa 50 mg + Levodopa 200 mg");}
    else if (selectedDrug == "Levocarnine syrup") {buttonClickShortcut("Levocarnine syrup", "L-Carnitine 1000 mg / 10 ml\n(120 ml)");}
    else if (selectedDrug == "Levoflox 250 tab") {buttonClickShortcut("Levoflox 250 tab", "Levofloxacin 250 mg");}
    else if (selectedDrug == "Levohistam drops") {buttonClickShortcut("Levohistam drops", "Levocetirizine 5 mg / 1 ml\n(10 ml & 20 ml)");}
    else if (selectedDrug == "Levohistam syrup") {buttonClickShortcut("Levohistam syrup", "Levocetirizine 2.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Levohistam tab") {buttonClickShortcut("Levohistam tab", "Levocetirizine 5 mg");}
    else if (selectedDrug == "Levophrine amp") {injectionClickShortcut("Levophrine amp", "Noradrenaline 4 mg / 4 ml");}
    else if (selectedDrug == "Levoxin vial") {injectionClickShortcut("Levoxin vial", "Levofloxacin 500 mg / 100 ml");}
    else if (selectedDrug == "Librax tab") {buttonClickShortcut("Librax tab", "Clidinium 2.5 mg + Chlordiazepoxide 5 mg");}
    else if (selectedDrug == "Lidocaine 1% amp") {injectionClickShortcut("Lidocaine 1% amp", "Lidocaine 1%");}
    else if (selectedDrug == "Lidocaine 2% amp") {injectionClickShortcut("Lidocaine 2% amp", "Lidocaine 2%");}
    else if (selectedDrug == "Limitless Allzyme Max tab") {buttonClickShortcut("Limitless Allzyme Max tab", "Chymotrypsin 8.4 mg + Trypsin 30 mg + Bromelain 120 mg");}
    else if (selectedDrug == "Limitless Baby D drops") {buttonClickShortcut("Limitless Baby D drops", "Vit D3 (Cholecalciferol) 1600 iu / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Limitless C-Zinc lozenges") {buttonClickShortcut("Limitless C-Zinc lozenges", "Vit C 100 mg + Zinc 5 mg");}
    else if (selectedDrug == "Limitless C-Zinc Plus tab") {buttonClickShortcut("Limitless C-Zinc Plus tab", "Vit C 500 mg + Zinc 15 mg + Vit D3 400 iu + Mg 20 mg + Elderberry 162.5 mg Echinacea 162.5 mg");}
    else if (selectedDrug == "Limitless Chromax Cut sach") {buttonClickShortcut("Limitless Chromax Cut sach", "Glucomannan + Inulin + Chromium + Green Tea + Green Coffee + Vit B3 + Vit C");}
    else if (selectedDrug == "Limitless Fortalase syrup") {buttonClickShortcut("Limitless Fortalase syrup", "Alpha Amylase 1500 U.CEIP / 5 ml\n(80 ml)");}
    else if (selectedDrug == "Limitless Lactoferrin sach") {buttonClickShortcut("Limitless Lactoferrin sach", "Lactoferrin 100 mg");}
    else if (selectedDrug == "Limitless Man Max tab") {buttonClickShortcut("Limitless Man Max tab", "Vitamins + Minerals");}
    else if (selectedDrug == "Limitless Omega-3 Fish Oil cap") {buttonClickShortcut("Limitless Omega-3 Fish Oil cap", "Fish Oil 2000 mg (Omega 3 1400 mg) + Vit D");}
    else if (selectedDrug == "Limitless Prenatal Max cap") {buttonClickShortcut("Limitless Prenatal Max cap", "Vitamins + Minerals");}
    else if (selectedDrug == "Limitless Prostanorm Max tab") {buttonClickShortcut("Limitless Prostanorm Max tab", "Saw Palmetto + Pumpkin Seed Oil Powder + Pygeum Africanum + Stinging Nittle + Zinc + Lycopena + Selenium");}
    else if (selectedDrug == "Limitless Turmeric cap") {buttonClickShortcut("Limitless Turmeric cap", "Curcumin (Turmeric) 500 mg + Piperine 2.5 mg");}
    else if (selectedDrug == "Limitless Woman Max tab") {buttonClickShortcut("Limitless Woman Max tab", "Vitamins + Minerals");}
    else if (selectedDrug == "Limitless Zinc tab") {buttonClickShortcut("Limitless Zinc tab", "Zinc 25 mg");}
    else if (selectedDrug == "Lincocin amp") {injectionClickShortcut("Lincocin amp", "Lincomycin 300 mg / 1 ml\nLincomycin 600 mg / 2 ml");}
    else if (selectedDrug == "Linex adult cap") {buttonClickShortcut("Linex adult cap", "Lactobacillus acidophilus +Bifidobacterium Animalis Subsp. Lactis");}
    else if (selectedDrug == "Linex sach") {buttonClickShortcut("Linex sach", "Lactobacillus acidophilus +Bifidobacterium Animalis Subsp. Lactis");}
    else if (selectedDrug == "Liometacen amp") {injectionClickShortcut("Liometacen amp", "Indomethacin 50 mg / 2 ml");}
    else if (selectedDrug == "Lipidalon 1 tab") {buttonClickShortcut("Lipidalon 1 tab", "Pitavastatin 1 mg");}
    else if (selectedDrug == "Lipifibrate tab") {buttonClickShortcut("Lipifibrate tab", "Fenofibrate 105 mg");}
    else if (selectedDrug == "Livabion amp") {injectionClickShortcut("Livabion amp", "Vit B1 5 mg + Vit B6 4 mg + Vit B12 2.5 mg + Folic Acid 1 mg + Nicotinamide 20 mg + D-Panthenol 6 mg + Orotic Acid 10 mg / 2 ml");}
    else if (selectedDrug == "Livial tab") {buttonClickShortcut("Livial tab", "Tibolone 2.5 mg");}
    else if (selectedDrug == "Lokelma 5 sach") {buttonClickShortcut("Lokelma 5 sach", "Sodium Zirconium Cyclosilicate 5 gm");}
    else if (selectedDrug == "Lomotil syrup") {buttonClickShortcut("Lomotil syrup", "Diphenoxylate 2.5 mg + Atropine 0.025 mg / 5 ml");}
    else if (selectedDrug == "Lomotil tab") {buttonClickShortcut("Lomotil tab", "Diphenoxylate 2.5 mg + Atropine 0.025 mg");}
    else if (selectedDrug == "Lomoxen tab") {buttonClickShortcut("Lomoxen tab", "Lomefloxacin 400 mg");}
    else if (selectedDrug == "Loprecough syrup") {buttonClickShortcut("Loprecough syrup", "Acetylcysteine 100 mg + Chlorpheniramine 2 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Lucidril 250 tab") {buttonClickShortcut("Lucidril 250 tab", "Meclofenoxate 250 mg");}
    else if (selectedDrug == "Lucidril 500 tab") {buttonClickShortcut("Lucidril 500 tab", "Meclofenoxate 500 mg");}
    else if (selectedDrug == "Luciforte vial") {injectionClickShortcut("Luciforte vial", "Meclofenoxate 500 mg");}
    else if (selectedDrug == "Lutofolone amp") {injectionClickShortcut("Lutofolone amp", "Estradiol 2 mg + Progesterone 20 mg");}
    else if (selectedDrug == "Maalox Plus susp") {buttonClickShortcut("Maalox Plus susp", "Aluminum Hydroxide 225 mg + Magnesium Hydroxide 200 mg + Simethicone 25 mg / 5 ml\n(180 ml & 355 ml)");}
    else if (selectedDrug == "Maalox Plus tab") {buttonClickShortcut("Maalox Plus tab", "Aluminum Hydroxide 200 mg + Magnesium Hydroxide 200 mg + Simethicone 25 mg");}
    else if (selectedDrug == "MabThera 10 mg/ml vial") {injectionClickShortcut("MabThera 10 mg/ml vial", "Rituximab 10 mg / ml\n(500 mg / 50 ml)\n(100 mg / 10 ml)");}
    else if (selectedDrug == "Maddovit D3 drops") {buttonClickShortcut("Maddovit D3 drops", "Vit D 400 iu / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Magnesium Plus tab") {buttonClickShortcut("Magnesium Plus tab", "Magnesium Gluconate 100 mg + Magnesium Oxide 400 mg\n(245 mg elemental Magnesium)");}
    else if (selectedDrug == "Magnesium Sulfate amp") {injectionClickShortcut("Magnesium Sulfate amp", "Magnesium Sulphate 10% (1 gm / 10 ml)");}
    else if (selectedDrug == "Malari-Co tab") {buttonClickShortcut("Malari-Co tab", "Artemether 20 mg + Lumefantrine 120 mg");}
    else if (selectedDrug == "Mannitol 10%") {injectionClickShortcut("Mannitol 10%", "Mannitol 10%");}
    else if (selectedDrug == "Mannitol 20%") {injectionClickShortcut("Mannitol 20%", "Mannitol 20%");}
    else if (selectedDrug == "Marcaine amp") {injectionClickShortcut("Marcaine amp", "Bupivacaine 0.5%");}
    else if (selectedDrug == "Marcal tab") {buttonClickShortcut("Marcal tab", "Calcium Acetate 700 mg\n(180 mg elemental calcium)");}
    else if (selectedDrug == "Marcofen 100 supp") {buttonClickShortcut("Marcofen 100 supp", "Ibuprofen 100 mg");}
    else if (selectedDrug == "Marcofen 300 supp") {buttonClickShortcut("Marcofen 300 supp", "Ibuprofen 300 mg");}
    else if (selectedDrug == "Marcofen 500 supp") {buttonClickShortcut("Marcofen 500 supp", "Ibuprofen 500 mg");}
    else if (selectedDrug == "Marevan 1 tab") {buttonClickShortcut("Marevan 1 tab", "Warfarin 1 mg");}
    else if (selectedDrug == "Martaviva tab") {buttonClickShortcut("Martaviva tab", "Dienogest 2 mg + Ethinyl Estradiol 0.03 mg (30 mcg)");}
    else if (selectedDrug == "Marvit cap") {buttonClickShortcut("Marvit cap", "Vitamins + Minerals");}
    else if (selectedDrug == "Marvit syrup") {buttonClickShortcut("Marvit syrup", "Vitamins + Minerals\n(100 ml)");}
    else if (selectedDrug == "Matrix cap") {buttonClickShortcut("Matrix cap", "Calcium + Vit K2 + Magnesium + Potassium + Zinc + Manganese + Boron + Copper + Vit D3 + Vit C + Beta Carotene");}
    else if (selectedDrug == "Maxdinir 125 susp") {buttonClickShortcut("Maxdinir 125 susp", "Cefdinir 125 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Maxdinir 250 susp") {buttonClickShortcut("Maxdinir 250 susp", "Cefdinir 250 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Maxdinir 300 cap") {buttonClickShortcut("Maxdinir 300 cap", "Cefdinir 300 mg");}
    else if (selectedDrug == "Maxical D susp") {buttonClickShortcut("Maxical D susp", "Calcium 300 mg + Magnesium 100 mg + Vit D 200 iu / 10 ml\n(120 ml)");}
    else if (selectedDrug == "Maxical tab") {buttonClickShortcut("Maxical tab", "Calcium 600 mg + Vit D3 400 IU");}
    else if (selectedDrug == "Maxipime 500 vial") {injectionClickShortcut("Maxipime 500 vial", "Cefepime 500 mg");}
    else if (selectedDrug == "Maxipime 1 gm vial") {injectionClickShortcut("Maxipime 1 gm vial", "Cefepime 1000 mg");}
    else if (selectedDrug == "Maxipime 2 gm vial") {injectionClickShortcut("Maxipime 2 gm vial", "Cefepime 2000 mg");}
    else if (selectedDrug == "Mayestrotense amp") {injectionClickShortcut("Mayestrotense amp", "Propranolol 1 mg / 1 ml");}
    else if (selectedDrug == "Meclizigo odf") {buttonClickShortcut("Meclizigo odf", "Meclizine 25 mg");}
    else if (selectedDrug == "Meclopram amp") {injectionClickShortcut("Meclopram amp", "Metoclopramide 10 mg / 2 ml");}
    else if (selectedDrug == "Meclopram drops") {buttonClickShortcut("Meclopram drops", "Metoclopramide 2 mg / 1 ml\n(10 ml)");}
    else if (selectedDrug == "Meclopram syrup") {buttonClickShortcut("Meclopram syrup", "Metoclopramide 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Meclopram tab") {buttonClickShortcut("Meclopram tab", "Metoclopramide 10 mg");}
    else if (selectedDrug == "Megace tab") {buttonClickShortcut("Megace tab", "Megestrol 160 mg");}
    else if (selectedDrug == "Megafen tab") {buttonClickShortcut("Megafen tab", "Ibuprofen 200 mg + Paracetamol 325 mg");}
    else if (selectedDrug == "Megalase syrup") {buttonClickShortcut("Megalase syrup", "Alpha Amylase 1000 U.CEIP / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Megalase tab") {buttonClickShortcut("Megalase tab", "Alpha Amylase 3000 U.CEIP");}
    else if (selectedDrug == "Melacryst odf") {buttonClickShortcut("Melacryst odf", "Melatonin 1.5 mg");}
    else if (selectedDrug == "Melatonin 3 cap") {buttonClickShortcut("Melatonin 3 cap", "Melatonin 3 mg");}
    else if (selectedDrug == "Melatonin 5 tab") {buttonClickShortcut("Melatonin 5 tab", "Melatonin 5 mg");}
    else if (selectedDrug == "Mena Q-45 cap") {buttonClickShortcut("Mena Q-45 cap", "Vit K2 (Menaquinone-7) 45 mcg");}
    else if (selectedDrug == "Mepecaine carpules") {injectionClickShortcut("Mepecaine carpules", "Mepivacaine 3%");}
    else if (selectedDrug == "Merional 75 vial") {injectionClickShortcut("Merional 75 vial", "Human Menopausal Gonadotrophin (FSH+LH) 75 iu");}
    else if (selectedDrug == "Meronem 500 vial") {injectionClickShortcut("Meronem 500 vial", "Meropenem 500 mg");}
    else if (selectedDrug == "Meronem 1 gm vial") {injectionClickShortcut("Meronem 1 gm vial", "Meropenem 1 gm");}
    else if (selectedDrug == "Merti cap") {buttonClickShortcut("Merti cap", "Chitosan 500 mg +Vit C 20 mg + Chromium 5 mcg");}
    else if (selectedDrug == "Mesna amp") {injectionClickShortcut("Mesna amp", "Mesna 100 mg / 1 ml");}
    else if (selectedDrug == "Mesocept amp") {injectionClickShortcut("Mesocept amp", "Norethisterone Enanthate 50 mg + Estradiol Valerate 5 mg / 1 ml");}
    else if (selectedDrug == "Metacardia 20 tab") {buttonClickShortcut("Metacardia 20 tab", "Trimetazidine 20 mg");}
    else if (selectedDrug == "Metacardia 35 MR tab") {buttonClickShortcut("Metacardia 35 MR tab", "Trimetazidine 35 mg");}
    else if (selectedDrug == "Methabiogen tab") {buttonClickShortcut("Methabiogen tab", "Dexamethasone 8 mg");}
    else if (selectedDrug == "Methocarbex tab") {buttonClickShortcut("Methocarbex tab", "Methocarbamol 750 mg + Ibuprofen 400 mg");}
    else if (selectedDrug == "Methyltechno odf") {buttonClickShortcut("Methyltechno odf", "Methylcobalamin (Mecobalamin) 1000 mcg");}
    else if (selectedDrug == "Methadone 5 tab") {buttonClickShortcut("Methadone 5 tab", "Methadone 5 mg");}
    else if (selectedDrug == "Methergin tab") {buttonClickShortcut("Methergin tab", "Methylergometrine Hydrogen Maleate (Methylergonovine) 0.125 mg");}
    else if (selectedDrug == "Methotrexate 50 mg vial") {injectionClickShortcut("Methotrexate 50 mg vial", "Methotrexate 50 mg / 2 ml");}
    else if (selectedDrug == "Miacalcic amp") {injectionClickShortcut("Miacalcic amp", "Calcitonin 100 IU / ml");}
    else if (selectedDrug == "Miacalcic nasal spray") {buttonClickShortcut("Miacalcic nasal spray", "Calcitonin 200 IU / dose");}
    else if (selectedDrug == "Micardis 40 tab") {buttonClickShortcut("Micardis 40 tab", "Telmisartan 40 mg");}
    else if (selectedDrug == "Microcept tab") {buttonClickShortcut("Microcept tab", "Levonorgestrel 0.03 mg (30 mcg) + Ethinyl Estradiol 0.15 mg (150 mcg)");}
    else if (selectedDrug == "Microlut tab") {buttonClickShortcut("Microlut tab", "Levonorgestrel 0.03 mg");}
    else if (selectedDrug == "Mictonorm 15 tab") {buttonClickShortcut("Mictonorm 15 tab", "Propiverine Hydrochloride 15 mg");}
    else if (selectedDrug == "Mictonorm XL 30 tab") {buttonClickShortcut("Mictonorm XL 30 tab", "Propiverine Hydrochloride 30 mg");}
    else if (selectedDrug == "Midathetic tab") {buttonClickShortcut("Midathetic tab", "Midazolam 7.5 mg");}
    else if (selectedDrug == "Midodrine drops") {buttonClickShortcut("Midodrine drops", "Midodrine 1%\n(10 ml)");}
    else if (selectedDrug == "Midodrine tab") {buttonClickShortcut("Midodrine tab", "Midodrine 2.5 mg");}
    else if (selectedDrug == "Miflonide inhalation caps") {buttonClickShortcut("Miflonide inhalation caps", "Budesonide 400 mcg");}
    else if (selectedDrug == "Migrostop tab") {buttonClickShortcut("Migrostop tab", "Almotriptan 12.5 mg");}
    else if (selectedDrug == "Migtriptan tab") {buttonClickShortcut("Migtriptan tab", "Rizatriptan 5 mg");}
    else if (selectedDrug == "Milga tab") {buttonClickShortcut("Milga tab", "Benfotiamine 40 mg + Vit B6 60 mg + Vit B12 250 mcg");}
    else if (selectedDrug == "Milga Advance tab") {buttonClickShortcut("Milga Advance tab", "Benfotiamine 300 mg + Vit B6 100 mg + Vit B12 250 mcg");}
    else if (selectedDrug == "Mimpara 30 tab") {buttonClickShortcut("Mimpara 30 tab", "Cinacalcet 30 mg");}
    else if (selectedDrug == "Minalax tab") {buttonClickShortcut("Minalax tab", "Bisacodyl 5 mg + Docusate Sodium 100 mg");}
    else if (selectedDrug == "Mini Guava drops") {buttonClickShortcut("Mini Guava drops", "Guava Leaves extract+ Tilia Flower extract + Black Seed extract\n(15 ml)");}
    else if (selectedDrug == "Minidiab tab") {buttonClickShortcut("Minidiab tab", "Glipizide 5 mg");}
    else if (selectedDrug == "Minipress 1 tab") {buttonClickShortcut("Minipress 1 tab", "Prazosin 1 mg");}
    else if (selectedDrug == "Minirin 0.1 tab") {buttonClickShortcut("Minirin 0.1 tab", "Desmopressin 0.1 mg");}
    else if (selectedDrug == "Minirin 0.2 tab") {buttonClickShortcut("Minirin 0.2 tab", "Desmopressin 0.2 mg");}
    else if (selectedDrug == "Minirin Melt 60 mcg") {buttonClickShortcut("Minirin Melt 60 mcg tab", "Desmopressin 60 mcg");}
    else if (selectedDrug == "Minirin Melt 120 mcg") {buttonClickShortcut("Minirin Melt 120 mcg tab", "Desmopressin 120 mcg");}
    else if (selectedDrug == "Minophylline-N amp") {injectionClickShortcut("Minophylline-N amp", "Aminophylline 125 mg / 5 ml (2.5%)");}
    else if (selectedDrug == "Miopan susp") {buttonClickShortcut("Miopan susp", "Magaldrate 540 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Miopan Plus susp") {buttonClickShortcut("Miopan Plus susp", "Magaldrate 540 mg + Simethicone 40 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Misotac tab") {buttonClickShortcut("Misotac tab", "Misoprostol 200 mcg");}
    else if (selectedDrug == "Mixtard 30 vial") {injectionClickShortcut("Mixtard 30 vial", "Insulin Isophane Human 70 units + Insulin Regular Human 30 units / ml");}
    else if (selectedDrug == "Mobitil 7.5 cap") {buttonClickShortcut("Mobitil 7.5 tab", "Meloxicam 7.5 mg");}
    else if (selectedDrug == "Mobitil 15 cap") {buttonClickShortcut("Mobitil 15 tab", "Meloxicam 15 mg");}
    else if (selectedDrug == "Mobitil amp") {injectionClickShortcut("Mobitil amp", "Meloxicam 15 mg /1.5 ml");}
    else if (selectedDrug == "Moduretic 5/50 tab") {buttonClickShortcut("Moduretic 5/50 tab", "Amiloride 5 mg + Hydrochlorothiazide 50 mg");}
    else if (selectedDrug == "Mono Mak 20 tab") {buttonClickShortcut("Mono Mak 20 tab", "Isosorbide Mononitrate 20 mg");}
    else if (selectedDrug == "Monopril 10 tab") {buttonClickShortcut("Monopril 10 tab", "Fosinopril 10 mg");}
    else if (selectedDrug == "Monuril sach") {buttonClickShortcut("Monuril sach", "Fosfomycin 3 gm");}
    else if (selectedDrug == "Mosedin Plus SR cap") {buttonClickShortcut("Mosedin Plus SR cap", "Loratadine 5 mg + Pseudoephedrine 120 mg");}
    else if (selectedDrug == "Mosedin syrup") {buttonClickShortcut("Mosedin syrup", "Loratadine 5 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Mosedin tab") {buttonClickShortcut("Mosedin tab", "Loratadine 10 mg");}
    else if (selectedDrug == "Morphine Sulphate 10 mg/ml amp") {injectionClickShortcut("Morphine Sulphate 10 mg/ml amp", "Morphine 10 mg / 1 ml");}
    else if (selectedDrug == "Morphine Sulphate 20 mg/ml amp") {injectionClickShortcut("Morphine Sulphate 20 mg/ml amp", "Morphine 20 mg / 1 ml");}
    else if (selectedDrug == "Mosapride 2.5 tab") {buttonClickShortcut("Mosapride 2.5 tab", "Mosapride 2.5 mg");}
    else if (selectedDrug == "Mosapride 5 tab") {buttonClickShortcut("Mosapride 5 tab", "Mosapride 5 mg");}
    else if (selectedDrug == "Moviprep sach") {buttonClickShortcut("Moviprep sach", "Sachet A contains: Macrogol 3350 + Sodium sulfate anhydrous + Sodium Chloride + Potassium Chloride\nSachet B contains: Ascorbic Acid + Sodium Ascorbate");}
    else if (selectedDrug == "Moxiflox tab") {buttonClickShortcut("Moxiflox tab", "Moxifloxacin 400 mg");}
    else if (selectedDrug == "Moxiflox infusion") {injectionClickShortcut("Moxiflox infusion", "Moxifloxacin 400 mg / 250 ml");}
    else if (selectedDrug == "Mpiviropack tab") {buttonClickShortcut("Mpiviropack tab", "Sofosbuvir 400 mg");}
    else if (selectedDrug == "Mpiviropack Plus tab") {buttonClickShortcut("Mpiviropack Plus tab", "Ledipasvir 90 mg + Sofosbuvir 400 mg");}
    else if (selectedDrug == "MST Continus tab") {buttonClickShortcut("MST Continus tab", "Morphine 30 mg");}
    else if (selectedDrug == "Mucinex tab") {buttonClickShortcut("Mucinex tab", "Guaifenesin 600 mg");}
    else if (selectedDrug == "Mucogel susp") {buttonClickShortcut("Mucogel susp", "Aluminium hydroxide + Magnesium Hydroxide + Oxethazine\n(180 ml)");}
    else if (selectedDrug == "Mucophylline syrup") {buttonClickShortcut("Mucophylline syrup", "Bromhexine 4 mg + Acephylline piperazine 100 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Mucosol adult syrup") {buttonClickShortcut("Mucosol adult syrup", "Carbocisteine 250 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Mucosol ped syrup") {buttonClickShortcut("Mucosol ped syrup", "Carbocisteine 125 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Mucosol cap") {buttonClickShortcut("Mucosol cap", "Carbocisteine 375 mg");}
    else if (selectedDrug == "Mucosta tab") {buttonClickShortcut("Mucosta tab", "Rebamipide 100 mg");}
    else if (selectedDrug == "Mucotec 150 cap") {buttonClickShortcut("Mucotec 150 cap", "Erdosteine 150 mg");}
    else if (selectedDrug == "Mucotec 300 cap") {buttonClickShortcut("Mucotec 300 cap", "Erdosteine 300 mg");}
    else if (selectedDrug == "Mucotec susp") {buttonClickShortcut("Mucotec susp", "Erdosteine 175 mg / 5ml\n(100 ml)");}
    else if (selectedDrug == "Multi-Relax 5 tab") {buttonClickShortcut("Multi-Relax 5 tab", "Cyclobenzaprine 5 mg");}
    else if (selectedDrug == "My-Sweet Baby N syrup") {buttonClickShortcut("My-Sweet Baby N syrup", "Dill Oil 2.3 mg + Caraway Oil 0.0183 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Mycostatin drops") {buttonClickShortcut("Mycostatin drops", "Nystatin 100 000 units / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Myfortic 180 tab") {buttonClickShortcut("Myfortic 180 tab", "Mycophenolic acid 180 mg");}
    else if (selectedDrug == "Myfortic 360 tab") {buttonClickShortcut("Myfortic 360 tab", "Mycophenolic acid 360 mg");}
    else if (selectedDrug == "Mylobac 10 tab") {buttonClickShortcut("Mylobac 10 tab", "Baclofen 10 mg");}
    else if (selectedDrug == "Myodonia 25 tab") {buttonClickShortcut("Myodonia 25 tab", "Milnacipran 25 mg");}
    else if (selectedDrug == "Myofen cap") {buttonClickShortcut("Myofen cap", "Chlorzoxazone 250 mg + Ibuprofen 200 mg");}
    else if (selectedDrug == "Na Nitroprusside vial") {injectionClickShortcut("Na Nitroprusside vial", "Sodium Nitroprusside 50 mg");}
    else if (selectedDrug == "Nalidram tab") {buttonClickShortcut("Nalidram tab", "Nalidixic Acid 500 mg");}
    else if (selectedDrug == "Naloxone amp") {injectionClickShortcut("Naloxone amp", "Naloxone 0.4 mg / 1 ml");}
    else if (selectedDrug == "Nalufin amp") {injectionClickShortcut("Nalufin amp", "Nalbuphine 20 mg / 1 ml");}
    else if (selectedDrug == "Nanazoxide susp") {buttonClickShortcut("Nanazoxide susp", "Nitazoxanide 100 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Nanazoxide tab") {buttonClickShortcut("Nanazoxide tab", "Nitazoxanide 500 mg");}
    else if (selectedDrug == "Nandurabolin 50 amp") {injectionClickShortcut("Nandurabolin 50 amp", "Nandrolone Decanoate 50 mg");}
    else if (selectedDrug == "Naprosyn 250 tab") {buttonClickShortcut("Naprosyn 250 tab", "Naproxen 250 mg");}
    else if (selectedDrug == "Naprosyn 500 supp") {buttonClickShortcut("Naprosyn 500 supp", "Naproxen 500 mg");}
    else if (selectedDrug == "Naprosyn 500 tab") {buttonClickShortcut("Naprosyn 500 tab", "Naproxen 500 mg");}
    else if (selectedDrug == "Naredrix tab") {buttonClickShortcut("Naredrix tab", "Naratriptan 2.5 mg");}
    else if (selectedDrug == "Narkleen cap") {buttonClickShortcut("Narkleen cap", "Activated Coconut charcoal + Coconut oil + Peppermint oil");}
    else if (selectedDrug == "Nashiliv 5 tab") {buttonClickShortcut("Nashiliv 5 tab", "Obeticholic Acid 5 mg");}
    else if (selectedDrug == "Naso-Cyanocobalamin nasal spray") {buttonClickShortcut("Naso-Cyanocobalamin nasal spray", "Cyanocobalamin 500 mcg / 0.1 ml");}
    else if (selectedDrug == "Nassar tab") {buttonClickShortcut("Nassar tab", "Aloe Vera 100 mg + Belladonna 10 mg + Colocynth 50 mg + Scammony 50 mg");}
    else if (selectedDrug == "Natrilix SR 1.5 tab") {buttonClickShortcut("Natrilix SR 1.5 tab", "Indapamide 1.5 mg");}
    else if (selectedDrug == "Natural Colon Aid tab") {buttonClickShortcut("Natural Colon Aid tab", "Psyllium husk +Bentonite +Citrus Pectin cellulose +Lactobacillus Acidophilus +Wheat Grass +Buckthorn bark +Goldenseal root +Gentian root +Black Walnut leaf +Orange peel");}
    else if (selectedDrug == "Nausilex amp") {injectionClickShortcut("Nausilex amp", "Alizapride 50 mg / 2 ml");}
    else if (selectedDrug == "Naviluca cap") {buttonClickShortcut("Naviluca cap", "Fluconazole 200 mg");}
    else if (selectedDrug == "Navoproxin supp") {buttonClickShortcut("Navoproxin supp", "Meclizine 50 mg");}
    else if (selectedDrug == "Navoproxin plus tab") {buttonClickShortcut("Navoproxin plus tab", "Meclizine 25 mg + Vit B6 50 mg");}
    else if (selectedDrug == "Nebido amp") {injectionClickShortcut("Nebido amp", "Testosterone Undecanoate 250 mg / 1 ml\n(the equivalent of about 157.9 mg testosterone)\n(4 ml)");}
    else if (selectedDrug == "Nebraglob drops") {buttonClickShortcut("Nebraglob drops", "Iron 15 mg + Vit C 40 mg + Folic Acid 80 mcg + Vit B12 0.4 mcg / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Neo-Bronchophane syrup") {buttonClickShortcut("Neo-Bronchophane syrup", "Diphenhydramine 5 mg + Guaifenesin 50 mg + Oxeladin 10 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Neo Minophylline syrup") {buttonClickShortcut("Neo Minophylline syrup", "Theophylline 50 mg + Guaifenesin 50 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Neocarbon cap") {buttonClickShortcut("Neocarbon cap", "Activated Charcoal 145 mg + Anise 50 mg + Peppermint 40 mg");}
    else if (selectedDrug == "Neomaint solution") {injectionClickShortcut("Neomaint solution", "Anhydrous Glucose 12 gm + Sodium Chloride 0.17555 gm + Potassium Chloride 0.07445 gm / 100 ml");}
    else if (selectedDrug == "Neomycin tab") {buttonClickShortcut("Neomycin tab", "Neomycin 500 mg");}
    else if (selectedDrug == "Neopression 1 tab") {buttonClickShortcut("Neopression 1 tab", "Brexpiprazole 1 mg");}
    else if (selectedDrug == "Neostigmine amp") {injectionClickShortcut("Neostigmine amp", "Neostigmine 0.5 mg / ml");}
    else if (selectedDrug == "Neostigmine tab") {buttonClickShortcut("Neostigmine tab", "Neostigmine 15 mg");}
    else if (selectedDrug == "Netlook 10 cap") {buttonClickShortcut("Netlook 10 cap", "Isotretinoin 10 mg");}
    else if (selectedDrug == "Netlook 20 cap") {buttonClickShortcut("Netlook 20 cap", "Isotretinoin 20 mg");}
    else if (selectedDrug == "Netlook 40 cap") {buttonClickShortcut("Netlook 40 cap", "Isotretinoin 40 mg");}
    else if (selectedDrug == "Neupogen prefilled syringe") {injectionClickShortcut("Neupogen prefilled syringe", "Filgrastim 300 mcg (30 mIU) /0.5 ml");}
    else if (selectedDrug == "Neurazine 25 tab") {buttonClickShortcut("Neurazine 25 tab", "Chlorpromazine 25 mg");}
    else if (selectedDrug == "Neurazine amp") {injectionClickShortcut("Neurazine amp", "Chlorpromazine 50 mg / 2 ml");}
    else if (selectedDrug == "Neuril amp") {injectionClickShortcut("Neuril amp", "Diazepam 10 mg / 2 ml");}
    else if (selectedDrug == "Neuril 2 tab") {buttonClickShortcut("Neuril 2 tab", "Diazepam 2 mg");}
    else if (selectedDrug == "Neuril 5 tab") {buttonClickShortcut("Neuril 5 tab", "Diazepam 5 mg");}
    else if (selectedDrug == "Neurimax amp") {injectionClickShortcut("Neurimax amp", "Vit B1 200 mg + Vit B2 4 mg + Vit B6 100 mg + Vit B12 1 mg");}
    else if (selectedDrug == "Neuroton tab") {buttonClickShortcut("Neuroton tab", "Vit B1 250 mg + Vit B2 15 mg + Vit B6 150 mg + Vit B12 0.25 mg + Folic Acid 0.5 mg");}
    else if (selectedDrug == "Neurovit amp") {injectionClickShortcut("Neurovit amp", "Vit B1 150 mg + Vit B6 100 mg + Vit B12 1 mg / 3 ml");}
    else if (selectedDrug == "Neurovit tab") {buttonClickShortcut("Neurovit tab", "Vit B1 250 mg + Vit B6 100 mg + Vit B12 0.25 mg");}
    else if (selectedDrug == "Nevilob 5 tab") {buttonClickShortcut("Nevilob 5 tab", "Nebivolol 5 mg");}
    else if (selectedDrug == "Nevilob Plus tab") {buttonClickShortcut("Nevilob Plus tab", "Nebivolol + Hydrochlorothiazide\n5/12.5\n5/25");}
    else if (selectedDrug == "Nexa Tic sach") {buttonClickShortcut("Nexa Tic sach", "Lactobacillus Acidophilus +Bifidobacterium Longum + Inulin +Zinc 5 mg");}
    else if (selectedDrug == "Nexium 20 tab") {buttonClickShortcut("Nexium 20 tab", "Esomeprazole 20 mg");}
    else if (selectedDrug == "Nexium 40 tab") {buttonClickShortcut("Nexium 40 tab", "Esomeprazole 40 mg");}
    else if (selectedDrug == "Nexium sach") {buttonClickShortcut("Nexium sach", "Esomeprazole 10 mg");}
    else if (selectedDrug == "Nexium vial") {injectionClickShortcut("Nexium vial", "Esomeprazole 40 mg");}
    else if (selectedDrug == "Nimotop tab") {buttonClickShortcut("Nimotop tab", "Nimodipine 30 mg");}
    else if (selectedDrug == "Nitroderm TTS 5 patches") {buttonClickShortcut("Nitroderm TTS 5 patches", "Nitroglycerin 5 mg / 24 hours");}
    else if (selectedDrug == "Nitromak retard 2.5 cap") {buttonClickShortcut("Nitromak retard 2.5 cap", "Nitroglycerin 2.5 mg");}
    else if (selectedDrug == "Nitronal vial") {injectionClickShortcut("Nitronal vial", "Nitroglycerin 1 mg / 1 ml");}
    else if (selectedDrug == "Nizatect 150 cap") {buttonClickShortcut("Nizatect 150 cap", "Nizatidine 150 mg");}
    else if (selectedDrug == "Nizatect 300 cap") {buttonClickShortcut("Nizatect 300 cap", "Nizatidine 300 mg");}
    else if (selectedDrug == "No Deprine tab") {buttonClickShortcut("No Deprine tab", "Tofisopam 50 mg");}
    else if (selectedDrug == "Noerosive syrup") {buttonClickShortcut("Noerosive syrup", "Ranitidine 75 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Nono Water syrup") {buttonClickShortcut("Nono Water syrup", "Caraway Oil 2.5 mg + Dill Oil 2.25 mg + Sodium Bicarbonate 50 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Nopain amp") {injectionClickShortcut("Nopain amp", "Nefopam 20 mg / 1 ml");}
    else if (selectedDrug == "Norflex amp") {injectionClickShortcut("Norflex amp", "Orphenadrin 30 mg / 1 ml");}
    else if (selectedDrug == "Norflex tab") {buttonClickShortcut("Norflex tab", "Orphenadrin 100 mg");}
    else if (selectedDrug == "Norgesic tab") {buttonClickShortcut("Norgesic tab", "Orphenadrin 35 mg + Paracetamol 450 mg");}
    else if (selectedDrug == "Norvasc 5 tab") {buttonClickShortcut("Norvasc 5 tab", "Amlodipine 5 mg");}
    else if (selectedDrug == "Notussil syrup") {buttonClickShortcut("Notussil syrup", "Cloperastine 20 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Novomix flexpen/penfills") {injectionClickShortcut("Novomix flexpen/penfills", "Insulin Aspart Protamine 50 units + Insulin Aspart 50 units / ml\nInsulin Aspart Protamine 70 units + Insulin Aspart 30 units / ml");}
    else if (selectedDrug == "Novonorm 0.5 tab") {buttonClickShortcut("Novonorm 0.5 tab", "Repaglinide 0.5 mg");}
    else if (selectedDrug == "Novorapid flexpen/penfills") {injectionClickShortcut("Novorapid flexpen/penfills", "Insulin Aspart 100 units / ml");}
    else if (selectedDrug == "Nucleobuvir Velpa tab") {buttonClickShortcut("Nucleobuvir Velpa tab", "Sofosbuvir 400 mg + Velpatasvir 100 mg");}
    else if (selectedDrug == "Nulivia sach") {buttonClickShortcut("Nulivia sach", "Fructo-oligosaccharide 3 gm");}
    else if (selectedDrug == "Octatron cap") {buttonClickShortcut("Octatron cap", "Zinc 11 mg + Selenium 55 mcg + Molybdenum 45 mg + Vit B7 10 mcg + Mixed Bioflavonoids 100 mg + Vit E 15 iu + Vit A 300 iu + Vit C 90 mg");}
    else if (selectedDrug == "Octomotol tab") {buttonClickShortcut("Octomotol tab", "Bumadizone 110 mg");}
    else if (selectedDrug == "Octovent Plus syrup") {buttonClickShortcut("Octovent Plus syrup", "Guaifenesin 50 mg + Salbutamol 2 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Ocuguard cap") {buttonClickShortcut("Ocuguard cap", "Ginkgo Biloba 40 mg + Selenium 10 mg + Vit A 11 mg + Vit B12 2.4 mg + Vit C 66 mg + Vit E 10 mg + Nicotinamide 10.5 + Zinc 1.9 mg");}
    else if (selectedDrug == "Omecod syrup") {buttonClickShortcut("Omecod syrup", "Cod Liver Oil + Vit A + Vit D3 + Vit E\n(100 ml)");}
    else if (selectedDrug == "Omega-3 Plus cap") {buttonClickShortcut("Omega-3 Plus cap", "Omega-3 Fish oil 1 gm + Wheat Germ Oil 100 mg");}
    else if (selectedDrug == "Omega Rx gummies") {buttonClickShortcut("Omega Rx gummies", "Omega-3 + vit C + Vit D");}
    else if (selectedDrug == "Omegaddox syrup") {buttonClickShortcut("Omegaddox syrup", "Omega3 Fish Oil + Vit A + Vit B1 + Vit B2 + Vit B3 + Vit B5 + Vit B6 + Vit B7 + Vit C + Vit D3 + Vit E + Iodine + Selenium + Zinc\n(200 ml)");}
    else if (selectedDrug == "Omegaseef cap") {buttonClickShortcut("Omegaseef cap", "Fish Oil 400 mg + Flax Seed Oil Flax Seed Oil 400 mg + Borage Oil 400 mg + Vit E 10 mg");}
    else if (selectedDrug == "Omez 10 cap") {buttonClickShortcut("Omez 10 cap", "Omeprazole 10 mg");}
    else if (selectedDrug == "Omez 20 cap") {buttonClickShortcut("Omez 20 cap", "Omeprazole 20 mg");}
    else if (selectedDrug == "Omez 40 cap") {buttonClickShortcut("Omez 40 cap", "Omeprazole 40 mg");}
    else if (selectedDrug == "Omez vial") {injectionClickShortcut("Omez vial", "Omeprazole 40 mg");}
    else if (selectedDrug == "Omnitrope 5mg/ 1.5ml cartridge") {injectionClickShortcut("Omnitrope 5mg/ 1.5ml cartridge", "Somatropin 5 mg / 1.5 ml");}
    else if (selectedDrug == "Omnitrope 10mg/ 1.5ml cartridge") {injectionClickShortcut("Omnitrope 10mg/ 1.5ml cartridge", "Somatropin 10 mg / 1.5 ml");}
    else if (selectedDrug == "Ondalenz 4 odf") {buttonClickShortcut("Ondalenz 4 odf", "Ondansetron 4 mg");}
    else if (selectedDrug == "Ondalenz 8 odf") {buttonClickShortcut("Ondalenz 8 odf", "Ondansetron 8 mg");}
    else if (selectedDrug == "One alpha drops") {buttonClickShortcut("One alpha drops", "Alfacalcidol 2 mcg / 1 ml\n(10 ml & 20 ml)");}
    else if (selectedDrug == "One alpha 0.25 cap") {buttonClickShortcut("One alpha 0.25 cap", "Alfacalcidol 0.25 mcg");}
    else if (selectedDrug == "One alpha 0.5 cap") {buttonClickShortcut("One alpha 0.5 cap", "Alfacalcidol 0.5 mcg");}
    else if (selectedDrug == "One alpha 1 mcg cap") {buttonClickShortcut("One alpha 1 mcg cap", "Alfacalcidol 1 mcg");}
    else if (selectedDrug == "One Two Three syrup") {buttonClickShortcut("One Two Three syrup", "Chlorpheniramine 1 mg + Pseudoephedrine 15 mg + Paracetamol 160 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Oplex-N syrup") {buttonClickShortcut("Oplex-N syrup", "Oxomemazine 1.65 mg +Guaifenesin 33.3 mg +Sodium benzoate 33.3 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Optaminess tab") {buttonClickShortcut("Optaminess tab", "L-Histidine + L-isoleucine + L-Leucine + L-Lysine acetate + L-Methionine + L-Phenylalanine + L-Threonine + L-Tryptophan + L-Tyrosine + L-Valine");}
    else if (selectedDrug == "Oracal tab") {buttonClickShortcut("Oracal tab", "Calcium Carbonate 1250 mg\n(500 mg elemental Calcium)");}
    else if (selectedDrug == "Orazone syrup") {buttonClickShortcut("Orazone syrup", "Dexamethasone 0.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Orazone tab") {buttonClickShortcut("Orazone tab", "Dexamethasone 0.5 mg");}
    else if (selectedDrug == "Orly cap") {buttonClickShortcut("Orly cap", "Orlistat 120 mg");}
    else if (selectedDrug == "Ornidaz tab") {buttonClickShortcut("Ornidaz tab", "Ornidazole 500 mg");}
    else if (selectedDrug == "Osipect syrup") {buttonClickShortcut("Osipect syrup", "Glyceryl Guaiacolate 50 mg + Potassium Citrate 50 mg + Terbutaline Sulphate 1.5 mg + Diphenhydramine HCl 14 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Ospen susp") {buttonClickShortcut("Ospen susp", "Penicillin V (Phenoxymethyl Penicillin) 400000 iu (250 mg) / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Ossilor-D drops") {buttonClickShortcut("Ossilor-D drops", "Vit D3 (Cholecalciferol) 400 iu / 0.5 ml\n(30 ml)");}
    else if (selectedDrug == "Ossofortin 10000 iu tab") {buttonClickShortcut("Ossofortin 10000 iu tab", "Vit D 10000 iu (0.25 mg)");}
    else if (selectedDrug == "Ossofortin 50000 iu tab") {buttonClickShortcut("Ossofortin 50000 iu tab", "Vit D 50000 iu (1.25 mg)");}
    else if (selectedDrug == "Ossofortin Original D3 tab") {buttonClickShortcut("Ossofortin Original D3 tab", "Vit D 5000 iu");}
    else if (selectedDrug == "Ost-map cap") {buttonClickShortcut("Ost-map cap", "Acemetacin 60 mg");}
    else if (selectedDrug == "Osteo tab") {buttonClickShortcut("Osteo tab", "Raloxifene 60 mg");}
    else if (selectedDrug == "Osteocare syrup") {buttonClickShortcut("Osteocare syrup", "Calcium 150 mg + Magnesium 75 mg + Zinc 3 mg + Vit D 76 iu / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Osteocare tab") {buttonClickShortcut("Osteocare tab", "Calcium 400 mg + Magnesium 150 mg + Zinc 5 mg + Vit D 100 iu");}
    else if (selectedDrug == "Oxifree cap") {buttonClickShortcut("Oxifree cap", "Zinc + Selenium + Molybdenum + Vit C + Vit E + Vit A + Proanthocyanidin + Bioflavonoid + Omega 3 + Thioctic Acid");}
    else if (selectedDrug == "Ozempic prefilled pen") {injectionClickShortcut("Ozempic prefilled pen", "Semaglutide\n(0.25 mg)\n(0.5 mg)\n(1 mg)");}
    else if (favContentDescription == "active") {generalDiag("Warning", "This drug either removed from the main list or the name has been changed\n\nRemove it from the favourite list then add it again");}
  }
  void getDosePQRSTUVWXYZ () {
    if (selectedDrug == "P.T.B tab") {buttonClickShortcut("P.T.B tab", "Pyrazinamide 500 mg");}
    else if (selectedDrug == "Paediment solution") {injectionClickShortcut("Paediment solution", "Anhydrous Glucose 10 gm + Sodium Chloride 0.2164 gm + Potassium Chloride 0.149 gm+ Calcium Gluconate 0.4 gm / 100 ml");}
    else if (selectedDrug == "Pan-Amin G solution") {injectionClickShortcut("Pan-Amin G solution", "D-Sorbitol + L-Arginine HCl + L-Histidine HCl H2O + L-Isoleucine + L-Leucine + L-Lysine HCl + L-Methionine + L-Phenylalanine + L-Threonine + L-Tryptophan + L-Valine + Glycine (Aminoacetic acid)");}
    else if (selectedDrug == "Panadol Acute Head Cold tab") {buttonClickShortcut("Panadol Acute Head Cold tab", "Brompheniramine 2 mg + Pseudoephedrine 30 mg + Paracetamol 500 mg");}
    else if (selectedDrug == "Panadol Advance tab") {buttonClickShortcut("Panadol Advance tab", "Paracetamol 500 mg");}
    else if (selectedDrug == "Panadol Cold&Flu Day tab") {buttonClickShortcut("Panadol Cold&Flu Day tab", "Paracetamol 500 mg + Caffeine 25 mg + Phenylephrine 5 mg");}
    else if (selectedDrug == "Panadol Extra tab") {buttonClickShortcut("Panadol Extra tab", "Paracetamol 500 mg + Caffeine 65 mg");}
    else if (selectedDrug == "Panadol Joint tab") {buttonClickShortcut("Panadol Joint tab", "Paracetamol 665 mg");}
    else if (selectedDrug == "Panadol Migrain tab") {buttonClickShortcut("Panadol Migrain tab", "Paracetamol 250 mg + Acetylsalicylic Acid 250 mg + Caffeine 65 mg");}
    else if (selectedDrug == "Panax Life cap") {buttonClickShortcut("Panax Life cap", "Ginseng 25 mg +Ginkgo Biloba 180 mg");}
    else if (selectedDrug == "Pansol solution") {injectionClickShortcut("Pansol solution", "Anhydrous Glucose 2.147 gm + Sodium Chloride 0.321 gm + Potassium Chloride 0.0596 gm + Sodium Lactate 0.3363 gm / 100 ml / 100 ml");}
    else if (selectedDrug == "Pantogar cap") {buttonClickShortcut("Pantogar cap", "Ca Pantothenate 60 mg + Keratin 20 mg + L-Cystine 20 mg + Para-Aminobenzoic Acid 20 mg + Vit B1 60 mg + Yeast 100 mg");}
    else if (selectedDrug == "Paramol supp") {buttonClickShortcut("Paramol supp", "Paracetamol 125 mg");}
    else if (selectedDrug == "Paramol syrup") {buttonClickShortcut("Paramol syrup", "Paracetamol 120 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Parkicapone tab") {buttonClickShortcut("Parkicapone tab", "Entacapone 200 mg");}
    else if (selectedDrug == "Parkintreat tab") {buttonClickShortcut("Parkintreat tab", "Rasagiline 1 mg");}
    else if (selectedDrug == "Parofen tab") {buttonClickShortcut("Parofen tab", "Ibuprofen 400 mg + Paracetamol 500 mg");}
    else if (selectedDrug == "Paroxetine 20 tab") {buttonClickShortcut("Paroxetine 20 tab", "Paroxetine 20 mg");}
    else if (selectedDrug == "Paroxetine CR 12.5 tab") {buttonClickShortcut("Paroxetine CR 12.5 tab", "Paroxetine 12.5 mg");}
    else if (selectedDrug == "Pectipro syrup") {buttonClickShortcut("Pectipro syrup", "Benproperine 15 mg / 5 ml\n(90 ml)");}
    else if (selectedDrug == "Pedialyte drink") {buttonClickShortcut("Pedialyte drink", "Electrolytes +Minerals\n(200 ml)");}
    else if (selectedDrug == "Pencitard vial") {injectionClickShortcut("Pencitard vial", "Benzathine penicillin G 1.2 million iu");}
    else if (selectedDrug == "Pentacold syrup") {buttonClickShortcut("Pentacold syrup", "Paracetamol 160 mg + Chlorpheniramine 1 mg + Dextromethorphan 5 mg + Phenylephrine 2.5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Pental tab") {buttonClickShortcut("Pental tab", "Pentoxifylline 400 mg");}
    else if (selectedDrug == "Pentamix syrup") {buttonClickShortcut("Pentamix syrup", "Guava leaves + Tilia leaves + Thyme leaves + Fennel + Eucalyptus\n(120 ml)");}
    else if (selectedDrug == "Pepon cap") {buttonClickShortcut("Pepon cap", "Pumpkin Seed Oil 300 mg");}
    else if (selectedDrug == "Pepon Plus cap") {buttonClickShortcut("Pepon Plus cap", "Pumpkin Seed Oil 300 mg + Saw Palmetto Oil 88 mg + Zinc 15 mg");}
    else if (selectedDrug == "Peptifix chew tab") {buttonClickShortcut("Peptifix chew tab", "Famotidine 10 mg + Ca Carbonate 800 mg + Mg Hydroxide 165 mg");}
    else if (selectedDrug == "Perfalgan vial") {injectionClickShortcut("Perfalgan vial", "Paracetamol 1 gm / 100 ml");}
    else if (selectedDrug == "Perfectil Original tab") {buttonClickShortcut("Perfectil Original tab", "Vitamins + Minerals");}
    else if (selectedDrug == "Pethidine amp") {injectionClickShortcut("Pethidine amp", "Pethidine (Meperidine)\n50 mg / 1 ml\n100 mg / 2 ml");}
    else if (selectedDrug == "Petro tab") {buttonClickShortcut("Petro tab", "Caffeine 60 mg + Drotaverine 40 mg + Paracetamol 400 mg");}
    else if (selectedDrug == "Phara ferro 27 tab") {buttonClickShortcut("Phara ferro 27 tab", "Iron + Zinc + Copper + Molybdenum + Vit B1 + Vit B2 + Vit B3 + Vit B5 + Vit B6 + Vit B7 + Vit B8 + Vit B9 + Vit B12 + Vit C + Vit E + Beta Carotene");}
    else if (selectedDrug == "Pharmaton Kiddi syrup") {buttonClickShortcut("Pharmaton Kiddi syrup", "Lysine + Vit B1 + Vit B2 + Vit B6 + Vit D3 + Vit E + Nicotinamide + Dexpanthenol + Calcium\n(80 ml)");}
    else if (selectedDrug == "Phenytin amp") {injectionClickShortcut("Phenytin amp", "Phenytoin 250 mg / 5 ml\nPhenytoin 100 mg / 2 ml");}
    else if (selectedDrug == "Phenytin 50 cap") {buttonClickShortcut("Phenytin 50 cap", "Phenytoin 50 mg");}
    else if (selectedDrug == "Phenytin 100 cap") {buttonClickShortcut("Phenytin 100 cap", "Phenytoin 100 mg");}
    else if (selectedDrug == "Phenytin susp") {buttonClickShortcut("Phenytin susp", "Phenytoin 30 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Philozac 10 cap") {buttonClickShortcut("Philozac 10 cap", "Fluoxetine 10 mg");}
    else if (selectedDrug == "Philozac 20 cap") {buttonClickShortcut("Philozac 20 cap", "Fluoxetine 20 mg");}
    else if (selectedDrug == "Photericin B vial") {injectionClickShortcut("Photericin B vial", "Amphotericin B 50 mg");}
    else if (selectedDrug == "Piascledine cap") {buttonClickShortcut("Piascledine cap", "Avocado Oil 100 mg + Soya Bean Oil 200 mg");}
    else if (selectedDrug == "Picolax drops") {buttonClickShortcut("Picolax drops", "Sodium Picosulphate 7.5 mg / 1 (0.75%) ml\n(15 ml)");}
    else if (selectedDrug == "Pirafene amp") {injectionClickShortcut("Pirafene amp", "Chlorpheniramine 5 mg / 1 ml");}
    else if (selectedDrug == "Pirfenex tab") {buttonClickShortcut("Pirfenex tab", "Pirfenidone 200 mg");}
    else if (selectedDrug == "PK-Merz tab") {buttonClickShortcut("PK-Merz tab", "Amantadine 100 mg");}
    else if (selectedDrug == "Plavicard tab") {buttonClickShortcut("Plavicard tab", "Clopidogrel 75 mg");}
    else if (selectedDrug == "Plendil 2.5 tab") {buttonClickShortcut("Plendil 2.5 tab", "Felodipine 2.5 mg");}
    else if (selectedDrug == "Pletaal 100 tab") {buttonClickShortcut("Pletaal 100 tab", "Cilostazol 100 mg");}
    else if (selectedDrug == "Podacef susp") {buttonClickShortcut("Podacef susp", "Cefpodoxime 100 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Podacef 100 tab") {buttonClickShortcut("Podacef 100 tab", "Cefpodoxime 100 mg");}
    else if (selectedDrug == "Podacef 200 tab") {buttonClickShortcut("Podacef 200 tab", "Cefpodoxime 200 mg");}
    else if (selectedDrug == "Pono cap") {buttonClickShortcut("Pono cap", "Mefenamic acid 250 mg");}
    else if (selectedDrug == "Pono forte cap") {buttonClickShortcut("Pono forte cap", "Mefenamic acid 500 mg");}
    else if (selectedDrug == "Potassium Chloride 15% amp") {injectionClickShortcut("Potassium Chloride 15% amp", "Potassium Chloride 15 % (2 mEq/ml)");}
    else if (selectedDrug == "Potassium M syrup") {buttonClickShortcut("Potassium M syrup", "Potassium Chloride 165 mg / 5 ml (2.2 mEq / 5 ml)\n(120 ml)");}
    else if (selectedDrug == "Power Caps cap") {buttonClickShortcut("Power Caps cap", "Ibuprofen 300 mg + Pseudoephedrine 45 mg");}
    else if (selectedDrug == "Power Cold & Flu tab") {buttonClickShortcut("Power Cold & Flu tab", "Paracetamol 500 mg + Pseudoephedrine 30 mg + Caffeine 30 mg + Chlorpheniramin 3 mg");}
    else if (selectedDrug == "Powerecta 10 tab") {buttonClickShortcut("Powerecta 10 tab", "Vardenafil 10 mg");}
    else if (selectedDrug == "Pradaxa cap") {buttonClickShortcut("Pradaxa cap", "Dabigatran\n75 mg\n110 mg\n150 mg");}
    else if (selectedDrug == "Praxilene tab") {buttonClickShortcut("Praxilene tab", "Naftidrofuryl Oxalate 200 mg");}
    else if (selectedDrug == "Precedex vial") {injectionClickShortcut("Precedex vial", "Dexmedetomidine 200 mcg / 2 ml");}
    else if (selectedDrug == "Pregavalex 50 cap") {buttonClickShortcut("Pregavalex 50 cap", "Pregabalin 50 mg");}
    else if (selectedDrug == "Prianil 400 CR tab") {buttonClickShortcut("Prianil 400 CR tab", "Lithium Carbonate 400 mg");}
    else if (selectedDrug == "Primalan syrup") {buttonClickShortcut("Primalan syrup", "Mequitazine 2.5 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Primalan tab") {buttonClickShortcut("Primalan tab", "Mequitazine 5 mg");}
    else if (selectedDrug == "Primacor amp") {injectionClickShortcut("Primacor amp", "Milrinone 10 mg / 10 ml");}
    else if (selectedDrug == "Primomycin susp") {buttonClickShortcut("Primomycin susp", "Erythromycin 200 mg + Trimethoprim 50 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Primox 7.5 tab") {buttonClickShortcut("Primox 7.5 tab", "Moexipril 7.5 mg");}
    else if (selectedDrug == "Primafoxin 1 gm vial") {injectionClickShortcut("Primafoxin 1 gm vial", "Cefoxitin 1 gm");}
    else if (selectedDrug == "Primaquine 2.5 tab") {buttonClickShortcut("Primaquine 2.5 tab", "Primaquine 2.5 mg");}
    else if (selectedDrug == "Primrose Plus cap") {buttonClickShortcut("Primrose Plus cap", "Evening Primrose Oil 1 gm + Vit E 4 mg");}
    else if (selectedDrug == "Prinorelax 15 ER cap") {buttonClickShortcut("Prinorelax 15 ER cap", "Cyclobenzaprine 15 mg");}
    else if (selectedDrug == "Probric syrup") {buttonClickShortcut("Probric syrup", "Bambuterol 5 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Probric 10 tab") {buttonClickShortcut("Probric 10 tab", "Bambuterol 10 mg");}
    else if (selectedDrug == "Probric 20 tab") {buttonClickShortcut("Probric 20 tab", "Bambuterol 20 mg");}
    else if (selectedDrug == "Procoralan 5 tab") {buttonClickShortcut("Procoralan 5 tab", "Ivabradine 5 mg");}
    else if (selectedDrug == "Prolia prefilled syringe") {injectionClickShortcut("Prolia prefilled syringe", "Denosumab 60 mg / 1 ml");}
    else if (selectedDrug == "Prolutex vial") {injectionClickShortcut("Prolutex vial", "Progesterone 25 mg / 1 ml");}
    else if (selectedDrug == "Progest 100 cap") {buttonClickShortcut("Progest 100 cap", "Progesterone 100 mg");}
    else if (selectedDrug == "Prograf 0.5 cap") {buttonClickShortcut("Prograf 0.5 cap", "Tacrolimus 0.5 mg");}
    else if (selectedDrug == "Prontogest amp") {injectionClickShortcut("Prontogest amp", "Progesterone 100 mg / 2 ml");}
    else if (selectedDrug == "Prontogest vag pessaries") {buttonClickShortcut("Prontogest vag pessaries", "Progesterone\n200 mg\n400 mg");}
    else if (selectedDrug == "Proscar tab") {buttonClickShortcut("Proscar tab", "Finasteride 5 mg");}
    else if (selectedDrug == "Prostetrol 10 MR tab") {buttonClickShortcut("Prostetrol 10 MR tab", "Alfuzosin 10 mg");}
    else if (selectedDrug == "Protam vial") {injectionClickShortcut("Protam vial", "Protamine Sulphate 10 mg / ml");}
    else if (selectedDrug == "Prothiaden 25 cap") {buttonClickShortcut("Prothiaden 25 cap", "Dosulepin 25 mg");}
    else if (selectedDrug == "Prothiaden 75 tab") {buttonClickShortcut("Prothiaden 75 tab", "Dosulepin 75 mg");}
    else if (selectedDrug == "Protozole tab") {buttonClickShortcut("Protozole tab", "Tinidazole 500 mg");}
    else if (selectedDrug == "Provera tab") {buttonClickShortcut("Provera tab", "Medroxyprogesterone 5 mg");}
    else if (selectedDrug == "Proviron tab") {buttonClickShortcut("Proviron tab", "Mestrolone 25 mg");}
    else if (selectedDrug == "Proximol tab") {buttonClickShortcut("Proximol tab", "Halphabarol 0.4 mg");}
    else if (selectedDrug == "Proximol Compound eff granules") {buttonClickShortcut("Proximol Compound eff granules", "Hexamine + Piperazine + Proximadiol");}
    else if (selectedDrug == "Prucasoft 1 tab") {buttonClickShortcut("Prucasoft 1 tab", "Prucalopride 1 mg");}
    else if (selectedDrug == "Prucasoft 2 tab") {buttonClickShortcut("Prucasoft 2 tab", "Prucalopride 2 mg");}
    else if (selectedDrug == "Pulmicort 0.25 nebulizer solution") {buttonClickShortcut("Pulmicort 0.25 nebulizer solution", "Budesonide 0.25 mg /ml");}
    else if (selectedDrug == "Pulmicort 0.5 nebulizer solution") {buttonClickShortcut("Pulmicort 0.5 nebulizer solution", "Budesonide 0.5 mg /ml");}
    else if (selectedDrug == "Pulmicort 100 turbuhaler") {buttonClickShortcut("Pulmicort 100 turbuhaler", "Budesonide 100 mcg /dose");}
    else if (selectedDrug == "Pulmicort 200 turbuhaler") {buttonClickShortcut("Pulmicort 200 turbuhaler", "Budesonide 200 mcg /dose");}
    else if (selectedDrug == "Purgaton tab") {buttonClickShortcut("Purgaton tab", "Calcium Sennoside 20 mg");}
    else if (selectedDrug == "Pyral supp") {buttonClickShortcut("Pyral supp", "Paracetamol 250 mg");}
    else if (selectedDrug == "Pystinon tab") {buttonClickShortcut("Pystinon tab", "Pyridostigmine 60 mg");}
    else if (selectedDrug == "Questran sach") {buttonClickShortcut("Questran sach", "Cholestyramine 4 gm");}
    else if (selectedDrug == "Quibron T/SR tab") {buttonClickShortcut("Quibron T/SR tab", "Theophylline 300 mg");}
    else if (selectedDrug == "Quinabiotic tab") {buttonClickShortcut("Quinabiotic tab", "Gemifloxacin 320 mg");}
    else if (selectedDrug == "Rabicid 10 tab") {buttonClickShortcut("Rabicid 10 tab", "Rabeprazole 10 mg");}
    else if (selectedDrug == "Rabicid 20 tab") {buttonClickShortcut("Rabicid 20 tab", "Rabeprazole 20 mg");}
    else if (selectedDrug == "Ramipril 1.25 cap") {buttonClickShortcut("Ramipril 1.25 cap", "Ramipril 1.25 mg");}
    else if (selectedDrug == "Ramixole 0.25 tab") {buttonClickShortcut("Ramixole 0.25 tab", "Pramipexole 0.25 mg");}
    else if (selectedDrug == "Ranexa 500 tab") {buttonClickShortcut("Ranexa 500 tab", "Ranolazine 500 mg");}
    else if (selectedDrug == "Rebif 44 prefilled syringe") {injectionClickShortcut("Rebif 44 prefilled syringe", "Interferon Beta-1a 44 mcg / 0.5 ml");}
    else if (selectedDrug == "Rectoplexil supp") {buttonClickShortcut("Rectoplexil supp", "Oxomemazine 3.3 mg + Guaifenesin 66.6 mg + Sodium benzoate 66.6 mg + Paracetamol 66.6 mg");}
    else if (selectedDrug == "Rehydro Zinc Sach") {buttonClickShortcut("Rehydro Zinc sach", "Oral Rehydration Solution (ORS)");}
    else if (selectedDrug == "Relax cap") {buttonClickShortcut("Relax cap", "Chlorzoxazone 250 mg + Paracetamol 300 mg");}
    else if (selectedDrug == "Relaxine tab") {buttonClickShortcut("Relaxine tab", "Thiocolchicoside 4 mg");}
    else if (selectedDrug == "Remeron tab") {buttonClickShortcut("Remeron tab", "Mirtazapine 30 mg");}
    else if (selectedDrug == "Remicade vial") {injectionClickShortcut("Remicade vial", "Infliximab 100 mg");}
    else if (selectedDrug == "Renagel tab") {buttonClickShortcut("Renagel tab", "Sevelamer 800 mg");}
    else if (selectedDrug == "Renal-S sach") {buttonClickShortcut("Renal-S sach", "Hexamine 500 mg + Khellin 1.83 mg + Piperazine 190 mg");}
    else if (selectedDrug == "Reparil tab") {buttonClickShortcut("Reparil tab", "Aescin 40 mg");}
    else if (selectedDrug == "Resinokaten powder") {buttonClickShortcut("Resinokaten powder", "Sodium Polystyrene Sulfonate 454 gm");}
    else if (selectedDrug == "Respipect syrup") {buttonClickShortcut("Respipect syrup", "Guaiacol 1 mg + Pholcodine 6.55 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Rheuxicam 4 tab") {buttonClickShortcut("Rheuxicam 4 tab", "Lornoxicam 4 mg");}
    else if (selectedDrug == "Rheuxicam 8 tab") {buttonClickShortcut("Rheuxicam 8 tab", "Lornoxicam 8 mg");}
    else if (selectedDrug == "Rheuxicam vial") {buttonClickShortcut("Rheuxicam vial", "Lornoxicam 8 mg / 2 ml");}
    else if (selectedDrug == "Rhinopro cap") {buttonClickShortcut("Rhinopro cap", "Carbinoxamine 4 mg + Phenylephrine 20 mg");}
    else if (selectedDrug == "Rhinopro syrup") {buttonClickShortcut("Rhinopro syrup", "Pseudoephedrine 540 mg + Carbinoxamine 24 mg / 90 ml\n(90 ml)");}
    else if (selectedDrug == "Rhinostop drops") {buttonClickShortcut("Rhinostop drops", "Pseudoephedrine 5 mg + Carbinoxamine 2 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Rhinotus syrup") {buttonClickShortcut("Rhinotus syrup", "Pseudoephedrine 540 mg + Carbinoxamine 24 mg + Dextromethorphan 90 mg / 90 ml\n(90 ml)");}
    else if (selectedDrug == "Ribavirin 200 cap") {buttonClickShortcut("Ribavirin 200 cap", "Ribavirin 200 mg");}
    else if (selectedDrug == "Ribavirin syrup") {buttonClickShortcut("Ribavirin syrup", "Ribavirin 200 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Rimactane cap") {buttonClickShortcut("Rimactane cap", "Rifampicin 300 mg");}
    else if (selectedDrug == "Rimactane syrup") {buttonClickShortcut("Rimactane syrup", "Rifampicin 100 mg / 5 ml (2%)\n(50 ml)");}
    else if (selectedDrug == "Ringer's solution") {injectionClickShortcut("Ringer's solution", "Sodium Chloride 0.86 gm + Potassium Chloride 0.03 gm + Calcium Chloride 0.033 gm / 100 ml");}
    else if (selectedDrug == "Ritalin tab") {buttonClickShortcut("Ritalin tab", "Methylphenidate 10 mg");}
    else if (selectedDrug == "Rivarospire tab") {buttonClickShortcut("Rivarospire tab", "Rivaroxaban\n2.5 mg\n10 mg\n15 mg\n20 mg");}
    else if (selectedDrug == "Rogitamine amp") {injectionClickShortcut("Rogitamine amp", "Phentolamine 10 mg / 1 ml");}
    else if (selectedDrug == "Rotahelex Advance drops") {buttonClickShortcut("Rotahelex Advance drops", "Ivy leaf extract + Thyme + Liquorice\n(60 ml)");}
    else if (selectedDrug == "Rotahelex drops") {buttonClickShortcut("Rotahelex drops", "Ivy leaf extract 21.5 mg / 5 ml\n(30 ml)");}
    else if (selectedDrug == "Rotahelex syrup") {buttonClickShortcut("Rotahelex syrup", "Ivy leaf extract 35 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Rotahelex tab") {buttonClickShortcut("Rotahelex tab", "Ivy leaf extract 35 mg");}
    else if (selectedDrug == "Rowachol cap") {buttonClickShortcut("Rowachol cap", "Menthol + Menthone + Alpha Pinene + Beta Pinene + Borneol + Camphene + Cineole");}
    else if (selectedDrug == "Royal Jelly cap") {buttonClickShortcut("Royal Jelly cap", "Royal Jelly 1000 mg");}
    else if (selectedDrug == "Royal Vit G cap") {buttonClickShortcut("Royal Vit G cap", "Ginseng + Royal Jelly + Vitamins + Minerals");}
    else if (selectedDrug == "Ruta-C tab") {buttonClickShortcut("Ruta-C tab", "Rutin 60 mg +Vit C 160 mg");}
    else if (selectedDrug == "Rybelsus tab") {buttonClickShortcut("Rybelsus tab", "Semaglutide\n3 mg\n7 mg\n14 mg");}
    else if (selectedDrug == "Rytmonorm tab") {buttonClickShortcut("Rytmonorm tab", "Propafenone 150 mg");}
    else if (selectedDrug == "Sacrofer amp") {injectionClickShortcut("Sacrofer amp", "Iron sucrose 100 mg / 5 ml");}
    else if (selectedDrug == "Salbovent tab") {buttonClickShortcut("Salbovent tab", "Salbutamol 2 mg");}
    else if (selectedDrug == "Salbovent forte cap") {buttonClickShortcut("Salbovent forte cap", "Salbutamol 4 mg");}
    else if (selectedDrug == "Salofalk tab") {buttonClickShortcut("Salofalk tab", "Mesalazine 500 mg");}
    else if (selectedDrug == "Sandimmun Neoral 25 cap") {buttonClickShortcut("Sandimmun Neoral 25 cap", "Cyclosporine 25 mg");}
    else if (selectedDrug == "Sandimmun Neoral syrup") {buttonClickShortcut("Sandimmun Neoral syrup", "Cyclosporine 100 mg / ml");}
    else if (selectedDrug == "Sandostatin amp") {injectionClickShortcut("Sandostatin amp", "Octreotide 0.1 mg / ml");}
    else if (selectedDrug == "Sanso-C 1 gm cap") {buttonClickShortcut("Sanso-C 1 gm cap", "Vit C 1 gm");}
    else if (selectedDrug == "Sansoimune syrup") {buttonClickShortcut("Sansoimune syrup", "Echinacea Purpurea 100 mg + Vit C 25 mg + Zinc 3 mg / 5 ml");}
    else if (selectedDrug == "Sansovit syrup") {buttonClickShortcut("Sansovit syrup", "Vit A + Vit B1 + Vit B2 + Vit B6 + Vit C + Vit D3 + Vit E + Nicotinamide + Dexpanthenol\n(120 & 200 & 400 gm)");}
    else if (selectedDrug == "Sansovit Iron syrup") {buttonClickShortcut("Sansovit Iron syrup", "Vit A + Vit B1 + Vit B2 + Vit B6 + Vit C + Vit D3 + Vit E + Nicotinamide + Dexpanthenol + Ferrous Gluconate\n(120 ml)");}
    else if (selectedDrug == "Saxenda prefilled pen") {injectionClickShortcut("Saxenda prefilled pen", "Liraglutide 18 mg / 3 ml");}
    else if (selectedDrug == "Sayana prefilled syringe") {injectionClickShortcut("Sayana prefilled syringe", "Medroxyprogesterone 104 mg / 0.65 ml");}
    else if (selectedDrug == "Schisolazine 2.5 tab") {buttonClickShortcut("Schisolazine 2.5 tab", "Olanzapine 2.5 mg");}
    else if (selectedDrug == "Schistocide susp") {buttonClickShortcut("Schistocide susp", "Praziquantel 600 mg / 5 ml\n(15 ml)");}
    else if (selectedDrug == "Seizolow drops") {buttonClickShortcut("Seizolow drops", "Sodium Valproate 200 mg / 1 ml\n(40 ml)");}
    else if (selectedDrug == "Seizolow syrup") {buttonClickShortcut("Seizolow syrup", "Sodium Valproate 250 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Selgon drops") {buttonClickShortcut("Selgon drops", "Pipazetate 40 mg / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Selgon supp") {buttonClickShortcut("Selgon supp", "Pipazetate 10 mg");}
    else if (selectedDrug == "Selgon tab") {buttonClickShortcut("Selgon tab", "Pipazetate 20 mg");}
    else if (selectedDrug == "Selokenzoc 25 tab") {buttonClickShortcut("Selokenzoc 25 tab", "Metoprolol Succinate 25 mg");}
    else if (selectedDrug == "Selona sach") {buttonClickShortcut("Selona sach", "Vit A + Vit C + Vit E + Zinc + Magnesium + Selenium");}
    else if (selectedDrug == "Septazole tab") {buttonClickShortcut("Septazole tab", "Sulfamethoxazole 400 mg + Trimethoprim 80 mg");}
    else if (selectedDrug == "Septazole forte tab") {buttonClickShortcut("Septazole forte tab", "Sulfamethoxazole 800 mg + Trimethoprim 160 mg");}
    else if (selectedDrug == "Septazole susp") {buttonClickShortcut("Septazole susp", "Sulfamethoxazole 200 mg + Trimethoprim 40 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Seretide Diskus 50/100") {buttonClickShortcut("Seretide Diskus 50/100", "Salmeterol 50 mcg + Fluticasone 100 mcg / actuation");}
    else if (selectedDrug == "Seretide Diskus 50/250") {buttonClickShortcut("Seretide Diskus 50/250", "Salmeterol 50 mcg + Fluticasone 250 mcg / actuation");}
    else if (selectedDrug == "Seretide Diskus 50/500") {buttonClickShortcut("Seretide Diskus 50/500", "Salmeterol 50 mcg + Fluticasone 500 mcg / actuation");}
    else if (selectedDrug == "Seretide Evohaler 25/50") {buttonClickShortcut("Seretide Evohaler 25/50", "Salmeterol 25 mcg + Fluticasone 50 mcg / dose");}
    else if (selectedDrug == "Seretide Evohaler 25/125") {buttonClickShortcut("Seretide Evohaler 25/125", "Salmeterol 25 mcg + Fluticasone 125 mcg / dose");}
    else if (selectedDrug == "Serinomantine 7 ER cap") {buttonClickShortcut("Serinomantine 7 ER cap", "Memantine 7 mg");}
    else if (selectedDrug == "Seroquel 25 tab") {buttonClickShortcut("Seroquel 25 tab", "Quetiapine 25 mg");}
    else if (selectedDrug == "Seroquel 50 XR tab") {buttonClickShortcut("Seroquel 50 XR tab", "Quetiapine 50 mg");}
    else if (selectedDrug == "Sertraline 25 tab") {buttonClickShortcut("Sertraline 25 tab", "Sertraline 25 mg");}
    else if (selectedDrug == "Serpass 50 tab") {buttonClickShortcut("Serpass 50 tab", "Sertraline 50 mg");}
    else if (selectedDrug == "Silipex cap") {buttonClickShortcut("Silipex cap", "Silymarin lecithin complex 202 mg");}
    else if (selectedDrug == "Simedill syrup") {buttonClickShortcut("Simedill syrup", "Simethicone 20 mg + Dill Oil 1 mg / 1 ml\n(120 ml)");}
    else if (selectedDrug == "Simethicone drops") {buttonClickShortcut("Simethicone drops", "Simethicone 20 mg / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Sina Dry syrup") {buttonClickShortcut("Sina Dry syrup", "Grindelia + Pimpinella + Primula + Rosa + Thyme\n(120 ml)");}
    else if (selectedDrug == "Sina Wet syrup") {buttonClickShortcut("Sina Wet syrup", "Grindelia + Pimpinella + Primula + Quebracho + Thyme\n(120 ml)");}
    else if (selectedDrug == "Sine up syrup") {buttonClickShortcut("Sine up syrup", "Chlorpheniramine 2.5 mg + Phenylephrine 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Singulair 4 sach") {buttonClickShortcut("Singulair 4 sach", "Montelukast 4 mg");}
    else if (selectedDrug == "Singulair 4 chew tab") {buttonClickShortcut("Singulair 4 chew tab", "Montelukast 4 mg");}
    else if (selectedDrug == "Singulair 5 chew tab") {buttonClickShortcut("Singulair 5 chew tab", "Montelukast 5 mg");}
    else if (selectedDrug == "Singulair 10 tab") {buttonClickShortcut("Singulair 10 tab", "Montelukast 10 mg");}
    else if (selectedDrug == "Sinupret tab") {buttonClickShortcut("Sinupret tab", "Elder Flowers + Gentian Root + Primrose Flowers + Vervain + Sorrel Herb");}
    else if (selectedDrug == "Sirdalud 2 tab") {buttonClickShortcut("Sirdalud 2 tab", "Tizanidine 2 mg");}
    else if (selectedDrug == "Sleep-Aid 5 tab") {buttonClickShortcut("Sleep-Aid 5 tab", "Zaleplon 5 mg");}
    else if (selectedDrug == "Sleepez 1 tab") {buttonClickShortcut("Sleepez 1 tab", "Eszopiclone 1 mg");}
    else if (selectedDrug == "Sodium Bicarbonate 4.2% vial") {injectionClickShortcut("Sodium Bicarbonate 4.2% vial", "NaHCo3 4.2%");}
    else if (selectedDrug == "Sodium Bicarbonate 8.4% vial") {injectionClickShortcut("Sodium Bicarbonate 8.4% vial", "NaHCo3 8.4%");}
    else if (selectedDrug == "Sodium Chloride 0.9% solution") {injectionClickShortcut("Sodium Chloride 0.9% solution", "Sodium Chloride 9 mg / ml");}
    else if (selectedDrug == "Sofenacin 5 tab") {buttonClickShortcut("Sofenacin 5 tab", "Solifenacin 5 mg");}
    else if (selectedDrug == "Soliqua 100/33 prefilled pen") {injectionClickShortcut("Soliqua 100/33 prefilled pen", "Insulin Glargine 100 units + Lixisenatide 33 mcg / ml");}
    else if (selectedDrug == "Solu-cortef vial") {injectionClickShortcut("Solu-cortef vial", "Hydrocortisone 100 mg");}
    else if (selectedDrug == "Solu-medrol 500 vial") {injectionClickShortcut("Solu-medrol 500 vial", "Methylprednisolone 500 mg");}
    else if (selectedDrug == "Solu-medrol 1 gm vial") {injectionClickShortcut("Solu-medrol 1 gm vial", "Methylprednisolone 1 gm");}
    else if (selectedDrug == "Solvimyst syrup") {buttonClickShortcut("Solvimyst syrup", "Acetylcysteine 100 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Somazina amp") {injectionClickShortcut("Somazina amp", "Citicoline 500 mg / 4 ml");}
    else if (selectedDrug == "Somazina drops") {buttonClickShortcut("Somazina drops", "Citicoline 100 mg / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Sominaletta amp") {injectionClickShortcut("Sominaletta amp", "Phenobarbital 40 mg / 1 ml");}
    else if (selectedDrug == "Sominaletta syrup") {buttonClickShortcut("Sominaletta syrup", "Phenobarbital 15 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Sominaletta tab") {buttonClickShortcut("Sominaletta tab", "Phenobarbital 15 mg");}
    else if (selectedDrug == "SpasColon 50 tab") {buttonClickShortcut("SpasColon 50 tab", "Pinaverium Bromide 50 mg");}
    else if (selectedDrug == "SpasColon 100 tab") {buttonClickShortcut("SpasColon 100 tab", "Pinaverium Bromide 100 mg");}
    else if (selectedDrug == "Spasmo-Amrase tab") {buttonClickShortcut("Spasmo-Amrase tab", "Ox Bile 30 mg + Pancreatin 300 mg + Papain 50 mg + Dimethicone 30 mg + Mebeverine 50 mg");}
    else if (selectedDrug == "Spasmo-digestin tab") {buttonClickShortcut("Spasmo-digestin tab", "Dicyclomine 5 mg + Papain 100 mg + Sanzyme 3500 36 mg + Simethicone 30 mg + Sodium Dehydrocholate 10 mg");}
    else if (selectedDrug == "Spasmocin amp") {injectionClickShortcut("Spasmocin amp", "Hyoscine-N-butylebromide 20 mg / 1 ml");}
    else if (selectedDrug == "Spasmocin tab") {buttonClickShortcut("Spasmocin tab", "Hyoscine-N-butylebromide 10 mg");}
    else if (selectedDrug == "Spasmocure amp") {injectionClickShortcut("Spasmocure amp", "Drotaverine 40 mg / 2 ml");}
    else if (selectedDrug == "Spasmocure tab") {buttonClickShortcut("Spasmocure tab", "Drotaverine 60 mg");}
    else if (selectedDrug == "Spasmofen amp") {injectionClickShortcut("Spasmofen amp", "Hyoscine-N-butylebromide 20 mg + Ketoprofen 100 mg / 2 ml");}
    else if (selectedDrug == "Spasmomen tab") {buttonClickShortcut("Spasmomen tab", "Otilonium Bromide 40 mg");}
    else if (selectedDrug == "Spasmopyralgin-M tab") {buttonClickShortcut("Spasmopyralgin-M tab", "Camylofin 25 mg + Dipyrone (Metamizole) 255 mg");}
    else if (selectedDrug == "Spasmorest syrup") {buttonClickShortcut("Spasmorest syrup", "Dicyclomine 10 mg / 5 ml (2%)\n(125 ml)");}
    else if (selectedDrug == "Spasmorest 10 tab") {buttonClickShortcut("Spasmorest 10 tab", "Dicyclomine 10 mg");}
    else if (selectedDrug == "Spasmorest 20 tab") {buttonClickShortcut("Spasmorest 20 tab", "Dicyclomine 20 mg");}
    else if (selectedDrug == "Spasmorest amp") {injectionClickShortcut("Spasmorest amp", "Dicyclomine 10 mg / 1 ml");}
    else if (selectedDrug == "Spasulance odf") {buttonClickShortcut("Spasulance odf", "Simethicone 62.5 mg");}
    else if (selectedDrug == "Sperience sach") {buttonClickShortcut("Sperience sach", "Lactoferrin 100 mg + Zinc + Vit C + Iron + Folic Acid + Calcium + Vit B1 + Vit B6 + Vit B12");}
    else if (selectedDrug == "Spinobac syrup") {buttonClickShortcut("Spinobac syrup", "Baclofen 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Spirex 1.5 tab") {buttonClickShortcut("Spirex 1.5 tab", "Spiramycin 1.5 million iu");}
    else if (selectedDrug == "Spirex 3 tab") {buttonClickShortcut("Spirex 3 tab", "Spiramycin 3 million iu");}
    else if (selectedDrug == "Spirex Plus tab") {buttonClickShortcut("Spirex Plus tab", "Spiramycin 1.5 million iu + Metronidazole 250 mg");}
    else if (selectedDrug == "Spiromide 20/50 tab") {buttonClickShortcut("Spiromide 20/50 tab", "Furosemide 20 mg + Spironolactone 50 mg");}
    else if (selectedDrug == "Spiromide 20/100 tab") {buttonClickShortcut("Spiromide 20/100 tab", "Furosemide 20 mg + Spironolactone 100 mg");}
    else if (selectedDrug == "Stablon tab") {buttonClickShortcut("Stablon tab", "Tianeptine 12.5 mg");}
    else if (selectedDrug == "Starkoprex 5 tab") {buttonClickShortcut("Starkoprex 5 tab", "Tadalafil 5 mg");}
    else if (selectedDrug == "Stalevo tab") {buttonClickShortcut("Stalevo tab", "Levodopa + Carbidopa + Entacapone\n(50/12.5/200)\n(100/25/200)\n(150/37.5/200)\n(200/50/200)");}
    else if (selectedDrug == "Staturic 40 tab") {buttonClickShortcut("Staturic 40 tab", "Febuxostat 40 mg");}
    else if (selectedDrug == "Stelara prefilled syringe/vial") {injectionClickShortcut("Stelara prefilled syringe/vial", "Ustekinumab\n45 mg / 0.5 ml (for SC)\n90 mg / 1 ml (for SC)\n130 mg / 26 ml (for IV infusion)");}
    else if (selectedDrug == "Stellasil 1 tab") {buttonClickShortcut("Stellasil 1 tab", "Trifluoperazine 1 mg");}
    else if (selectedDrug == "Sterogyl 15 H amp") {injectionClickShortcut("Sterogyl 15 H amp", "Ergocalciferol 600000 iu / 1.5 ml");}
    else if (selectedDrug == "Steronate tab") {buttonClickShortcut("Steronate tab", "Norethisterone Acetate 5 mg");}
    else if (selectedDrug == "Stigmide syrup") {buttonClickShortcut("Stigmide syrup", "Pyridostigmine 60 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Stimulan 400 cap") {buttonClickShortcut("Stimulan 400 cap", "Piracetam 400 mg");}
    else if (selectedDrug == "Stimulan amp") {injectionClickShortcut("Stimulan amp", "Piracetam 1000 mg / 5 ml");}
    else if (selectedDrug == "Stimulan syrup") {buttonClickShortcut("Stimulan syrup", "Piracetam 1000 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Stopspasm tab") {buttonClickShortcut("Stopspasm tab", "Phloroglucinol 62 mg + Trimethylphloroglucinol 80 mg");}
    else if (selectedDrug == "Streptomycin vial") {injectionClickShortcut("Streptomycin vial", "Streptomycin Sulphate 1000 mg");}
    else if (selectedDrug == "Streptoquin syrup") {buttonClickShortcut("Streptoquin syrup", "Diiodohydroxyquinoline 100 mg + Homatropine 0.5 mg + Phthalyl Sulfathiazole 150 mg + Streptomycin 85 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Streptoquin tab") {buttonClickShortcut("Streptoquin tab", "Diiodohydroxyquinoline 200 mg + Homatropine 2.5 mg + Phthalyl Sulfathiazole 200 mg + Streptomycin 100 mg");}
    else if (selectedDrug == "Stugeron tab") {buttonClickShortcut("Stugeron tab", "Cinnarizine 25 mg");}
    else if (selectedDrug == "Sulfozinc 10 syrup") {buttonClickShortcut("Sulfozinc 10 syrup", "Zinc 10 mg / 5 ml\n(80 ml)");}
    else if (selectedDrug == "Sulfozinc 20 syrup") {buttonClickShortcut("Sulfozinc 20 syrup", "Zinc 20 mg / 5 ml\n(80 ml)");}
    else if (selectedDrug == "Supravit cap") {buttonClickShortcut("Supravit cap", "Vitamins + Minerals");}
    else if (selectedDrug == "Suprax 200 cap") {buttonClickShortcut("Suprax 200 cap", "Cefixime 200 mg");}
    else if (selectedDrug == "Suprax 400 cap") {buttonClickShortcut("Suprax 400 cap", "Cefixime 400 mg");}
    else if (selectedDrug == "Suprax susp") {buttonClickShortcut("Suprax susp", "Cefixime 100 mg / 5 ml\n(30 ml & 60 ml)");}
    else if (selectedDrug == "Swabivent nebulizer solution") {buttonClickShortcut("Swabivent nebulizer solution", "Ipratropium Bromide 500 mcg + Salbutamol 2.5 mg / 2.5 ml");}
    else if (selectedDrug == "Symbicort 80/4.5 turbuhaler") {buttonClickShortcut("Symbicort 80/4.5 turbuhaler", "Budesonide 80 mcg +Formoterol 4.5 mcg /dose");}
    else if (selectedDrug == "Symbicort 160/4.5 turbuhaler") {buttonClickShortcut("Symbicort 160/4.5 turbuhaler", "Budesonide 160 mcg +Formoterol 4.5 mcg /dose");}
    else if (selectedDrug == "Symbicort 320/9 turbuhaler") {buttonClickShortcut("Symbicort 320/9 turbuhaler", "Budesonide 160 mcg +Formoterol 9 mcg /dose");}
    else if (selectedDrug == "Symmebact-D drops") {buttonClickShortcut("Symmebact-D drops", "Lactobacillus Reuteri 100 million CFU +Vit D3 400 IU / 5 drops\n(15 ml)");}
    else if (selectedDrug == "Synjardy tab") {buttonClickShortcut("Synjardy tab", "Empagliflozin +Metformin\n(5/850)\n(5/1000)\n(12.5/850)\n(12.5/1000)");}
    else if (selectedDrug == "Syntocinon 5 iu amp") {injectionClickShortcut("Syntocinon 5 iu amp", "Oxytocin 5 iu / 1 ml");}
    else if (selectedDrug == "Syntocinon 10 iu amp") {injectionClickShortcut("Syntocinon 10 iu amp", "Oxytocin 10 iu / 1 ml");}
    else if (selectedDrug == "Taminil-N cap") {buttonClickShortcut("Taminil-N cap", "Oseltamivir 75 mg");}
    else if (selectedDrug == "Taminil-N susp") {buttonClickShortcut("Taminil-N susp", "Oseltamivir 60 mg / 5 ml\n(30 ml & 60 ml)");}
    else if (selectedDrug == "Tamoxifen 10 tab") {buttonClickShortcut("Tamoxifen 10 tab", "Tamoxifen 10 mg");}
    else if (selectedDrug == "Tamoxifen 20 tab") {buttonClickShortcut("Tamoxifen 20 tab", "Tamoxifen 20 mg");}
    else if (selectedDrug == "Tamsulin cap") {buttonClickShortcut("Tamsulin cap", "Tamsulosin 0.4 mg");}
    else if (selectedDrug == "Tamsulin Plus tab") {buttonClickShortcut("Tamsulin Plus tab", "Tamsulosin 0.4 mg + Solifenacin 6 mg");}
    else if (selectedDrug == "Tareg 40 tab") {buttonClickShortcut("Tareg 40 tab", "Valsartan 40 mg");}
    else if (selectedDrug == "Targocid 200 vial") {injectionClickShortcut("Targocid 200 vial", "Teicoplanin 200 mg");}
    else if (selectedDrug == "Targocid 400 vial") {injectionClickShortcut("Targocid 400 vial", "Teicoplanin 400 mg");}
    else if (selectedDrug == "Tariflox 200 tab") {buttonClickShortcut("Tariflox 200 tab", "Ofloxacin 200 mg");}
    else if (selectedDrug == "Tariflox 400 tab") {buttonClickShortcut("Tariflox 400 tab", "Ofloxacin 400 mg");}
    else if (selectedDrug == "Tavacin 500 tab") {buttonClickShortcut("Tavacin 500 tab", "Levofloxacin 500 mg");}
    else if (selectedDrug == "Tavacin 750 tab") {buttonClickShortcut("Tavacin 750 tab", "Levofloxacin 750 mg");}
    else if (selectedDrug == "Tavegyl syrup") {buttonClickShortcut("Tavegyl syrup", "Clemastine 0.5 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Tavegyl tab") {buttonClickShortcut("Tavegyl tab", "Clemastine 1 mg");}
    else if (selectedDrug == "Tazocin vial") {injectionClickShortcut("Tazocin vial", "Piperacillin 4 gm + Tazobactam 500 mg");}
    else if (selectedDrug == "Tebofortin 40 tab") {buttonClickShortcut("Tebofortin 40 tab", "Ginkgo Biloba 40 mg");}
    else if (selectedDrug == "Tebofortin 80 tab") {buttonClickShortcut("Tebofortin 80 tab", "Ginkgo Biloba 80 mg");}
    else if (selectedDrug == "Tebofortin drops") {buttonClickShortcut("Tebofortin drops", "Ginkgo Biloba 40 mg / 1 ml\n(30 ml)");}
    else if (selectedDrug == "Tecavir 0.5 tab") {buttonClickShortcut("Tecavir 0.5 tab", "Entecavir 0.5 mg");}
    else if (selectedDrug == "Tegretol syrup") {buttonClickShortcut("Tegretol syrup", "Carbamazepine 100 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Tegretol 200 tab") {buttonClickShortcut("Tegretol 200 tab", "Carbamazepine 200 mg");}
    else if (selectedDrug == "Tegretol 200 CR tab") {buttonClickShortcut("Tegretol 200 CR tab", "Carbamazepine 200 mg");}
    else if (selectedDrug == "Telfast Decongestant tab") {buttonClickShortcut("Telfast Decongestant tab", "Fexofenadine 60 mg + Pseudoephedrine 120 mg");}
    else if (selectedDrug == "Temodal cap") {buttonClickShortcut("Temodal cap", "Temozolomide\n20 mg\n100 mg\n250 mg");}
    else if (selectedDrug == "Tempra syrup") {buttonClickShortcut("Tempra syrup", "Paracetamol 160 mg / 5 ml\n(90 ml)");}
    else if (selectedDrug == "Tenaviron tab") {buttonClickShortcut("Tenaviron tab", "Tenofovir Disoproxil Fumarate 300 mg");}
    else if (selectedDrug == "Tenedone tab") {buttonClickShortcut("Tenedone tab", "Atenolol + Chlorthalidone\n(50 / 25)\n(100 / 25)");}
    else if (selectedDrug == "Tenormin 25 tab") {buttonClickShortcut("Tenormin 25 tab", "Atenolol 25 mg");}
    else if (selectedDrug == "Tensopleron 25 tab") {buttonClickShortcut("Tensopleron 25 tab", "Eplerenone 25 mg");}
    else if (selectedDrug == "Tentavair 80 inhaler") {buttonClickShortcut("Tentavair 80 inhaler", "Ciclesonide 80 mcg /actuation");}
    else if (selectedDrug == "Testonon amp") {injectionClickShortcut("Testonon amp", "Testosterone Propionate 30 mg + Testosterone Phenylpropionate 60 mg + Testosterone Isocaproate 60 mg + Testosterone Decanoate 100 mg / 1 ml\n(the equivalent of about 176 mg testosterone)");}
    else if (selectedDrug == "Tetracid 250 cap") {buttonClickShortcut("Tetracid 250 cap", "Tetracycline 250 mg");}
    else if (selectedDrug == "Teveten 600 tab") {buttonClickShortcut("Teveten 600 tab", "Eprosartan 600 mg");}
    else if (selectedDrug == "Thiazopril 20/12.5 tab") {buttonClickShortcut("Thiazopril 20/12.5 tab", "Enalapril 20 mg + Hydrochlorothiazide 12.5 mg");}
    else if (selectedDrug == "Thiopental 500 vial") {injectionClickShortcut("Thiopental 500 vial", "Thiopental 500 mg");}
    else if (selectedDrug == "Thiopental 1 gm vial") {injectionClickShortcut("Thiopental 1 gm vial", "Thiopental 1000 mg");}
    else if (selectedDrug == "Thiotacid 300 tab") {buttonClickShortcut("Thiotacid 300 tab", "Alpha Lipoic Acid (Thioctic Acid) 300 mg");}
    else if (selectedDrug == "Thiotacid 600 tab") {buttonClickShortcut("Thiotacid 600 tab", "Alpha Lipoic Acid (Thioctic Acid) 600 mg");}
    else if (selectedDrug == "Thiotacid amp") {injectionClickShortcut("Thiotacid amp", "Alpha Lipoic Acid (Thioctic Acid) 300 mg / 10 ml");}
    else if (selectedDrug == "Thiotacid Compound 300 cap") {buttonClickShortcut("Thiotacid Compound 300 cap", "Alpha Lipoic Acid (Thioctic Acid) 300 mg + Benfotiamine 40 mg+ Vit B12 250 mcg");}
    else if (selectedDrug == "Thiotacid Compound 600 cap") {buttonClickShortcut("Thiotacid Compound 600 cap", "Alpha Lipoic Acid (Thioctic Acid) 600 mg + Benfotiamine 80 mg+ Vit B12 500 mcg");}
    else if (selectedDrug == "Thrombexx amp") {injectionClickShortcut("Thrombexx amp", "Recombinant Hirudin 15 mg / 1 ml");}
    else if (selectedDrug == "Thyrocil 50 tab") {buttonClickShortcut("Thyrocil 50 tab", "Propylthiouracil 50 mg");}
    else if (selectedDrug == "Tienam vial") {injectionClickShortcut("Tienam vial", "Imipenem 500 mg + Cilastatin 500 mg");}
    else if (selectedDrug == "Tinifloxacin tab") {buttonClickShortcut("Tinifloxacin tab", "Ciprofloxacin 500 mg + Tinidazole 600 mg");}
    else if (selectedDrug == "Tiratam syrup") {buttonClickShortcut("Tiratam syrup", "Levetiracetam 100 mg / 1 ml\n(120 ml)");}
    else if (selectedDrug == "Tiratam 500 tab") {buttonClickShortcut("Tiratam 500 tab", "Levetiracetam 500 mg");}
    else if (selectedDrug == "Tiratam 500 XR tab") {buttonClickShortcut("Tiratam 500 XR tab", "Levetiracetam 500 mg");}
    else if (selectedDrug == "Tiratam 750 tab") {buttonClickShortcut("Tiratam 750 tab", "Levetiracetam 750 mg");}
    else if (selectedDrug == "Tiratam 1000 tab") {buttonClickShortcut("Tiratam 1000 tab", "Levetiracetam 1000 mg");}
    else if (selectedDrug == "Tiratam vial") {injectionClickShortcut("Tiratam vial", "Levetiracetam 500 mg / 5 ml");}
    else if (selectedDrug == "Tobolanza cap") {buttonClickShortcut("Tobolanza cap", "Alverine Citrate 60 mg + Simethicone 300 mg");}
    else if (selectedDrug == "Tofranil 25 tab") {buttonClickShortcut("Tofranil 25 tab", "Imipramine 25 mg");}
    else if (selectedDrug == "Topamax 25 tab") {buttonClickShortcut("Topamax 25 tab", "Topiramate 25 mg");}
    else if (selectedDrug == "Topging cap") {buttonClickShortcut("Topging cap", "Green Tea extract + Garcinia Cambogia extract + Ginger + Chromium");}
    else if (selectedDrug == "Toplexil syrup") {buttonClickShortcut("Toplexil syrup", "Oxomemazine 0.33 mg + Guaifenesin 0.33 mg / 1 ml");}
    else if (selectedDrug == "Topmode cap") {buttonClickShortcut("Topmode cap", "Sulpiride 50 mg");}
    else if (selectedDrug == "Topmode forte cap") {buttonClickShortcut("Topmode forte cap", "Sulpiride 200 mg");}
    else if (selectedDrug == "Toria sach") {buttonClickShortcut("Toria sach", "Colostrum + Lactoferrin +Vit C + Vit E + Selenium + Zinc");}
    else if (selectedDrug == "Total syrup") {buttonClickShortcut("Total syrup", "Cod liver oil (Omega 3 + Vit A + Vit D)\n(120 ml)");}
    else if (selectedDrug == "Tremfya prefilled syringe") {injectionClickShortcut("Tremfya prefilled syringe", "Guselkumab 100 mg / ml");}
    else if (selectedDrug == "Trendo tab") {buttonClickShortcut("Trendo tab", "Betaine HCL 150 mg + L-Glutamic acid 120 mg + Dandelion 35 mg + Rosemary 35 mg + Fennel seed 35 mg + Peppermint 50 mg");}
    else if (selectedDrug == "Totavit syrup") {buttonClickShortcut("Totavit syrup", "Vit A + Vit D3 + vit E + Vit B1 + vit B2 + vit B6 + vit B12 + vit C + Calcium + Biotin + Folic Acid + Iron\n(100 ml)");}
    else if (selectedDrug == "Tresiba prefilled pen") {injectionClickShortcut("Tresiba prefilled pen", "Insulin Degludec 100 units / ml");}
    else if (selectedDrug == "Triactin syrup") {buttonClickShortcut("Triactin syrup", "Cyproheptadine 2 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Triactin tab") {buttonClickShortcut("Triactin tab", "Cyproheptadine 4 mg");}
    else if (selectedDrug == "Triaminic drops") {buttonClickShortcut("Triaminic drops", "Pseudoephedrine 7.5 mg / 0.8 ml\n(15 ml)");}
    else if (selectedDrug == "Trib Gold cap") {buttonClickShortcut("Trib Gold cap", "Tribulus Terrestris 250 mg");}
    else if (selectedDrug == "Tridil vial") {injectionClickShortcut("Tridil vial", "Nitroglycerin 5 mg / 1 ml");}
    else if (selectedDrug == "Triguard cap") {buttonClickShortcut("Triguard cap", "Vit C 500 mg + Vit D 500 iu + Zinc 10 mg");}
    else if (selectedDrug == "Trileptal susp") {buttonClickShortcut("Trileptal susp", "Oxcarbazepine 300 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Trileptal tab") {buttonClickShortcut("Trileptal tab", "Oxcarbazepine\n150 mg\n300 mg\n600 mg");}
    else if (selectedDrug == "Trimed Flu tab") {buttonClickShortcut("Trimed Flu tab", "Loratadine 5 mg + Paracetamol 500 mg + Pseudoephedrine 120 mg");}
    else if (selectedDrug == "Trio-Clar cap") {buttonClickShortcut("Trio-Clar cap", "Omeprazole 20 mg + Tinidazole 500 mg + Clarithromycin 500 mg");}
    else if (selectedDrug == "Triocept tab") {buttonClickShortcut("Triocept tab", "-6 brown tablets: Levonorgestrel 0.05 mg + Ethinyl estradiol 0.03 mg\n-5 white tablets: Levonorgestrel 0.075 mg + Ethinyl estradiol 0.04 mg\n-10 yellow tablets: Levonorgestrel 0.125 mg + Ethinyl estradiol 0.03 mg");}
    else if (selectedDrug == "Trittico 50 tab") {buttonClickShortcut("Trittico 50 tab", "Trazodone 50 mg");}
    else if (selectedDrug == "Trivarol tab") {buttonClickShortcut("Trivarol tab", "Vit B1 125 mg + Vit B6 125 mg + Vit B12 125 mcg + Folic Acid 0.5 mg");}
    else if (selectedDrug == "Trivastal Retard tab") {buttonClickShortcut("Trivastal Retard tab", "Piribedil 50 mg");}
    else if (selectedDrug == "Trospamexin tab") {buttonClickShortcut("Trospamexin tab", "Trospium Chloride 20 mg");}
    else if (selectedDrug == "Trulicity 0.75 prefilled pen") {injectionClickShortcut("Trulicity 0.75 prefilled pen", "Dulaglutide 0.75 mg / 0.5 ml");}
    else if (selectedDrug == "Trypsican tab") {buttonClickShortcut("Trypsican tab", "Pancreatin + Papain + Bromelain + Trypsin + Alpha chymotrypsin + Sophora Japonica");}
    else if (selectedDrug == "Tryptizol 10 tab") {buttonClickShortcut("Tryptizol 10 tab", "Amitriptyline 10 mg");}
    else if (selectedDrug == "Tryptizol 25 tab") {buttonClickShortcut("Tryptizol 25 tab", "Amitriptyline 25 mg");}
    else if (selectedDrug == "Tudasidone 40 tab") {buttonClickShortcut("Tudasidone 40 tab", "Lurasidone 40 mg");}
    else if (selectedDrug == "Tusscapine syrup") {buttonClickShortcut("Tusscapine syrup", "Noscapine 15 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Tussi ibm syrup") {buttonClickShortcut("Tussi ibm syrup", "Noscapine 15 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Tussin syrup") {buttonClickShortcut("Tussin syrup", "Diphenhydramine 7 mg + Guaifenesin 50 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Tussistop syrup") {buttonClickShortcut("Tussistop syrup", "Levodropropizine 30 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Tussistop tab") {buttonClickShortcut("Tussistop tab", "Levodropropizine 60 mg");}
    else if (selectedDrug == "Twins D3 drops") {buttonClickShortcut("Twins D3 drops", "Vit D3 400 iu + Vit K2 5 mcg / 4 drops");}
    else if (selectedDrug == "Tygacil vial") {injectionClickShortcut("Tygacil vial", "Tigecycline 50 mg");}
    else if (selectedDrug == "Tysabri vial") {injectionClickShortcut("Tysabri vial", "Natalizumab 300 mg");}
    else if (selectedDrug == "Ultragriseofulvin susp") {buttonClickShortcut("Ultragriseofulvin susp", "Griseofulvin 125 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Ultragriseofulvin tab") {buttonClickShortcut("Ultragriseofulvin tab", "Griseofulvin 125 mg");}
    else if (selectedDrug == "Ultrasolv syrup") {buttonClickShortcut("Ultrasolv syrup", "Carbocysteine 125 mg + Guaifenesin 100 mg + Oxomemazine 2 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Ultrasolv tab") {buttonClickShortcut("Ultrasolv tab", "Carbocysteine 375 mg + Guaifenesin 225 mg + Oxomemazine 5 mg");}
    else if (selectedDrug == "Unictam 375 vial") {injectionClickShortcut("Unictam 375 vial", "Ampicillin 250 mg + Sulbactam 125 mg");}
    else if (selectedDrug == "Unictam 750 vial") {injectionClickShortcut("Unictam 750 vial", "Ampicillin 500 mg + Sulbactam 250 mg");}
    else if (selectedDrug == "Unictam 1.5 gm vial") {injectionClickShortcut("Unictam 1.5 gm vial", "Ampicillin 1000 mg + Sulbactam 500 mg");}
    else if (selectedDrug == "Unictam 3 gm vial") {injectionClickShortcut("Unictam 3 gm vial", "Ampicillin 2000 mg + Sulbactam 1000 mg");}
    else if (selectedDrug == "Unictam susp") {buttonClickShortcut("Unictam susp", "Sultamicillin 250 mg (Ampicillin 167 mg + Sulbactam 83 mg) / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Unictam 375 tab") {buttonClickShortcut("Unictam 375 tab", "Sultamicillin 375 mg (Ampicillin 250 mg + Sulbactam 125 mg)");}
    else if (selectedDrug == "Unictam 750 tab") {buttonClickShortcut("Unictam 750 tab", "Sultamicillin 750 mg (Ampicillin 500 mg + Sulbactam 250 mg)");}
    else if (selectedDrug == "Unovit syrup") {buttonClickShortcut("Unovit syrup", "Royal Jelly 100 mg + Honey 4 gm / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Uralyt-U granules") {buttonClickShortcut("Uralyt-U granules", "Potassium Sodium Hydrogen Citrate (6:6:3:5) 2.4gm/2.5gm(MeasureSpoon)");}
    else if (selectedDrug == "Urinex cap") {buttonClickShortcut("Urinex cap", "Camphene + Alfa-Pinene + Beta-Pinene + Borneol + Cineole + Anethol + Fenchone");}
    else if (selectedDrug == "Uripan 5 tab") {buttonClickShortcut("Uripan 5 tab", "Oxybutynin 5 mg");}
    else if (selectedDrug == "Uripan 10 tab") {buttonClickShortcut("Uripan 10 tab", "Oxybutynin 10 mg");}
    else if (selectedDrug == "Uripan syrup") {buttonClickShortcut("Uripan syrup", "Oxybutynin 5 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Urivin sach") {buttonClickShortcut("Urivin sach", "Atropine Sulphate + Colchicine + Piperazine + Khellin");}
    else if (selectedDrug == "Uro-Vaxom cap") {buttonClickShortcut("Uro-Vaxom cap", "Bacterial Lysate 6 mg\nLyophilized Bacterial Lysates of E.coli");}
    else if (selectedDrug == "Ursofalk cap") {buttonClickShortcut("Ursofalk cap", "Ursodeoxycholic Acid 250 mg");}
    else if (selectedDrug == "Ursoplus cap") {buttonClickShortcut("Ursoplus cap", "Ursodeoxycholic Acid 250 mg + Silymarin 140 mg");}
    else if (selectedDrug == "Uvamin retard cap") {buttonClickShortcut("Uvamin retard cap", "Nitrofurantoin 100 mg");}
    else if (selectedDrug == "Valponex tab") {buttonClickShortcut("Valponex 200 tab", "Sodium Valproate 200 mg");}
    else if (selectedDrug == "Valysernex 500 tab") {buttonClickShortcut("Valysernex 500 tab", "Valacyclovir 500 mg");}
    else if (selectedDrug == "Valysernex 1 gm tab") {buttonClickShortcut("Valysernex 1 gm tab", "Valacyclovir 1 gm");}
    else if (selectedDrug == "Vamid 10 tab") {buttonClickShortcut("Vamid 10 tab", "Leflunomide 10 mg");}
    else if (selectedDrug == "Vamid 20 tab") {buttonClickShortcut("Vamid 20 tab", "Leflunomide 20 mg");}
    else if (selectedDrug == "Vamid 100 tab") {buttonClickShortcut("Vamid 100 tab", "Leflunomide 100 mg");}
    else if (selectedDrug == "Vancomycin-Lyomark susp") {buttonClickShortcut("Vancomycin-Lyomark susp", "Vancomycin 1 gm /20 ml (50mg/ml)");}
    else if (selectedDrug == "Vancomycin 500 vial") {injectionClickShortcut("Vancomycin 500 vial", "Vancomycin 500 mg");}
    else if (selectedDrug == "Vancomycin 1 gm vial") {injectionClickShortcut("Vancomycin 1 gm vial", "Vancomycin 1 gm");}
    else if (selectedDrug == "Vapozol solution") {buttonClickShortcut("Vapozol solution", "Benzoin Tincture + Camphor + Eucalyptus + Peppermint Oil");}
    else if (selectedDrug == "Vascular tab") {buttonClickShortcut("Vascular tab", "Isoxsuprine 20 mg");}
    else if (selectedDrug == "Velosef 125 susp") {buttonClickShortcut("Velosef 125 susp", "Cephradine 125 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Velosef 250 susp") {buttonClickShortcut("Velosef 250 susp", "Cephradine 250 mg / 5 ml\n(60 ml & 100 ml)");}
    else if (selectedDrug == "Velosef 500 cap") {buttonClickShortcut("Velosef 500 cap", "Cephradine 500 mg");}
    else if (selectedDrug == "Velosef 1 gm cap") {buttonClickShortcut("Velosef 1 gm cap", "Cephradine 1000 mg");}
    else if (selectedDrug == "Velosef 500 vial") {injectionClickShortcut("Velosef 500 vial", "Cephradine 500 mg");}
    else if (selectedDrug == "Velosef 1 gm vial") {injectionClickShortcut("Velosef 1 gm vial", "Cephradine 1000 mg");}
    else if (selectedDrug == "Venlatrin 37.5 tab") {buttonClickShortcut("Venlatrin 37.5 tab", "Venlafaxine 37.5 mg");}
    else if (selectedDrug == "Vental inhaler") {buttonClickShortcut("Vental inhaler", "Salbutamol 100 mcg / dose");}
    else if (selectedDrug == "Vental Compositum inhaler") {buttonClickShortcut("Vental Compositum inhaler", "Beclomethasone 50 mcg + Salbutamol 100 mcg / dose");}
    else if (selectedDrug == "Ventocough syrup") {buttonClickShortcut("Ventocough syrup", "Salbutamol 1 mg + Bromhexine 2 mg + Guaifenesin 50 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Ventolin syrup") {buttonClickShortcut("Ventolin syrup", "Salbutamol 2 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Ventolin expectorant syrup") {buttonClickShortcut("Ventolin expectorant syrup", "Guaifenesin 50 mg + Salbutamol 1 mg / 5 ml\n(125 ml)");}
    else if (selectedDrug == "Verm-1 tab") {buttonClickShortcut("Verm-1 tab", "Mebendazole 500 mg");}
    else if (selectedDrug == "Vermizole susp") {buttonClickShortcut("Vermizole susp", "Albendazole 200 mg / 5 ml\n(30 ml)");}
    else if (selectedDrug == "Verpamil 40 tab") {buttonClickShortcut("Verpamil 40 tab", "Verapamil 40 mg");}
    else if (selectedDrug == "Vexamod 37.5 SR cap") {buttonClickShortcut("Vexamod 37.5 SR cap", "Venlafaxine 37.5 mg");}
    else if (selectedDrug == "Viagra 50 tab") {buttonClickShortcut("Viagra 50 tab", "Sildenafil 50 mg");}
    else if (selectedDrug == "Vibramycin tab") {buttonClickShortcut("Vibramycin tab", "Doxycycline 100 mg");}
    else if (selectedDrug == "Victoza prefilled pen") {injectionClickShortcut("Victoza prefilled pen", "Liraglutide 18 mg / 3 ml");}
    else if (selectedDrug == "Vidrop drops") {buttonClickShortcut("Vidrop drops", "Vit D3 (Cholecalciferol) 2800 iu / 1 ml\n(15 ml)");}
    else if (selectedDrug == "Vilaphoria 10 tab") {buttonClickShortcut("Vilaphoria 10 tab", "Vilazodone 10 mg");}
    else if (selectedDrug == "Vinporal tab") {buttonClickShortcut("Vinporal tab", "Vinpocetine 5 mg");}
    else if (selectedDrug == "Virinrest 400 tab") {buttonClickShortcut("Virinrest 400 tab", "Ribavirin 400 mg");}
    else if (selectedDrug == "Virustat 200 susp") {buttonClickShortcut("Virustat 200 susp", "Acyclovir 200 mg / 5 ml \n(120 ml)");}
    else if (selectedDrug == "Virustat 200 tab") {buttonClickShortcut("Virustat 200 tab", "Acyclovir 200 mg");}
    else if (selectedDrug == "Virustat 400 tab") {buttonClickShortcut("Virustat 400 tab", "Acyclovir 400 mg");}
    else if (selectedDrug == "Virustat 800 tab") {buttonClickShortcut("Virustat 800 tab", "Acyclovir 800 mg");}
    else if (selectedDrug == "Visanne tab") {buttonClickShortcut("Visanne tab", "Dienogest 2 mg");}
    else if (selectedDrug == "Visceralgine amp") {injectionClickShortcut("Visceralgine amp", "Tiemonium Methylsulfate 5 mg / 2 ml");}
    else if (selectedDrug == "Visceralgine supp") {buttonClickShortcut("Visceralgine supp", "Tiemonium methylsulfate 20 mg");}
    else if (selectedDrug == "Visceralgine syrup") {buttonClickShortcut("Visceralgine syrup", "Tiemonium methylsulfate 10 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Visceralgine tab") {buttonClickShortcut("Visceralgine tab", "Tiemonium methylsulfate 50 mg");}
    else if (selectedDrug == "Vitacid C 500 sach") {buttonClickShortcut("Vitacid C 500 sach", "Vit C 500 mg");}
    else if (selectedDrug == "Vitacid C 1 gm eff tab") {buttonClickShortcut("Vitacid C 1 gm eff tab", "Vit C 1 gm");}
    else if (selectedDrug == "Vitacid Calcium tab") {buttonClickShortcut("Vitacid Calcium tab", "Vit C 1 gm + Calcium 320 mg");}
    else if (selectedDrug == "Vitaferrol cap") {buttonClickShortcut("Vitaferrol cap", "Iron 115.5 mg + Cyanocobalamin 7.5 mcg + Folic Acid 1 mg + Vit C 150 mg + Manganese 2.5 mg + Zinc 7 mg");}
    else if (selectedDrug == "Vitaferrol syrup") {buttonClickShortcut("Vitaferrol syrup", "Iron 38 mg + Thiamine 1 mg + Riboflavin 1 mg + Pyridoxine 0.5 mg + Cyanocobalamin 4 mcg + Panthenol 1.5 mg + Nicotinamide 6 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Vitamount for men cap") {buttonClickShortcut("Vitamount for men cap", "Vit A + Vit B1 + Vit B2 + Vit B6 + Vit B12 + Vit C + Vit D + Vit E + Vit K + Niacinamide + Ca pantothenate + Folic Acid + Zinc + Selenium + Chromium60 + Copper");}
    else if (selectedDrug == "Vitamount for women cap") {buttonClickShortcut("Vitamount for women cap", "Vit A + Vit B1 + Vit B2 + Vit B6 + Vit B12 + Vit C + Vit D + Vit E + Vit K + Niacinamide + Ca pantothenate + Folic Acid + Zinc + Iron + Calcium + Magnesium + Copper");}
    else if (selectedDrug == "Vitamount syrup") {buttonClickShortcut("Vitamount syrup", "Vit A + Vit B1 + Vit B2 + Vit B3 + Vit B6 + Vit B12 + Vit C + Vit D + Vit E + Biotin + Ca pantothenate + Iodine + Zinc + Iron + Manganese + Chromium\n(120 ml)");}
    else if (selectedDrug == "Vitayami tab") {buttonClickShortcut("Vitayami tab", "Vit A + Vit B1 + Vit B2 + Vit B3 + Vit B5 + Vit B6 + Vit B7 + Vit B12 + Vit C + Vit D + Vit E + Folic Acid + Ca + Chromium + Cu + Iodine + Iron + Mg + Mn + Molybdenum + Selenium + Zinc");}
    else if (selectedDrug == "Vitifect syrup") {buttonClickShortcut("Vitifect syrup", "Calcium 50 mg + Vit A 1200 iu + Vit B1 1 mg + Vit B2 1 mg + Vit B3 5 mg + Vit B6 0.5 mg + Vit C 50 mg + Vit D 100 iu + Vit E 2 mg / 5 ml\n(120 ml)");}
    else if (selectedDrug == "Vitosel sach") {buttonClickShortcut("Vitosel sach", "Lactoferrin + Ferrous Fumarate + Colostrum + Folic Acid + Vit A + Vit B1 + Vit B2 + Vit B3 + Vit B6 + Vit B12 + Vit E");}
    else if (selectedDrug == "Vokanamet tab") {buttonClickShortcut("Vokanamet tab", "Canagliflozin + Metformin\n(50/850)\n(50/1000)\n(150/850)\n(150/1000)");}
    else if (selectedDrug == "Voltaren 25 tab") {buttonClickShortcut("Voltaren 25 tab", "Diclofenac Na 25 mg");}
    else if (selectedDrug == "Voltaren 50 tab") {buttonClickShortcut("Voltaren 50 tab", "Diclofenac Na 50 mg");}
    else if (selectedDrug == "Voltaren SR 75 tab") {buttonClickShortcut("Voltaren SR 75 tab", "Diclofenac Na 75 mg");}
    else if (selectedDrug == "Voltaren SR 100 tab") {buttonClickShortcut("Voltaren SR 100 tab", "Diclofenac Na 100 mg");}
    else if (selectedDrug == "Voltaren 100 supp") {buttonClickShortcut("Voltaren 100 supp", "Diclofenac Na 100 mg");}
    else if (selectedDrug == "Vomibreak tab") {buttonClickShortcut("Vomibreak tab", "Doxylamine 10 mg + Pyridoxine 10 mg");}
    else if (selectedDrug == "Vomistop cap") {buttonClickShortcut("Vomistop cap", "Metoclopramide 7.5 mg + Vit B6 40 mg + Dimethicone 50 mg");}
    else if (selectedDrug == "Vonaspire 10 tab") {buttonClickShortcut("Vonaspire 10 tab", "Vonoprazan 10 mg");}
    else if (selectedDrug == "Vonaspire 20 tab") {buttonClickShortcut("Vonaspire 20 tab", "Vonoprazan 20 mg");}
    else if (selectedDrug == "Vosevi tab") {buttonClickShortcut("Vosevi tab", "Sofosbuvir 400 mg + Velpatasvir 100 mg + Voxilaprevir 100 mg");}
    else if (selectedDrug == "Wellinta SR tab") {buttonClickShortcut("Wellinta SR tab", "Bupropion 150 mg");}
    else if (selectedDrug == "Westabreath tab") {buttonClickShortcut("Westabreath tab", "Roflumilast 0.5 mg");}
    else if (selectedDrug == "Xanax 0.25 tab") {buttonClickShortcut("Xanax 0.25 tab", "Alprazolam 0.25 mg");}
    else if (selectedDrug == "Xanax 0.5 XR tab") {buttonClickShortcut("Xanax 0.5 XR tab", "Alprazolam 0.5 mg");}
    else if (selectedDrug == "Xgeva vial") {injectionClickShortcut("Xgeva vial", "Denosumab 120 mg / 1.7 ml");}
    else if (selectedDrug == "Xilone syrup") {buttonClickShortcut("Xilone syrup", "Prednisolone 5 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Xilone forte syrup") {buttonClickShortcut("Xilone forte syrup", "Prednisolone 15 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Xolair vial") {injectionClickShortcut("Xolair vial", "Omalizumab 150 mg");}
    else if (selectedDrug == "Xultophy prefilled pen") {injectionClickShortcut("Xultophy prefilled pen", "Liraglutide 3.6 mg + Insulin Degludec 100 iu / 1 ml");}
    else if (selectedDrug == "Xyntha vial") {injectionClickShortcut("Xyntha vial", "Blood Coagulation Factor VIII\n250 iu\n500 iu\n1000 iu");}
    else if (selectedDrug == "Yasmin tab") {buttonClickShortcut("Yasmin tab", "Drospirenone 3 mg + Ethinyl Estradiol 0.03 mg (30 mcg)");}
    else if (selectedDrug == "Yaz tab") {buttonClickShortcut("Yaz tab", "Drospirenone 3 mg + Ethinyl Estradiol 0.02 mg (20 mcg)");}
    else if (selectedDrug == "Yomesan chew tab") {buttonClickShortcut("Yomesan chew tab", "Niclosamide 500 mg");}
    else if (selectedDrug == "Zaditen syrup") {buttonClickShortcut("Zaditen syrup", "Ketotifen 1 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Zaditen tab") {buttonClickShortcut("Zaditen tab", "Ketotifen 1 mg");}
    else if (selectedDrug == "Zandros cap") {buttonClickShortcut("Zandros cap", "Fish Oil 1200 mg (Omega3 600 mg) +Vit E 19 iu");}
    else if (selectedDrug == "Zanoglide 2/30 tab") {buttonClickShortcut("Zanoglide 2/30 tab", "Glimepiride 2 mg + Pioglitazone 30 mg");}
    else if (selectedDrug == "Zantac 150 tab") {buttonClickShortcut("Zantac 150 tab", "Ranitidine 150 mg");}
    else if (selectedDrug == "Zantac 300 tab") {buttonClickShortcut("Zantac 300 tab", "Ranitidine 300 mg");}
    else if (selectedDrug == "Zantac amp") {injectionClickShortcut("Zantac amp", "Ranitidine 50 mg / 2 ml");}
    else if (selectedDrug == "Zestoretic 20/12.5 tab") {buttonClickShortcut("Zestoretic 20/12.5 tab", "Lisinopril 20 mg + Hydrochlorothiazide 12.5 mg");}
    else if (selectedDrug == "Zestril 5 tab") {buttonClickShortcut("Zestril 5 tab", "Lisinopril 5 mg");}
    else if (selectedDrug == "Zimocefox 250 susp") {buttonClickShortcut("Zimocefox 250 susp", "Cefuroxime 250 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Zinctron cap") {buttonClickShortcut("Zinctron cap", "Zinc 11 mg + Copper 0.9 mg + Vit C 107 mg + Vit B6 1.625 mg + Citrus Bioflavonoids 150 mg");}
    else if (selectedDrug == "Zinol 500 vial") {injectionClickShortcut("Zinol 500 vial", "Cefazolin 500 mg");}
    else if (selectedDrug == "Zithrokan 500 cap") {buttonClickShortcut("Zithrokan 500 cap", "Azithromycin 500 mg");}
    else if (selectedDrug == "Zithrokan 100 susp") {buttonClickShortcut("Zithrokan 100 susp", "Azithromycin 100 mg / 5 ml\n(15 ml)");}
    else if (selectedDrug == "Zithrokan 200 susp") {buttonClickShortcut("Zithrokan 200 susp", "Azithromycin 200 mg / 5 ml\n(15 ml)");}
    else if (selectedDrug == "Zocef 125 susp") {buttonClickShortcut("Zocef 125 susp", "Cefuroxime 125 mg / 5 ml\n(60 ml)");}
    else if (selectedDrug == "Zocor 10 tab") {buttonClickShortcut("Zocor 10 tab", "Simvastatin 10 mg");}
    else if (selectedDrug == "Zodium tab") {buttonClickShortcut("Zodium tab", "Zolpidem 10 mg");}
    else if (selectedDrug == "Zofran amp") {injectionClickShortcut("Zofran amp", "Ondansetron 8 mg / 4 ml OR\nOndansetron 4 mg / 2 ml");}
    else if (selectedDrug == "Zofran syrup") {buttonClickShortcut("Zofran syrup", "Ondansetron 4 mg / 5 ml\n(50 ml)");}
    else if (selectedDrug == "Zolidocyrl tab") {buttonClickShortcut("Zolidocyrl tab", "Tedizolid 200 mg");}
    else if (selectedDrug == "Zonactam vial") {injectionClickShortcut("Zonactam vial", "Cefoperazone 1 gm + Sulbactam 0.5 gm");}
    else if (selectedDrug == "Zovirax 400 susp") {buttonClickShortcut("Zovirax 400 susp", "Acyclovir 400 mg / 5 ml \n(100 ml)");}
    else if (selectedDrug == "Zovirax 250 vial") {injectionClickShortcut("Zovirax 250 vial", "Acyclovir 250 mg");}
    else if (selectedDrug == "Zovirax 500 vial") {injectionClickShortcut("Zovirax 500 vial", "Acyclovir 500 mg");}
    else if (selectedDrug == "Zyloric 100 tab") {buttonClickShortcut("Zyloric 100 tab", "Allopurinol 100 mg");}
    else if (selectedDrug == "Zyloric 300 tab") {buttonClickShortcut("Zyloric 300 tab", "Allopurinol 300 mg");}
    else if (selectedDrug == "Zyprexa 5 tab") {buttonClickShortcut("Zyprexa 5 tab", "Olanzapine 5 mg");}
    else if (selectedDrug == "Zyprexa 7.5 tab") {buttonClickShortcut("Zyprexa 7.5 tab", "Olanzapine 7.5 mg");}
    else if (selectedDrug == "Zyprexa 10 tab") {buttonClickShortcut("Zyprexa 10 tab", "Olanzapine 10 mg");}
    else if (selectedDrug == "Zyrtec drops") {buttonClickShortcut("Zyrtec drops", "Cetirizine 10 mg / 1 ml\n(10 ml)");}
    else if (selectedDrug == "Zyrtec syrup") {buttonClickShortcut("Zyrtec syrup", "Cetirizine 5 mg / 5 ml\n(100 ml)");}
    else if (selectedDrug == "Zyrtec tab") {buttonClickShortcut("Zyrtec tab", "Cetirizine 10 mg");}
    else if (selectedDrug == "Zyrovazet tab") {buttonClickShortcut("Zyrovazet tab", "Rosuvastatin + Ezetimibe\n(5 / 10)\n(10 / 10)\n(20 / 10)\n(40 / 10)");}
    else if (selectedDrug == "Zytiga 250 tab") {buttonClickShortcut("Zytiga 250 tab", "Abiraterone 250 mg");}
    else if (favContentDescription == "active") {generalDiag("Warning", "This drug either removed from the main list or the name has been changed\n\nRemove it from the favourite list then add it again");}
  }

  void loadSavedPreferences () {
    SharedPreferences.getInstance().then((prefs) {
      setState(() {
        saveAgeChecked = prefs.getBool(saveAgeCheckbox) ?? false;
        saveMenuChecked = prefs.getBool(saveMenuCheckbox) ?? false;
        saveWeightChecked = prefs.getBool(saveWeightCheckbox) ?? false;
        saveSearchChecked = prefs.getBool(saveSearchCheckbox) ?? false;
      });
    });

    Future.delayed(const Duration(seconds: 1), () {
      SharedPreferences.getInstance().then((prefs) {
        if (saveMenuChecked) {
          showAgeDiag();
          // if (_dropdownButtonKey.currentContext != null) {
          //   _dropdownButtonKey.currentContext?.visitChildElements((element) {
          //     if (element.widget is Semantics) {
          //       element.visitChildElements((element) {
          //         if (element.widget is Actions) {
          //           element.visitChildElements((element) {
          //             Actions.invoke(element, _intent);
          //             return;
          //           });
          //         }
          //       });
          //     }
          //   });
          // }
        }
        else {
          setState(() {
            SharedPreferences.getInstance().then((prefs) {
              selectedAgeTextMenu = prefs.getString(saveAgeCheckboxValue) ?? 'age';
              if (!saveSearchChecked) ageMenuClicked = true;
              setSelectedAgeData();
            });
          });
        }
      });

      setState(() {
        SharedPreferences.getInstance().then((prefs) {
          weightText.text = prefs.getString(saveWeightCheckboxValue) ?? '';
          if (weightText.text.isNotEmpty)  myVar = double.parse(weightText.text);
        });

        SharedPreferences.getInstance().then((prefs) {
          searchEditText.text = prefs.getString(saveSearchCheckboxValue) ?? '';
          filterItemsByName(prefs.getString(saveSearchCheckboxValue) ?? '');
        });
      });
    });
  }

  void setSelectedAgeData() {
    if (selectedAgeTextMenu == 'age') {weightText.text = ''; myVar = 0; selectedAge = 0; selectedAgeTextVar = 'age'; weightHint = '0';} else { if (ageMenuClicked && favContentDescription == 'inactive') {searchEditFocus.requestFocus();} setState(() {ageBorder = Colors.grey;});}
    if (selectedAgeTextMenu == '2 weeks') {if (weightText.text == '') myVar = 3.5; selectedAge = 3.5; selectedAgeTextVar = "2 weeks"; weightHint = "Default 3.5";}
    if (selectedAgeTextMenu == '1 month') {if (weightText.text == '') myVar = 4; selectedAge = 4; selectedAgeTextVar = "1 month"; weightHint = "Default 4";}
    if (selectedAgeTextMenu == '2 months') {if (weightText.text == '') myVar = 4.5; selectedAge = 4.5; selectedAgeTextVar = "2 months"; weightHint = "Default 4.5";}
    if (selectedAgeTextMenu == '3 months') {if (weightText.text == '') myVar = 5; selectedAge = 5; selectedAgeTextVar = "3 months"; weightHint = "Default 5";}
    if (selectedAgeTextMenu == '4 months') {if (weightText.text == '') myVar = 5.5; selectedAge = 5.5; selectedAgeTextVar = "4 months"; weightHint = "Default 5.5";}
    if (selectedAgeTextMenu == '5 months') {if (weightText.text == '') myVar = 6; selectedAge = 6; selectedAgeTextVar = "5 months"; weightHint = "Default 6";}
    if (selectedAgeTextMenu == '6 months') {if (weightText.text == '') myVar = 6.5; selectedAge = 6.5; selectedAgeTextVar = "6 months"; weightHint = "Default 6.5";}
    if (selectedAgeTextMenu == '7 months') {if (weightText.text == '') myVar = 7; selectedAge = 7; selectedAgeTextVar = "7 months"; weightHint = "Default 7";}
    if (selectedAgeTextMenu == '8 months') {if (weightText.text == '') myVar = 7.5; selectedAge = 7.5; selectedAgeTextVar = "8 months"; weightHint = "Default 7.5";}
    if (selectedAgeTextMenu == '9 months') {if (weightText.text == '') myVar = 8; selectedAge = 8; selectedAgeTextVar = "9 months"; weightHint = "Default 8";}
    if (selectedAgeTextMenu == '10 months') {if (weightText.text == '') myVar = 8.5; selectedAge = 8.5; selectedAgeTextVar = "10 months"; weightHint = "Default 8.5";}
    if (selectedAgeTextMenu == '11 months') {if (weightText.text == '') myVar = 9; selectedAge = 9; selectedAgeTextVar = "11 months"; weightHint = "Default 9";}
    if (selectedAgeTextMenu == '➤ 1 year') {if (weightText.text == '') myVar = 9.5; selectedAge = 9.5; selectedAgeTextVar = "1 year"; weightHint = "Default 9.5";}
    if (selectedAgeTextMenu == '1.5 years') {if (weightText.text == '') myVar = 11; selectedAge = 11; selectedAgeTextVar = "1.5 years"; weightHint = "Default 11";}
    if (selectedAgeTextMenu == '➤ 2 years') {if (weightText.text == '') myVar = 12; selectedAge = 12; selectedAgeTextVar = "2 years"; weightHint = "Default 12";}
    if (selectedAgeTextMenu == '2.5 years') {if (weightText.text == '') myVar = 13; selectedAge = 13; selectedAgeTextVar = "2.5 years"; weightHint = "Default 13";}
    if (selectedAgeTextMenu == '➤ 3 years') {if (weightText.text == '') myVar = 14; selectedAge = 14; selectedAgeTextVar = "3 years"; weightHint = "Default 14";}
    if (selectedAgeTextMenu == '3.5 years') {if (weightText.text == '') myVar = 15; selectedAge = 15; selectedAgeTextVar = "3.5 years"; weightHint = "Default 15";}
    if (selectedAgeTextMenu == '➤ 4 years') {if (weightText.text == '') myVar = 16; selectedAge = 16; selectedAgeTextVar = "4 years"; weightHint = "Default 16";}
    if (selectedAgeTextMenu == '4.5 years') {if (weightText.text == '') myVar = 17; selectedAge = 17; selectedAgeTextVar = "4.5 years"; weightHint = "Default 17";}
    if (selectedAgeTextMenu == '➤ 5 years') {if (weightText.text == '') myVar = 18; selectedAge = 18; selectedAgeTextVar = "5 years"; weightHint = "Default 18";}
    if (selectedAgeTextMenu == '5.5 years') {if (weightText.text == '') myVar = 19; selectedAge = 19; selectedAgeTextVar = "5.5 years"; weightHint = "Default 19";}
    if (selectedAgeTextMenu == '➤ 6 years') {if (weightText.text == '') myVar = 20; selectedAge = 20; selectedAgeTextVar = "6 years"; weightHint = "Default 20";}
    if (selectedAgeTextMenu == '➤ 7 years') {if (weightText.text == '') myVar = 22; selectedAge = 22; selectedAgeTextVar = "7 years"; weightHint = "Default 22";}
    if (selectedAgeTextMenu == '➤ 8 years') {if (weightText.text == '') myVar = 26; selectedAge = 26; selectedAgeTextVar = "8 years"; weightHint = "Default 26";}
    if (selectedAgeTextMenu == '➤ 9 years') {if (weightText.text == '') myVar = 30; selectedAge = 30; selectedAgeTextVar = "9 years"; weightHint = "Default 30";}
    if (selectedAgeTextMenu == '➤ 10 years') {if (weightText.text == '') myVar = 34; selectedAge = 34; selectedAgeTextVar = "10 years"; weightHint = "Default 34";}
    if (selectedAgeTextMenu == '➤ 11 years') {if (weightText.text == '') myVar = 39; selectedAge = 39; selectedAgeTextVar = "11 years"; weightHint = "Default 39";}
    if (selectedAgeTextMenu == '➤ 12 years') {if (weightText.text == '') myVar = 44; selectedAge = 44; selectedAgeTextVar = "12 years"; weightHint = "Default 44";}
    if (selectedAgeTextMenu == '➤ 13 years') {if (weightText.text == '') myVar = 48; selectedAge = 48; selectedAgeTextVar = "13 years"; weightHint = "Default 48";}
    if (selectedAgeTextMenu == '➤ 14 years') {if (weightText.text == '') myVar = 52; selectedAge = 52; selectedAgeTextVar = "14 years"; weightHint = "Default 52";}
    if (selectedAgeTextMenu == '➤ 15 years') {if (weightText.text == '') myVar = 56; selectedAge = 56; selectedAgeTextVar = "15 years"; weightHint = "Default 56";}
    if (selectedAgeTextMenu == '➤ 16 years') {if (weightText.text == '') myVar = 60; selectedAge = 60; selectedAgeTextVar = "16 years"; weightHint = "Default 60";}
    if (selectedAgeTextMenu == '➤ 17 years') {if (weightText.text == '') myVar = 63; selectedAge = 63; selectedAgeTextVar = "17 years"; weightHint = "Default 63";}
    if (selectedAgeTextMenu == '➤ Adult') {if (weightText.text == '') myVar = 70; selectedAge = 70; selectedAgeTextVar = "adult"; weightHint = "Default 70";}

    if (saveAgeChecked) {
      SharedPreferences.getInstance().then((prefs) {
        prefs.setString(saveAgeCheckboxValue, selectedAgeTextMenu);
      });
    } else {
      SharedPreferences.getInstance().then((prefs) {
        prefs.setString(saveAgeCheckboxValue, 'age');
      });
    }
  }

  Future<void> saveFavListLocally() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> serializedItems = _favFilteredItems.map((item) => _serializeItem(item)).toList();
    await prefs.setStringList('save_fav_list', serializedItems);
  }

  Future<void> loadFavListLocally() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? savedItems = prefs.getStringList('save_fav_list');
    if (savedItems != null) {
      setState(() {
        _favFilteredItems = savedItems.map((item) => _deserializeItem(item)).toList();
      });
    }
  }

  Future<void> saveFavListCloud() async {
    if (!Platform.isWindows) {
      final FirebaseDatabase database = FirebaseDatabase.instance;
      List<String> serializedItems = _favFilteredItems.map((item) => _serializeItem(item)).toList();

      String getMonthName(int month) {
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return monthNames[month - 1];
      }
      String formatDateAndTime(DateTime dateTime) {
        final day = dateTime.day;
        final month = getMonthName(dateTime.month);
        final hour = dateTime.hour;
        final minute = dateTime.minute;
        final amPm = hour >= 12 ? 'pm' : 'am';
        final hour12 = hour > 12 ? hour - 12 : hour;
        return '$day $month, ${hour12.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')} $amPm';
      }
      final currentDateTime = DateTime.now();
      lastSync = formatDateAndTime(currentDateTime);

      SharedPreferences prefs = await SharedPreferences.getInstance();
      try {
        await database.ref().child('users/${user!.uid}/items').set(serializedItems).whenComplete(() async => await prefs.setString('lastSync', lastSync));
      }
      catch (error) {
        // BotToast.showText(text: "sync failed");
      }

    }
  }

  Future<void> loadFavListCloud() async {
    if (!Platform.isWindows) {
      if (loadIntentionally) {
        final FirebaseDatabase database = FirebaseDatabase.instance;
        DataSnapshot snapshot = await database.ref().child('users/${user!.uid}/items').get();
        try {
          if (snapshot.value != null) {
            if (favContentDescription == 'active') {
              setState(() {
                favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
                favDrugListV = false; sortManually = false;
                mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
                favAddTextV = false;
                filterBannerV = true; bannerHeight = 45;
              });
            }
            setState(() {
              _favFilteredItems = (snapshot.value as List<dynamic>).map((item) => _deserializeItem(item)).toList();
            });
            BotToast.showText(text: "favorite list load success");
            saveFavListLocally();
          }
          else {
            BotToast.showText(text: "online list is empty");
          }
        }
        catch (error) {
          BotToast.showText(text: "favorite list load failed");
        }
      }
      else {
        if (premium && (user != null )) {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text("Load",),
                content: const Text("Would you like to delete the current favourite list and load the list saved on cloud?"),
                actions: <Widget>[
                  TextButton(
                    child: const Text("Yes, load online list"),
                    onPressed: () async {
                      Navigator.of(context).pop();
                      final FirebaseDatabase database = FirebaseDatabase.instance;
                      DataSnapshot snapshot = await database.ref().child('users/${user!.uid}/items').get();
                      try {
                        if (snapshot.value != null) {
                          if (favContentDescription == 'active') {
                            setState(() {
                              favContentDescription = 'inactive'; favImage = 'assets/images/fav_not_active.png';
                              favDrugListV = false; sortManually = false;
                              mainDrugListV = true; if (_filteredItems.length < 6) {notFoundV = true;} searchLinearV = true;
                              favAddTextV = false;
                              filterBannerV = true; bannerHeight = 45;
                            });
                          }
                          setState(() {
                            _favFilteredItems = (snapshot.value as List<dynamic>).map((item) => _deserializeItem(item)).toList();
                          });
                          BotToast.showText(text: "favorite list load success");
                          saveFavListLocally();
                        }
                        else {
                          BotToast.showText(text: "online list is empty");
                        }
                      }
                      catch (error) {
                        BotToast.showText(text: "favorite list load failed");
                      }
                    },
                  ),
                  TextButton(
                    child: const Text("No, keep current list"),
                    onPressed: () {
                      Navigator.of(context).pop();
                      saveFavListCloud();
                    },
                  ),
                ],
              );
            },
          );
        }
      }
    }
  }

  Map<String, String> _deserializeItem(String item) {
    List<String> parts = item.split('|');
    return {
      'trade': parts[0],
      'generic': parts[1],
      'search': parts[2],
      'color': parts[3],
      'indications': parts[4],
    };
  }

  String _serializeItem(Map<String, String> item) {
    return '${item['trade']}|${item['generic']}|${item['search']}|${item['color']}|${item['indications']}';
  }

  Future<void> showRewarded() async {
    if (unityRewardedReady) {
      UnityAds.showVideoAd(
        placementId: unityRewardedID,
        onSkipped: (placementId) {
          BotToast.showText(text: "ad skipped");
          if (points < 30) {
            unityRewardedReady = false;
            UnityAds.load(
              placementId: unityRewardedID,
              onComplete: (placementId) => unityRewardedReady = true,
            );
          }
        },
        onComplete: (placementId) {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text("You got +5 points"),
                content: Text("you can now open injections extra 5 times.\n\nyour total points is ${points.toString()}\n\nWould you like to watch another ad to accumulate points?"),
                actions: <Widget>[
                  TextButton(
                    child: const Text("yes, watch another ad"),
                    onPressed: () {
                      Navigator.of(context).pop();
                      if (unityRewardedReady) {
                        showRewarded();
                      }
                      else {
                        Future.delayed(const Duration(seconds: 2), () {
                          showRewarded();
                        });
                      }
                    },
                  ),
                  TextButton(
                    child: const Text("no, later"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              );
            },
          );
          // BotToast.showText(text: "you got +5 points");
          setState(() {
            points = points < 1 ? 5 : points + 5;
          });
          savePoints(points);
          if (points < 30) {
            unityRewardedReady = false;
            UnityAds.load(
              placementId: unityRewardedID,
              onComplete: (placementId) => unityRewardedReady = true,
            );
          }
        },
        onFailed: (placementId, error, message) {
          BotToast.showText(text: "Error. failed to show ad");
          if (points < 30) {
            unityRewardedReady = false;
            UnityAds.load(
              placementId: unityRewardedID,
              onComplete: (placementId) => unityRewardedReady = true,
            );
          }
        }
      );
    }
    else {
      if (await checkInternetConnection()) {BotToast.showText(text: "ad not ready yet");} else {BotToast.showText(text: "check internet connection");}
    }
  }

  void showInterstitial () {
    if (showInterstitialEvery3Sec % 6 == 3 && !premium && (Platform.isIOS || Platform.isAndroid)) {
      if (unityInterstitialReady) {
        UnityAds.showVideoAd(placementId: unityInterstitialID,
          onComplete: (placementID){
            unityInterstitialReady = false;
            UnityAds.load(placementId: unityInterstitialID,
                onComplete: (placementId) => unityInterstitialReady = true);
          },
          onFailed: (placementID, error, message){
            unityInterstitialReady = false;
            UnityAds.load(placementId: unityInterstitialID,
                onComplete: (placementId) => unityInterstitialReady = true);
          },
          onSkipped: (placementID){
            unityInterstitialReady = false;
            UnityAds.load(placementId: unityInterstitialID,
                onComplete: (placementId) => unityInterstitialReady = true);
          },);
      }
    }
  }

  void loadBothAds () {
    WidgetsFlutterBinding.ensureInitialized().addPostFrameCallback((_) => requestPermissionForAds());
    loadUnityAds();
  }

  void loadUnityAds () {
    if (!premium && (Platform.isIOS || Platform.isAndroid)) {
      UnityAds.init(
        gameId: unityGameId,
        // testMode: true,
        onComplete: () =>{
          UnityAds.load(
            placementId: unityRewardedID,
            onComplete: (placementId) => unityRewardedReady = true,
          ),
          UnityAds.load(placementId: unityInterstitialID,
              onComplete: (placementId) => unityInterstitialReady = true),
        },
      );
    }
  }

  Future<int> loadPoints() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getInt('points') ?? 0;
  }

  void savePoints(int points) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('points', points);
  }

  void adPayDiag () {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Visibility(visible: watchVideoV,
                  child: Container(
                    width: double.infinity,
                    height: null,
                    color: Colors.red[700],
                    padding: const EdgeInsets.all(4),
                    child: const Text(
                      'injections are locked',
                      style: TextStyle(color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  height: null,
                  color: Colors.yellow[50],
                  padding: const EdgeInsets.all(4),
                  child: const Text(
                    'Full Version Features:',
                    style: TextStyle(color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  height: null,
                  color: Colors.yellow[50],
                  padding: const EdgeInsets.all(4),
                  child: const Text(
                    '-remove all ads\n-permanent access to injections\n-search drugs by indications\n-use the favorite list',
                    style: TextStyle(color: Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
                if (Platform.isAndroid)
                  Container(
                    width: double.infinity,
                    height: null,
                    margin: const EdgeInsets.only(bottom: 2),
                    color: Colors.yellow[50],
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(onTap: () {
                          Navigator.of(context).pop();
                          claimPay = false; userTap = true;
                          BotToast.showText(text: "wait a moment");
                          loadIntentionally = false;
                          signInWithGoogle().whenComplete(() => firestore().whenComplete(() => loadFavListCloud()));
                        },
                          child: Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              boxShadow: const [BoxShadow (color: Colors.black45, spreadRadius: 1, blurRadius: 1, offset: Offset(1, 1))],
                              color: Colors.green[600],
                              borderRadius: BorderRadius.circular(20),
                            ),
                            alignment: Alignment.center,
                            padding: const EdgeInsets.all(8),
                            child: const Text("Unlock full version",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                        GestureDetector(onTap: () async {
                          Navigator.of(context).pop();
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text("restore purchase"),
                                content: const Text("Make sure there is internet connection. Then on the next screen, choose the Email you used to unlock full version"),
                                actions: <Widget>[
                                  TextButton(
                                    child: const Text("Start"),
                                    onPressed: () async {
                                      Navigator.of(context).pop();
                                      claimPay = true; userTap = false;
                                      BotToast.showText(text: "wait a moment");
                                      loadIntentionally = false;
                                      signInWithGoogle().whenComplete(() => firestore().whenComplete(() => loadFavListCloud()));
                                    },
                                  ),
                                ],
                              );
                            },
                          );
                        },
                          child: Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              boxShadow: const [BoxShadow (color: Colors.black45, spreadRadius: 1, blurRadius: 1, offset: Offset(1, 1))],
                              color: Colors.green[600],
                              borderRadius: BorderRadius.circular(20),
                            ),
                            alignment: Alignment.center,
                            padding: const EdgeInsets.all(8),
                            child: const Text(
                              'Already paid',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (Platform.isIOS || Platform.isMacOS)
                  Container(
                    width: double.infinity,
                    height: null,
                    margin: const EdgeInsets.only(bottom: 2),
                    color: Colors.yellow[50],
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(onTap: () async {
                          Navigator.of(context).pop();
                          _purchaseProduct();
                          purchasePressed = true;
                        },
                          child: Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              boxShadow: const [BoxShadow (color: Colors.black45, spreadRadius: 1, blurRadius: 1, offset: Offset(1, 1))],
                              color: Colors.green[600],
                              borderRadius: BorderRadius.circular(40),
                            ),
                            alignment: Alignment.center,
                            padding: const EdgeInsets.all(8),
                            child: Text(
                              'Activate full version for $price (once in life)',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                        GestureDetector(onTap: () {
                          Navigator.of(context).pop();
                          InAppPurchase.instance.restorePurchases();
                          purchasePressed = true;
                        },
                          child: Container(margin: const EdgeInsets.only(bottom: 8),
                            child: const Text(
                              'Restore purchase',
                              style: TextStyle(
                                color: Colors.blue,
                                decoration: TextDecoration.underline,
                                decorationColor: Colors.blue,
                                decorationThickness: 2,
                                decorationStyle: TextDecorationStyle.solid,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (Platform.isWindows)
                  GestureDetector(onTap: () {
                    Navigator.of(context).pop();
                    windowsEmailController.text = "";
                    windowsEditDiagStart();
                  },
                    child: Container(
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        boxShadow: const [BoxShadow (color: Colors.black45, spreadRadius: 1, blurRadius: 1, offset: Offset(1, 1))],
                        color: Colors.blueAccent[700],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.center,
                      padding: const EdgeInsets.all(8),
                      child: const Text("Unlock full version",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                Visibility(visible: watchVideoV,
                  child: Container(color: Colors.black,
                      child: const SizedBox(height: 2,width: double.maxFinite,)),
                ),
                Visibility(visible: watchVideoV,
                  child: Column(children: [
                    Container(
                      width: double.infinity,
                      height: null,
                      color: Colors.yellow[50],
                      padding: const EdgeInsets.all(8),
                      child: const Text(
                        'or watch video ad to unlock injections temporarily\n او يمكنك مشاهدة اعلان فيديو لفتح الحقن بشكل مؤقت',
                        style: TextStyle(color: Colors.black,
                        ),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      height: null,
                      color: Colors.yellow[50],
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          GestureDetector(onTap: () {
                            Navigator.of(context).pop();
                            showRewarded();
                          },
                            child: Container(
                              margin: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                boxShadow: const [BoxShadow (color: Colors.black45, spreadRadius: 1, blurRadius: 1, offset: Offset(1, 1))],
                                color: Colors.blueAccent[700],
                                borderRadius: BorderRadius.circular(40),
                              ),
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(8),
                              child: const Text(
                                'Watch short ad',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<bool> checkInternetConnection() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        return true;
      }
    } on SocketException catch (_) {
      return false;
    }
    return false;
  }

  void _handlePurchaseUpdates(List<PurchaseDetails> purchases) {
    for (PurchaseDetails purchase in purchases) {
      switch (purchase.status) {
        case PurchaseStatus.purchased:
          InAppPurchase.instance.completePurchase(purchase);
          if (purchasePressed) {
            generalDiag("purchase success", "Full version activated successfully");
          }
          _savePurchaseStatus(true);
          setState(() {
            premiumFeatures();
          });
          break;
        case PurchaseStatus.error:
          InAppPurchase.instance.completePurchase(purchase);
          BotToast.showText(text: "error");
          break;
        case PurchaseStatus.canceled:
          InAppPurchase.instance.completePurchase(purchase);
          _savePurchaseStatus(false);
          BotToast.showText(text: "canceled");
          break;
        case PurchaseStatus.pending:
          BotToast.showText(text: "pending");
          break;
        case PurchaseStatus.restored:
          _savePurchaseStatus(true);
          if (purchasePressed) {
            generalDiag("purchase restored", "Full version restored successfully");
          }
          setState(() {
            premiumFeatures();
          });
          break;
      }
    }
  }

  //in-app purchase for IOS and MACOS
  Future<void> _loadProducts() async {
    try {
      ProductDetailsResponse response = await InAppPurchase.instance.queryProductDetails(_productIds);
      // save the product details to state
      setState(() {
        _products = response.productDetails;
        price = _products.first.price;
      });
    }
    catch (error) {
      price = "16.99\$";
    }
  }

  Future<void> _purchaseProduct() async {
    if (_products.isNotEmpty) {
      // initiate the purchase flow
      final PurchaseParam purchaseParam =
      PurchaseParam(productDetails: _products.first);
      InAppPurchase.instance.buyNonConsumable(purchaseParam: purchaseParam);
    }
    else {
      BotToast.showText(text: "try again later");
    }
  }

  Future<void> _savePurchaseStatus(bool isPurchased) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('isPurchased', isPurchased);
  }

  Future<void> _checkPurchaseStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? isPurchased = prefs.getBool('isPurchased');

    if (isPurchased != null && isPurchased) {
      setState(() {
        premiumFeatures();
      });
    }
  }

  Future<void> inAppPurchaseStatus () async {
    if (Platform.isIOS || Platform.isMacOS || Platform.isAndroid) {
      InAppPurchase .instance.purchaseStream
          .listen((List<PurchaseDetails> purchases) {
        _handlePurchaseUpdates(purchases);
      });
      if (Platform.isIOS || Platform.isMacOS) {
        _loadProducts();
        _checkPurchaseStatus();
      }
      else {
        InAppPurchase.instance.restorePurchases();
      }
    }
  }

  void premiumFeatures () {
    premium = true; premiumTo = "yes"; unlockDrawerV = false;
    favIconV = true;  switchV = true;
    premiumFreeCheck = "premium";
  }

  Future<void> detectPlatform () async {
    if (kIsWeb) {
      currentPlatform = "web";
      //tar
      setState(() {
        shdo = true;
      });
    }
    else {
      if (Platform.isAndroid) {
        currentPlatform = "android";
        unityGameId = "4638137"; unityInterstitialID = "Interstitial_Android"; unityRewardedID = "Rewarded_Android"; unityBannerID = "Banner_Android";
        //tar
        setState(() {
          shdo = true;
        });
      }
      else if (Platform.isMacOS) {
        currentPlatform = "macos";
        //tar
        SharedPreferences prefs = await SharedPreferences.getInstance();
        setState(() {
          shdo = prefs.getBool('shdo') ?? false;
        });
      }
      else if (Platform.isIOS) {
        currentPlatform = "ios";
        unityGameId = "4638136"; unityInterstitialID = "Interstitial_iOS"; unityRewardedID = "Rewarded_iOS"; unityBannerID = "Banner_iOS";
        //tar
        SharedPreferences prefs = await SharedPreferences.getInstance();
        setState(() {
          shdo = prefs.getBool('shdo') ?? false;
        });
      }
      else if (Platform.isWindows) {
        currentPlatform = "windows";
        //tar
        setState(() {
          shdo = true;
        });
      }
      else if (Platform.isLinux) {
        currentPlatform = "linux";
        //tar
        setState(() {
          shdo = true;
        });
      }
      else if (Platform.isFuchsia) {
        currentPlatform = "fuchsia";
        //tar
        setState(() {
          shdo = true;
        });
      }
    }
  }

  Future<void> initFirebase() async {
    // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform,);
    bool needsWeb = Platform.isLinux | Platform.isWindows;
    await Firebase.initializeApp(
      options: needsWeb
          ? DefaultFirebaseOptions.web
          : DefaultFirebaseOptions.currentPlatform,
    );
  }

  Future<void> firestore() async {
    if (Platform.isAndroid || Platform.isWindows) {
      final docSnapshot = await FirebaseFirestore.instance.collection('clctn_egydose').doc('Bum898uibXjDCLQLCpHo').get();
      final docSnapshot2 = await FirebaseFirestore.instance.collection('clctn_egydose').doc('Bun').get();
      final docSnapshotA = await FirebaseFirestore.instance.collection('clctn_egydose').doc('docAuto1').get();
      final docSnapshotB = await FirebaseFirestore.instance.collection('clctn_egydose').doc('docAuto2').get();
      final docSnapshotBlock = await FirebaseFirestore.instance.collection('clctn_egydose').doc('P0mFQC3LMFr9nOUQQG7c').get(); //blocked

      try {
        if (docSnapshot.exists) {
          List<dynamic> em1 = docSnapshot.get('emls').map((item) => item.toString().toLowerCase()).toList();
          List<dynamic> em2 = docSnapshot2.get('emls2').map((item) => item.toString().toLowerCase()).toList();
          List<dynamic> em3 = docSnapshotA.get('list').map((item) => item.toString().toLowerCase()).toList();
          List<dynamic> em4 = docSnapshotB.get('list').map((item) => item.toString().toLowerCase()).toList();
          List<dynamic> emb = docSnapshotBlock.get('blkd').map((item) => item.toString().toLowerCase()).toList();
          if (Platform.isAndroid) {
            if (user != null) {
              if (em1.contains('${user?.email?.toLowerCase()}') || em2.contains('${user?.email?.toLowerCase()}') || em3.contains('${user?.email?.toLowerCase()}') || em4.contains('${user?.email?.toLowerCase()}')) {
                setState(() {premiumFeatures();});
                SharedPreferences prefs = await SharedPreferences.getInstance();
                bool unlocked = prefs.getBool('congratulations') ?? true;
                if (unlocked) {
                  generalDiag("Application fully unlocked", "تم تفعيل النسخة الكاملة من التطبيق");
                  prefs.setBool('congratulations', false);
                }
              }
              else {
                if (claimPay) {
                  claimPayDiag();
                }
                else {
                  if (userTap && !premium) {
                    goToPayPage();
                  }
                }
              }
              if (emb.contains('${user?.email?.toLowerCase()}')) {exit(0);}
            }
          }
          else {
          String windowsEmailConfirmed = "";
          if (windowsUserTap) {
            windowsEmailConfirmed = windowsEmail;
          }
          else {
            try {
              final prefs = await SharedPreferences.getInstance();
              windowsEmailConfirmed = prefs.getString('winMl')!;
            }
            catch (e) {
              windowsEmailConfirmed = "";
            }
          }
          try {
          if (em1.contains(windowsEmailConfirmed.toLowerCase()) || em2.contains(windowsEmailConfirmed.toLowerCase()) || em3.contains(windowsEmailConfirmed.toLowerCase()) || em4.contains(windowsEmailConfirmed.toLowerCase())) {
            if (windowsUserTap) {
              if (codeDiag) {
                if (enteredCode == cdML) {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('winMl', windowsEmail);
                  if (!mounted) return;
                  Navigator.of(context).pop();
                  generalDiag("Application fully unlocked", "تم تفعيل النسخة الكاملة من التطبيق");
                  setState(() {
                    premiumFeatures();
                  });
                }
                else {
                  BotToast.showText(text: "wrong code");
                }
              }
              else {
                sendEmail(windowsEmail);
              }
            }
            else {
              setState(() {premiumFeatures();});
            }
          }
          else {
            if (windowsUserTap) {
              setState(() {
                windowsEditDiagNotRegistered();
              });
            }
          }
          }
          catch (error) {
            if (windowsUserTap) {
              setState(() {
                generalDiag("error", "check internet connection");
              });
            }
          }
          if (emb.contains(windowsEmailConfirmed.toLowerCase())) {exit(0);}
          }
        }
      }
      catch (error) {
        // BotToast.showText(text: "error2: $error");
      }
    }
  }

  void claimPayDiag () {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Not registered"),
          content: const Text("The email account you choose is not registered for full version"),
          actions: <Widget>[
            TextButton(
              child: const Text("Unlock full version now"),
              onPressed: () {
                Navigator.of(context).pop();
                goToPayPage();
              },
            ),
            TextButton(
              child: const Text("choose another account"),
              onPressed: () {
                Navigator.of(context).pop();
                BotToast.showText(text: "wait a moment");
                loadIntentionally = false;
                signOut().whenComplete(() => signInWithGoogle().whenComplete(() => firestore().whenComplete(() => loadFavListCloud())));
              },
            ),
            TextButton(
              child: const Text("Cancel"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void generalDiag (String signDiagTitle, String signDiagMessage) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(signDiagTitle),
          content: Text(signDiagMessage),
        );
      },
    );
  }

  //permission for ads
  Future<void> requestPermissionForAds() async {
    final TrackingStatus status = await AppTrackingTransparency.trackingAuthorizationStatus;
    setState(() => _authStatus = '$status');
    if (status == TrackingStatus.notDetermined && Platform.isIOS && !premium) {
      if (mounted) {
        await showCustomTrackingDialog(context);
      }
      await Future.delayed(const Duration(milliseconds: 200));
      final TrackingStatus status = await AppTrackingTransparency.requestTrackingAuthorization();
      setState(() {
        _authStatus = '$status';
        if (_authStatus == "TrackingStatus.notDetermined") {authorizationStatus = "not determined";} else if (_authStatus == "TrackingStatus.authorized") {authorizationStatus = "authorized";} else if (_authStatus == "TrackingStatus.denied") {authorizationStatus = "denied";} else if (_authStatus == "TrackingStatus.notSupported") {authorizationStatus = "not supported";} else if (_authStatus == "TrackingStatus.restricted") {authorizationStatus = "restricted";}
      });
    }

    uuid = await AppTrackingTransparency.getAdvertisingIdentifier();
  }

  Future<void> showCustomTrackingDialog(BuildContext context) async =>
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Dear User'),
          content: const Text(
            'We care about your privacy and data security. We keep this app free by showing ads. '
                'Can we continue to use your data to tailor ads for you?\n\nYou can change your choice anytime in the app settings. '
                'Our partners will collect data and use a unique identifier on your device to show you ads.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Continue'),
            ),
          ],
        ),
      );

  Future<void> getPackageInfo () async {
    try {
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      appName = packageInfo.appName;
      packageName = packageInfo.packageName;
      setState(() {
        currentVersion = packageInfo.version.substring(0, packageInfo.version.length-2);
      });
      currentBuildNumber = int.parse(packageInfo.buildNumber);
      //android
      final lv = await FirebaseFirestore.instance.collection('update').doc('latest').get();
      if (lv.exists) {
        latestVersionAndroid = lv.get("version");
        latestBuildNumberAndroid = lv.get("code");
        latestDateAndroid = lv.get("date");
      }
      //windows
      final lvw = await FirebaseFirestore.instance.collection('update').doc('latestWindows').get();
      if (lvw.exists) {
        latestVersionWindows = lvw.get("version");
        latestBuildNumberWindows = lvw.get("code");
        latestDateWindows = lvw.get("date");
      }
    } catch (error) {
      // print("An error occurred: $error");
    }
  }
  void showUpdateDiagAndroid () {
    if (!notificationDiagShown) {
      updateDiagShown = true;
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Update Available', textAlign: TextAlign.center,),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('\nCurrent version: $currentVersion', style: const TextStyle(color: Colors.red, fontSize: 18),),
                  Text('Latest version: $latestVersionAndroid\n$latestDateAndroid', style: const TextStyle(color: Colors.green, fontSize: 18),),
                  const Text('\n\nNote: if direct download didn\'t work, visit official website to download from it'),
                ],
              ),
            ),
            actions: <Widget>[
              Center(
                child: Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.grey[200],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      child: const Text('Direct download'),
                      onPressed: () {
                        Navigator.of(context).pop();
                        launchUrl(Uri.parse("https://github.com/Dr-AhmadTaha/egydose/raw/main/Egydose_$latestVersionAndroid.apk"), mode: LaunchMode.externalApplication);
                      },
                    ),
                    const SizedBox(height: 6,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.grey[200],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      child: const Text('Visit website'),
                      onPressed: () {
                        Navigator.of(context).pop();
                        launchUrl(Uri.parse("https://egydose.com/egydose/"),
                            mode: LaunchMode.externalApplication);
                      },
                    ),
                    const SizedBox(height: 6,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.grey[200],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      child: const Text('Later'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      );
    }
  }

  void showUpdateDiagWindows () {
    if (!notificationDiagShown) {
      updateDiagShown = true;
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Update Available', textAlign: TextAlign.center,),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('\nCurrent version: $currentVersion', style: const TextStyle(color: Colors.red, fontSize: 18),),
                  Text('Latest version: $latestVersionWindows\n$latestDateWindows', style: const TextStyle(color: Colors.green, fontSize: 18),),
                  const Text('\n\nNote: if direct download didn\'t work, visit official website to download from it'),
                ],
              ),
            ),
            actions: <Widget>[
              Center(
                child: Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.grey[200],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      child: const Text('Direct download'),
                      onPressed: () {
                        Navigator.of(context).pop();
                        launchUrl(Uri.parse("https://github.com/Dr-AhmadTaha/egydose-windows/raw/main/Egydose_$latestVersionWindows.rar"), mode: LaunchMode.externalApplication);
                      },
                    ),
                    const SizedBox(height: 8,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.grey[200],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      child: const Text('Visit website'),
                      onPressed: () {
                        Navigator.of(context).pop();
                        launchUrl(Uri.parse("https://egydose.com/egydose-windows"),
                            mode: LaunchMode.externalApplication);
                      },
                    ),
                    const SizedBox(height: 8,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.grey[200],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                      child: const Text('Later'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> checkUpdateOnStartupOnceADay () async {
    if (Platform.isAndroid) {
      final prefs = await SharedPreferences.getInstance();
      final lastShownDate = prefs.getString('lastShownDate');

      if (lastShownDate != null) {
        final now = DateTime.now();
        final lastDate = DateTime.parse(lastShownDate);
        if (now.day != lastDate.day || now.month != lastDate.month || now.year != lastDate.year) {
          try {
            if (latestBuildNumberAndroid > currentBuildNumber) {
              showUpdateDiagAndroid();
              prefs.setString('lastShownDate', now.toIso8601String());
            }
          } catch (e) {
            // BotToast.showText(text: 'Error: $e');
          }
        }
      } else {
        prefs.setString('lastShownDate', DateTime.now().subtract(const Duration(days: 1)).toIso8601String());
      }
    }
    if (Platform.isWindows) {
      final prefs = await SharedPreferences.getInstance();
      final lastShownDate = prefs.getString('lastShownDate');

      if (lastShownDate != null) {
        final now = DateTime.now();
        final lastDate = DateTime.parse(lastShownDate);
        if (now.day != lastDate.day || now.month != lastDate.month || now.year != lastDate.year) {
          try {
            if (latestBuildNumberWindows > currentBuildNumber) {
              showUpdateDiagWindows();
              prefs.setString('lastShownDate', now.toIso8601String());
            }
          } catch (e) {
            // BotToast.showText(text: 'Error: $e');
          }
        }
      } else {
        prefs.setString('lastShownDate', DateTime.now().subtract(const Duration(days: 1)).toIso8601String());
      }
    }
  }

  void goToPayPage () {
    Navigator.push(context, MaterialPageRoute(builder: (context) =>  PaymentPage(email: '${user?.email}')),);
  }

  Future<void> signInWithGoogle() async {
    final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
    try {
      final googleUser = await GoogleSignIn(scopes: ['profile', 'email']).signIn();
      if (googleUser == null) {
        BotToast.showText(text: "canceled");
        return;
      }

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      // Sign in to Firebase Authentication using the new credential
      final UserCredential userCredential = await firebaseAuth.signInWithCredential(credential);
      // Get the current user
      user = userCredential.user;
      // Update the state to reflect the new user
      setState(() {});
    }
    catch (error) {
      showSignInFailDiag();
    }
  }

  void showSignInFailDiag () {
    if (currentPlatform == "macos" || currentPlatform == "windows" || currentPlatform == "linux") {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return const AlertDialog(
            title: Text("error when signing in"),
            content: Text("This is may be because:\n\n1-no internet connection.\n2-This is PC. Signing in is not available in macOS or Windows"),
          );
        },
      );
    }
    else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text("error when signing in"),
            content: const Text("This is may be because:\n\n1-no internet connection.\n2-Your phone doesn't support google services as Huawei devices.\n\n\nIf your android device doesn't support google services, download 'Gspace' app from internet, install it, then open TTG from it."),
            actions: [
              TextButton(onPressed: () async {
                Navigator.of(context).pop();
                await launchUrl(Uri.parse("https://gspaceteam.com/"), mode: LaunchMode.externalApplication);
              }, child: const Text("Download Gspace"),
              )],
          );
        },
      );
    }
  }

  Future<void> signOut() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
    await firebaseAuth.signOut();
    await googleSignIn.signOut();
    user = firebaseAuth.currentUser;
    setState(() {});
  }

  Future<void> checkCurrentUser () async {
    final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
    user = firebaseAuth.currentUser;
  }

  Future<void> getNotificationData () async {
    try {
      final msg = await FirebaseFirestore.instance.collection('messages').doc('notification').get();
      if (msg.exists) {
        msgId = msg.get("id");
        msgTitle = msg.get("title");
        msgBody = msg.get("body");
        actionOn = msg.get("actionOn");
        actionName = msg.get("actionName");
        actionData = msg.get("actionData");
        //newly added
        targetPlatforms = msg.get("targetPlatforms");
        maxVersionNum = msg.get("maxVersionNum");
        freeORpaid = msg.get("freeORpaid");
        Timestamp tempStamp = msg.get("endDate");
        endDate = tempStamp.toDate();
      }
      //tar
      if (Platform.isIOS || Platform.isMacOS) {
        final tah = await FirebaseFirestore.instance.collection('tofaha').doc('goraa').get();
        if (tah.exists) {
          raz = tah.get("ramz");
          makbol = tah.get("makbol");
          if (makbol) {
            setState(() async {
              shdo = true;
              SharedPreferences prefs = await SharedPreferences.getInstance();
              await prefs.setBool('shdo', true);
            });
          }
        }
      }
    }
    catch (error) {
      // print("get notification error $error");
    }
  }

  Future<void> checkAvailableNotifications () async {
    Future.delayed(const Duration(seconds: 5), () async {
      final prefs = await SharedPreferences.getInstance();
      final lastMessageId = prefs.getInt("lastMessageId");
      try {
        if (lastMessageId != null) {
          if (msgId > lastMessageId && targetPlatforms.contains(currentPlatform) && maxVersionNum >= currentBuildNumber && endDate.isAfter(DateTime.now()) && freeORpaid.contains(premiumFreeCheck)) {
            showNotificationDiag();
            prefs.setInt('lastMessageId', msgId);
          }
        }
        else {
          prefs.setInt('lastMessageId', 0);
        }
      } catch (error) {
        // BotToast.showText(text: "error4: $error");
      }
    });
  }

  void showNotificationDiag () {
    if (!updateDiagShown) {
      notificationDiagShown = true;
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(msgTitle, textAlign: TextAlign.center,),
            content: Text(msgBody, textAlign: TextAlign.center,),
            actions: <Widget>[
              Visibility(visible: actionOn,
                child: Center(
                  child:  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.grey[200],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                      ),
                    ),
                    child: Text(actionName),
                    onPressed: () {
                      Navigator.of(context).pop();
                      launchUrl(Uri.parse(actionData), mode: LaunchMode.externalApplication);
                    },
                  ),
                ),
              ),
            ],
          );
        },
      );
    }
  }

  void checkIosMacosUpdate() async {
    try {
      if (Platform.isIOS) {
        await AppVersionUpdate.checkForUpdates(
          appleId: '6452034344',
        ).then((result) async {
          String? ver = result.storeVersion;
          if (result.canUpdate!) {
            AppVersionUpdate.showAlertUpdate(
              appVersionResult: result,
              context: context,
              backgroundColor: Colors.grey[200],
              title: 'New version available ($ver)',
              titleTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600, fontSize: 24.0),
              content: 'A new version of Egydose is available, Would you like to update your application?',
              contentTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w400,),
              updateButtonText: 'Update Now',
              cancelButtonText: 'Later',);
          }
          else {
            if (checkUpdateTap) {generalDiag("No update available", "You are using the latest version ($ver)");}
          }
        });
      }
    }
    catch (error) {
      // print("check update $error");
    }

  }

  void rateAppDiag() {
    rateMyApp.showRateDialog(
      context,
      title: 'Rate the app',
      message: 'If you like this app, please take a little bit of your time to review it !\nIt really helps us and it shouldn\'t take you more than one minute.',
      rateButton: 'RATE',
      noButton: 'NO THANKS',
      laterButton: 'MAYBE LATER',
      listener: (button) {
        switch(button) {
          case RateMyAppDialogButton.rate:
          // print('Clicked on "Rate".');
            break;
          case RateMyAppDialogButton.later:
          // print('Clicked on "Later".');
            break;
          case RateMyAppDialogButton.no:
          // print('Clicked on "No".');
            break;
        }

        return true;
      },
      ignoreNativeDialog: true,
      dialogStyle: const DialogStyle(),
      onDismissed: () => rateMyApp.callEvent(RateMyAppEventType.laterButtonPressed),
      // contentBuilder: (context, defaultContent) => content, // This one allows you to change the default dialog content.
      // actionsBuilder: (context) => [], // This one allows you to use your own buttons.
    );
  }

  void showFavHelpDiag () {
    favListNum = _favFilteredItems.length;
    String onOff = "off";
    if (user != null) {
      onOff = "on";
    }
    if (Platform.isIOS || Platform.isAndroid) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Text("Sync is $onOff\n\nlast sync:\n$lastSync\n\nsaved drugs number: $favListNum\n----------------------\nIf sync is on, list items will be saved on cloud continuously if there is internet connection.\n\nPress and hold any drug to remove from the favourite list.",
              ),
          );
        },
      );
    }
    else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Text("Sync is working only on android and iOS\n\nsaved drugs number: $favListNum\n\nPress and hold any drug to remove from the favourite list.",
              textAlign: TextAlign.center,),
          );
        },
      );
    }
  }

  void deleteFavDiag () {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Warning"),
          content: const Text("Are you sure you want to delete all favourite list items?"),
          actions: <Widget>[
            TextButton(
              child: const Text("delete"),
              onPressed: () {
                setState(() {
                  _favFilteredItems.clear();
                  saveFavListLocally().whenComplete(() => initFirebase().whenComplete(() => saveFavListCloud()));
                  if (_favFilteredItems.isEmpty) {
                    favAddTextV = true;
                  }
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> crashlytics () async {
    if (!Platform.isWindows) {
      // Pass all uncaught "fatal" errors from the framework to Crashlytics
      FlutterError.onError = (errorDetails) {
        FirebaseCrashlytics.instance.recordFlutterFatalError(errorDetails);
      };
      // Pass all uncaught asynchronous errors that aren't handled by the Flutter framework to Crashlytics
      PlatformDispatcher.instance.onError = (error, stack) {
        FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
        return true;
      };
    }
  }

  Future<void> sendEmail (String recipientEmail) async {
    cdML = (Random().nextInt(900000) + 100000).toString();
    final ps = await FirebaseFirestore.instance.collection('windows').doc('app pass').get();
    final smtpServer = gmail('egydose@gmail.com', ps.get('appPass'));
    final message = Message()
      ..from = const Address('egydose@gmail.com', 'Egydose app')
      ..recipients.add(recipientEmail)
      ..subject = 'windows code for Egydose'
      ..text = 'your code is: $cdML\n\nenter this code in the app to unlock full version of Egydose in windows';
    BotToast.showText(text: "please wait", duration: const Duration(seconds: 5));
    try {
      send(message, smtpServer);
      // print('Message sent: ');
      windowsEditDiagSendCode();
    }  catch (e) {
      generalDiag("error", "network error, try again later");
      // print('Message not sent.$e');
      // for (var p in e.problems) {
      //   print('Problem: ${p.code}: ${p.msg}');
      // }
    }
  }

  void windowsEditDiagStart () {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          scrollable: true,
          title: const Text("unlock full version"),
          content: TextFormField(
            controller: windowsEmailController,
            decoration: InputDecoration(
              hintText: 'enter your email',
              hintStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(color: Colors.green),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(color: Colors.black),
              ),
            ),
            textInputAction: TextInputAction.next,
            style: const TextStyle(fontSize: 16,
            ),
            onChanged: (value) {

            },
          ),
          actions: <Widget>[
            TextButton(
              child: const Text("confirm"),
              onPressed: () async {
              Navigator.of(context).pop();
              windowsEmail = windowsEmailController.text;
              windowsUserTap = true;
              codeDiag = false;
              firestore();
              },
            ),
            TextButton(
              child: const Text("Cancel"),
              onPressed: () {
                Navigator.of(context).pop();
                windowsUserTap = false;
                codeDiag = false;
              },
            ),
          ],
        );
      },
    );
  }
  void windowsEditDiagNotRegistered () {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          scrollable: true,
          title: const Text("unlock full version"),
          content: const Text("This email is not registered. Contact us to unlock full version", style: TextStyle(color: Colors.red), textAlign: TextAlign.center,),
          actions: <Widget>[
            TextButton(
              child: const Text("contact now"),
              onPressed: () async {
                Navigator.of(context).pop();
                windowsUserTap = true;
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>  HelpPage(help: "contact", premium: premiumTo, unityBannerID: unityBannerID)),
                );
              },
            ),
            TextButton(
              child: const Text("Cancel"),
              onPressed: () {
                Navigator.of(context).pop();
                windowsUserTap = false;
              },
            ),
          ],
        );
      },
    );
  }
  void windowsEditDiagSendCode () {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          scrollable: true,
          title: const Text("unlock full version"),
          content: Column(
            children: [
              Text(windowsEmail),
              const SizedBox(height: 20,),
              TextFormField(
                decoration: InputDecoration(
                  hintText: 'enter code',
                  hintStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5),
                    borderSide: const BorderSide(color: Colors.green),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5),
                    borderSide: const BorderSide(color: Colors.black),
                  ),
                ),
                textInputAction: TextInputAction.done,
                style: const TextStyle(fontSize: 16,
                ),
                onChanged: (value) {
                  enteredCode = value;
                },
              ),
              const SizedBox(height: 10,),
              Text("a code has been sent to $windowsEmail\nwrite it in the field above", textAlign: TextAlign.center,),
              const Text("Try again later if not sent within 2 minutes", style: TextStyle(color: Colors.grey, fontSize: 12), textAlign: TextAlign.center,),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: const Text("confirm"),
              onPressed: () async {
                windowsUserTap = true;
                codeDiag = true;
                firestore();
              },
            ),
            TextButton(
              child: const Text("Cancel"),
              onPressed: () {
                Navigator.of(context).pop();
                enteredCode = "";
                windowsUserTap = false;
                codeDiag = false;
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> getSavedColorBW () async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("saveColorBW") != null) {
      drugColors = prefs.getString("saveColorBW")!;
    }
  }

  // Future<void> themeNotifyDiag() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   final hasSeenDialog = prefs.getBool('hasSeenThemeDialog') ?? false;
  //   if (!hasSeenDialog) {
  //     generalDiag("Dark theme", "You can switch themes from settings");
  //     prefs.setBool('hasSeenThemeDialog', true);
  //   }
  // }

  void filterDiag() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: blackWhiteBackground(context),
          title: Text("filter drugs", textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, color: blackWhiteText(context)),
          ),
          contentPadding: const EdgeInsets.all(4),
          content: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/all.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('Show all drugs'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/cap.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('capsules / tablets'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/drink.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('syrup / suspension / drops'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/syringe.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('injections'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/suppository.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('suppositories'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/sachets.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('sachets'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/inhaler.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('inhalers'),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset('assets/images/others.jpg', width: 38, height: 38,),
                    const SizedBox(width: 8),
                    const Text('others'),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void showAllDrugsShortcut () {
    setState(() {
      allDrugsFrame = Colors.red;
      tabFrame = Colors.transparent;
      drinkFrame = Colors.transparent;
      syringeFrame = Colors.transparent;
      suppositoryFrame = Colors.transparent;
      sachetsFrame = Colors.transparent;
      inhalersFrame = Colors.transparent;
      othersFrame = Colors.transparent;
      // selectedFilterText = "Show all drugs";
    });
    if (searchHint == 'search trade or generic name') {
      filterItemsByName("");
      filterItemsByName(searchEditText.text);
    }
    else {
      filterItemsByIndication("");
      filterItemsByIndication(searchEditText.text);
    }
    filterItemsByType("", "", "", "", "", "", "", "");
  }

  String removeDecimalIfZero(double value) {
    String stringValue = value.toString();
    if (stringValue.endsWith('.0')) {
      return stringValue.substring(0, stringValue.length - 2);
    } else {
      return stringValue;
    }
  }

  void showAgeDiag () {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          // title: const Center(child: Text('Select age')),
          content: Container(padding: EdgeInsets.zero, margin: EdgeInsets.zero,
            width: double.minPositive,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: ageItems.length,
              itemBuilder: (BuildContext context, int index) {
                bool isBold = shouldBeBold(ageItems[index]);
                return ListTile(dense: true,
                  title: Center(child: Text(ageItems[index], style: TextStyle(fontSize: isBold ? 19 : 18, fontWeight: isBold ? FontWeight.bold : FontWeight.normal,))),
                  onTap: () {
                    Navigator.of(context).pop();
                    setState(() {
                      selectedAgeTextMenu = ageItems[index];
                      setSelectedAgeData ();
                    });
                  },
                );
              },
            ),
          ),
        );
      },
    );
  }

  bool shouldBeBold(String item) {
    // Add your logic here. For example:
    return item.contains('➤');
  }

}

extension HexColor on Color {
  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}