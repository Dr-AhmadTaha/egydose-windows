import 'dart:io';
import 'package:flutter/material.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';
import 'package:url_launcher/url_launcher.dart';

class HelpPage extends StatefulWidget {
  final String help;

  const HelpPage({super.key, required this.help, required this.premium, required this.unityBannerID});
  final String premium;
  final String unityBannerID;

  @override
  State<HelpPage> createState() => HelpPageState();
}

class HelpPageState extends State<HelpPage> {

  String title = "Help";
  bool howV = true;
  bool contactV = true;
  double bannerHeight = 0;
  final GlobalKey bannerKey = GlobalKey();
  int myPic = 0;
  Color? blackWhiteText(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.white : Colors.black;}
  Color? blackWhiteBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[900] : Colors.grey[200];}
  Color? buttonBackgroundColor(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[700] : Colors.grey[400];}


  @override
  void initState() {
    super.initState();
    if (widget.help == "help") {title = "Help"; contactV = false;}
    else {title = "Contact"; howV = false;}
    if (widget.premium != 'yes') {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: blackWhiteBackground(context),
        appBar: AppBar(
          title: Text(title),

        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(left: 0, right: 0,top: 0, bottom: bannerHeight),
          child: Column(
            children: [
              Visibility(
                visible: howV,
                child: Container(alignment: Alignment.center,
                  child: IntrinsicWidth(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(height: 8),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("General use", "Choose age from menu (mandatory), appropriate weight will be calculated automatically.\n\nYou can write the weight yourself if weight is more or less than the calculated one.\n\nThen choose the drug you want.");
                            },
                            child: Text('How to use the app', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Searching drugs", "Search any drug by generic name (preferred) or by trade name, and the result will be shown.\n\n The main list have only one trade name that is shown as search result.\n\n Other trade names are mentioned in the dose page.\n\n In some drugs as antihypertensive drugs, only the lowest concentration is available and other higher concentrations are mentioned in the dose page.\n\nYou can also search drugs by indication (for premium users only).\n\n If you are not sure of the drug name, you can type space when searching (leave empty space instead of the unknown letter).");
                            },
                            child: Text('How to search drugs', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Pregnancy Categories", "-Category A: Used safely\n\n-Category B: Used safely when needed\n\n-Category C: Used with caution if clearly needed and no safer drug available\n\n-Category D: Used only in life-threatening emergencies when no safe drug available\n\n-Category X: Contraindicated");
                            },
                            child: Text('Pregnancy categories', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Oral drugs", "20 drops = 1 dropper = 1 ml\n\nBottle quantity is shown under composition. It useful when prescribing antibiotic to consider treatment course");
                            },
                            child: Text('How to use oral drugs', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Parenteral drugs", "The result doses are in ml, after reconstitution with the fluid amount mentioned, then dilute further as mentioned in administration.\n\n 1 ml = 100 unit of insulin syringe (100 unit syringe), and when the result dose is less than 0.1 ml, it is better to use the insulin syringe to take the exact amount.\n\n When diluting for IV administration, for example, when I say every 1 ml result dose is diluted in 100 ml solution, then if the result dose is 4 ml then you will dilute the result dose in 400 ml solution, and if the result dose is 0.2 ml you will dilute the result dose in 20 ml solution...etc.\n\n If the dose is more than the amount after reconstitution, you should use another vial or use higher concentration.");
                            },
                            child: Text('How to use injections', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Preterm infants", "Enter weight and age in days and choose gestational age.\n\n If no age is selected, it is considered zero and the dose is calculated as 0 day.");
                            },
                            child: Text('Dose for preterm infants', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Hepatic and renal patients", "Use drugs with caution even when no adjustment needed.\n\n Calculators are available in the app to calculate CrCl or Child Pugh score");
                            },
                            child: Text('Dose for hepatic and renal patients', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Geriatric patients", "Investigate for renal or hepatic impairment at first, if present, use hepatic or renal patient mode.\n\n Always use drugs with caution even it is the same as adult dose with monitoring renal and hepatic functions.");
                            },
                            child: Text('Geriatric patients', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Favourite list", "This feature is available only to premium users\n\nPress and hold any drug to add it to favourite list.\n\nClick on the star icon on the top right corner to view favourite list.\n\nClick and hold any drug in the favourite list to remove it.\n\nPress back or press the star icon again to go back to the main drug list.\n\nyou can save favourite list on cloud by signing in with google");
                            },
                            child: Text('Favourite list', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Updating the app", "When there is update available, you will get a message when you open the app informing you about the update.\n\nClick this message and the new update will be downloaded. Got to the file location on your phone and install it. The message will continue to appear once daily if there is update available.\n\nIf the message gone before you click it, either wait for it the next day when you open the app, or go to www.egydose.com and download the latest update and install it");
                            },
                            child: Text('How to update the app', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Drugs that need weight", "Most of adult doses are fixed whatever the weight is, but some drugs need the weight to be calculated accurately in adults.\nThese drugs are:\n\nInsulin\nIron injection\nAcyclovir injection\nAmikacin\nGentamicin\nMetronidazole injection\nDigoxin Injection\nEnoxaparin\nTeicoplanin\nDopamine\nDobutamine\nPropofol\nAmphotericin B\nMidazolam injection\nNa Nitroprusside\nIvermectin oral\nKetamine\nIsotretinoin\nCyclosporine\nAzathioprine\nAcetylcysteine injection\nAcetazolamide\nUrsodiol\nMethotrexate\nErythropoietin\nL-Carnitine injection\nDeflazacort\nCyclophosphamide\nRituximab\nMannitol\nFilgrastim\nFactor VIII\nNalbuphine\nCalcitonin\nIfosfamide\nMesna\nTirofiban\nRibavirin\nBevacizumab\nChlorambucil\nTemozolomide\nDexmedetomidine\nSodium Bicarbonate\nTacrolimus");
                            },
                            child: Text('Drugs that need weight in adults', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help( "Advertisements", "-Only in mobile devices\n\nTo view injections doses, you need to watch 1 video ad to get 5 points to unlock injections 5 times\n\nYou can accumulate points (up to 30 points) when online to view injections multiple times even if offline.\nTo do this, open side menu and click on the video icon to watch more than 1 video\n\nThere may be some interstitial ads that appear, but they are muted and you can skip them after 5 seconds");
                            },
                            child: Text('Advertisements', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        if (Platform.isAndroid)
                          Container(padding: const EdgeInsets.all(4),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.all(10),
                                textStyle: const TextStyle(fontSize: 18),
                                backgroundColor: buttonBackgroundColor(context),
                              ),
                              onPressed: () {
                                help("Full version", "Unlock full version of the app to:\n-have permanent access to injections\n-remove all ads\n-use favorite list\n-search drugs by indication\n\n Activating full version is only once in life. If you change the phone, use the same google account on the new phone, then:\n\nif you unlocked full version when the app on the play store, then the full version will be activated automatically\n\nif you unlocked full version by contacting us, sign in with Gmail and select the Gmail you sent to us");
                              },
                              child: Text('Full version', style: TextStyle(
                                fontWeight: FontWeight.bold, color: blackWhiteText(context),
                              ),),
                            ),
                          ),
                        if (Platform.isMacOS || Platform.isIOS)
                          Container(padding: const EdgeInsets.all(4),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.all(10),
                                textStyle: const TextStyle(fontSize: 18),
                                backgroundColor: buttonBackgroundColor(context),
                              ),
                              onPressed: () {
                                help("Full version", "Unlock full version of the app to:\n-have permanent access to injections\n-remove all ads\n-use favorite list\n-search drugs by indication\n\n Activating full version is only once in life. If you change the phone, use the same email ID on the new phone and click restore purchase to restore your full version");
                              },
                              child: Text('Full version', style: TextStyle(
                                fontWeight: FontWeight.bold, color: blackWhiteText(context),
                              ),),
                            ),
                          ),
                        if (Platform.isWindows)
                          Container(padding: const EdgeInsets.all(4),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.all(10),
                                textStyle: const TextStyle(fontSize: 18),
                                backgroundColor: buttonBackgroundColor(context),
                              ),
                              onPressed: () {
                                help("Full version", "Unlock full version of the app to:\n-have permanent access to injections\n-remove all ads\n-use favorite list\n-search drugs by indication\n\n Activating full version is only once in life.\n\nFull version in Windows is associated with Android (same subscription).");
                              },
                              child: Text('Full version', style: TextStyle(
                                fontWeight: FontWeight.bold, color: blackWhiteText(context),
                              ),),
                            ),
                          ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Abbreviations", "PRN = when needed\n\n SWI = Sterile Water for Injection\n\n LRTI = Lower Respiratory Tract Infection\n\n URTI = Upper Respiratory Tract Infection\n\n UTI = Urinary Tract Infection\n\n TID = three times / day\n\n PO = orally\n\n TIA = Transient Ischaemic Attack\n\n ASCVD = AtheroSclerotic CardioVascular Disease\n\n ACLS = Advanced Cardiac Life Support\n\n NS = Normal Saline\n\n D5W = 5% Dextrose in Water\n\nD50W = 50% Dextrose\n\n D10W = 10% Dextrose in Water\n\n LR = Lactate Ringer\n\n CRRT = Continuous Renal Replacement Therapy\n\n MAC = Monitored Anesthesia Care\n\n AEDs = AntiEpileptic Drugs\n\n PTSD = Posttraumatic Stress Disorder\n\n CAD = Coronary Artery Disease\n\n PAD = Peripheral Artery Disease\n\n PE = Pulmonary Embolism\n\n DVT = Deep Vein Thrombosis\n\n IT = Intrathecal\n\n odf = orodispersible film\n\n VTE = Venous Thromboembolic Events\n\n CABG = Coronary Artery Bypass Grafting");
                            },
                            child: Text('Abbreviations', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              AlertDialog detailsDiag = AlertDialog(
                                content: const SingleChildScrollView(
                                  child: Column(mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Center(
                                        child: Text('Colors',
                                          style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                      Center(
                                        child: Text("you can disable these default colors from settings",
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontStyle: FontStyle.italic,
                                            color: Colors.grey,
                                          ),),
                                      ),
                                      SizedBox(height: 24),
                                      Text(
                                        'Anti-inflammatory, Antipyretics and analgesics',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFFF44336),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Antimicrobials (antibiotics, antivirals, antiparasitic.....)',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Colors.black,
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'CardioVascular drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFFF4780B),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Respiratory System and Antihistamines drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF2E7D32),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'GIT drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF3F51B5),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Neurological drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF04D5C1),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Hormone Related drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFFFA3BBA),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Corticosteroids',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF9C27B0),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Urinary Tract and Male genital drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF607D8B),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Vitamins and Minerals',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF03A9F4),
                                        ),
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'Other drugs',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontStyle: FontStyle.italic,
                                          color: Color(0xFF795548),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                backgroundColor: Colors.white,
                                actions: [
                                  TextButton(
                                    child: const Text(
                                      'Close',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue,
                                      ),
                                    ),
                                    onPressed: () => Navigator.pop(context),
                                  ),
                                ],
                              );
                              showDialog(context: context, builder: (BuildContext context) => detailsDiag);
                            },
                            child: Text('Drug Colors', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        Container(padding: const EdgeInsets.all(4),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(10),
                              textStyle: const TextStyle(fontSize: 18),
                              backgroundColor: buttonBackgroundColor(context),
                            ),
                            onPressed: () {
                              help("Version history", "V11.3 (6/7/2024):\n-improvements and fixes\n\nV11.1 (2/6/2034):\n-sort favourite list manually\n-fixes and improvements\n\nV11.0 (4/5/2024):\n-Search drugs by category\n-Sort favourite list by type\n-adjustments and fixes\n\nV10.8 (4/3/2024):\n-added more drugs\n-added a reminder if the selected drug needs accurate weight\n\nV10.6 (16/2/2024):\n-added infusion rate calculator\n-fixed new search method\n\nV10.5 (10/2/2024):\n-dark theme enabled\n-filter drugs by form\n-improve search method\n\nV10.4 (25/12/2023):\n-The app available on Windows\n-remove support of android 5.1\n\nV10.3 (1/12/2023):\n-bug fixes\n-support android 14\n-remove support of android 4.4\n\nV10.1 (7/11/2023):\n-added more drugs\n\nV10.0 (28/10/2023):\n-app is available for iPhones\n-Favorite list enhancement\n\nV9.9 (28/4/2023):\n-Help section modified\n-Creatinine Clearance automatic paste\n\nV9.7 (22/3/2023):\n-updated doses\n\nV9.6 (22/2/2023):\n-added more drugs\n\nV9.5 (17/1/2023):\n-more improvements and fixes\n\nV9.4 (16/12/2022):\n-updated doses\n\nV9.1 (7/11/2022):\n-more improvements\n-added more drugs\n-You can now watch more than 1 video ad at once to get more points for injections doses\n\nV9.0 (8/10/2022):\n-added more drugs\n-fixed ads not working\n-Changed age and weight system\n\nV8.8 (27/8/2022):\n-added drugs\n-updated doses\n\nV8.6 (18/7/2022):\n-added more drugs\n\nV8.3 (22/5/2022):\n-added G6PD deficiency compatibility\n\nV8.2 (4/5/2022):\n-added options for ease of use\n-added favourite list for premium users\n-click on a drug in suggested alternative to direct you to this drug in main list\n-added more drugs\n-updated doses\n\nV8.1 (6/4/2022):\n-improvements and fixes\n\nV8.0 (24/3/2022):\n-ads for free users\n-added more drugs\n\nV7.7 (12/3/2022):\n-added more drugs\n-updated doses according to latest guidelines\n\nV7.6 (24/2/2022):\n-added more drugs\n-more improvements\n\nV7.5 (6/2/2022):\n-more improvements\n\nV7.3 (11/1/2022):\n-added more drugs\n\nV7.1 (30/12/2021):\n-added more drugs\n\nV7.0 (16/12/2021):\n-added more drugs\n-fixed performance issues\n\nV6.7 (4/12/2021):\n-updated drug information\n-added more drugs\n-more improvements\n\nV6.6 (30/10/2021):\n-more drugs added\n-more improvements\n-price updated\n\nV6.5 (9/10/2021):\n-Some fixes and improvements\n\nV6.0 (27/9/2021):\n-added alternative suggestions\n-added more drugs\n-more improvements\n\nV5.6 (14/7/2021):\n-added more drugs\n-Simplified Help page\n\nV5.4 (22/6/2021):\n-added link to facebook page\n-more adjustments\n\nV5.3 (18/6/2021):\n-disabled dark theme of the app in xiaomi devices\n-fixed arabic numbers in arabic devices\n-modified some references\n-added more drugs\n\nV5.2 (31/5/2021):\n-added male genital drugs\n-added other drugs requested by users\n-added pregnancy and lactation compatibility\n-added geriatric patient mode\n-added reference to every drug\n\nV4.9 (13/5/2021):\n-added CVS drugs\n-added Hypertension drugs\n-added oral diabetic drugs\n-added other drugs requested by users\n-added link to Medscape page for drug interactions\n-mentioned drugs that need to be discontinued gradually\n-watching video ads now will be valid even after closing the app\n\nV4.8 (18/4/2021):\n-added CNS drugs\n-added Thyroid drugs\n-added miscellaneous drugs\n-Reduced startup time\n-For premium users: Drug of Choice is replaced by Search by Indication\n\nV4.6 (12/4/2021):\n-added renal patient mode\n-added hepatic patient mode\n-added calculators\n-added more drugs\n-added more details to indications\n\nV4.5 (10/2/2021):\n-added more drugs\n-added more details to indications\n-added off-label indications*\n\nV4.4 (17/1/2021):\n-added more drugs\n\nV4.2 (13/12/2020):\n-added more drugs for neonates\n-added miscellaneous drugs\n-some visual enhancements\n\nV4.1 (5/12/2020):\n-added CVS drugs for neonates\n-added details to IV administrations\n-added details to oral administration\n\nV4.0 (25/11/2020):\n-now you can calculate doses for premature infants\n-more drugs added\n-improvements and bugfixs\n\nV3.6 (8/11/2020):\n-added analgesics for adults\n\nV3.5 (29/10/2020):\n-added more drugs\n-some adjustments\n\nV3.3 (21/10/2020):\n-added GIT drugs for adults\n\nV3.2 (15/10/2020):\n-added adult vitamins/Iron (oral/injections)\n-some fixes\n\nV3.1 (11/10/2020):\n-added antibiotic tablets and capsules\n-added indications in details\n-improvements and bug fixes\n\nV2.6 (26/9/2020):\n-some adjustments\n\nV2.5 (17/9/2020):\n-bug fixes and improvements\n\nV2.4 (1/9/2020):\n-added more drugs\n\nV2.3 (28/7/2020):\n-minor fixes and improvements\n\nV2.2 (5/6/2020):\n-added more drugs\n\nV2.1 (22/5/2020):\n-added more oral drugs\n-added parenteral drugs\n-added toxic doses\n-added choice of drugs\n-added bottle quantities to all oral drugs\n-added link to my new app: Topical Treatment Guide\n-more improvements\n\nV1.8 (1/5/2020):\n-added more drugs\n\nV1.7 (15/4/2020):\n-added more drugs\n-added dosage details to some drugs\n-you can search by trade name or generic name\n-more improvements\n-fixed bugs\n\nV1.6 (1/4/2020):\n-now you can search drugs to reach the drug you want more quickly\n-more improvements\n\nV1.4 (15/3/2020):\n-added more drugs\n\nV1.3 (1/3/2020):\n-added more drugs\n-more improvements\n\nV1.2 (15/2/2020):\n-added more drugs\n-bugs fixed\n\nV1.1 (25/1/2020):\n-added more drugs\n\nV1.0 (1/1/2020):\n-The start");
                            },
                            child: Text('Version history', style: TextStyle(
                              fontWeight: FontWeight.bold, color: blackWhiteText(context),
                            ),),
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
              Visibility( visible: contactV,
                child: Container(
                  color: blackWhiteBackground(context),
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  width: double.infinity,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector( onTap: () {
                        myPic = myPic + 1;
                        if (myPic > 9) {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return Dialog(
                                child: Image.asset("assets/images/medo.jpg"),
                              );
                            },
                          );
                        }
                      },
                        child: Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 20),
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.indigoAccent, width: 6),
                          ),
                          child: Text(
                            "\nEgydose\n_____________________\n\nDr. Ahmad Taha\n",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.italic,
                              color: Colors.indigoAccent[700],
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(top: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: double.infinity,
                              margin: const EdgeInsets.only(top: 20, bottom: 10),
                              padding: const EdgeInsets.all(8),
                              color: Colors.indigoAccent[700],
                              child: const Text(
                                "Contact",
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(height: 100,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Expanded(flex: 1,
                                    child: Padding( padding: const EdgeInsets.all(4),
                                      child: GestureDetector(
                                        onTap: () async {
                                          await launchUrl(Uri.parse("http://m.me/egydosecalc"), mode: LaunchMode.externalApplication);
                                        },
                                        child: Image.asset(
                                          "assets/images/messenger.png",
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded( flex: 1,
                                    child: Padding( padding: const EdgeInsets.all(4),
                                      child: GestureDetector(
                                        onTap: () async {
                                          await launchUrl(Uri.parse("mailto:medo122008@gmail.com"), mode: LaunchMode.externalApplication);
                                        },
                                        child: Image.asset(
                                          "assets/images/gmail.png",
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: double.infinity,
                              margin: const EdgeInsets.only(top: 30, bottom: 10),
                              padding: const EdgeInsets.all(8),
                              color: Colors.indigoAccent[700],
                              child: const Text(
                                "Follow",
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(height: 100,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Expanded( flex: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: GestureDetector( onTap: () async {
                                        try {
                                          if (await canLaunchUrl(Uri.parse("fb://page/104517495215742")) && (Platform.isIOS || Platform.isAndroid)) {
                                            await launchUrl(Uri.parse("fb://page/104517495215742"), mode: LaunchMode.externalApplication);
                                          } else {
                                            throw 'Could not launch';
                                          }
                                        } catch (e) {
                                          await launchUrl(Uri.parse("https://www.facebook.com/egydosecalc/"), mode: LaunchMode.externalApplication);
                                        }
                                      },
                                        child: Image.asset(
                                          "assets/images/facebook_logo.png", scale: 3,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded( flex: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: GestureDetector( onTap: () async {
                                        await launchUrl(Uri.parse("https://www.youtube.com/channel/UCXVVJCEnxwAjqq9FUiDhJ-A"), mode: LaunchMode.externalApplication);
                                      },
                                        child: Image.asset(
                                          "assets/images/youtube_logo.png", scale: 3,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded( flex: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: GestureDetector( onTap: () async {
                                        await launchUrl(Uri.parse("https://twitter.com/Egydose"), mode: LaunchMode.externalApplication);
                                      },
                                        child: Image.asset(
                                          "assets/images/twitter_logo.png", scale: 1.5,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded( flex: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: GestureDetector( onTap: () async {
                                        await launchUrl(Uri.parse("https://t.me/egydose"), mode: LaunchMode.externalApplication);
                                      },
                                        child: Image.asset(
                                          "assets/images/telegram_logo.png",
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded( flex: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.all(12),
                                      child: GestureDetector( onTap: () async {
                                        await launchUrl(Uri.parse("https://www.instagram.com/egydose/"), mode: LaunchMode.externalApplication);
                                      },
                                        child: Image.asset(
                                          "assets/images/instagram_logo.png",
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
        bottomSheet:
        SizedBox(height: bannerHeight,
          child: Center(child: UnityBannerAd( key: bannerKey,
            placementId: widget.unityBannerID,
            onShown: (placementId) {
            setState(() {
              bannerHeight = 60;
            });
              Future.delayed(const Duration(seconds: 1), () {
                if (Platform.isIOS) {
                  final RenderBox? renderBox = bannerKey.currentContext?.findRenderObject() as RenderBox?;
                  setState(() {
                    bannerHeight = renderBox!.size.height + MediaQuery.of(context).padding.bottom + 30;
                  });
                }
              });
            },
            onFailed: (placementId, error, message)  {
              setState(() {
                bannerHeight = 0;
              });
            },
          ),),));
  }

  void help(String title, String details) {
    AlertDialog detailsDiag = AlertDialog(
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(details),
          ],
        ),
      ),
      actions: [
        TextButton(
          child: const Text(
            'Close',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ],
    );
    showDialog(context: context, builder: (BuildContext context) => detailsDiag);
  }

}