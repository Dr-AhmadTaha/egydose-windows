
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter_paypal/flutter_paypal.dart';
import 'package:url_launcher/url_launcher.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({super.key, required this.email});
  final String email;

  @override
  State<PaymentPage> createState() => PaymentPageState();
}

class PaymentPageState extends State<PaymentPage> {
  String egyPrice = "500";
  String dollarPrice = "12";
  bool payPalAvailable = true;
  Color? blackWhiteBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[900] : Colors.grey[200];}

  @override
  void initState() {
    super.initState();
    firestorePayment();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      child: Scaffold(backgroundColor: blackWhiteBackground(context),
      appBar: AppBar(
        title: const Text("Payment"),

      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(padding: const EdgeInsets.only(top: 8, bottom: 8, left: 4, right: 4),
              margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4, top: 4),
              color: blackWhiteBackground(context),
              child: Column(
                children: [
                  const Text("Unlocking full version will be associated with this account:",
                    style: TextStyle(
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,),
                  Text(widget.email,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                    textAlign: TextAlign.center,),
                  const Text("even if you changed the device, reinstall the app or after update\n",
                    style: TextStyle(
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,),
                  const Text("if you would like to choose another email, go back and change it from the side menu in main page\n",
                    style: TextStyle(
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,),
                  const Text("-Payment is only once in life\n",
                    style: TextStyle(
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,),
                  Text("-Payment for full version in android is the same in all android devices and Windows with the same Gmail, and don't include other operating systems as iPhones",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.red[300],
                    ),
                    textAlign: TextAlign.center,),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              height: null,
              padding: const EdgeInsets.all(4),
              child: const Text(
                'Full Version Features:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              width: double.infinity,
              height: null,
              padding: const EdgeInsets.all(4),
              child: const Text(
                '-permanent access to injections\n-remove all ads\n-search drugs by indication\n-use the favorite list',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
            ),
            const SizedBox(height: 20,),
            Visibility(visible: payPalAvailable,
              child: GestureDetector(onTap: ()  {
                if (widget.email.isNotEmpty) {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) => UsePaypal(
                        // sandboxMode: true,
                          clientId: "Abbp57oKSidjaG6sGBm2jAYtbQ6n2lrBUQzxFhu8RvnkEIDugjBTn4rza_zQM9P7G0dEmLPXmFTlAbWt",
                          secretKey: "EPoLcZvZ08ChpCE8qe8Ec0lUmwdX5b2ld2iLymg7ApXehOA2bfbWyHrv6_vr7IkDPklNl1CPqFROdRt8",
                          returnURL: "https://egydose.com/payment-status-success/",
                          cancelURL: "https://egydose.com/payment-status-failed/",
                          transactions: [
                            {
                              "amount": {
                                "total": dollarPrice,
                                "currency": "USD",
                                "details": {
                                  "subtotal": dollarPrice,
                                  "shipping": '0',
                                  "shipping_discount": 0
                                }
                              },
                              "description":
                              "unlock all categories, remove ads, use favorite list, search by indication",
                              // "payment_options": {
                              //   "allowed_payment_method":
                              //       "INSTANT_FUNDING_SOURCE"
                              // },
                              "item_list": {
                                "items": [
                                  {
                                    "name": "Egydose full version",
                                    "quantity": 1,
                                    "price": dollarPrice,
                                    "currency": "USD"
                                  }
                                ],

                              }
                            }
                          ],
                          note: "keep the email sent to you after payment",
                          onSuccess: (Map params) async {
                            BotToast.showText(text: "success");
                            firestoreAdd();
                          },
                          onError: (error) {
                            BotToast.showText(text: "error");
                          },
                          onCancel: (params) {
                            BotToast.showText(text: "cancelled");
                          }),
                    ),
                  );
                }
                else {
                  BotToast.showText(text: "Email not identified yet");
                }
              },
                child: Container(
                  margin: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.green[600],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    "Pay $dollarPrice\$ with PayPal",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            GestureDetector(onTap: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text("Contact us"),
                    content: const Text("تواصل معنا لاتمام عملية الدفع باستخدام فودافون كاش او اي محفظة الكترونية او انستاباي"
                        "\n"
                        "التفعيل مدى الحياة وهيكون مرتبط بالجيميل اللي سجلت بيه عشان لو غيرت التلفون بعدين او مسحته ونزلته تانى او بعد التحديثات",
                      textAlign: TextAlign.center,),
                    actions: <Widget>[
                      TextButton(
                        child: const Text("Contact by messenger (recommended)"),
                        onPressed: () {
                          Navigator.of(context).pop();
                          launchUrl(Uri.parse("http://m.me/egydosecalc"), mode: LaunchMode.externalApplication);
                        },
                      ),
                      TextButton(
                        child: const Text("Contact by Gmail"),
                        onPressed: () async {
                          Navigator.of(context).pop();
                          await launchUrl(Uri.parse("mailto:medo122008@gmail.com"), mode: LaunchMode.externalApplication);
                        },
                      ),
                    ],
                  );
                },
              );
            },
              child: Container(
                margin: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Colors.blueAccent[700],
                  borderRadius: BorderRadius.circular(20),
                ),
                alignment: Alignment.center,
                padding: const EdgeInsets.all(8),
                child: Column(
                  children: [
                    Text(
                      "دفع $egyPrice جنيه بالمحافظ الالكترونية أو انستاباي",
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),),
    //     onPopInvoked: (didPop) async {
    //
    // }
    );
  }

  Future<void> firestoreAdd() async {
    final docSnapshotA = await FirebaseFirestore.instance.collection('clctn_egydose').doc('docAuto1').get();

    try {
      if (docSnapshotA.exists) {
        List<dynamic> em1 = docSnapshotA.get('list');
        if (em1.length < 4000) {
          FirebaseFirestore.instance.collection('clctn_egydose').doc('docAuto1').update({'list': FieldValue.arrayUnion([widget.email])});
        }
        else {
          FirebaseFirestore.instance.collection('clctn_egydose').doc('docAuto2').update({'list': FieldValue.arrayUnion([widget.email])});
        }
        paypalDiag();
      }
    } catch (e) {
      BotToast.showText(text: 'error');
    }
  }

  Future<void> firestorePayment() async {
    try {
      final payData = await FirebaseFirestore.instance.collection('payment').doc('data').get();
      if (payData.exists) {
        setState(() {
          payPalAvailable = payData.get("paypal");
          egyPrice = payData.get("egypt");
          dollarPrice = payData.get("dollar");
        });
      }
    }
    catch (error) {
      BotToast.showText(text: "error");
    }

  }

  void paypalDiag (){
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Success"),
          content: const Text("Unlocked full version, restart the app to see the result"),
          actions: <Widget>[
            TextButton(
              child: const Text("ok"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

}


