import 'dart:io';

import 'package:egydosecalcfree/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';

class CalculatorPage extends StatefulWidget {

  const CalculatorPage({super.key, required this.calc, required this.returnedCrcl, required this.premium, required this.unityBannerID});
  final String calc;
  final String returnedCrcl;
  final String premium;
  final String unityBannerID;

  @override
  State<CalculatorPage> createState() => CalculatorPageState();
}

class CalculatorPageState extends State<CalculatorPage> {

  bool mainV = true;
  bool renalAdultV = false;
  bool renalChildV = false;
  bool hepaticV = false;
  bool weightV = false;
  bool dropRateV = false;
  String renalAdultResult = '';
  String renalChildResult = '';
  String hepaticResult = 'Result:   Class A';
  String dropRateResult = '';
  Color hepaticColor = Colors.green;
  int totalBilirubinValue = 1;
  int serumAlbuminValue = 1;
  int inrValue = 1;
  int ascitesValue = 1;
  int encephalopathyValue = 1;
  FocusNode kilogramFocus = FocusNode();
  FocusNode poundFocus = FocusNode();
  final TextEditingController kilogramController = TextEditingController();
  final TextEditingController poundController = TextEditingController();
  final TextEditingController renalAdultAgeController = TextEditingController();
  final TextEditingController renalAdultWeightController = TextEditingController();
  final TextEditingController renalAdultCreatinineController = TextEditingController();
  final TextEditingController renalChildrenAgeController = TextEditingController();
  final TextEditingController renalChildrenHeightController = TextEditingController();
  final TextEditingController renalChildrenCreatinineController = TextEditingController();
  final TextEditingController dropVolumeController = TextEditingController();
  final TextEditingController dropDurationController = TextEditingController();
  final TextEditingController dropFactorController = TextEditingController();
  String adultMeasureRadio = 'mg/dL';
  String childrenMeasureRadio = 'mg/dL';
  String adultGenderRadio = 'Male';
  String childrenGenderRadio = 'Male';
  double crclAdultResult = 0;
  double crclChildrenResult = 0;
  FocusNode adultCalcFocus = FocusNode();
  FocusNode childrenCalcFocus = FocusNode();
  FocusNode dropFocus = FocusNode();
  int volumeNum = 0;
  int durationNum = 0;
  int factorNum = 15;
  String lastCalc = '';
  double bannerHeight = 0;
  final GlobalKey bannerKey = GlobalKey();
  Color? denseBlackWhiteBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[900] : Colors.grey[50];}
  Color? greenBackColor(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("233d27") : Colors.green[50];}
  Color? yellowBackColor(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? HexColor.fromHex("403c1e") : Colors.yellow[100];}
  Color? blackWhiteText(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.white : Colors.black;}
  Color? blackWhiteBackground(BuildContext context) {final theme = Theme.of(context); return theme.brightness == Brightness.dark ? Colors.grey[700] : Colors.grey[200];}


  @override
  void initState() {
    super.initState();
    if (widget.calc == 'main') {mainV = true; weightV = false; renalChildV = false; renalAdultV = false; hepaticV = false; dropRateV = false;}
    if (widget.calc == 'adult renal') {mainV = false; weightV = false; renalChildV = false; renalAdultV = true; hepaticV = false; dropRateV = false;}
    if (widget.calc == 'children renal') {mainV = false; weightV = false; renalChildV = true; renalAdultV = false; hepaticV = false; dropRateV = false;}
    if (widget.calc == 'hepatic') {mainV = false; weightV = false; renalChildV = false; renalAdultV = false; hepaticV = true; dropRateV = false;}
    if (widget.calc == 'drop') {mainV = false; weightV = false; renalChildV = false; renalAdultV = false; hepaticV = false; dropRateV = true;}
    if (widget.premium != 'yes') {}
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) {
          return;
        }
        if (mainV == false && widget.calc == 'main') {
          setState(() {
            mainV = true; weightV = false; renalChildV = false; renalAdultV = false; hepaticV = false; dropRateV = false;
          });
        }
        else {
          if (lastCalc == 'child renal') {Navigator.pop(context, crclChildrenResult.toStringAsFixed(1)); }
          else if (lastCalc == 'adult renal') {Navigator.pop(context, crclAdultResult.toStringAsFixed(1)); }
          else {
            Navigator.pop(context);
          }
        }
      },
      child: Scaffold(backgroundColor: denseBlackWhiteBackground(context),
        appBar: AppBar(
          title: const Text('Calculators'),
        ),
        body: Container(padding: EdgeInsets.only(left: 0, right: 0,top: 0, bottom: bannerHeight),
          // decoration: const BoxDecoration(
          //   image: DecorationImage(
          //     image: AssetImage('assets/images/yyy.jpg'),
          //     fit: BoxFit.cover,
          //   ),
          // ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Visibility(visible: mainV,
                  child: Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.all(15),
                        width: double.maxFinite,
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              mainV = false; renalAdultV = false; renalChildV = false; hepaticV = false; weightV = true; dropRateV = false;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: greenBackColor(context),
                            textStyle: const TextStyle(fontWeight: FontWeight.bold),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                          ),
                          child: Text('Weight Converter', style: TextStyle(color: blackWhiteText(context)),),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.all(15),
                        width: double.maxFinite,
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              mainV = false; renalAdultV = true; renalChildV = false; hepaticV = false; weightV = false; dropRateV = false;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: greenBackColor(context),
                            textStyle: const TextStyle(fontWeight: FontWeight.bold),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                          ),
                          child: Text('Creatinine Clearance Calculator for adults', style: TextStyle(color: blackWhiteText(context)),),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.all(15),
                        width: double.maxFinite,
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              mainV = false; renalAdultV = false; renalChildV = true; hepaticV = false; weightV = false; dropRateV = false;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: greenBackColor(context),
                            textStyle: const TextStyle(fontWeight: FontWeight.bold),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                          ),
                          child: Text('Creatinine Clearance Calculator for children', style: TextStyle(color: blackWhiteText(context)),),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.all(15),
                        width: double.maxFinite,
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              mainV = false; renalAdultV = false; renalChildV = false; hepaticV = true; weightV = false; dropRateV = false;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: greenBackColor(context),
                            textStyle: const TextStyle(fontWeight: FontWeight.bold, ),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                          ),
                          child: Text('Child Pugh Score Calculator', style: TextStyle(color: blackWhiteText(context)),),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.all(15),
                        width: double.maxFinite,
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              mainV = false; renalAdultV = false; renalChildV = false; hepaticV = false; weightV = false; dropRateV = true;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: greenBackColor(context),
                            textStyle: const TextStyle(fontWeight: FontWeight.bold, ),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                          ),
                          child: Text('Infusion Drop Rate Calculator', style: TextStyle(color: blackWhiteText(context)),),
                        ),
                      ),
                    ],
                  ),
                ),
                Visibility(visible: renalAdultV,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(color: blackWhiteBackground(context),
                        width: double.infinity,
                        padding: const EdgeInsets.only(top: 12, bottom: 12, left: 2, right: 2),
                        margin: const EdgeInsets.only(bottom: 22),
                        child: Column(children: [
                          Text(
                            'Creatinine Clearance Calculator for adults',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: blackWhiteText(context),
                            ),
                          ),
                          const Text(
                            '(Cockroft-Gault Formula)',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Age in years:    ',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: blackWhiteBackground(context),
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: Colors.grey, width: 1,),
                                ),
                                child: TextField( textAlign: TextAlign.center,
                                  controller: renalAdultAgeController,
                                  decoration: const InputDecoration(
                                    hintText: "enter age",
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.all(4),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  style: TextStyle(color: blackWhiteText(context)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Weight in kg:    ',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: blackWhiteBackground(context),
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: Colors.grey, width: 1,),
                                ),
                                child: TextField( textAlign: TextAlign.center,
                                  controller: renalAdultWeightController,
                                  decoration: const InputDecoration(
                                    hintText: "enter weight",
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.all(4),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  style: TextStyle(color: blackWhiteText(context)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Expanded(
                                  child: Text(
                                    'Serum Creatinine:    ',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: blackWhiteBackground(context),
                                      borderRadius: BorderRadius.circular(50),
                                      border: Border.all(color: Colors.grey, width: 1,),
                                    ),
                                    child: TextField( textAlign: TextAlign.center,
                                      controller: renalAdultCreatinineController,
                                      decoration: const InputDecoration(
                                        hintText: "enter value",
                                        hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.all(4),
                                      ),
                                      inputFormatters: [
                                        FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                      ],
                                      keyboardType: TextInputType.number,
                                      style: TextStyle(color: blackWhiteText(context)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Radio(
                                  value: 'mg/dL',
                                  groupValue: adultMeasureRadio,
                                  onChanged: (value) {
                                    setState(() {
                                      adultMeasureRadio = value.toString();
                                    });
                                  },
                                ),
                                GestureDetector(onTap: () {
                                  setState(() {
                                    adultMeasureRadio = 'mg/dL';
                                  });
                                },
                                    child: const Text('mg/dL')),
                                Radio(
                                  value: 'μmol/L',
                                  groupValue: adultMeasureRadio,
                                  onChanged: (value) {
                                    setState(() {
                                      adultMeasureRadio = value.toString();
                                    });
                                  },
                                ),
                                GestureDetector(onTap: () {
                                  setState(() {
                                    adultMeasureRadio = 'μmol/L';
                                  });
                                },
                                    child: const Text('μmol/L')),
                              ],
                            )
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(flex: 1,
                              child: Text(
                                'Gender:    ',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(flex: 2,
                              child: Center(
                                child: Row(
                                  children: [
                                    Radio(
                                      value: 'Male',
                                      groupValue: adultGenderRadio,
                                      onChanged: (value) {
                                        setState(() {
                                          adultGenderRadio = value.toString();
                                        });
                                      },
                                    ),
                                    GestureDetector(onTap: () {
                                      setState(() {
                                        adultGenderRadio = 'Male';
                                      });
                                    },
                                      child: const Text(
                                        'Male',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                    Radio(
                                      value: 'Female',
                                      groupValue: adultGenderRadio,
                                      onChanged: (value) {
                                        setState(() {
                                          adultGenderRadio = value.toString();
                                        });
                                      },
                                    ),
                                    GestureDetector(onTap: () {
                                      setState(() {
                                        adultGenderRadio = 'Female';
                                      });
                                    },
                                      child: const Text(
                                        'Female',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(focusNode: adultCalcFocus,
                        style: ElevatedButton.styleFrom(
                          textStyle: const TextStyle(fontSize: 18),
                          backgroundColor: blackWhiteBackground(context),
                          elevation: 6,
                        ),
                        onPressed: () {
                          try {
                            if (renalAdultAgeController.text.isEmpty || renalAdultWeightController.text.isEmpty || renalAdultCreatinineController.text.isEmpty) {
                              BotToast.showText(text: "Please fill missing data");
                            } else {
                              if (adultMeasureRadio == 'mg/dL' && adultGenderRadio == 'Male') {
                                crclAdultResult = ((140 - double.parse(renalAdultAgeController.text)) *
                                    double.parse(renalAdultWeightController.text)) /
                                    (double.parse(renalAdultCreatinineController.text) * 72);
                              }

                              if (adultMeasureRadio == 'mg/dL' && adultGenderRadio == 'Female') {
                                crclAdultResult = ((140 - double.parse(renalAdultAgeController.text)) *
                                    0.85 *
                                    double.parse(renalAdultWeightController.text)) /
                                    (double.parse(renalAdultCreatinineController.text) * 72);
                              }

                              if (adultMeasureRadio == 'μmol/L' && adultGenderRadio == 'Male') {
                                crclAdultResult = ((140 - double.parse(renalAdultAgeController.text)) *
                                    double.parse(renalAdultWeightController.text)) /
                                    (double.parse(renalAdultCreatinineController.text) * 72 * 0.0113);
                              }

                              if (adultMeasureRadio == 'μmol/L' && adultGenderRadio == 'Female') {
                                crclAdultResult = ((140 - double.parse(renalAdultAgeController.text)) *
                                    0.85 *
                                    double.parse(renalAdultWeightController.text)) /
                                    (double.parse(renalAdultCreatinineController.text) * 72 * 0.0113);
                              }

                              setState(() {
                                renalAdultResult = "CrCl =   ${crclAdultResult.toStringAsFixed(1)}  ml/min";
                              });
                              adultCalcFocus.requestFocus();
                              lastCalc = "adult renal";
                            }
                          }
                          catch (error) {
                            BotToast.showText(text: "Please enter valid data");
                          }
                        },
                        child: Text(
                          'Calculate',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic,
                            color: blackWhiteText(context),
                          ),
                        ),
                      ),
                      Container(alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: blackWhiteBackground(context),
                        ),
                        width: double.infinity,
                        margin: const EdgeInsets.all(30),
                        padding: const EdgeInsets.all(15),
                        child: Text(renalAdultResult,
                          style: TextStyle(
                            fontSize: 24,
                            color: blackWhiteText(context),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                Visibility(visible: renalChildV,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(color: blackWhiteBackground(context),
                        width: double.infinity,
                        padding: const EdgeInsets.only(top: 12, bottom: 12, left: 2, right: 2),
                        margin: const EdgeInsets.only(bottom: 22),
                        child: Column(children: [
                          Text(
                            'Creatinine Clearance Calculator for children',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: blackWhiteText(context),
                            ),
                          ),
                          const Text('(Original Schwartz method)',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Age in years:    ',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container( 
                                decoration: BoxDecoration(
                                color: blackWhiteBackground(context),
                                borderRadius: BorderRadius.circular(50),
                                border: Border.all(color: Colors.grey, width: 1,),
                              ),
                                child: TextField( textAlign: TextAlign.center,
                                  controller: renalChildrenAgeController,
                                  decoration: const InputDecoration(
                                    hintText: "enter age",
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.all(4),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  style: TextStyle(color: blackWhiteText(context)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text('Height in cm:    ',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: blackWhiteBackground(context),
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: Colors.grey, width: 1,),
                                ),
                                child: TextField( textAlign: TextAlign.center,
                                  controller: renalChildrenHeightController,
                                  decoration: const InputDecoration(
                                    hintText: "enter height",
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.all(4),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  style: TextStyle(color: blackWhiteText(context)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Expanded(
                                  child: Text(
                                    'Serum Creatinine:    ',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: blackWhiteBackground(context),
                                      borderRadius: BorderRadius.circular(50),
                                      border: Border.all(color: Colors.grey, width: 1,),
                                    ),
                                    child: TextField( textAlign: TextAlign.center,
                                      controller: renalChildrenCreatinineController,
                                      decoration: const InputDecoration(
                                        hintText: "enter value",
                                        hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.all(4),
                                      ),
                                      inputFormatters: [
                                        FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                      ],
                                      keyboardType: TextInputType.number,
                                      style: TextStyle(color: blackWhiteText(context)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Radio(
                                  value: 'mg/dL',
                                  groupValue: childrenMeasureRadio,
                                  onChanged: (value) {
                                    setState(() {
                                      childrenMeasureRadio = value.toString();
                                    });
                                  },
                                ),
                                GestureDetector(onTap: () {
                                  setState(() {
                                    childrenMeasureRadio = 'mg/dL';
                                  });
                                },
                                    child: const Text('mg/dL')),
                                Radio(
                                  value: 'μmol/L',
                                  groupValue: childrenMeasureRadio,
                                  onChanged: (value) {
                                    setState(() {
                                      childrenMeasureRadio = value.toString();
                                    });
                                  },
                                ),
                                GestureDetector(onTap: () {
                                  setState(() {
                                    childrenMeasureRadio = 'μmol/L';
                                  });
                                },
                                    child: const Text('μmol/L')),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(flex: 1,
                              child: Text(
                                'Gender:    ',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(flex: 2,
                              child: Center(
                                child: Row(
                                  children: [
                                    Radio(
                                      value: 'Male',
                                      groupValue: childrenGenderRadio,
                                      onChanged: (value) {
                                        setState(() {
                                          childrenGenderRadio = value.toString();
                                        });
                                      },
                                    ),
                                    GestureDetector(onTap: () {
                                      setState(() {
                                        childrenGenderRadio = 'Male';
                                      });
                                    },
                                      child: const Text(
                                        'Male',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                    Radio(
                                      value: 'Female',
                                      groupValue: childrenGenderRadio,
                                      onChanged: (value) {
                                        setState(() {
                                          childrenGenderRadio = value.toString();
                                        });
                                      },
                                    ),
                                    GestureDetector(onTap: () {
                                      setState(() {
                                        childrenGenderRadio = 'Female';
                                      });
                                    },
                                      child: const Text(
                                        'Female',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(focusNode: childrenCalcFocus,
                        style: ElevatedButton.styleFrom(
                          textStyle: const TextStyle(fontSize: 18),
                          backgroundColor: blackWhiteBackground(context),
                          elevation: 6,
                        ),
                        onPressed: () {
                          try {
                            if (renalChildrenAgeController.text.isEmpty || renalChildrenHeightController.text.isEmpty || renalChildrenCreatinineController.text.isEmpty) {
                              BotToast.showText(text: "Please fill missing data");
                            } else {
                              if (childrenMeasureRadio == 'mg/dL') {
                                if (double.parse(renalChildrenAgeController.text) < 1) {
                                  crclChildrenResult = (0.45 * double.parse(renalChildrenHeightController.text) /
                                      double.parse(renalChildrenCreatinineController.text));
                                } else {
                                  if (double.parse(renalChildrenAgeController.text) < 13) {
                                    crclChildrenResult = (0.55 * double.parse(renalChildrenHeightController.text) /
                                        double.parse(renalChildrenCreatinineController.text));
                                  } else {
                                    if (childrenGenderRadio == "Male") {
                                      crclChildrenResult = (0.7 * double.parse(renalChildrenHeightController.text) /
                                          double.parse(renalChildrenCreatinineController.text));
                                    } else {
                                      crclChildrenResult = (0.55 * double.parse(renalChildrenHeightController.text) /
                                          double.parse(renalChildrenCreatinineController.text));
                                    }
                                  }
                                }
                              } else {
                                if (double.parse(renalChildrenAgeController.text) < 1) {
                                  crclChildrenResult = (0.45 * double.parse(renalChildrenHeightController.text)) /
                                      (double.parse(renalChildrenCreatinineController.text) * 0.0113);
                                } else {
                                  if (double.parse(renalChildrenAgeController.text) < 13) {
                                    crclChildrenResult = (0.55 * double.parse(renalChildrenHeightController.text)) /
                                        (double.parse(renalChildrenCreatinineController.text) * 0.0113);
                                  } else {
                                    if (childrenGenderRadio == 'Male') {
                                      crclChildrenResult = (0.7 * double.parse(renalChildrenHeightController.text)) /
                                          (double.parse(renalChildrenCreatinineController.text) * 0.0113);
                                    } else {
                                      crclChildrenResult = (0.55 * double.parse(renalChildrenHeightController.text)) /
                                          (double.parse(renalChildrenCreatinineController.text) * 0.0113);
                                    }
                                  }
                                }
                              }

                              setState(() {
                                renalChildResult = "CrCl   = ${crclChildrenResult.toStringAsFixed(1)}  ml/min";
                              });
                              childrenCalcFocus.requestFocus();
                              lastCalc = "child renal";
                            }
                          }
                          catch (error) {
                            BotToast.showText(text: "Please enter valid data");
                          }
                        },
                        child: Text(
                          'Calculate',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic,
                            color: blackWhiteText(context),
                          ),
                        ),
                      ),
                      Container(alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: blackWhiteBackground(context),
                        ),
                        width: double.infinity,
                        margin: const EdgeInsets.all(30),
                        padding: const EdgeInsets.all(15),
                        child: Text(renalChildResult,
                          style: TextStyle(
                            fontSize: 24,
                            color: blackWhiteText(context),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                Visibility(visible: hepaticV,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(color: blackWhiteBackground(context),
                        width: double.infinity,
                        padding: const EdgeInsets.only(top: 12, bottom: 12, left: 2, right: 2),
                        margin: const EdgeInsets.only(bottom: 22),
                        child: Text(
                          'Child-Pugh Score',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: blackWhiteText(context),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: greenBackColor(context),
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Total Bilirubin:',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 35,
                              child: RadioListTile(
                                title: const Text('<2 mg/dL (<34.2 μmol/L)'),
                                value: 1,
                                groupValue: totalBilirubinValue,
                                onChanged: (value) {
                                  setState(() {
                                    totalBilirubinValue = value!;
                                    calculateChildPughScore ();
                                  });
                                },
                              ),
                            ),
                            SizedBox(height: 35,
                              child: RadioListTile(
                                title: const Text('2-3 mg/dL (34.2-51.3 μmol/L)'),
                                value: 2,
                                groupValue: totalBilirubinValue,
                                onChanged: (value) {
                                  setState(() {
                                    totalBilirubinValue = value!;
                                    calculateChildPughScore ();
                                  });
                                },
                              ),
                            ),
                            SizedBox(height: 40,
                              child: RadioListTile(
                                title: const Text('>3 mg/dL (>51.3 μmol/L)'),
                                value: 3,
                                groupValue: totalBilirubinValue,
                                onChanged: (value) {
                                  setState(() {
                                    totalBilirubinValue = value!;
                                    calculateChildPughScore ();
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: greenBackColor(context),
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Serum Albumin:',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 35,
                              child: RadioListTile(
                                title: const Text('>3.5 g/dL (>35 g/L)'),
                                value: 1,
                                groupValue: serumAlbuminValue,
                                onChanged: (value) {
                                  setState(() {
                                    serumAlbuminValue = value!;
                                    calculateChildPughScore ();
                                  });
                                },
                              ),
                            ),
                            SizedBox(height: 35,
                              child: RadioListTile(
                                title: const Text('2.8-3.5 g/dL (28-35 g/L)'),
                                value: 2,
                                groupValue: serumAlbuminValue,
                                onChanged: (value) {
                                  setState(() {
                                    serumAlbuminValue = value!;
                                    calculateChildPughScore ();
                                  });
                                },
                              ),
                            ),
                            SizedBox(height: 40,
                              child: RadioListTile(
                                title: const Text('<2.8 g/dL (<28 g/L)'),
                                value: 3,
                                groupValue: serumAlbuminValue,
                                onChanged: (value) {
                                  setState(() {
                                    serumAlbuminValue = value!;
                                    calculateChildPughScore ();
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: greenBackColor(context),
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'INR:',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      inrValue = 1;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 1,
                                          groupValue: inrValue,
                                          onChanged: (value) {
                                            setState(() {
                                              inrValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('<1.7'),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      inrValue = 2;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 2,
                                          groupValue: inrValue,
                                          onChanged: (value) {
                                            setState(() {
                                              inrValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('1.7-2.3'),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      inrValue = 3;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 3,
                                          groupValue: inrValue,
                                          onChanged: (value) {
                                            setState(() {
                                              inrValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('>2.3'),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: greenBackColor(context),
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Ascites:',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      ascitesValue = 1;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 1,
                                          groupValue: ascitesValue,
                                          onChanged: (value) {
                                            setState(() {
                                              ascitesValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('Absent'),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      ascitesValue = 2;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 2,
                                          groupValue: ascitesValue,
                                          onChanged: (value) {
                                            setState(() {
                                              ascitesValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('Slight'),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      ascitesValue = 3;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 3,
                                          groupValue: ascitesValue,
                                          onChanged: (value) {
                                            setState(() {
                                              ascitesValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Flexible(child: Text('Moderate or large',)),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: greenBackColor(context),
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Encephalopathy:',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      encephalopathyValue = 1;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 1,
                                          groupValue: encephalopathyValue,
                                          onChanged: (value) {
                                            setState(() {
                                              encephalopathyValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('None'),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      encephalopathyValue = 2;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 2,
                                          groupValue: encephalopathyValue,
                                          onChanged: (value) {
                                            setState(() {
                                              encephalopathyValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('Grade 1-2'),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(onTap: () {
                                    setState(() {
                                      encephalopathyValue = 3;
                                      calculateChildPughScore ();
                                    });
                                  },
                                    child: Row(mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          value: 3,
                                          groupValue: encephalopathyValue,
                                          onChanged: (value) {
                                            setState(() {
                                              encephalopathyValue = value!;
                                              calculateChildPughScore ();
                                            });
                                          },
                                        ),
                                        const Text('Grade 3-4'),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: blackWhiteBackground(context),
                        ),
                        width: double.infinity,
                        margin: const EdgeInsets.all(20),
                        padding: const EdgeInsets.all(15),
                        child: Text(hepaticResult,
                          style: TextStyle(
                            fontSize: 24,
                            color: hepaticColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Visibility(visible: weightV,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(color: blackWhiteBackground(context),
                        width: double.infinity,
                        padding: const EdgeInsets.only(top: 12, bottom: 12, left: 2, right: 2),
                        margin: const EdgeInsets.only(bottom: 22),
                        child: Text(
                          'Weight Converter',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: blackWhiteText(context),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              color: blackWhiteBackground(context),
                              borderRadius: BorderRadius.circular(50),
                              border: Border.all(color: Colors.grey, width: 1,),
                            ),
                            width: 100,
                            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            child: TextField(textAlign: TextAlign.center,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.all(4),
                              ),
                              focusNode: kilogramFocus,
                              controller: kilogramController,
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                              ],
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              onChanged: (value) {
                                if (kilogramFocus.hasFocus) {
                                  if (kilogramController.text.isEmpty) {
                                    poundController.text = '';
                                  }
                                  else {
                                    poundController.text = (double.parse(kilogramController.text) * 2.20462262185).toStringAsFixed(2);
                                  }
                                }
                              },
                              style: TextStyle(color: blackWhiteText(context),),
                            ),
                          ),
                          const Text('kilogram', style: TextStyle(fontSize: 18),),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              color: blackWhiteBackground(context),
                              borderRadius: BorderRadius.circular(50),
                              border: Border.all(color: Colors.grey, width: 1,),
                            ),
                            width: 100,
                            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            child: TextField(textAlign: TextAlign.center,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.all(4),
                              ),
                              focusNode: poundFocus,
                              controller: poundController,
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                              ],
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              onChanged: (value) {
                                if (poundFocus.hasFocus) {
                                  if (poundController.text.isEmpty) {
                                    kilogramController.text = '';
                                  }
                                  else {
                                    kilogramController.text = (double.parse(poundController.text) / 2.20462262185).toStringAsFixed(2);
                                  }
                                }
                              },
                              style: TextStyle(color: blackWhiteText(context),),
                            ),
                          ),
                          const Text('pounds  ', style: TextStyle(fontSize: 18),),
                        ],
                      ),
                      Container(margin: const EdgeInsets.only(top: 32),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            textStyle: const TextStyle(fontSize: 18),
                            backgroundColor: blackWhiteBackground(context),
                            elevation: 6,
                          ),
                          onPressed: () {
                            kilogramController.text = '';
                            poundController.text = '';
                          },
                          child: Text(
                            'Clear',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.italic,
                              color: blackWhiteText(context),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),),
                Visibility(visible: dropRateV,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(color: blackWhiteBackground(context),
                        width: double.infinity,
                        padding: const EdgeInsets.only(top: 12, bottom: 12, left: 2, right: 2),
                        margin: const EdgeInsets.only(bottom: 22),
                        child: Column(children: [
                          Text(
                            'Infusion Drop Rate Calculator',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: blackWhiteText(context),
                            ),
                          ),
                        ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Fluid Volume (in ml):',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: blackWhiteBackground(context),
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: Colors.grey, width: 1,),
                                ),
                                child: TextField( textAlign: TextAlign.center,
                                  controller: dropVolumeController,
                                  decoration: const InputDecoration(
                                    hintText: "required",
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.all(4),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  style: TextStyle(color: blackWhiteText(context)),
                                  onChanged: (value) {
                                    if (value == '' || value == '.') {
                                      volumeNum = 0;
                                    }
                                    else {
                                      volumeNum = int.parse(value);
                                    }
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text('Duration (in minutes):',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: blackWhiteBackground(context),
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: Colors.grey, width: 1,),
                                ),
                                child: TextField( textAlign: TextAlign.center,
                                  controller: dropDurationController,
                                  decoration: const InputDecoration(
                                    hintText: "required",
                                    hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.all(4),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                  ],
                                  keyboardType: TextInputType.number,
                                  textInputAction: TextInputAction.next,
                                  style: TextStyle(color: blackWhiteText(context)),
                                  onChanged: (value) {
                                    if (value == '' || value == '.') {
                                      durationNum = 0;
                                    }
                                    else {
                                      durationNum = int.parse(value);
                                    }
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 16, left: 4, right: 4),
                        color: yellowBackColor(context),
                        padding: const EdgeInsets.only(right: 4, left: 4),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Expanded(
                                  child: Text(
                                    'Drop Factor:     ',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: blackWhiteBackground(context),
                                      borderRadius: BorderRadius.circular(50),
                                      border: Border.all(color: Colors.grey, width: 1,),
                                    ),
                                    child: TextField( textAlign: TextAlign.center,
                                      controller: dropFactorController,
                                      decoration: const InputDecoration(
                                        hintText: "default 15",
                                        hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal),
                                        border: InputBorder.none,
                                        contentPadding: EdgeInsets.all(4),
                                      ),
                                      inputFormatters: [
                                        FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,5}')),
                                      ],
                                      keyboardType: TextInputType.number,
                                      style: TextStyle(color: blackWhiteText(context)),
                                      onChanged: (value) {
                                        if (value == '' || value == '.') {
                                          factorNum = 15;
                                        }
                                        else {
                                          factorNum = int.parse(value);
                                        }
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(focusNode: dropFocus,
                        style: ElevatedButton.styleFrom(
                          textStyle: const TextStyle(fontSize: 18),
                          backgroundColor: blackWhiteBackground(context),
                          elevation: 6,
                        ),
                        onPressed: () {
                          try {
                            if (dropVolumeController.text.isEmpty || dropDurationController.text.isEmpty) {
                              BotToast.showText(text: "please enter missing data");
                            }
                            else {
                              String rateMinutes = (volumeNum*factorNum~/durationNum).toStringAsFixed(0);
                              String rateSeconds = ((volumeNum*factorNum~/durationNum)/60).toStringAsFixed(0);
                              setState(() {
                                dropRateResult = "$rateMinutes drops / minute\nOR\n$rateSeconds drops / second";
                              });
                              dropFocus.requestFocus();
                            }
                          }
                          catch (error) {
                            BotToast.showText(text: "Please enter valid data");
                          }
                        },
                        child: Text(
                          'Calculate',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic,
                            color: blackWhiteText(context),
                          ),
                        ),
                      ),
                      Container(alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: blackWhiteBackground(context),
                        ),
                        width: double.infinity,
                        margin: const EdgeInsets.all(30),
                        padding: const EdgeInsets.all(8),
                        child: Text(dropRateResult,
                          style: TextStyle(
                            fontSize: 18,
                            color: blackWhiteText(context),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 0, horizontal: 8),
                        child: Text(
                          '-Enter total volume after dilution (if needed)\n-Drop factor is usually printed directly on the packaging of the IV tubing set. It is usually 10, 15 or 20 gtt/mL (60 gtt/ml in microdrip). if you leave it empty, it will be calculated as 15 by default',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        bottomSheet:
        SizedBox(height: bannerHeight,
          child: Center(child: UnityBannerAd(key: bannerKey,
            placementId: widget.unityBannerID,
            onShown: (placementId) {
              setState(() {
                bannerHeight = 60;
              });
              Future.delayed(const Duration(seconds: 1), () {
                if (Platform.isIOS) {
                  final RenderBox? renderBox = bannerKey.currentContext?.findRenderObject() as RenderBox?;
                  setState(() {
                    bannerHeight = renderBox!.size.height + MediaQuery.of(context).padding.bottom + 30;
                  });
                }
              });
            },
            onFailed: (placementId, error, message)  {
              setState(() {
                bannerHeight = 0;
              });
            },
          ),),)),
    );

  }

  void calculateChildPughScore () {
    int childPughScoreVar = totalBilirubinValue + serumAlbuminValue + inrValue + ascitesValue + encephalopathyValue;
    if (childPughScoreVar < 7) {
      hepaticResult = "Result:   Class A";
      hepaticColor = Colors.green;
    }
    else {
      if (childPughScoreVar < 10) {
        hepaticResult = "Result:   Class B";
        hepaticColor = Colors.orange[300]!;
      }
      else {
        hepaticResult = "Result:   Class C";
        hepaticColor = Colors.red;
      }
    }
  }
}